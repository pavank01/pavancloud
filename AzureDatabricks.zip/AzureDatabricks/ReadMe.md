# Azure Databricks ARM Template by Azure Product Team

## Table of Contents
[Overview](#overview)

[Logging](#logging)

[Parameters](#parameters)

[Example](#example)


## Overview
This ARM template will provision a premium Azure Databricks Workspace with VNet injection and no Public IP to comply with First American Standards.  For more information please see [Service Onboarding in the Azure One Note.](http://communities.spweb06.firstam.net/sites/ITOperations/Azure/_layouts/OneNote.aspx?id=%2Fsites%2FITOperations%2FAzure%2FOneNote%2FAzure&wd=target%28Service%20Onboarding.one%7CA9C72A57-C1F3-4DF6-8290-22EE6ED707E3%2FAzure%20DataBricks%7C0E89AE9A-953C-4196-B1CB-8B7BECDB2048%2F%29)  

It will also configure the Diagnostic Settings to send logs to Event Hub in accordance with Security Policy standards and TGB guidance.  **Do NOT build Azure Databricks manually, please use this ARM Template.**

## Logging
Azure Databricks workspaces require the logs to be sent to Event Hub.  Event Hubs are environment and region specific.  E.g. (Non-prod/West US 2)

For more information please see the <a href="http://communities.spweb06.firstam.net/sites/ITOperations/Azure/_layouts/OneNote.aspx?id=%2Fsites%2FITOperations%2FAzure%2FOneNote%2FAzure&wd=target%28User%20Guide.one%7C049A5AEF-4A94-4865-9160-C9CE15BB08BA%2FEnable%20Storage%20Account%20Diagnostic%20%28Azure%20Portal%5C%29%7C46051454-D256-4276-A74F-410BAEFF11C0%2F%29">One Note Page on Storage Account Diagnostics</a>.  The target Event Hubs and rules are the same for Azure Datbricks.

## Parameters
The following parameters are required to deploy the ARM Template.
* **workspaceName** - Name of the Databricks instance (See OneNote for Naming Standards)
* **managedResourceGroupName** - Azure Databricks will create another resource group and deploy cluster resources in it.  This managed Resource Group name must follow the naming convention or it will be denied by policy.  ***This is not the Resource Group that the workspace will be created in, this is an addtional Resource Group managed by Databricks.***
* **customVirtualNetworkId** - Both subnets for Azure Databricks must be created in the same VNet
* **customPublicSubnetName** - Subnet used for external communication.  Must be the same size as the private subnet.  Minimum Size /26
* **customPrivateSubnetName** - Subnet used for internal Databricks communication.  Must be the same size as the public subnet. Minimum Size /26
* **eventHubAuthorizationRuleId** - Full resource ID for Event Hub logging
* **eventHubName** - Namespace of the Event Hub
* **location** - Allowed locations are only West US 2 and East US, Databricks is not supported in West Central US

## Example
Below is an an example of how to create a databricks instance in Non-Prod West US 2 for DBSM. 
**You will need to modify the parameters to fit your own deployment.**

```powershell
$databricksVNET = Get-AzVirtualNetwork -ResourceGroupName DBSM-N-1-DBSM-RG-3 -Name DBSM-N-1-PaaS-VN-1

# Azure Databricks Environment Parameters
$databricksTemplateParameters = @{
    "workspaceName" = 'dbsmans1dbmldatabricks1'
    "managedResourceGroupName" = "DBSM-N-1-DBML-RG-2"
    "customVirtualNetworkId" = $databricksVNET.Id
    "customPublicSubnetName" = "S-10.65.212.0-23"
    "customPrivateSubnetName" = "S-10.65.214.0-23"
    "eventHubAuthorizationRuleId" = "/subscriptions/e63b08c3-d314-48d8-b10a-c58199bb78b1/resourceGroups/AZUR-P-1-SCES-RG-1/providers/Microsoft.EventHub/namespaces/AZUR-P-1-SCES-EH-2/authorizationrules/AzureActivityManagePolicy"
    "eventHubName" = "insights-operational-logs"
    "location" = 'WestUS2'
    }
$databricksDeploymentParameters = @{
    ResourceGroupName = "DBSM-N-1-DBML-RG-1"
    Name = 'DBSM-N-1-DBML-RG-1-Deployment'
    Mode = 'Incremental'
    TemplateFile = '.\Azure-Databricks-ARMTemplate.json'
    TemplateParameterObject = $databricksTemplateParameters 
    }

New-AzResourceGroupDeployment @databricksDeploymentParameters  -Verbose 
```