provider "azurerm" {
  skip_provider_registration = true
  features {}

  subscription_id = "2e060d5f-1619-4e6b-9834-0241677ac8a5"
}

module "kubernetes_cluster" {
  source = "git::https://facloud@dev.azure.com/facloud/AzureProduct-Modules/_git/kubernetes-cluster?ref=v1.0.0"

  resource_group_name         = "GREG-P-1-GREG-RG-6"
  aks_name                    = "GREG-P-1-GREG-KS-6"
  location                    = "westus2"

  aks_subnet_id               = "/subscriptions/2e060d5f-1619-4e6b-9834-0241677ac8a5/resourceGroups/GREG-P-1-GREG-RG-6/providers/Microsoft.Network/virtualNetworks/GREG-P-1-GREG-VN-6/subnets/S-10.1.0.0-24"
  ilb_subnet_id               = "/subscriptions/2e060d5f-1619-4e6b-9834-0241677ac8a5/resourceGroups/GREG-P-1-GREG-RG-6/providers/Microsoft.Network/virtualNetworks/GREG-P-1-GREG-VN-6/subnets/S-10.1.2.0-27"
  container_registry_id       = "/subscriptions/2e060d5f-1619-4e6b-9834-0241677ac8a5/resourcegroups/GREG-P-1-GREG-RG-6/providers/Microsoft.ContainerRegistry/registries/mt15gregacr6"

  vm_size                     = "Standard_D4_v3"
  enable_auto_scaling         = true
  enable_host_encryption      = false
  autoscale_max_count         = 2
  autoscale_min_count         = 1
  node_count                  = 1

  admin_ssh_key               =  tls_private_key.aks.public_key_openssh

  business_application_number = "ABC123"
  application_service_number  = "DEF456"
}

resource "tls_private_key" "aks" {
  algorithm = "RSA"
  rsa_bits  = "2048"
}