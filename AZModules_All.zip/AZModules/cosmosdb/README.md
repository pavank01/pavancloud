# FA Cosmos DB Module by Azure Product Team

## Table of Contents
[Introduction](#introduction)

## Introduction

This module is for creating [Azure CosmosDB Accounts](https://azure.microsoft.com/en-us/products/cosmos-db)

For a summary on the parameters that it requires, please view the `cosmosdb\variables.tf` file.

For a list of required Azure portal IP addresses please see [here](https://learn.microsoft.com/en-us/azure/cosmos-db/how-to-configure-firewall#allow-requests-from-the-azure-portal).

Example with required variables:
```terraform
module "cosmosdb_v1" {
  source = "https://facloud@dev.azure.com/facloud/AzureProduct-Modules/_git/cosmosdb?ref=v1.x"

  name              = "testans1azurcd1"
  resource_group_id = "/subscriptions/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxxx/resourceGroups/AZUR-N-1-AZUR-RG-1"
  location          = "westus2"

  consistency_policy = {
    consistency_level = "Session"
  }

  geo_location = [ {
    location = "westus2"
    failover_priority = 0
  } ]
}
```

Example with private endpoint and other options:
```terraform
module "cosmosdb_v1" {
  source = "https://facloud@dev.azure.com/facloud/AzureProduct-Modules/_git/cosmosdb?ref=v1.x"

  name              = "testans1azurcd1"
  resource_group_id = "/subscriptions/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxxx/resourceGroups/AZUR-N-1-TEST-RG-1"
  location          = "westus2"
  kind              = "MongoDB"

  capabilities = ["EnableServerless", "EnableMongo"]

  consistency_policy = {
    consistency_level = "Strong"
  }

  backup_options = {
    type                = "Periodic"
    interval_in_minutes = 240
    retention_in_hours  = 8
  }

  geo_location = [ {
    location = "westus2"
    failover_priority = 0
  },
  {
    location = "westcentralus"
    failover_priority = 1
  } ]

  analytical_storage_enabled = true
  analytical_storage_type = "WellDefined"

  cors_rules = [{
    allowed_headers = ["*"]
    allowed_methods = ["GET", "POST", "PUT", "PATCH"]
    allowed_origins = ["https://example.com"]
    exposed_headers = ["*"]
  }]

  private_endpoints = [{
    private_endpoint_name = "testans1azurcd1-PE1"
    subresource_name      = "MongoDB"
    subnet_id             = "/subscriptions/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx/resourceGroups/AZUR-N-1-AZUR-RG-1/providers/Microsoft.Network/virtualNetworks/AZUR-N-1-AZUR-VN-1/subnets/S-10.x.x.x"
    ip_configurations = [{
      name               = "testans1azurcd1-ipconfig1"
      member_name        = "testans1azurcd1"
      private_ip_address = "10.x.x.x"
      },
      {
        name               = "testans1azurcd1-ipconfig2"
        member_name        = "testans1azurcd1-westus2"
        private_ip_address = "10.x.x.x"
      }
    ]
  }]
}
```