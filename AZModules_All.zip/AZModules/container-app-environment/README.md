# Workload Profile
- Minimum of a /27 subnet is required
- Subnet must be delegated to "Microsoft.App/environments" with action "Microsoft.Network/virtualNetworks/subnets/join/action"

# Consumption
- Minimum of /23 subnet is required
- Subnet must not be delegated to anything or deployment will fail