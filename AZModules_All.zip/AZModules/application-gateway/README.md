# Azure External Application Gateway Module by Azure Product Team

## Table of Contents
[Introduction](#introduction)

[Module Reasoning](#modulereasoning)

[External AG Implementation](#externalagimplementation)

## Introduction
The `application-gateway` directory holds the FA custom template to build application gateway resources.

[Terraform Page](https://www.terraform.io/docs/providers/azurerm/r/application_gateway.html)

[FA One Note](http://communities.spweb06.firstam.net/sites/ITOperations/Azure/_layouts/OneNote.aspx?id=%2Fsites%2FITOperations%2FAzure%2FOneNote%2FAzure&wd=target%28Service%20Onboarding.one%7CA9C72A57-C1F3-4DF6-8290-22EE6ED707E3%2FApplication%20Gateway%20-%20Service%20Overview%7C8188C3F8-64C3-47C7-9C51-9C8B92B9A17E%2F%29onenote:http://communities.spweb06.firstam.net/sites/ITOperations/Azure/OneNote/Azure/Service%20Onboarding.one#Application%20Gateway%20-%20Service%20Overview&section-id={A9C72A57-C1F3-4DF6-8290-22EE6ED707E3}&page-id={8188C3F8-64C3-47C7-9C51-9C8B92B9A17E}&end)

## Module Reasoning

An abstraction module was deemed unnecessary at this stage as only the Azure Product Team will provision them and we can abstract the attributes on the FA custom module instead.

FA custom template is recommended for `External Application Gateways` to obfuscate and enforce certain parameters of an application gateways. Also to help implement Terraform's application gateways nested blocks dynamically.

`Internal Application Gateways` are not part of the scope of this module. A separate discussion will be required to discuss feasibility of internal application gateways.

## External AG Implementation

### main.tf
The main Terraform script. It takes in the parameters from variables.tf in same directory and creates the resources for the application gateway.

### variables.tf
File containing the list of parameters that the module takes. It describes the parameters, default values, and allowed values among other things.\
Some of the more complex parameters are described below and further detailed in usage.

### backend_pool_config
A list of backend_pool_config objects to be used with the Application Gateway.

* **name** - (Required) The name of the Backend Address Pool.
* **fqdns** - (Optional) A list of FQDN's which should be part of the Backend Address Pool.
* **ip_addresses** - (Optional) A list of IP Addresses which should be part of the Backend Address Pool.

```terraform
 backend_pool_config = [{
    name         = "FA-Pool1"
    ip_addresses = ["10.98.0.68"]
  },
  {
    name = "FA-Pool2"
    fqdns = ["fqdn1","fqdn2"]
  }]
```

### authentication_cert_config
A list of authentication certificates objects to be used with the application gateway.  The names given here will need to be consistent with backend_settings_config.  

* **name** - (Required) The Name of the Authentication Certificate to use.
* **data** - (Required) The contents of the Authentication Certificate which should be used.  
  * The example below shows conversion from a file, but the actual contents are what is required.

```terraform
  authentication_cert_config = [{
    name = "fa_auth_cert1"
    data = "${base64encode(file("files/keys/example1.cer"))}"
  },
  {
    name = "fa_auth_cert2"
    data = "${base64encode(file("files/keys/example1.cer"))}"
  }]
```

### probe_config
A list of probe configuration blocks to be used with backend settings.

* **name** - (Required) The Name of the Probe.
* **interval** - (Required) The Interval between two consecutive probes in seconds. 
  * Possible values range from 1 second to a maximum of 86,400 seconds.
* **protocol** - (Required) The Protocol used for this Probe. 
  * Possible values are Http and Https.
* **path** - (Required) The Path used for this Probe.
* **timeout** - (Required) The Timeout used for this Probe, which indicates when a probe becomes unhealthy. 
  * Possible values range from 1 second to a maximum of 86,400 seconds.
* unhealthy_threshold - (Required) The Unhealthy Threshold for this Probe, which indicates the amount of retries which should be attempted before a node is deemed unhealthy. 
  * Possible values are from 1 - 20 seconds.
* **host** - (Optional) The Hostname used for this Probe.
  * If the Application Gateway is configured for a single site, by default the Host name should be specified as ‘127.0.0.1’, unless otherwise configured in custom probe.
  * Cannot be set if pick_host_name_from_backend_http_settings is set to true.
* **pick_host_name_from_backend_http_settings** - (Optional) Whether the host header should be picked from the backend http settings. 
  * Defaults to false.
* **minimum_servers** - (Optional) The minimum number of servers that are always marked as healthy. 
  * Defaults to 0.
* **body** - (Optional) A snippet from the Response Body which must be present in the Response.
* **status_code** - (Optional) A list of allowed status codes for this Health Probe.  Can be comma separated or hyphenated

```terraform
probe {
    name                = "default"
    protocol            = "Https"
    path                = "/"
    interval            = 5
    host                = "mywebsite.com"
    timeout             = 4
    unhealthy_threshold = 3
    status_code         = ["200","302","310-399"]
  }
```

### backend_settings_config
A list of backend settings to be used in the application gateway.

* **name** - (Required) The name of the Backend HTTP Settings Collection.
* **cookie_based_affinity** - (Required) Is Cookie-Based Affinity enabled? Possible values are Enabled and Disabled.
* **port**- (Required) The port which should be used for this Backend HTTP Settings Collection.
* **protocol**- (Required) The Protocol which should be used. Possible values are Http and Https.
* **request_timeout** - (Required) The request timeout in seconds, which must be between 1 and 86400 seconds.
* **affinity_cookie_name** - (Optional) The name of the affinity cookie.
* **path** - (Optional) The Path which should be used as a prefix for all HTTP requests.
* **probe_name** - (Optional) The name of an associated HTTP Probe.
* **host_name** - (Optional) Host header to be sent to the backend servers. 
  * Cannot be set if pick_host_name_from_backend_address is set to true.
* **pick_host_name_from_backend_address** - (Optional) Whether host header should be picked from the host name of the backend server. 
  * Defaults to false.
* **authentication_certificate** - (Optional) A list of certificate names used for the backend settings.
* **connection_draining** - (Optional) Enable or Disable connection draining.
  * **enabled** - Allowed values are true or false.
  * **drain_timeout_sec** = (Required if connection_draining is set) The number of seconds connection draining is active.
    * Acceptable values are from 1 to 3600

```terraform
  backend_settings_config = [{
    name                  = "FA-BEHTTP"
    cookie_based_affinity = "Disabled"
    port                  = "80"
    protocol              = "http"
    request_timeout       = "1"
    connection_draining = [{
      enabled = true
      drain_timeout_sec = 60
    }]
    },
    {
      name                       = "FA-BEHTTPS"
      cookie_based_affinity      = "Disabled"
      port                       = "443"
      protocol                   = "https"
      request_timeout            = "1"
      authentication_certificate = ["certname1", "certname2"]
  }]
```

### ssl_cert_config
A list of all external facing certs to to be used with the application gateway.  This is required if using the Https protocol.  

* **name** - (Required) The Name of the SSL certificate that is unique within this Application Gateway
* **data** - (Optional) PFX certificate.  
  * Needs to be read in as base64 encoded.
* **password** - (Optional) Password for the pfx file specified in data. 
  * Required if data is set.

```terraform
ssl_cert_config = [{
    name = "fa_auth_external"
    data = "${filebase64("./externalcert.pfx")}"
    password = "passwordgoeshere"
  }]
```

### http_listener_config
A list of all listeners to be used with the application gateway.

* **name** - (Required) The Name of the HTTP Listener.
* **protocol** - (Required) The Protocol to use for this HTTP Listener. 
  * Possible values are Http and Https.
* **host_name** - (Optional) The Hostname which should be used for this HTTP Listener.
* **require_sni** - (Optional) Required if the host_name is set.  The module will set this to true if the host_name is not null. 
  * Defaults to false.
* **ssl_certificate_name** - (Optional) The name of the associated SSL Certificate which should be used for this HTTP Listener.
  * This must be set if using Https as the protocol.
* **custom_error_configuration** - (Optional) One or more custom_error_configuration blocks as defined below.
  * **status_code** - (Required) Status code of the application gateway customer error. Possible values are HttpStatus403 and HttpStatus502
  * **custom_error_page_url** - (Required) Error page URL of the application gateway customer error.

```terraform
http_listener_config = [{
    name = "FA-Listener1"
    protocol = "Http"
    custom_error_configuration = [{
      status_code = "HttpStatus403"
      custom_error_page_url = "www.fa-errorurl.com"
    },
    {
      status_code = "HttpStatus502"
      custom_error_page_url = "www.fa-oops.com"
    }]
  },
  {
    name = "FA-Listener2"
    protocol = "Https"
    require_sni = true
    host_name = "testurl.mt-1.firstam.net"
  }]
```

### redirect_config
A list of redirect configurations to be used for routing rules.

* **name** - (Required) Unique name of the redirect configuration block
* **redirect_type** - (Required) The type of redirect. Possible values are Permanent, Temporary, Found and SeeOther
* **target_listener_name** - (Optional) The name of the listener to redirect to. Cannot be set if target_url is set.
* **target_url** - (Optional) The Url to redirect the request to. Cannot be set if target_listener_name is set.
* **include_path** - (Optional) Whether or not to include the path in the redirected Url. Allowed values are true or false. Defaults to false
* **include_query_string** - (Optional) Whether or not to include the query string in the redirected Url. 
  * Allowed values are true or false. Default to false

### url_path_map_config
A list of URL Path Maps to be used with request routing rules.  This is required for Path Based Routing.

* **name** - (Required) The Name of the URL Path Map.  
* **path_rule** - (Required) List of path rules
  * **name** - (Required) The Name of the Path Rule.
  * **paths** - (Required) A list of Paths used in this Path Rule.  
  * **backend_address_pool_name** - (Optional) The Name of the Backend Address Pool to use for this Path Rule.
    * Cannot be set if redirect_configuration_name is set.  
  * **backend_http_settings_name** - (Optional) The Name of the Backend HTTP Settings Collection to use for this Path Rule. 
    * Cannot be set if redirect_configuration_name is set.
  * **redirect_configuration_name** - (Optional) The Name of a Redirect Configuration to use for this Path Rule. 
    * Cannot be set if backend_address_pool_name or backend_http_settings_name is set.

```terraform
  path_rule = [{
    name    = "rule1"
    paths   = ["/path1","/path2"]
  },
  {
    name    = "rule2"
    paths   = ["/path3","/path4"]
  }
  ]
```

* **default_backend_address_pool_name** - (Optional) The Name of the Default Backend Address Pool which should be used for this URL Path Map.
  * Cannot be set if default_redirect_configuration_name is set.
* **default_backend_http_settings_name** - (Optional) The Name of the Default Backend HTTP Settings Collection which should be used for this URL Path Map.
  * Cannot be set if default_redirect_configuration_name is set.
* **default_redirect_configuration_name** - (Optional) The Name of the Default Redirect Configuration which should be used for this URL Path Map.
  * Cannot be set if either default_backend_address_pool_name or default_backend_http_settings_name is set.

### request_routing_rule_config
A list of request routing rules to be used for the application gateway.

* **name** - (Required) The Name of this Request Routing Rule.
* **rule_type** - (Required) The Type of Routing that should be used for this Rule. Possible values are Basic and PathBasedRouting.
* **http_listener_name** - (Required) The Name of the HTTP Listener which should be used for this Routing Rule.
* **backend_address_pool_name** - (Optional) The Name of the Backend Address Pool which should be used for this Routing Rule.
  * Cannot be set if redirect_configuration_name is set.
* **backend_http_settings_name** - (Optional) The Name of the Backend HTTP Settings Collection which should be used for this Routing Rule.
  * Cannot be set if redirect_configuration_name is set.
* **redirect_configuration_name** - (Optional) The Name of the Redirect Configuration which should be used for this Routing Rule.
  * Cannot be set if either backend_address_pool_name or backend_http_settings_name is set.
* **url_path_map_name** - (Optional) The Name of the URL Path Map which should be associated with this Routing Rule.

```terraform
 request_routing_rule_config =  [{
    name                       = "FA-Route1"
    rule_type                  = "Basic"
    http_listener_name         = "FA-Listener1"
    backend_address_pool_name  = "FA-Pool1"
    backend_http_settings_name = "FA-BEHTTP"
  },
   {
    name                       = "FA-Route2"
    rule_type                  = "Basic"
    http_listener_name         = "FA-Listener2"
    backend_address_pool_name  = "FA-Pool2"
    backend_http_settings_name = "FA-BEHTTPS"
  }]
```

## Usage
Please read Terraform's documentation linked above.

* The Application Gateway has a lot of optional parameters but a bare minimum you will need to create:
  * 1 backend pool
  * 1 backend http setting
  * 1 listener
  * 1 request routing rule.  

If using Https, you will also need at least a publc facing cert, but First American standards for Https also require an internal cert. Certificates are defined and imported in their own separate blocks and then referenced in configurations by name.   
### *The following parameters should be passed in from the main module.*
### appgwname
The name of the Application Gateway.  
* Naming standard:
  * <Owner:2>-<Acc#>-<Subscription#>-<AppId:4>-AG-<Iteration#>  
	  * EX: *SO-1-4-SEPO-AG-1*  
* Naming standard:  
  * <Owner:4>-<P/N prod/nonprod>-<Acc#>-<AppId:4>-AG-<Iteration#>  
    * EX: *AZUR-P-1-AZUR-AG-1*  

### pipname
The name of the public IP address that will be assigned to the Application Gateway.  
* Public IP creation  
  * Basic Sku
  * Dynamic Assignment

* Naming standard:  
  * <Owner:2>-<Acc#>-<Subscription#>-<AppId:4>-AG-<Iteration#>-IP1  
    * EX: *SO-1-4-SEPO-AG-1-IP1*  
* Naming standard:  
  * <Owner:4>-<P/N prod/nonprod>-<Acc#>-<AppId:4>-AG-<Iteration#>-IP1  
    * EX: *AZUR-P-1-AZUR-AG-1-IP1*  

### resource_group_name
The name of the resource group in which the Application Gateway will be created.

### subnet_id
The subnet id for the Application Gateway, default should be the `ApplicationGatewaySubnet` ID from the outputs of the mgmt_subnets in the Landing Zone Module. This paramter also creates an implicit dependency so that Terraform knows to not build the Application Gateway until the subnet `ApplicationGatewaySubnet` resource is created.

### log_analytics_id
This is the resource ID of AZUR-P-AzureSub-1/AZUR-P-1-AZUR-RG-3/AZUR-P-1-AZUR-OI-1. It is the output of landing-zone-core module.

### *The following parameters are set by the module*
### frontend
FrontEnd ports and IP configurations are set to the name of the app gateway_port number.  There are only 2 ports created, 80 and 443.

### waf_configuration
    name     = "WAF_Medium"
    tier     = "WAF"
    capacity = var.instance_count
This ensures only `v1 WAF` can be built.

### instance_count
This variable sets the number of instances of the Application Gateway.  Default is set to 2, no configuration is required if you do not want to create more than 2 instances.

### SSL Policy

```terraform 
ssl_policy {
    policy_type = var.ssl_policy_type
    policy_name = lower(var.ssl_policy_type) == "predefined" ? "AppGwSslPolicy20170401S": null
    cipher_suites = lower(var.ssl_policy_type) == "predefined" ? []: var.ssl_cipher_suites
    min_protocol_version = "TLSv1_2"
  }
```

### ssl_policy_type
SSL policy for the Application Gateway.  Options are `Predefined` and `Custom`.  Default is set to `AppGwSslPolicy20170401S`.  This default is acceptable for most deployments.  If you need a custom SSL policy you will need to set this to `Custom` and also define the string list of acceptable SSL cipher suites to be used.

### ssl_ciper_suites
A string list of cipher suites to be used with the Application Gateway. You MUST include `TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256` with v1. Please see the [Microsoft Documentation](TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256) for more information.

Here is an example of a fairly strict set of cipher suites to be used with Application Gateway v1

```terraform
["TLS_RSA_WITH_AES_256_CBC_SHA256",
"TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384",
"TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256",
"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256",
"TLS_RSA_WITH_AES_128_GCM_SHA256",
"TLS_RSA_WITH_AES_128_CBC_SHA256",
"TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384",
"TLS_RSA_WITH_AES_256_CBC_SHA",
"TLS_RSA_WITH_AES_128_CBC_SHA"]
```

### waf_configuration
WAF policy set to `detection` using `OWASP 3.0` ruleset

### http2_config
Enables or disables http2 globally.  Defaults to false.

## Outputs
### *The module outputs the following fields*
### appgw_id
The id of the created application gateway.
### pip_id
The id of the public Ip address associated with this load balancer.
### diagnostic_settings
A string array of the name of the diagnostics settings collected for application gateways. This will be consumed at a later time by another module.
