data "azurerm_client_config" "current" {}

module "keyvault" {

  source = "git::https://facloud.visualstudio.com/AzureProduct-Modules/_git/key-vault?ref=v1.0.0"

  name                          = "AZUR-N-1-AZUR-KV-99"
  location                      = "westus2"
  resource_group_id             = "/subscriptions/84b20a1d-1029-4400-b529-2592f26718dd/resourceGroups/AZUR-N-1-AZUR-RG-99"

  access_policies = [
    {
      object_id               = data.azurerm_client_config.current.object_id
      key_permissions         = ["Get"]
      secret_permissions      = ["Get"]
      certificate_permissions = ["Get"]
    }
  ]
}

module "keyvault1" {
  source            = "git::https://facloud.visualstudio.com/AzureProduct-Modules/_git/key-vault?ref=v1.1.0"
  name              = "AZUR-N-1-AZUR-KV-2"
  location          = "westus2"
  resource_group_id = "/subscriptions/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx/resourceGroups/AZUR-N-1-CENG-RG-1"
  access_policies = [
    {
      object_id               = data.azurerm_client_config.current.object_id
      key_permissions         = ["Get"]
      secret_permissions      = ["Get"]
      certificate_permissions = ["Get"]
    }
  ]
  private_endpoints = [{
    private_endpoint_name = "SURE-N-1-AZUR-KV-2-PE1"
    subnet_id             = "/subscriptions/84b20a1d-1029-4400-b529-2592f26718dd/resourceGroups/AZUR-N-1-CENG-RG-1/providers/Microsoft.Network/virtualNetworks/AZUR-N-1-AZUR-VN-1/subnets/S-10.x.x.x"
    ip_configurations = [{
      name               = "AZUR-N-1-AZUR-KV-2-ipconfig1"
      private_ip_address = "10.x.x.x"
    }]
  }]
}
