

module "clu" {
    source = "git::https://facloud.visualstudio.com/AzureProduct-Modules/_git/conversational-language-understanding?ref=v1.x"

    name                  = "AZUR-N-1-CENG-LU-1"
    location              = "westus2"
    resource_group_id     = "/subscriptions/50bfd09a-e376-4e72-86d9-6a493b0e1184/resourceGroups/AZUR-N-1-CENG-RG-4"
    custom_subdomain_name = "azurn1cenglu1"
}


module "clu" {
    source = "git::https://facloud.visualstudio.com/AzureProduct-Modules/_git/conversational-language-understanding?ref=test"

    name                  = "AZUR-N-1-CENG-LU-10"
    location              = "westus2"
    resource_group_id     = "/subscriptions/50bfd09a-e376-4e72-86d9-6a493b0e1184/resourceGroups/AZUR-N-1-CENG-RG-4"
    custom_subdomain_name = "azurn1cenglu10"
    identity_type = {
      type         = "UserAssigned"
      identity_ids = ["/subscriptions/50bfd09a-e376-4e72-86d9-6a493b0e1184/resourceGroups/AZUR-N-1-CENG-RG-4/providers/Microsoft.ManagedIdentity/userAssignedIdentities/UMI-AZUR-N-CENG-RG-10"]
      }
}
