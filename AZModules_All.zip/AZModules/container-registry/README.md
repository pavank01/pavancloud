Example with required variables:
```terraform
module "acr" {
  source = "https://facloud@dev.azure.com/facloud/AzureProduct-Modules/_git/container-registry?ref=v1.x"
  name = "azurans1testcr1"
  location = "westus2"
  resource_group_id = "/subscriptions/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxxx/resourceGroups/AZUR-N-1-AZUR-RG-1"
  georeplications = []
}

```

Example with private endpoint and other options:
```terraform
module "acr" {
  source = "https://facloud@dev.azure.com/facloud/AzureProduct-Modules/_git/container-registry?ref=v1.x"
  name = "azurans1testcr1"
  location = "westus2"
  resource_group_id = "/subscriptions/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxxx/resourceGroups/AZUR-N-1-AZUR-RG-1"
  georeplications = []
  private_endpoints = [{
    private_endpoint_name = "TEST-N-1-AZUR-CR-1-PE1"
    subnet_id             = "/subscriptions/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx/resourceGroups/AZUR-N-1-AZUR-RG-1/providers/Microsoft.Network/virtualNetworks/AZUR-N-1-AZUR-VN-1/subnets/S-10.x.x.x"
    subresource_name = "registry"
    ip_configurations = [{
      name               = "TEST-N-1-AZUR-CR-1-ipconfig1"
      private_ip_address = "10.x.x.x"
    }]
  }]
}
```