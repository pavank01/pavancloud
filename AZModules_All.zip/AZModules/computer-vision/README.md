# Example with required variables:

module "computervision"{
  source                  = "../.."
  name                    = "xxxx-N-1-xxxx-CV-1"
  resource_group_id       = "/subscriptions/af5f9e78-a7e2-4cce-9b5f-933bae12d7f1/resourceGroups/datthathreyam"
  location                = "westus2"
  sku_name                = "S1"
  custom_subdomain_name   = "xxxx-xxxx-cv-1"
}

Example with private endpoint and other options:

module "computervision"{
  source                  = "../.."
  name                    = "xxxx-N-1-xxxx-CV-1"
  resource_group_id       = "/subscriptions/af5f9e78-a7e2-4cce-9b5f-933bae12d7f1/resourceGroups/datthathreyam"
  location                = "westus2"
  sku_name                = "S1"
  custom_subdomain_name   = "xxxx-xxxx-cv-1"

  private_endpoints = [{
    private_endpoint_name = "xxxx-N-1-xxxx-CV-1-PE1"
    subnet_id             = "/subscriptions/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx/resourceGroups/AZUR-N-1-AZUR-RG-1/providers/Microsoft.Network/virtualNetworks/AZUR-N-1-AZUR-VN-1/subnets/S-10.x.x.x"
    ip_configurations = [{
      name                = "xxxx-N-1-xxxx-CV-1-ipconfig1"
      private_ip_address  = "10.0.0.9"
    }]
  }]
}