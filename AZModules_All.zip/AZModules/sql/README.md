## Please see variables.tf for self-documenting inputs. Example usage:

```
module "sql" {
  source = "git::https://dev.azure.com/facloud/AzureProduct-Modules/_git/sql?ref=v2.x"

    name              = "azurans1azurss1"
    resource_group_id = "/subscriptions/50bfd09a-e376-4e72-86d9-6a493b0e1184/resourceGroups/AZUR-N-1-CENG-RG-1"
    location          = "westus2"
}

module "sql_private_endpoint" {
  source = "git::https://dev.azure.com/facloud/AzureProduct-Modules/_git/sql?ref=v2.x"

    name                          = "azurans1azurss2"
    resource_group_id             = "/subscriptions/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx/resourceGroups/AZUR-N-1-CENG-RG-1"
    location                      = "westus2"
    public_network_access_enabled = false
    include_rollup_ips            = false
    connection_policy             = "Proxy"

    private_endpoints = [{
      private_endpoint_name = "azurans1azurss2-PE1"
      subnet_id             = "/subscriptions/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx/resourceGroups/AZUR-N-1-AZUR-RG-1/providers/Microsoft.Network/virtualNetworks/MT-1-AVNM-PROD-VN-2/subnets/S-10.x.x.x-28"
      ip_configurations = [{
        name               = "azurans1azurss2-ipconfig1"
        private_ip_address = "10.x.x.x"
      }]
    }]
}
```