# FA Storage Resource Modules by Azure Product Team

## Table of Contents
[Introduction](#introduction)

## Introduction

This module is for creating [Azure Storage Accounts](https://docs.microsoft.com/en-us/azure/storage/common/storage-account-overview)

For a summary on the parameters that it requires, please view the `storage-account\variables.tf` file.

Example with required variables:
```terraform
module "custom_script" {
  source = "https://facloud@dev.azure.com/facloud/AzureProduct-Modules/_git/storage-account"

  name                = "testans1azursa1"
  resource_group_name = "TEST-N-1-AZUR-RG-1"
}
```

Example with all optional variables:
```terraform
module "custom_script" {
  source = "https://facloud@dev.azure.com/facloud/AzureProduct-Modules/_git/storage-account"

  name                     = "testans1azursa1"
  resource_group_name      = "TEST-N-1-AZUR-RG-1"
  location                 = "westus2"
  account_kind             = "StorageV2"
  account_tier             = "Premium"
  account_replication_type = "GRS"
  access_tier              = "Hot"
}
```

Example with private endpoint for all common services:
```terraform
module "storage-account_private-endpoint" {
  source = "https://facloud@dev.azure.com/facloud/AzureProduct-Modules/_git/storage-account"

  name                = "testans1azursa1"
  resource_group_name = "TEST-N-1-AZUR-RG-1"
  location            = "westus2"

  private_endpoints = [{
    private_endpoint_name = "testans1azursa1-PE1"
    subnet_id             = "/subscriptions/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx/resourceGroups/AZUR-N-1-AZUR-RG-1/providers/Microsoft.Network/virtualNetworks/AZUR-N-1-AZUR-VN-1/subnets/S-10.x.x.x"
    subresource_name      = "blob"
    ip_configurations = [{
      name               = "testans1azursa1-ipconfig1"
      private_ip_address = "10.x.x.x"
    }]
    },
    {
      private_endpoint_name = "testans1azursa1-PE2"
      subnet_id             = "/subscriptions/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx/resourceGroups/AZUR-N-1-AZUR-RG-1/providers/Microsoft.Network/virtualNetworks/AZUR-N-1-AZUR-VN-1/subnets/S-10.x.x.x"
      subresource_name      = "table"
      ip_configurations = [{
        name               = "testans1azursa1-ipconfig2"
        private_ip_address = "10.x.x.x"
      }]
    },
    {
      private_endpoint_name = "testans1azursa1-PE3"
      subnet_id             = "/subscriptions/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx/resourceGroups/AZUR-N-1-AZUR-RG-1/providers/Microsoft.Network/virtualNetworks/AZUR-N-1-AZUR-VN-1/subnets/S-10.x.x.x"
      subresource_name      = "queue"
      ip_configurations = [{
        name               = "testans1azursa1-ipconfig3"
        private_ip_address = "10.x.x.x"
      }]
    },
    {
      private_endpoint_name = "testans1azursa1-PE4"
      subnet_id             = "/subscriptions/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx/resourceGroups/AZUR-N-1-AZUR-RG-1/providers/Microsoft.Network/virtualNetworks/AZUR-N-1-AZUR-VN-1/subnets/S-10.x.x.x"
      subresource_name      = "file"
      ip_configurations = [{
        name               = "testans1azursa1-ipconfig4"
        private_ip_address = "10.x.x.x"
      }]
  }]
}
```