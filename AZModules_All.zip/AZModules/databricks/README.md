# FA Databricks Module by Azure Product Team

## Table of Contents
[Overview](#overview)

## Overview

This module is for creating an [Azure Databricks Workspace](https://azure.microsoft.com/en-us/products/cosmos-db).

For a summary on the parameters that it requires, please view the `databricks\variables.tf` file.

For onboarding documentation, including the subnet requirements, please view the [One Note Documentation](https://firstam.sharepoint.com/sites/ITOperations/Azure/_layouts/OneNote.aspx?id=%2Fsites%2FITOperations%2FAzure%2FOneNote%2FAzure&wd=target%28Service%20Onboarding.one%7CA9C72A57-C1F3-4DF6-8290-22EE6ED707E3%2FDatabricks%20Service%20Programmatic%20Build%7C0258DB56-E473-4355-9263-EDA4016AF9E8%2F%29).

Currently this module sets 3 IAM members as admins since the Service Principal that creates the workspace is a non-interactive account.

For the most common type of deployment, please see the `examples\generic\index.tf` file.

The Databricks Terraform provider has some limitations, see error message below:
```terraform
│ The module at module.databricks is a legacy module which contains its
│ own local provider configurations, and so calls to it may not use the
│ count, for_each, or depends_on arguments.
```