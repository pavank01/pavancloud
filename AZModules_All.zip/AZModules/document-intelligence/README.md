Example With Required Variables

module "fr" {
    source = "git::https://dev.azure.com/facloud/AzureProduct-Modules/_git/document-intelligence?ref=v1.x"

    name                  = "AZUR-S-1-AZUR-FR-1"
    location              = "westus2"
    resource_group_id     = /subscriptions/af5f9e78-a7e2-4cce-9b5f-933bae12d7f1/resourceGroups/AZUR-S-1-AZUR-RG-1"
    custom_subdomain_name = "azurs1azurfr1"
}

Example With Private Endpoint

module "fr" {
    source = "git::https://dev.azure.com/facloud/AzureProduct-Modules/_git/document-intelligence?ref=v1.x"

    name                  = "AZUR-S-1-AZUR-FR-1"
    location              = "westus2"
    resource_group_id     = /subscriptions/af5f9e78-a7e2-4cce-9b5f-933bae12d7f1/resourceGroups/AZUR-S-1-AZUR-RG-1"
    custom_subdomain_name = "azurs1azurfr1"

    private_endpoints     = [{
    private_endpoint_name = "azurs1azurfr1-PE1"
    subnet_id             = "/subscriptions/xxxxx-xxxxxxxxxx-xxxxxxxx/resourceGroups/AZUR-S-1-AZUR-RG-1/providers/Microsoft.Network/virtualNetworks/AZUR-S-1-AZUR-VN-1/subnets/SubnetName"
    ip_configurations     = [{
      name                = "azurs1azurfr1-ipconfig1"
      private_ip_address  = "10.xx.xx.xx"
      }
    ]
  }]
}
