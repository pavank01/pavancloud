Please see variables.tf for self-documenting inputs. Example usage:

```
module "vm" {
  source = "git::https://dev.azure.com/facloud/AzureProduct-Modules/_git/virtual-machine?ref=v2.x"

  name              = "AZUVNAPPGREG001"
  resource_group_id = "/subscriptions/50bfd09a-e376-4e72-86d9-6a493b0e1184/resourceGroups/AZUR-N-1-CENG-RG-1"
  location          = "westus2"
  os_type           = "Windows"
  size              = "Standard_B4ms"
  admin_username    = "faadmin"
  source_image_id   = "/subscriptions/e63b08c3-d314-48d8-b10a-c58199bb78b1/resourceGroups/AZUR-P-1-FAIB-RG-1/providers/Microsoft.Compute/galleries/azuraps1faibig1/images/Windows_2022_FA_GOLD"

  nics = [
    {
      name = "AZUVNAPPGREG001-NIC1"
      ip_configurations = [
        {
          name      = "ipconfig1",
          address   = "10.65.18.40",
          subnet_id = "/subscriptions/50bfd09a-e376-4e72-86d9-6a493b0e1184/resourceGroups/AZUR-N-1-AZUR-RG-1/providers/Microsoft.Network/virtualNetworks/AZUR-N-1-AZUR-VN-1/subnets/S-10.65.18.32-27",
          primary   = true
        }
      ]
    }
  ]
  data_disks = [
    {
      name                 = "AZUVNAPPGREG001-DATA-1"
      storage_account_type = "StandardSSD_LRS"
      size_gb              = 128
      lun                  = 0
      caching              = "None"
    },
    {
      name                 = "AZUVNAPPGREG001-DATA-2"
      storage_account_type = "UltraSSD_LRS"
      size_gb              = 128
      lun                  = 1
      zone                 = 3  # zone should be set for Ultra disk, 3 for East US 2, West US 2
      caching              = "None" 
    }
  ]
}
```