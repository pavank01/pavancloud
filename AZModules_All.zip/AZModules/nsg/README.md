# Azure NSG Module by Azure Product Team

## Table of Contents

[Introduction](#introduction)

[variables.tf](#variables)

[nsg.tf](#nsg)

[outputs.tf](#outputs)

[examples](#examples)

## Introduction
The `nsg` directory holds the FA custom template designed to create a network security group (nsg).  This module can be used in conjunction with nsg-global-rule and nsg-service-rule modules to create and nsg that contains global and specific service sets of firewall rules.

## nsg
This terraform module creates a network security group (nsg).  The module accepts a resource group name and security group name as variables and returns the nsg id and name.

## variables
File containing the list of parameters that the module accepts. 
Parameters include:
    resource_group_name 
        type        = string
        description = "(Required) The name for the resource group that the  
        default value = none
 
    network_security_group_name
        type        = string
        description = "(Required) The name of NSG that rules will be associated with"
        default value = none

## outputs
Then name of the NSG created is output:
NSG name - module.NSG.name

The id of the NSG created is output:
NSG ID - module.NSG.id

## Examples:


### Create an NSG

```terraform

module "NSG" {
  source                = "git::https://facloud@dev.azure.com/facloud/AzureProduct-Modules/_git/nsg?ref=v1.0.0"
  resource_group_name   = "AZUR-N-1-SOSG-RG-1"
  nsg_name              = "S-10.65.8.16-28-NSG"
}

```
### Create an NSG that will be associated with a non-production subnet that will house an ase

```terraform

// --------------------------------------------------------------------------------------
// Create NSG
module "NSG" {
  source                            = "git::https://facloud@dev.azure.com/facloud/AzureProduct-Modules/_git/nsg?ref=v1.0.0"
  resource_group_name               = "AZUR-N-1-SOSG-RG-1"
  nsg_name                          = "S-10.65.8.16-28-NSG"
}

// Attach Global Security rules
module "nsg-global-rules" {
    source                          = git::https://facloud.visualstudio.com/AzureNSGRules/_git/AzureNSGRules//modules/nsg-global-rules
    resource_group_name             = "AZUR-N-1-SOSG-RG-1"
    network_security_group_name     = "module.NSG.name"
    subnet_address_space            = "10.65.8.16/28"
    ruleset_type                    = "np-std-sn"
}

// Attach Service Security rules
module "nsg-service-rules" {
    source                          = git::https://facloud.visualstudio.com/AzureNSGRules/_git/AzureNSGRules//modules/nsg-service-rules
    resource_group_name             = "AZUR-N-1-SOSG-RG-1"
    network_security_group_name     = "module.NSG.name"
    subnet_address_space            = "10.65.8.16/28"
    service_type                    = "ase"
}

```
