# FA AZUR-RG network build out

## Table of Contents
[Introduction](#introduction)

[variables.tf](#variablestf)

[outputs.tf](#outputstf)

[main.tf](#maintf)

## Introduction
The `landing-zone-core` module holds the FA custom template to build out the network within AZUR resource groups. This complex modules calls upon base modules for the build out.

The build out includes the following resources:

- Resource Group
- Virtual Network
- Management Subnets
- Route Tables

Production resources and Storage accounts are not part of this base template.

## variables.tf
File containing the list of parameters that the module takes. It describes the parameters, default values, and allowed values among other things.

## outputs.tf
File containing the list of output values that Terraform will return back. It can be a list of ids to a list of subnets.

### custom_subnets
```json
{
  "ase" = {}
  "sqlmi" = {}
  "standard" = {
    "S-10.65.57.0-28" = {
      "address_prefix" = "10.65.57.0/28"
      "id" = "/subscriptions/099b3e2d-bdc3-4642-aa89-5214b713c2c4/resourceGroups/JLIU-N-2-JLIU-RG-1/providers/Microsoft.Network/virtualNetworks/JLIU-N-2-JLIU-VN-1/subnets/S-10.65.57.0-28"
    }
    "S-10.65.57.16-28" = {
      "address_prefix" = "10.65.57.16/28"
      "id" = "/subscriptions/099b3e2d-bdc3-4642-aa89-5214b713c2c4/resourceGroups/JLIU-N-2-JLIU-RG-1/providers/Microsoft.Network/virtualNetworks/JLIU-N-2-JLIU-VN-1/subnets/S-10.65.57.16-28"
    }
  }
}
```

## main.tf
The main Terraform script. It takes in the parameters from variables.tf and creates the resources for AZUR resource group.

### Resource Group
The resource group calls upon the base-module to create the resource group with hardcoded tag values for ApplicationID, ApplicationName, and EnvironmentName.

### Virtual Network
The virtual network will get created within the newly created resource group. Tags and location are set to be same as the resource group. The DNS servers are hardcoded to FA standard and the subnets are dynamically created.

### Management Subnets
Dynamically created FA Azure Product Team management subnets. 

### Customer subnets
Dynamically created subnets for customer VMs, ASEs, SQL MIs, etc.

## Example

```terraform
module "resource_group" {
  source = "git::https://facloud@dev.azure.com/facloud/AzureProduct-Modules/_git/landing-zone-core?ref=v1.0.0"

  resource_group_name                        = "JLIU-N-2-JLIU-RG-1"
  virtual_network_name                       = "JLIU-N-2-JLIU-VN-1"
  location                                   = "westus2"
  virtual_network_address_space_list         = ["10.65.0.0/22"]
  network_virtual_appliance_load_balancer_ip = "10.65.0.180"

  custom_subnets_map = {
    standard = {
      JLIU_Dev = {
        name                                           = "S-10.65.0.0-28"
        address_prefix                                 = "10.65.0.0/28"
        service_endpoints                              = ["Microsoft.KeyVault"]
        enforce_private_link_endpoint_network_policies = true # If set to true, 'enforce_private_link_service_network_policies', has to be false
      }
      JLIU_Dev2 = {
        name           = "S-10.65.0.16-28"
        address_prefix = "10.65.0.16/28"
      }
      JLIU_Stage = {
        name                                          = "S-10.65.0.64-28"
        address_prefix                                = "10.65.0.64/28"
        enforce_private_link_service_network_policies = true # If set to true, 'enforce_private_link_endpoint_network_policies', has to be false
      }
    }
    ase = {
      JLIU_Dev = {
        name           = "S-10.65.0.32-27"
        address_prefix = "10.65.0.32/27"
      }
    }
  }
}
```