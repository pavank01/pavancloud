import json
import boto3
import urllib3
http = urllib3.PoolManager(cert_reqs='CERT_NONE')
from urllib.parse import quote
import os
from ldap3 import Server, Connection, ALL, NTLM, SIMPLE
import logging
import socket

# Used for sending error emails
import smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


logging.basicConfig()
logging.getLogger().setLevel(logging.INFO)


##################################
# EXPECTED TAGS                  #
#   name                         #
#   ad_cleanup                   #
#   EnvironmentName              #
#   ApplicationServiceNumber     #
# OPTIONAL TAGS                  #
#    DomainController            #
#    team_dl                     #
#    domain                      #
##################################

# ip_address:   # no longer needed from tag, getting from instance
# SecretARN:    # no longer needed, getting from environment variable
# ou_path -    # no longer needed from tag, getting from ldap

def lambda_handler(event, context):
    print("Incomming Events: " + str(event))
    #init variables
    ad_cleanup = None
    team_dl = None
    server_hostname = None
    environment_name = None
    app_team_code = None
    dns_domain_name = None
    ou_path = None
    
    region = event["region"]
    myVars = globals()

    termination_type = None
    try:
        instance_id = event["detail"]["EC2InstanceId"]
        termination_type = "auto_scale_group"
    except Exception as e:
        print("EC2InstanceId is only on events from AutoScale Groups, not ec2, so adding this guardrail")
        instance_id = event["detail"]["instance-id"]
        termination_type = "ec2_instance"

    client = boto3.client('ec2', region_name=region, use_ssl=False, verify=None)
    res = client.describe_instances(InstanceIds=[instance_id])
    tags = res['Reservations'][0]['Instances'][0]['Tags']
    eval_for_cleanup = "no"
    print("!! Instance Tags:")
    print(str(tags))
    for t in tags:
        # tags_to_vars(t)
        print("Key, ",  t["Key"])
        print("value =", t["Value"])
        myVars[t["Key"].lower()] = t["Value"]
        

    try:
        if myVars["ad_cleanup"].lower() == "yes":
            print("ad_cleanup is yes, continuing with decom...")
            ad_cleanup = "yes"
        else:
            print("ad_cleanup is not yes, exiting")
            exit(0)
    except Exception as e:
        print("No variable: 'ad_cleanup', nothing to do, exiting")
        ad_cleanup = "no"
        exit(0)

    try:
        # The Application Team requesting use of Integral Endpoint ie: appteam_dl@firstam.com or FAHQ-DL-APPDL-Team
        team_dl = myVars["team_dl"]
    except Exception as e:
        print("No variable tag: team_dl, falling back to lambda environment vairable")
        team_dl = os.environ["team_dl"]

    try:
        ip_address = str(res['Reservations'][0]['Instances'][0]['PrivateIpAddress'])
        print("Retrieve Server IP Address: " + str(ip_address))
    except Exception as e:
        try:
            print("Unable to retrive IP from boto3.describe_instances. Attempting from tag...")
            ip_address = myVars["ip_address"]
        except Exception as e:
            print("Unable to get IP Address from Instance via boto3.describe_instances or tags")
            send_failure_email(team_dl, "Unable to Identify IP Address for EC2 Instance", instance_id)
            exit(1)

    try:
        server_hostname = myVars["name"]
    except Exception as e:
        print("No variable: name, failing - exiting")
        send_failure_email(team_dl, "Unable to Identify Server Name Tag on EC2 Instance", instance_id, ip_address)
        exit(1)


    try:
        environment_name = myVars["environmentname"]
    except Exception as e:
        print("No variable: EvironmentName, failing - exiting")
        send_failure_email(team_dl, "Unable to Identify EnvironmentName Tag on EC2 Instance", instance_id, ip_address, server_hostname)
        exit(1)

    try:
        # The ApplicationServiceNumber abbreviation as found in the CMDB ie: ApplicationServiceNumber
        app_team_code = myVars["applicationservicenumber"]
    except Exception as e:
        print("No variable tag: ApplicationServiceNumber, failing - exiting")
        send_failure_email(team_dl, "Unable to Identify ApplicationServiceNumber Tag on EC2 Instance", instance_id, ip_address, server_hostname)
        exit(1)

    try:
        # This can be set on the instance in case of intl.corp.firstam.com
        dns_domain_name = myVars["domain"]
    except Exception as e:
        print('No dns_domain_name Environment Variable, using corp.firstam.com as default')
        dns_domain_name = "corp.firstam.com"

    secret_name = environment_name + "/ad_cleanup_credentials"

    # ################## DEFAULT VALUES - CHANGE APPROPRIATELY START ###################
    try:
        secrets = get_ou_username_password_from_secrets_manager(region, secret_name)
        credentials_ou_username = secrets["ad_username"]  # Either in plain text or get from secrets manager
        credentials_ou_password = secrets["ad_password"]
    except Exception as e:
        print("No secret found for " + secret_name + ", failing - exiting")
        print("Error Message is: " + str(e))
        send_failure_email(team_dl, f"Unable to locate secrets from AWS Secrets manager {secret_name}", instance_id, ip_address, server_hostname)
        exit(1)

    try:
        ou_path =  myVars["ou_path"] # get_ou_path(domain_controller, server_hostname, credentials_ou_username, credentials_ou_password, dns_domain_name) #'OU=YOUR OU (Dev) Servers,OU=Servers,DC=corp,DC=firstam,DC=com'
    except Exception as e:
        print("Unable to find ou_path in tags exiting")
        print("Error Message is: " + str(e))
        send_failure_email(team_dl, "Unable to locate OU correlating to provided server name", instance_id, ip_address, server_hostname)
        exit(1)

    # ################## DEFAULT VALUES - CHANGE APPROPRIATELY END ###################
    credentials_ou_username = quote(credentials_ou_username)
    credentials_ou_password = quote(credentials_ou_password)

    ou_path = quote(ou_path)
    fail_counter = 0
    if ad_cleanup == "yes":
        try:
            while fail_counter < 5:
                response_status, response_message = exec_decom(server_hostname=server_hostname, dns_domain_name=dns_domain_name, ip_address=ip_address, ou_path=ou_path, credentials_ou_username=credentials_ou_username, credentials_ou_password=credentials_ou_password, team_dl=team_dl, app_team_code=app_team_code)
                if response_status == 'Failure':
                    fail_counter = fail_counter + 1
                    print("Received a Failure trying to decommission server.  Fail Attempt Counter: " + str(fail_counter))
                else:
                    print(response_status + ": Server " + str(server_hostname) + " (" + str(ip_address) + ") all DNS Records Removed and Server Removed from DNS, release wait and continue")
                    if termination_type == "auto_scale_group":
                        complete_lifecycle_hook(event, context)
                    break
            if fail_counter >= 5:
                print(response_status + ": Don't proceed")
                print(response_message)
                if termination_type == "auto_scale_group":
                    abandon_lifecycle_hook(event, context)
                send_failure_email(team_dl, "Unable to remove server from Active Directory & DNS", instance_id, ip_address, server_hostname)
                exit(1)

        except Exception as e:
            print('Exception: ' + str(e))
            if termination_type == "auto_scale_group":
                abandon_lifecycle_hook(event, context)
    else:
        print("Server not configured for Active Directory Clean Up, AD_Cleanup Server Tag, not present or not set to 'yes'.  Moving on.")


def exec_decom(server_hostname, dns_domain_name, ip_address, ou_path, credentials_ou_username, credentials_ou_password, team_dl, app_team_code):
    headers = {"team_dl": team_dl, "app_team_code": app_team_code}
    try:
        print("sending: " + str("https://ies.firstam.com/integral/v1/decommission_server?server_hostname=" + server_hostname + "&dns_domain_name=" + dns_domain_name + "&server_ip_address=" + ip_address + "&ou_path=" + ou_path + "&credentials_ou_username=" + credentials_ou_username + "&credentials_ou_password=" + credentials_ou_password))
        response = http.request("GET", "https://ies.firstam.com/integral/v1/decommission_server?server_hostname=" + server_hostname + "&dns_domain_name=" + dns_domain_name + "&server_ip_address=" + ip_address + "&ou_path=" + ou_path + "&credentials_ou_username=" + credentials_ou_username + "&credentials_ou_password=" + credentials_ou_password, headers=headers)
    except Exception as e:
        print("exception sending request: " + str(e))
        return "Failure", "Failure"
    print("raw response data: " + str(response.data))
    # rs = "{" + str(response.data.decode('utf-8')).replace("'", '"') + "}"
    # print("clean data: " + str(rs))
    try:
        jresp = json.loads(str(response.data.decode('utf-8')))
        response_status = str(jresp['Status'])
        response_message = str(jresp['Message'])
        return response_status, response_message
    except Exception as e:
        print('Exception: ' + str(e))
        return "Failure", "Failure"


def complete_lifecycle_hook(event, context):
    client = boto3.client('autoscaling', region_name=event['region'], use_ssl=False, verify=None)
    response = client.complete_lifecycle_action(LifecycleHookName=event['detail']['LifecycleHookName'],
                                                LifecycleActionToken=event['detail']['LifecycleActionToken'],
                                                AutoScalingGroupName=event['detail']['AutoScalingGroupName'],
                                                LifecycleActionResult='CONTINUE',
                                                InstanceId=event['detail']['EC2InstanceId'])


def abandon_lifecycle_hook(event, context):
    client = boto3.client('autoscaling', region_name=event['region'], use_ssl=False, verify=None)
    response = client.complete_lifecycle_action(LifecycleHookName=event['detail']['LifecycleHookName'],
                                                LifecycleActionToken=event['detail']['LifecycleActionToken'],
                                                AutoScalingGroupName=event['detail']['AutoScalingGroupName'],
                                                LifecycleActionResult='ABANDON',
                                                InstanceId=event['detail']['EC2InstanceId'])


def get_ou_username_password_from_secrets_manager(region_name, secret_name):
    session = boto3.session.Session(region_name=region_name)
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name, verify=False
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
        # Decrypts secret using the associated KMS key.
        # Depending on whether the secret is a string or binary, one of these fields will be populated.
        secret = get_secret_value_response['SecretString']
        json_secret = json.loads(secret)
        return json_secret
    except Exception as e:
        print("error fetching credentials: " + str(e))
        raise


def send_failure_email(team_dl, error_message, instance_id, ip_address="", server_name=""):
    smtp_server = "mail.firstam.com"
    port = 25  # For starttls
    sender_email = "arpsteam@firstam.com"
    receiver_email = team_dl

    # Set up the email message object
    message = MIMEMultipart("alternative")
    message["Subject"] = "Failure to Domain Unjoin Server - EC2 Cleanup"
    message["From"] = sender_email
    message["To"] = team_dl

    # Create the email message content
    text = f"""\
    DNS Unjoin Failed for the following server:

    Instance ID: {instance_id}
    Server Name: {server_name}
    IP Address: {ip_address}
    Error Message: {error_message}
    Additional Logs can be found in CloudWatch Logs <TODO: Add Log Group Name>

    Reminder the following are required for a successful DNS Unjoin:
    EC2 Tags:
    - name
    - ad_cleanup
    - EnvironmentName
    - ApplicationServiceNumber

    AWS Secret Manager AD Credentials
    - ad_username
    - ad_password

    This message is sent via the DNS Cleanup Lambda deployed via the following terraoform module.
    <TODO: insert link to terraform module>
    """
    try:
        part1 = MIMEText(text, "plain")
        message.attach(part1)

        # Create a secure SSL context
        context = ssl.create_default_context()
        # Try to log in to server and send email
        with smtplib.SMTP(smtp_server, port) as server:
            server.starttls(context=context) # Secure the connection
            server.sendmail(
                sender_email, receiver_email, message.as_string()
        )
    except Exception as e:
        logging.error("[!] unable to send failure email: %s" % str(e))
        logging.error("Error Message: " + str(text))
        raise
