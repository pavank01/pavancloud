FA SQL Managed Instance Module By Azure Team

# Introduction 

This module is for creating Azure SQL Managed Instance

For a summary on the parameters that it requires, Please view the sqlmi\variables.tf file.

Example with required variables:

module "module_azu_sqlmi" {
source = "../.."

name = "test-1-sql-mi-01"
resource_group_name = "pppavankumar"
location = "westus2"
subnet_id = "/subscriptions/af5f9e78-a7e2-4cce-9b5f-933bae12d7f1/resourceGroups/pppavankumar/providers/Microsoft.Network/virtualNetworks/pavanvnet/subnets/testsqlmi"
sku_name = "GP_Gen5"
vcores = 16
storage_account_type = "LRS"
storage_size_in_gb = 512

private_endpoints = [{
    private_endpoint_name = "test-1-sql-mi-01-pe-1"
    subnet_id = "/subscriptions/af5f9e78-a7e2-4cce-9b5f-933bae12d7f1/resourceGroups/pppavankumar/providers/Microsoft.Network/virtualNetworks/pavanvnet/subnets/pe-subnet"
    ip_configurations = [{
      name = "testsqlmi-ipconfig1"
      private_ip_address = "10.1.3.25"
    }]

}]

}