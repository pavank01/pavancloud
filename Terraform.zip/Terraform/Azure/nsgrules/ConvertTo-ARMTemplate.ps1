# | -------------------------------------------------------------------------------------------------------------
# | File : ConvertTo-ARMTemplate.ps1                                          
# | Version : 1.00                                         
# | Purpose : Script used for converting existing NSG Rules json to ARM template for use with New-FAAzSubnet.ps1
# | 
# | -------------------------------------------------------------------------------------------------------------
# | Maintenance History                                            
# | -------------------------------------------------------------------------------------------------------------                                            
# | Name            Date         Version  Description        
# | -------------------------------------------------------------------------------------------------------------
# | Lok Liu         01-08-2021   1.00     Creation
# | -------------------------------------------------------------------------------------------------------------

Param (
  [Parameter(Mandatory=$true)]$NSGJson   #Individual NSG rule in Json format exported by ConcatRulesForTesting.ps1. It accepts the full path to a NSG JSON file, or PSObject created by ConcatRulesForTesting.ps1.
)

$baseARMJson = @"
{
  "`$schema": "https://schema.management.azure.com/schemas/2015-01-01/deploymentTemplate.json#",
  "contentVersion": "1.0.0.0",
  "parameters": {
      "SubnetName": {
          "type": "string"
      },
      "cidr": {
          "type": "string"
      },
      "location": {
          "type": "string"
      }
  },
  "variables": {
      "SecurityGroupName": "[concat(parameters('SubnetName'),'-NSG')]"
  },
  "resources": [
      {
          "type": "Microsoft.Network/networkSecurityGroups",
          "name": "[variables('SecurityGroupName')]",
          "apiVersion": "2018-10-01",
          "location": "[parameters('location')]",
          "tags": {
              "BusinessApplicationNumber": "[resourceGroup().tags.BusinessApplicationNumber]",
              "ApplicationServiceNumber": "[resourceGroup().tags.ApplicationServiceNumber]"
          },
          "properties": {
              "securityRules": __Rules__,
              "defaultSecurityRules": []
          },
          "dependsOn": []
      }
  ],
  "outputs": {
      "resourceID": {
          "type": "string",
          "value": "[resourceId('Microsoft.Network/networkSecurityGroups', variables('SecurityGroupName'))]"
      }
  }
}
"@

If ($NSGJson) {
  If ($NSGJson.GetType().Name -eq "String") {
    If (( Test-Path $NSGJson) ) {
      $json1 = Get-Content $NSGJson
      $json2 = $json1 | ConvertFrom-Json
    }
    Else {
      Return "$NSGJson not found"
    }
  }
  ElseIf ($NSGJson | Get-Member | Where-Object {$_.Name -eq "securityRules"}) {
    $json2 = $NSGJson
  }

}

################################
# Function
################################
Function Start-ARMTemplateConversion {
  Param (
    [Parameter(Mandatory=$true)]$jsonObject
  )
  $extraColumns = @("sourcePortRanges", "destinationPortRanges", "sourceAddressPrefixes", "destinationAddressPrefixes")

  $template = @()
  $jsonObject.SecurityRules | ForEach {
    $allproperties = ($_ | Select-Object * -ExcludeProperty name, description | Get-Member | Where-Object {$_.MemberType -eq "NoteProperty"}).Name + $extraColumns
    $template += [PSCustomObject][Ordered]@{
      name = $_.Name
      properties = $_ | Select-Object $allproperties
    }
  }
  
  # Convert single item collection to string (eg. sourcePortRange = {"*"} ----> sourcePortRange = "*"
  $template | ForEach {
    $thisRule = $_
    $columns = ($thisRule.properties | Get-Member | Where-Object {$_.MemberType -eq "NoteProperty"}).Name
    $columns | ForEach {
      $thisColumn = $_
      If ($thisColumn -NotMatch ($extraColumns -Join "|")) {
        If ( ($thisRule.properties.$($_).GetType()).Name -eq "Object[]") {
          If ( ($thisRule.properties.$($_) | Measure-Object).Count -eq 1 ) {
            # Convert single item array to string
            $thisRule.properties.$($_) = $thisRule.properties.$($_)[0]
          }
          Else {
            # Move to "pural properties"
            # Example: destinationPortRange = {"80", "443"} ---> destinationPortRanges = {"80", "443"}
            Switch ($thisColumn) {
              "sourcePortRange"           {
                $thisRule.properties.sourcePortRanges = $thisRule.properties.sourcePortRange
                $thisRule.properties.sourcePortRange = ""
              }
              "destinationPortRange"      {
                $thisRule.properties.destinationPortRanges = $thisRule.properties.destinationPortRange
                $thisRule.properties.destinationPortRange = ""
              }
              "sourceAddressPrefix"       {
                $thisRule.properties.sourceAddressPrefixes = $thisRule.properties.sourceAddressPrefix
                $thisRule.properties.sourceAddressPrefix = ""
              }
              "destinationAddressPrefix"  {
                $thisRule.properties.destinationAddressPrefixes = $thisRule.properties.destinationAddressPrefix
                $thisRule.properties.destinationAddressPrefix = ""
              }
            }
          }
        }
      }
    }
  }
  
  $json_template = $template | ConvertTo-Json -Depth 100
  
  $rules = $json_template -Replace("\\u003csubnetCIDR\\u003e|<subnetCIDR>", "[parameters('cidr')]") -Replace("null", "[]") -Replace("\r") # Replace hidden \r after ConvertTo-Json
  
  ##########################################
  # Creating a new usable NSG ARM template
  ##########################################
  
  ## Pad leading space to $rules
  $rulesPadded = @()
  $rules.Split("`n") | ForEach {
    If ($_ -Match "^\s|^\]") {
      $rulesPadded += " " * 14 + $_
    }
    Else {
      $rulesPadded += $_
    }
  }
  
  If (( $rules.Split("`n") | Measure-Object).Count -eq  ($rulesPadded | Measure-Object).Count) {
    $nsgArmTemplate = $baseARMJson -Replace("__Rules__", ($rulesPadded | Out-String).TrimEnd()) 
  }
  Else {
    Write-Warning "Padded securityRules count not matched, using original rules without padding...."
    $nsgArmTemplate = $baseARMJson -Replace("__Rules__", $rules) 
  }
  
  return $nsgArmTemplate, $rules
  
}

################################
# Main
################################

$ArmTempalte = Start-ARMTemplateConversion -jsonObject $json2 

If ($ArmTempalte) {
  Return $ArmTempalte[0]
}
Else {
  Return "Error exporting the ARM template..."
}
