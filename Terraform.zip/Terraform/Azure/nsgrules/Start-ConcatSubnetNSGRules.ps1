# | ----------------------------------------------------------------------------------
# | File : Start-ConcatSubnetNSGRules.ps1
# | Version : 1.0.0                                         
# | Purpose : Helper script to call ConcatRulesForTesting.ps1 to generate NSG Json files
# |           for each subnet type defined in $subnetType.
# | 
# | ----------------------------------------------------------------------------------
# | Maintenance History                                            
# | -------------------                                            
# | Name            Date         Version  Description        
# | ----------------------------------------------------------------------------------------------------
# | Lok Liu         11-05-2020   1.0      Creation
# | Lok Liu         01-04-2021   1.1      Add option to export as ARM template format (use in commondata)
# | Lok Liu         01-08-2021   1.2      Add support for export as ARM Template using
# |                                         ConvertTo-ARMTemplate.ps1 
# | Lok Liu         02-18-2021   1.3      Add Restricted subnet type (np-rst-sn & p-rst-sn)
# |                                          and fix error in VM subnet NSG.
# | Lok Liu         09-08-2021   1.4      Make output folder default location to be more 'dynamic'.
# | ----------------------------------------------------------------------------------------------------

Param (
  $jsonFolder = "$([Environment]::GetFolderPath('Desktop'))/AzureNSGRules_Rules_export_$(Get-Date -f 'yyyy-MM-dd')",
  $ConcatRuleScriptPath = ".",
  [Switch]$ExportARMTemplate,
  [Switch]$ExportCSV
)

# -----------------
# Configurations
# -----------------
# Subnet type to export (Here-String)
$NSGType = @"
  SQLMISubnet
  ASESubnet
  AKSSubnet
  DBMigrationSubnet
  APIMgmtSubnet
  RedisSubnet
  AppGatewaySubnet
  VM
  NormalSubnet
  RestrictedNormalSubnet
"@

# Environments
$Envs = "Prod", "NonProd"

# DBS or Standard
$BUs = "DBS", "STD"

# -----------------
# Process
# -----------------

If (!(Test-Path -Path $jsonFolder)) {
  New-Item -ItemType "directory" -Path $jsonFolder | Out-Null
}

$Report = @()
ForEach ($bu in $BUs) {
  ForEach ($env in $Envs) {
    $NSGType.Split("`n").Trim() | ForEach {
      $snType = $_

      Switch ($bu) {
        Default    {$bu1 = $bu.ToLower()}
      }

      Switch ($env) {
        "Prod"    {$env1 = "p"}
        "nonProd" {$env1 = "np"}
      }

      Switch ($snType) {
        "VM"                      {$nsg_type = "vm"}
        "NormalSubnet"            {$nsg_type = "sn"}
        "RestrictedNormalSubnet"  {$bu1 = "rst"; $nsg_type = "sn"}
        "DBMigrationSubnet"       {$nsg_type = "sn_dbms"}
        "APIMgmtSubnet"           {$nsg_type = "sn_apim"}
        default                   {$nsg_type = "sn_" + ( $snType.Replace("Subnet", "").ToLower() ) }
      }
      $subnet_nsg_type = "$($env1)-$($bu1)-$($nsg_type)"


      $armTemplate = If ($ExportARMTemplate) {"-ExportARMTemplate"} Else {$Null}
      $cmd = ( "$($ConcatRuleScriptPath)/ConcatRulesForTesting.ps1 -Environment $($env) -Type $($snType) -RulesPath '$($ConcatRuleScriptPath)/Rules' -OutputFile '$($jsonFolder)/$($subnet_nsg_type).json' $($armTemplate)" )

      If ($bu -eq "DBS") {
        $extraSwitch = " -DBS"
      }
      Else {
        $extraSwitch = $Null
      }
  
      $cmd +=  $extraSwitch
      $rpt = Invoke-Expression  $cmd
 
      ForEach ($rule in $rpt["CSV"]) {
        $Report += [PSCustomObject][Ordered]@{
          BU                        = $bu
          Env                       = $env
          SubnetType                = $snType
          nsg_type                  = $subnet_nsg_type
          RuleType                  = $rule.RuleType
          SourceFileName            = $rule.SourceFileName
          direction                 = $rule.direction
          priority                  = $rule.priority
          name                      = $rule.name
          sourcePortRange           = $rule.sourcePortRange
          destinationPortRange      = $rule.destinationPortRange
          protocol                  = $rule.protocol
          sourceAddressPrefix       = $rule.sourceAddressPrefix
          destinationAddressPrefix  = $rule.destinationAddressPrefix
          access                    = $rule.access
        }
      }
    }
  }
}

#Export to CSV
$columnOrder = @("BU", "Env", "SubnetType", "RuleType", "SourceFileName", "nsg_type", "direction", "priority", "name", "sourcePortRange", "destinationPortRange", "protocol", "sourceAddressPrefix", "destinationAddressPrefix", "access")
If ($ExportCSV) {$Report | Select-Object $columnOrder | Export-CSV "$jsonFolder/_allNSGRules.csv" -NoTypeInfo}  # $columnOrder matches Azure Portal NSG rule column order.

$Report
