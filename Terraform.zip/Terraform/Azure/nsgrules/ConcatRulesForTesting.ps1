# | ----------------------------------------------------------------------------------
# | File : ConcatRulesForTesting.ps1                                          
# | Version : 1.00                                         
# | Purpose : Script used for testing to combine NSG rules to make sure it matches Production
# | 
# | ----------------------------------------------------------------------------------
# | Maintenance History                                            
# | -------------------                                            
# | Name            Date         Version  Description        
# | ------------------------------------------------------------------------------------------
# | Jaime Liu       11-05-2019   1.00     Creation
# | Lok Liu         10-20-2020   1.1      Add extra subnet type (Redis, Application Gateway);
# |                                       Add feature to export as CSV.
# | Lok Liu         01-08-2021   1.2      Add support for export as ARM Template using
# |                                         ConvertTo-ARMTemplate.ps1
# | Lok Liu         02-18-2021   1.3      Add Restricted subnet type (np-rst-sn & p-rst-sn),
# |                                          and fix error in VM subnet NSG.
# | ------------------------------------------------------------------------------------------

<#
    .SYNOPSIS
        Combine Rules for checking
    .DESCRIPTION
        FA NSG rules have been templatized into categories. This script is useful for combining the rules for 
        a specific NSG type to make sure said type has all the correct rules.
    .PARAMETER Environment
        Environment to retrieve appopriate NSG rules for. Values allowed:
        - NonProd
        - Prod
    .PARAMETER Type
        The NSG type to retrieve NSG rules for combining. Values allowed:
        - NormalSubnet - Subnet without any service-specific rules, most likely for VM subnet
        - RestrictedNormalSubnet - Subnet without any service-specific rules, and no east-west traffic
        - VM - VM level NSG, VM subnet NSG use "NormalSubnet" or "RestrictedNormalSubnet"
        - AKSSubnet - Subnet used for Azure Kubernetes Services
        - ASESubnet - Subnet used for App Service Environments
        - SQLMISubnet - Subnet used for SQL Managed Instance
        - DBMigrationSubnet - Subnet used for Database Migratin Service
        - APIMgmtSubnet - Subnet used for API Management
        - RedisSubnet - Subnet used for Redis cache
        - AppGatewaySubnet - Subnet used for Application Gateway

    .PARAMETER DBS
        Is the NSG going to be inside a DBS subscription?
        Default is false
    .PARAMETER RulesPath
        Path to the local root directory where the rules are located at
    .PARAMETER OutputFile
        Name and path to place the combined NSG file in
        Default is ./NSG-Test.json
    .INPUTS
        String
        Switch
    .OUTPUTS
        PSCustomObject
#>
Param(
    [Parameter(Mandatory=$true)][ValidateSet("NonProd", "Prod")]
    [String] $Environment,
    [Parameter(Mandatory=$true)][ValidateSet("NormalSubnet", "RestrictedNormalSubnet", "AKSSubnet", "ASESubnet", "SQLMISubnet", "VM", "DBMigrationSubnet", "APIMgmtSubnet", "RedisSubnet", "AppGatewaySubnet")]
    [String] $Type,
    [Parameter(Mandatory=$false)]
    [switch] $DBS,
    [Parameter(Mandatory=$false)]
    [String] $RulesPath = "./Rules",
    [Parameter(Mandatory=$false)]
    [String] $OutputFile = "./NSG-Test.json",
    [Switch] $ExportARMTemplate
)

###########################
# Function
###########################
Function Add-ExtraInfo {
    Param (
        $Rules,
        $Type,
        $SourceFileName,
        [Switch]$SourceFileNameRelativePath = $True
    )

    $ruleSet = @()
    ForEach ($rule in $Rules) {
         If ($SourceFileNameRelativePath) {
            $filePathName = "/Rules/" + ( $SourceFileName -Split("/Rules/") | Select-Object -Last 1 )
        }
        Else {
            $filePathName = $SourceFileName
        }

        $ruleSet += [PSCustomObject][Ordered]@{
            RuleType                  = $Type
            SourceFileName            = $filePathName
            direction                 = $rule.direction
            priority                  = $rule.priority
            name                      = $rule.name
            sourcePortRange           = $rule.sourcePortRange -Join ", "
            destinationPortRange      = $rule.destinationPortRange -Join ", "
            protocol                  = $rule.protocol -Join ", "
            sourceAddressPrefix       = $rule.sourceAddressPrefix -Join ", "
            destinationAddressPrefix  = $rule.destinationAddressPrefix -Join ", "
            access                    = $rule.access
        }
    }
    Return $ruleSet
}

###########################
# Main
###########################

<#
    Based on nsg-global-rules.tf

    NSG Type   _1. Base/Global  _2. Env             _3. SubnetBase         _4. Service-Specific Subnet (Shared)         _5. App-Specific Subnet (Unique to each App)
    --------   --------------  ------------------   ------------------     ---------------------------------------  ------------------------------------------
    np-std-vm  Base_ruleset    GenNonProd_ruleset
    np-std-sn  Base_ruleset    GenNonProd_ruleset   SubnetBase_ruleset[ALL]  aks/ase/apim/dbm/sqlmi/redis/appgateway  APP0001234, APP0002323......
    np-rst-sn  Base_ruleset    GenNonProd_ruleset   SubnetBase_ruleset[2]
    np-dbs-vm  Base_ruleset    DBSNonProd_ruleset   SubnetBase_ruleset[ALL]
    np-dbs-sn  Base_ruleset    DBSNonProd_ruleset   SubnetBase_ruleset       aks/ase/apim/dbm/sqlmi/redis/appgateway
    p-std-vm   Base_ruleset    GenProd_ruleset
    p-std-sn   Base_ruleset    GenProd_ruleset      SubnetBase_ruleset[ALL]  aks/ase/apim/dbm/sqlmi/redis/appgateway
    p-rst-sn   Base_ruleset    GenProd_ruleset      SubnetBase_ruleset[2]
    p-dbs-vm   Base_ruleset    DBSProd_ruleset
    p-dbs-sn   Base_ruleset    DBSProd_ruleset      SubnetBase_ruleset[ALL]  aks/ase/apim/dbm/sqlmi/redis/appgateway
#>

# Get rule locations
$rulesFileList = Get-ChildItem $RulesPath -Recurse -Filter "*.json" | Foreach-Object FullName

# If run on Windows, file path is separated by "\".
# Change this to "/" to match the filter criteria below.
$rulesFileList  = $rulesFileList -Replace("\\", "/")

$ruleList2 = @()

# Init memory to base rules
# _1. Base_ruleset -- for All subnet types -- apply to all subnet for VM, DBS and Standard (non-DBS)
$tempRulesList = Get-Content ($rulesFileList | Where-Object { $_ -like "*BaseRules.json" }) | Out-String | ConvertFrom-Json 
$ruleList2 += Add-ExtraInfo -Rules $tempRulesList.securityRules -Type "1. Global" -SourceFileName ($rulesFileList | Where-Object { $_ -like "*BaseRules.json" })


# Add Environment specific rules to memory
# _2. 
If ($Environment -eq "NonProd"){
    If ($DBS) {
        # np-dbs-(vm | sn)
        # DBSNonProd_ruleset
        $tmpRule = (Get-Content ($rulesFileList | Where-Object { $_ -like "*Environment/Non-Prod.json" }) | Out-String | ConvertFrom-Json).securityRules
        $tempRulesList.securityRules += $tmpRule
        $ruleList2 += Add-ExtraInfo -Rules $tmpRule -Type "2. NonProd-DBS" -SourceFileName ($rulesFileList | Where-Object { $_ -like "*Environment/Non-Prod.json" })
    }
    Else {
        # np-std-(vm | sn) -OR- np-rst-sn
        # GenNonProd_ruleset 
        $tmpRule = (Get-Content ($rulesFileList | Where-Object { $_ -like "*NonDBS/Non-Prod.json" }) | Out-String | ConvertFrom-Json).securityRules
        $tempRulesList.securityRules += $tmpRule
        $ruleList2 += Add-ExtraInfo -Rules $tmpRule -Type "2. NonProd-Standard" -SourceFileName ($rulesFileList | Where-Object { $_ -like "*NonDBS/Non-Prod.json" })
    }
}
Else {  #Prod
    If ($DBS) {
        # p-dbs-(vm | sn)
        # DBSProd_ruleset
        $tmpRule = (Get-Content ($rulesFileList | Where-Object { $_ -like "*Environment/Prod.json" }) | Out-String | ConvertFrom-Json).securityRules
        $tempRulesList.securityRules += $tmpRule
        $ruleList2 += Add-ExtraInfo -Rules $tmpRule -Type "2. Prod-DBS" -SourceFileName ($rulesFileList | Where-Object { $_ -like "*Environment/Prod.json" })
    }
    Else {
        # p-std-(vm | sn) -OR- p-rst-sn
        # GenProd_ruleset
        $tmpRule = (Get-Content ($rulesFileList | Where-Object { $_ -like "*NonDBS/Prod.json" }) | Out-String | ConvertFrom-Json).securityRules
        $tempRulesList.securityRules += $tmpRule
        $ruleList2 += Add-ExtraInfo -Rules $tmpRule -Type "2. Prod-Standard" -SourceFileName ($rulesFileList | Where-Object { $_ -like "*NonDBS/Prod.json" })
    }
}

# Add NSG type specific rules to memory
If ($Type -ne "VM") {
    # _3. Only for subnet type (-sn)
    If ( ($Type -Match "Restricted") -And (!$DBS) ) {
        $tmpRule = (Get-Content ($rulesFileList | Where-Object { $_ -like "*SubnetBase.json" }) | ConvertFrom-Json).securityRules | Select-Object -Last 1
        $tempRulesList.securityRules += $tmpRule
        $ruleList2 += Add-ExtraInfo -Rules $tmpRule -Type "3. SubnetBase (Restricted)" -SourceFileName ($rulesFileList | Where-Object { $_ -like "*SubnetBase.json" })
    }
    ElseIf ( ($Type -Match "Restricted") -And ($DBS) )  {
        # No Restricted subnet type for DBS
        $tempRulesList = $Null
        $ruleList2 = $Null
    }
    Else {
        $tmpRule = (Get-Content ($rulesFileList | Where-Object { $_ -like "*SubnetBase.json" }) | ConvertFrom-Json).securityRules
        $tempRulesList.securityRules += $tmpRule
        $ruleList2 += Add-ExtraInfo -Rules $tmpRule -Type "3. SubnetBase" -SourceFileName ($rulesFileList | Where-Object { $_ -like "*SubnetBase.json" })
    }

    switch ($Type){
        "NormalSubnet" { 
            # Subnet for VM:
            # _1. Global,
            # _2. Env and
            # _3. SubnetBase
        }

        "RestrictedNormalSubnet" { 
            # Subnet for VM:
            # _1. Global,
            # _2. Env and
            # _3. SubnetBase[2]
        }

        "AKSSubnet" {
            # _4. aks
            $tmpRule = (Get-Content ($rulesFileList | Where-Object { $_ -like "*/AKS.json" }) | Out-String | ConvertFrom-Json).securityRules
            $tempRulesList.securityRules += $tmpRule
            $ruleList2 += Add-ExtraInfo -Rules $tmpRule -Type "4. AKSSubnet" -SourceFileName ($rulesFileList | Where-Object { $_ -like "*/AKS.json" })
        }

        "ASESubnet" {
            # _4. ase
            $tmpRule = (Get-Content ($rulesFileList | Where-Object { $_ -like "*/ASE.json" }) -Raw | ConvertFrom-Json).securityRules    # error when not using -Raw
            $tempRulesList.securityRules += $tmpRule
            $ruleList2 += Add-ExtraInfo -Rules $tmpRule -Type "4. ASESubnet" -SourceFileName ($rulesFileList | Where-Object { $_ -Like "*/ASE.json" })
        }

        "SQLMISubnet" {
            # _4. sqlmi
            $tmpRule = (Get-Content ($rulesFileList | Where-Object { $_ -like "*/SQLMI.json" }) | Out-String | ConvertFrom-Json).securityRules
            $tempRulesList.securityRules += $tmpRule
            $ruleList2 += Add-ExtraInfo -Rules $tmpRule -Type "4. SQLMISubnet" -SourceFileName ($rulesFileList | Where-Object { $_ -like "*/SQLMI.json" })
        }

        "DBMigrationSubnet" {
            # _4. dbms
            $tmpRule = (Get-Content ($rulesFileList | Where-Object { $_ -like "*/DBMS.json" }) | Out-String | ConvertFrom-Json).securityRules
            $tempRulesList.securityRules += $tmpRule
            $ruleList2 += Add-ExtraInfo -Rules $tmpRule -Type "4. DBMigrationSubnet" -SourceFileName ($rulesFileList | Where-Object { $_ -like "*/DBMS.json" })
        }

        "APIMgmtSubnet" {
            # _4. apim
            $tmpRule = (Get-Content ($rulesFileList | Where-Object { $_ -like "*/APIM.json" }) | Out-String | ConvertFrom-Json).securityRules
            $tempRulesList.securityRules += $tmpRule
            $ruleList2 += Add-ExtraInfo -Rules $tmpRule -Type "4. APIMgmtSubnet" -SourceFileName ($rulesFileList | Where-Object { $_ -like "*/APIM.json" })
        }

        "RedisSubnet" {
            # _4. redis
            $tmpRule = (Get-Content ($rulesFileList | Where-Object { $_ -like "*/Redis.json" }) | Out-String | ConvertFrom-Json).securityRules
            $tempRulesList.securityRules += $tmpRule
            $ruleList2 += Add-ExtraInfo -Rules $tmpRule -Type "4. RedisSubnet" -SourceFileName ($rulesFileList | Where-Object { $_ -like "*/Redis.json" })
        }

        "AppGatewaySubnet" {
            # _4. appgateway
            $tmpRule = (Get-Content ($rulesFileList | Where-Object { $_ -like "*/AppGateway.json" }) | Out-String | ConvertFrom-Json).securityRules
            $tempRulesList.securityRules += $tmpRule
            $ruleList2 += Add-ExtraInfo -Rules $tmpRule -Type "4. AppGatewaySubnet" -SourceFileName ($rulesFileList | Where-Object { $_ -like "*/AppGateway.json" })
        }
    }
}
Else {
    # Do Nothing for $Type = "VM"
    # (-vm)
    # This is for use with VM NSG (non-subnet); for VM subnet NSG, use "NormalSubnet".
    # VM_NSG is a combination of 
    #    1. Global, and 
    #    2. Env only.
}

# Sort the rules
If ($tempRulesList) {
    $finalRules = New-Object -TypeName PSObject -Property @{ "securityRules" = @() }
    $tempRules = $tempRulesList.securityRules | Sort-Object -Property @{Expression = "direction"; Descending = $false}, @{Expression = "priority"; Descending = $false}
    $finalRules.securityRules = $tempRules
}


# Convert to CSV
If ($ruleList2) {
    $finalRulesCSV = $ruleList2 | Sort-Object -Property @{Expression = "direction"; Descending = $false}, @{Expression = "priority"; Descending = $false}
}

If ($finalRules) {
    # Output rules into a file
    if (Test-Path $OutputFile) {
        Remove-Item $OutputFile -Force
    }

    $finalRules | ConvertTo-Json -depth 100 | Out-File $OutputFile
    If ($ExportARMTemplate) {
        (./ConvertTo-ARMTemplate.ps1 -NSGJson $finalRules) | Out-File ($OutputFile -Replace(".json", "-ARMTemplate.json"))
    }
}

# Return rules
return @{
    "JSON" = $finalRules
    "CSV"  = $finalRulesCSV
}
