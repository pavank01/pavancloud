# Azure NSG Service Rule Module by Azure Product Team

## Table of Contents

[Introduction](#introduction)

[variables.tf](#variables)

[nsg-service-rules.tf](#nsg-service-rules)

[outputs.tf](#outputs)

[examples](#examples)

## Introduction
The `nsg-service-rules` directory holds the FA custom template designed to ingest network security group (nsg) rules from a predetermined set of .json files and apply them to a specific supplied nsg.  

The .json files ingested by this module contain rules required for function of the following services:

Azure Kubernetes Service (AKS)
Application Service Environment (ASE)
API Management (APIM)
Database Migration Service (DBM)
SQL Managed Instance (SQLMI)

## nsg-service-rules
This terraform module takes in nsg rule sets from .json files that are needed for specific azure services and applies them to an nsg based on what type of service will be using the subnet that the nsg will be applied to. User supplies resource group name, nsg name, subnet cidr, and type of service to be used.  

## variables
File containing the list of parameters that the module accepts. 
Parameters include:
    resource_group_name 
        type        = string
        description = "(Required) The name for the resource group that the  
        default value = none
 
    network_security_group_name
        type        = string
        description = "(Required) The name of NSG that rules will be associated with"
        default value = none

    subnet_address_space
        type        = string
        description = "(Required) Subnet that the rule will be applied to or in valid input must be the form ###.###.###.###/## 10.10.10.10/24"
        default     = none

    service_type
        type        = string
        description = "(Required) Identifies what the NSG will be used for and is used to build the rule set
        valid values:  
                        "aks"   - for Azure Kubernetes Service
                        "ase"   - for Application Service Environment 
                        "apim"  - for API Management
                        "dbm"   - for Database Migration Service
                        "sqlmi" - for SQL Managed Instance

## outputs
None

## Examples:

### Attach Service Specific Security rules for a api mgmt subnet

```Terraform
module "nsg-service-rules" {
    source                          = "git::https://facloud.visualstudio.com/AzureNSGRules/_git/AzureNSGRules//modules/nsg-global-rules"
    resource_group_name             = "AZUR-N-1-SOSG-RG-1"
    network_security_group_name     = "S-10.65.8.16-28-NSG"
    subnet_address_space            = "10.65.8.16/28"
    service_type                    = "apim"
}
```

### Attach Service Specific Security rules for a sql migration subnet

```Terraform
module "nsg-service-rules" {
    source                          = "git::https://facloud.visualstudio.com/AzureNSGRules/_git/AzureNSGRules//modules/nsg-service-rules"
    resource_group_name             = "AZUR-N-1-SOSG-RG-1"
    network_security_group_name     = "S-10.65.8.16-28-NSG"
    subnet_address_space            = "10.65.8.16/28"
    service_type                    = "sqlmi"
}
```
