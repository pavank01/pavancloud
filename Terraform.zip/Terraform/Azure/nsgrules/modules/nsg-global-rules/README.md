# Azure NSG Global Rule Module by Azure Product Team

## Table of Contents

[Introduction](#introduction)

[variables.tf](#variables)

[nsg-global-rules.tf](#nsg-global-rules)

[outputs.tf](#outputs)

[examples](#examples)

## Introduction
The `nsg-global-rules` directory holds the FA custom template intended to apply approved sets of network security group (nsg) global firewall rules to user provided nsg. The set of global rules to apply are determined based on user input about the environment that the nsg will be applied to.

## nsg-global-rules
This terraform module takes in global nsg rule sets from .json files, determines what set to apply based on values provided by the use, and applies them to an nsg that is also supplied by the user. User supplies resource group name, nsg name, subnet cidr, and an identifier that tells what environment the nsg will be applied to.  

## variables
File containing the list of parameters that the module accepts. 
Parameters include:
    resource_group_name 
        type          = string
        description   = "(Required) The name for the resource group that the  
        default value = none
 
    network_security_group_name
        type          = string
        description   = "(Required) The name of NSG that rules will be associated with"
        default value = none

    virtual_network_address_space
        type          = string
        description   = "(Required) Subnet that the rule will be applied to or in valid input must be the form ###.###.###.###/## 10.10.10.10/24"
        default       = none

    service_type
        type          = string
        description   = "(Required) Identifies what the NSG will be used for and is used to build the rule set; valid options are in the form [np|p-std|dbs-vm|sn]"
        valid values:  
                      "np-std-vm" - non-production standard virtual machine
                      "np-std-sn" - non-production standard subnet
                      "np-dbs-vm" - non-production database solutions virtual machine
                      "np-dbs-sn" - non-production database solutions subnet
                      "p-std-vm" - production standard virtual machine
                      "p-std-sn" - production standard subnet
		              "p-dbs-vm" - production database solutions virtual machine
		              "p-dbs-sn" - production database solutions subnet

## outputs
None at this time

## Examples

### Attach Global Security rules for a non-production standard subnet
```Terraform

module "nsg-global-rules" {
    source                        = "git::https://facloud.visualstudio.com/AzureNSGRules/_git/AzureNSGRules//modules/nsg-global-rules"
    resource_group_name           = "AZUR-N-1-SOSG-RG-1"
    network_security_group_name   = "S-10.65.17.0-28-NSG"
    subnet_address_space          = "10.65.17.0/28"
    ruleset_type                  = "np-std-sn"
}

```
### Attach Service Specific Security rules for a production dns subnet
```Terraform

module "nsg-global-rules" {
    source                      = "git::https://facloud.visualstudio.com/AzureNSGRules/_git/AzureNSGRules//modules/nsg-service-rules"
    resource_group_name         = "DBSM-P-1-SOSG-RG-1"
    network_security_group_name = "S-10.65.128.96-27-NSG"
    subnet_address_space        = "10.65.128.96/27"
    ruleset_type                = "p-dbs-sn"
}

```