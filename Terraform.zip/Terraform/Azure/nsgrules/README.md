# ConcatRulesForTesting.ps1

## Table of Contents
[Introduction](#introduction)

[Parameters](#parameters)

[Usage Samples](#usage-samples)

## Introduction
FA NSG rules have been centralized and templatized into categories. This script is useful for combining the rules for a specific NSG type to make sure said type has all the correct rules.

## Parameters

### Environment (String)
Environment to retrieve appopriate NSG rules for. Values allowed:

- NonProd
- Prod

### Type (String)
The NSG type to retrieve NSG rules for combining. Values allowed:

- NormalSubnet - Subnet used for VMs and scalesets
- AKSSubnet - Subnet used for Azure Kubernetes Services
- ASESubnet - Subnet used for App Service Environments
- SQLMISubnet - Subnet used for SQL Managed Instance
- DBMigrationSubnet - Subnet used for DB Migration Service
- VM - NSG is for VMs

### DBS (Switch)
Is the NSG going to be inside a DBS subscription?
Default is false

### OutputFile (String)
Name and path to place the combined NSG file in
Default is .\NSG-Test.json

## Usage Samples

### NSG rules for Non-Prod VM for non-DBS subscriptions

```PowerShell
ConcatRulesForTesting.ps1 -Environment NonProd -Type VM -OutputFile .\FA-NonProd-VM-NSG.json 
```

### NSG rules for Non-Prod VM for DBS subscriptions

```PowerShell
ConcatRulesForTesting.ps1 -Environment NonProd -Type VM -DBS -OutputFile .\FA-NonProd-DBS-VM-NSG.json 
```

### NSG rules for Prod AKS Subnet for non-DBS subscription

```PowerShell
ConcatRulesForTesting.ps1 -Environment Prod -Type AKSSubnet -OutputFile .\FA-Prod-AKS-Subnet-NSG.json 
```

### NSG rules for Prod Normal Subnet (for VMs) for DBS subscription

```PowerShell
ConcatRulesForTesting.ps1 -Environment Prod -Type NormalSubnet -DBS -OutputFile .\FA-Prod-DBS-Subnet-NSG.json 
```
