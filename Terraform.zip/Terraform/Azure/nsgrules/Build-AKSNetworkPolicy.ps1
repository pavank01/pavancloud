[CmdletBinding()]
param(
    $JSON,
    [String] $OutputPath
)

Function Add-CIDRBlock {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()]
        $cidrBlock
    )

    $cidrList = @()

    foreach ($cidr in $cidrBlock) {
        if ($cidr -match "/") {
            $cidrList += @{
                ipBlock = @{
                    cidr = $cidr
                }
            }
        }
        else {
            $cidrList += @{
                ipBlock = @{
                    cidr = ($cidr + "/32")
                }
            }
        }
    }

    return $cidrList
}

Function Add-PortRange {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()]
        $protocol,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()]
        $portRange
    )

    $portList = @()

    if ($protocol -eq "*") {
        $portList += @{
            protocol = $protocol
        }
    }
    else {
        foreach ($port in $portRange) {
            if ($port -match "-") {
                $splitPort = $port.Split("-")
                $portList += [ordered]@{
                    protocol = $protocol
                    port     = [int]$splitPort[0]
                    endPort  = [int]$splitPort[1]
                }
            }
            else {
                $portList += [ordered]@{
                    protocol = $protocol
                    port     = [int]$port
                }
            }
        }
    }

    return $portList
}

Function Add-InboundRule {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()]
        $rule
    )

    if ($rule.sourceAddressPrefix -match $regex) {

        if ($rule.protocol -eq "*" -and $rule.destinationPortRange -eq "*") {
            return @{from = @(Add-CIDRBlock $rule.sourceAddressPrefix) }
        }

        if ($rule.protocol -eq "TCP" -or $rule.protocol -eq "UDP") {
            return [ordered]@{from = @(Add-CIDRBlock $rule.sourceAddressPrefix); ports = @(Add-PortRange $rule.protocol $rule.destinationPortRange) }
        }

        if ($rule.protocol -eq "*" -and $rule.destinationPortRange -ne "*") {
            $combinedProtocolRules = @()
            $combinedProtocolRules += [ordered]@{from = @(Add-CIDRBlock $rule.sourceAddressPrefix); ports = @(Add-PortRange "TCP" $rule.destinationPortRange) }
            $combinedProtocolRules += [ordered]@{from = @(Add-CIDRBlock $rule.sourceAddressPrefix); ports = @(Add-PortRange "UDP" $rule.destinationPortRange) }
            return $combinedProtocolRules
        }
    } else {
        return
    }
}

Function Add-OutboundRule {
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()]
        $rule
    )

    if ($rule.destinationAddressPrefix -match $regex) {

        if ($rule.protocol -eq "*" -and $rule.destinationPortRange -eq "*") {
            return @{to = @(Add-CIDRBlock $rule.destinationAddressPrefix) }
        }

        if ($rule.protocol -eq "TCP" -or $rule.protocol -eq "UDP") {
            return [ordered]@{to = @(Add-CIDRBlock $rule.destinationAddressPrefix); ports = @(Add-PortRange $rule.protocol $rule.destinationPortRange) }
        }

        if ($rule.protocol -eq "*" -and $rule.destinationPortRange -ne "*") {
            $combinedProtocolRules = @()
            $combinedProtocolRules += [ordered]@{to = @(Add-CIDRBlock $rule.destinationAddressPrefix); ports = @(Add-PortRange "TCP" $rule.destinationPortRange) }
            $combinedProtocolRules += [ordered]@{to = @(Add-CIDRBlock $rule.destinationAddressPrefix); ports = @(Add-PortRange "UDP" $rule.destinationPortRange) }
            return $combinedProtocolRules
        }
    } else {
        return
    }
}

if ($JSON) {

    $ruleList = (Get-Content $JSON | ConvertFrom-Json).securityRules
    $fileName = "aks-global-rules"
    # Regex to match either IPv4 address or CIDR block
    # https://stackoverflow.com/questions/31178400/regex-to-extract-an-ip-address-from-a-string
    $regex = [regex] "\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b"
    $inboundRules = @()
    $outboundRules = @()

    foreach ($rule in $ruleList) {
        if (($rule.priority -lt 4000) -and ($rule.direction -eq "Inbound")) {
            $inboundRules += Add-InboundRule $rule
        }
        elseif (($rule.priority -lt 4000) -and ($rule.direction -eq "Outbound")) {
            $outboundRules += Add-OutboundRule $rule
        }
        else {
            Write-Host "$($rule.name) not processed."
        }
    }

    $globalRulesYAML = [pscustomobject][ordered]@{
        apiVersion = "networking.k8s.io/v1"
        kind       = "NetworkPolicy"
        metadata   = @{name = "global-rules-network-policy" }
        spec       = @{podSelector = @{}; policyTypes = @("Ingress"; "Egress") }
        ingress    = $inboundRules
        egress     = $outboundRules
    }

    $globalRulesYAML | ConvertTo-Json -Depth 9 | yq eval - --prettyPrint | Out-File $OutputPath/$fileName.yaml -Encoding UTF8
}
else {
    Write-Error "No JSON file containing rules found."
}