﻿# | ----------------------------------------------------------------------------------
# | File : Validate-BaseRulesJson.ps1
# | Version : 1.0.0                                         
# | Purpose : Script to validate the NSG Base Rules Json file and the IP address inside them.
# | 
# | ----------------------------------------------------------------------------------
# | Maintenance History                                            
# | -------------------                                            
# | Name            Date         Version  Description        
# | ----------------------------------------------------------------------------------------------------
# | Akhil M        11-12-2021     1.0      Creation
# | ----------------------------------------------------------------------------------------------------
param(
    [String]$JsonPath
)

function Get-IPrangeStartEnd {
    <# 
	  .SYNOPSIS  
	    Get the IP addresses in a range 
	  .EXAMPLE 
	   Get-IPrangeStartEnd -start 192.168.8.2 -end 192.168.8.20 
	  .EXAMPLE 
	   Get-IPrangeStartEnd -ip 192.168.8.2 -mask 255.255.255.0 
	  .EXAMPLE 
	   Get-IPrangeStartEnd -ip 192.168.8.3 -cidr 24 
	#> 
	 
    param ( 
        [string]$start, 
        [string]$end, 
        [string]$ip, 
        [string]$mask, 
        [int]$cidr 
    ) 
	 
    function IP-toINT64 () { 
        param ($ip) 
	 
        $octets = $ip.split(".") 
        return [int64]([int64]$octets[0] * 16777216 + [int64]$octets[1] * 65536 + [int64]$octets[2] * 256 + [int64]$octets[3])
    } 
	 
    function INT64-toIP() { 
        param ([int64]$int) 

        return (([math]::truncate($int / 16777216)).tostring() + "." + ([math]::truncate(($int % 16777216) / 65536)).tostring() + "." + ([math]::truncate(($int % 65536) / 256)).tostring() + "." + ([math]::truncate($int % 256)).tostring() )
    } 
	 
    if ($ip) { $ipaddr = [Net.IPAddress]::Parse($ip) } 
    if ($cidr) { $maskaddr = [Net.IPAddress]::Parse((INT64-toIP -int ([convert]::ToInt64(("1" * $cidr + "0" * (32 - $cidr)), 2)))) } 
    if ($mask) { $maskaddr = [Net.IPAddress]::Parse($mask) } 
    if ($ip) { $networkaddr = new-object net.ipaddress ($maskaddr.address -band $ipaddr.address) } 
    if ($ip) { $broadcastaddr = new-object net.ipaddress (([system.net.ipaddress]::parse("255.255.255.255").address -bxor $maskaddr.address -bor $networkaddr.address)) } 
	 
    if ($ip) { 
        $startaddr = IP-toINT64 -ip $networkaddr.ipaddresstostring 
        $endaddr = IP-toINT64 -ip $broadcastaddr.ipaddresstostring 
    }
    else { 
        $startaddr = IP-toINT64 -ip $start 
        $endaddr = IP-toINT64 -ip $end 
    } 
	 
    $temp = "" | Select start, end
    $temp.start = INT64-toIP -int $startaddr
    $temp.end = INT64-toIP -int $endaddr
    return $temp
}
# Test if JSON is valid or Not.
$IsValid = Get-Content $JsonPath -Raw | Test-Json 
if ($IsValid) {
    $Result = "Success"
    Write-Host "Valid Json." -ForegroundColor Green
    $Json = try { Get-Content $JsonPath -Raw | ConvertFrom-Json } catch { $null }
    if ($Json -ne $null) {
        # Test IP's/CIDR's are valid or Not, If the json is valid.
        $sourceAddressPrefix = $Json.securityRules.sourceAddressPrefix
        $destinationAddressPrefix = $Json.securityRules.destinationAddressPrefix
        $AddressPrefixes = $sourceAddressPrefix + $destinationAddressPrefix       
    
        foreach ($Address in $AddressPrefixes) {
            if ($Address -notin ('*', 'VirtualNetwork', 'AzureLoadBalancer', 'AzureMonitor', 'Storage', 'AzureKeyVault')) {
                $IPCheck = ($Address -as [IPaddress]) -as [Bool]
                if ($IPCheck) {
                    # Write-Host "$Address is valid"
                }
                elseif ($Address -like "*/*") {
                    $cidr = $Address.split("/")
                    if ([int]$cidr[1] -ge 0 -and [int]$cidr[1] -le 32) {

                        $StartIP = (Get-IPrangeStartEnd -ip $cidr[0] -cidr $cidr[1]).start
                        if ($StartIP -ne $cidr[0]) {                            
                            Write-Host $Address -ForegroundColor Red
                            Write-Output ("[Error] Invalid Range.")
                            $Result = "Failed"
                        }

                    }
                    else {
                        Write-Host $Address -ForegroundColor Red
                        Write-Output ("[Error] Invalid Subnet.")
                        $Result = "Failed"
                    }
                }
                else {
                    Write-Host $Address -ForegroundColor Red
                    Write-Output ("[Error] Address is Not Valid")
                    $Result = "Failed"
                }

            }
        }
    }
    else {        
        write-Host "Invalid Json."
        $Result = "Failed"
    }
}
else {
    $Result = "Failed"
}
if ($Result -eq "Failed") {
    # Fail the build Pipeline if Validation fails.
    Write-Output ("[Error] NSG Rules Validation - Failed")
    Write-Host "##vso[task.complete result=Failed;]Failed"
}
else {
    Write-Host "NSG Rules Validation - $Result"
}
