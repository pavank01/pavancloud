# Azure Resource Group

This repository contains a terraform module to deploy a Resource Group in Microsoft Azure Cloud

These types of resources are supported:

* [azurerm_resource_group](https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group)

## Usage:

The following example demonstrate how to use this module:

```hcl
module "azurerm_resource_group" {
    source    = "./modules/azurerm_resource_group"
    name      = "rg-1"
    location  = "eastus"
    tags = {
        customer     = "Customer1"
        region       = "eastus"
        environment  = "dev"
    }
}
```

## Conditional creation

## Terraform version

Terraform version v0.12.6 or newer is required for this module to work.

## AzureRM version

AzureRM provider version ">= 2.0" is required for this module to work.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|:----:|:-----:|:-----:|
| name | The name of the resource group to create | string |  | yes |
| location | The Azure region where Resource Group is created | string |  | yes |
| tags | The map of tags to apply to this resource | map(string) |  | no |

## Output variables

| Name | Description |
|------|-------------|
| id | The resource id for the resource group being deployed |
| name | Name of the resource group which is created |
