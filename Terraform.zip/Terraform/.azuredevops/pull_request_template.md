# Thank you for contributing to the Cloud Enablement Modules. Please ensure you follow the below steps prior to submitting your PR to get the appropriate reviews.

## Guide:
To generate the below logs on windows you can append your terraform command with `> file.txt` to automatically log the the output to a file on your local machine. Please also ensure to add the `-no-color` flag to any terraform command you intend to log to a file to ensure it is easily readable. 

## Change Description
Please detail your changes to this module so that the reviewers can better understand your code changes

## Validations
- [ ] Terraform Plan completes with no warnings or errors
- Please attach terraform plan as plan.txt (remove this line)
- [ ] Terraform apply completes with no warnings or errors
- Please attach terraform apply as apply.txt (remove this line)
- [ ] Terraform destroy completes with no warnings or errors
- Please attach terraform destroy as destroy.txt (remove this line)
- [ ] Attach a work item