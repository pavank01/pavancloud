﻿<#
.DESCRIPTION
Restore-FAAzureVM.ps1 will restore an Azure VM that has been
deleted along with it's disks. There are some assumptions:
1. There is an XML export from the VM prior to it's deletion.
2. The XML file will need to be modified prior to running this script.
Each disk in the XML file will need it's <DiskName> value changed
to the actual disk blob name (ie: AZUVNTSTAZUR200-OS.vhd).
3. You will need to be able to login as the local admin account.
The VM will need to be removed and re-added to the domain.
.PARAMETER ProdSubscription
The Azure subscription where the production VM is located.
.PARAMETER ProdService
The Azure cloud service where the production VM is located.
.PARAMETER ProdStorageAccount
The Azure storage account where the production blobs are
located.
.PARAMETER ProdStorageContainer
The Azure storage container where the production blobs are
located.
.PARAMETER VmToRestore
The Azure VM that you want to restore.
.PARAMETER BackupSubscription
The Azure subscription where the backup blob is located.
.PARAMETER BackupStorageAccount
The Azure storage account where the backup blob is located.
.PARAMETER BackupStorageContainer
The Azure storage container where the backup blob is located.
.EXAMPLE
.\Restore-FAAzureVM.ps1 -ProdSubscription SO-1-AzureSub-1 -ProdService SO-1-1-AZUR-CS-1 -ProdStorageAccount soa1s1azursa1 -ProdStorageContainer vhds -VmToRestore AZUVNTSTAZUR200 -BackupSubscription SO-1-AzureSub-3 -BackupStorageAccount soa1s3azursa1 -BackupStorageContainer backups
#>
param(

    [Parameter(Mandatory=$True)]
    [string]$ProdSubscription,

    [Parameter(Mandatory=$True)]
    [string]$ProdService,

    [Parameter(Mandatory=$True)]
    [string]$ProdStorageAccount,

    [Parameter(Mandatory=$True)]
    [string]$ProdStorageContainer,
        
    [Parameter(Mandatory=$True)]
    [string]$VmToRestore = $null,

    [Parameter(Mandatory=$True)]
    [string]$BackupSubscription,

    [Parameter(Mandatory=$True)]
    [string]$BackupStorageAccount,

    [Parameter(Mandatory=$True)]
    [string]$BackupStorageContainer,

    $ExportFolder = "C:\MyScripts\Azure\Backups\XMLExports",

    $ExportFileName = $VmToRestore + ".xml",

    $ExportPath = (Join-Path $ExportFolder $ExportFileName)

)

# Get the production and backup contexts
# -------------------------------------------------------------------

Select-AzureSubscription $BackupSubscription | Out-Null

$BackupKey = Get-AzureStorageKey -StorageAccountName $BackupStorageAccount

$BackupContext = New-AzureStorageContext -StorageAccountName $BackupStorageAccount -StorageAccountKey $BackupKey.Primary

Select-AzureSubscription $ProdSubscription | Out-Null

$ProdKey = Get-AzureStorageKey -StorageAccountName $ProdStorageAccount

$ProdContext = New-AzureStorageContext -StorageAccountName $ProdStorageAccount -StorageAccountKey $ProdKey.Primary

Select-AzureSubscription $BackupSubscription | Out-Null


# Get the backup blobs to restore
# -------------------------------------------------------------------

$BackupBlobs = Get-AzureStorageBlob -Blob ($VmToRestore + "*") -Container $BackupStorageContainer -Context $BackupContext.Context



# Restore VHDs from backup subscription
# -------------------------------------------------------------------

Select-AzureSubscription $BackupSubscription | Out-Null

foreach ($Blob in $BackupBlobs) {

    Start-AzureStorageBlobCopy -srcContext $BackupContext -SrcContainer $BackupStorageContainer -SrcBlob $Blob.Name -destContext $ProdContext -DestContainer $ProdStorageContainer -Force

    Get-AzureStorageBlob -Blob $Blob.Name -Context $ProdContext -Container $ProdStorageContainer | Get-AzureStorageBlobCopyState -WaitForComplete

}

Select-AzureSubscription $ProdSubscription | Out-Null

# Get the disk info for the production location
# -------------------------------------------------------------------

$RestoreBlobs = Get-AzureStorageBlob -Blob ($VmToRestore + "*") -Container $ProdStorageContainer -Context $ProdContext.Context


# Get the blob names to determine which is OS and Data
# -------------------------------------------------------------------

foreach ($Blob in $RestoreBlobs) {

    if ($Blob.Name -like "*-OS.vhd") {

        Add-AzureDisk -DiskName $Blob.Name -MediaLocation $Blob.ICloudBlob.StorageUri.PrimaryUri.AbsoluteUri -OS Windows

    } else {

        Add-AzureDisk -DiskName $Blob.Name -MediaLocation $Blob.ICloudBlob.StorageUri.PrimaryUri.AbsoluteUri
        
    }

}


# Reprovision VM
# -------------------------------------------------------------------

Import-AzureVM -Path $ExportPath | New-AzureVM -ServiceName $ProdService