﻿$Date = (Get-Date).ToString("yyyy-MM-dd")
$Month = (Get-Date).ToString("yyyy-MM")
$LastMonth = (Get-Date).AddMonths(-1).ToString("yyyy-MM")
$BillReportRoot = "E:\Scripts\Billing"
$PathToWebRoot = "C:\inetpub\wwwroot"
$BillingWebRoot = "C:\inetpub\wwwroot\billing"

$CurrentMTDFullName = "AzureBill-$Date-MTDFull.csv"
$CurrentMTDFullPath = Join-Path -Path $BillReportRoot -ChildPath $CurrentMTDFullName

$CurrentMTDParseName = "AzureBill-$Date-MTDParse.csv"
$CurrentMTDParsePath = Join-Path -Path $BillReportRoot -ChildPath $CurrentMTDParseName

$MTDSummaryHTMLPath = "E:\Scripts\Billing\MTDSummary.htm"

# Identify the latest full month report in the download directory
$LastMonthFullFiles = Get-ChildItem -Path C:\inetpub\wwwroot\billing -Filter *full.csv -File | Sort-Object -Property LastWriteTime -Descending
$LastMonthFullName = $LastMonthFullFiles[0].Name

# Identify the latest full month parsed report in the download directory
$LastMonthParseFiles = Get-ChildItem -Path C:\inetpub\wwwroot\billing -Filter *fullparse.csv -File | Sort-Object -Property LastWriteTime -Descending
$LastMonthParseName = $LastMonthParseFiles[0].Name

# Download MTD bill and save as CSV
$CurrentMTDReport = E:\Scripts\Download-FAAzureBillingData.ps1 -Month $Month -FileName $CurrentMTDFullPath

# Parse MTD bill
$CurrentMTDParse = E:\Scripts\Parse-AzureBill.ps1 -csvFileName $CurrentMTDFullPath |
    Select-Object -Property ApplicationCode,CostType,@{Name='Cost';Expression={[math]::Round($_.Cost,2)}} |
    Sort-Object -Property ApplicationCode,CostType
    
# Save MTD parse as CSV
$CurrentMTDParse | Export-Csv -Path $CurrentMTDParsePath -NoTypeInformation -Force

# Convert MTD parsed bill to HTML page
$CurrentMTDParse | ConvertTo-Html -Title "Month to Date Summary" -CssUri table_format.css -PreContent "<h1>Month to Date Summary for $Date</h1><p><pre><a href=""/billing/$LastMonthFullName"" download>Download $LastMonth full bill</a>     <a href=""/billing/$LastMonthParseName"" download>Download $LastMonth summary bill</a>     <a href=""/billing/$CurrentMTDParseName"" download>Download $Date MTD summary</a></pre></p>" |
    Out-File -FilePath $MTDSummaryHTMLPath -Force

# Copy MTD HTML web page to web directory
Copy-Item -Path $MTDSummaryHTMLPath -Destination $PathToWebRoot -Force

# Copy MTD parsed bill to download directory
Copy-Item -Path $CurrentMTDParsePath -Destination $BillingWebRoot -Force