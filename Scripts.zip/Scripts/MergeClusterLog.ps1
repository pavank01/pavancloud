<#
	.SYNOPSIS
		Merges Cluster Event Logs from each Cluster Node into a single CSV for evaluation.

	.DESCRIPTION
		Will generate the Cluster logs for all Nodes in a Cluster, copy the logs to a central folder, trim the logs to the specified time frame, merge the logs together in chronological order, and output a CSV file ready to be opened in Excel for evaluation. Will attempt to add the Node names next to the Node numbers and add the Node names next to the IP addresses in the log entries. The merged log will have a column for the Node name the specific entry came from and a column for the Node number.

	.PARAMETER ClusterName
		Cluster name or Node name to generate cluster log files to merge. Cluster log files will be generated on each node in C:\Temp\ClusterLogs before being copied to the NewClusterLogPath.
		* Cannot be used with ClusterLogFiles

	.PARAMETER ClusterLogFiles
		Cluster log files to merge. Can use wildcards.
		* Cannot be used with ClusterName
		* NOTE: This parameter is currently broken. It was originally designed to help with Windows 2008 Clusters. It broke due to changes added later to support getting the Node numbers.

	.PARAMETER NewClusterLogPath
		Path to all generated files
		* If not specified will create a folder under C:\Temp with the name provided to the ClusterName parameter

	.PARAMETER MergedClusterLogName
		New merged cluster log file name.
		* If not specified will use MergedClusterLog_yyyy-mm-dd_hh.mm.csv

	.PARAMETER EventTime
		Date / Time of failover event. New merged log will start 1 hour before and end 2 hours after this time.
		* Can use either 12 hour or 24 hour date time formats.
		* Cannot be used with StartTime and EndTime.

	.PARAMETER StartTime
		Date / Time for first log record.
		* Can use either 12 hour or 24 hour date time formats.
		* Must be used with EndTime.
		* Cannot be used with EventTime

	.PARAMETER EndTime
		Date / Time for last log record.
		* Can use either 12 hour or 24 hour date time formats.
		* Must be used with StartTime.
		* Cannot be used with EventTime

	.PARAMETER IncludeEventLogs
		Specifies that the Event Logs "Application", "System", "Setup", and "Microsoft-Windows-MsLbfoProvider/Operational" should be included.
		* These Event Logs may not have millisecond time resolution so will be grouped at the beginning of the second in which they occurred.

	.PARAMETER RemoveSourceLogs
		Deletes source cluster log files generated on each node in C:\Temp\ClusterLogs after completing the copies.

	.PARAMETER DontUseLocalTime
		Specifies that the time stamp for each cluster log entry should use Greenwich Mean Time (GMT) instead of local time.

	.OUTPUTS
		CSV File

	.NOTES
		Written by Ryan Amsbury
		v0.5
#>
[CmdletBinding()]
Param(
	# Node name to generate cluster log files to merge. Cluster log files will be generated on this node in C:\Temp\ClusterLogs
	[Parameter(ParameterSetName='ClusterNameAuto', Mandatory=$True)]
	[Parameter(ParameterSetName='ClusterNameCustom', Mandatory=$True)]
	[String]$ClusterName,

	# Cluster log files to merge. Can use wildcards.
	[Parameter(ParameterSetName='ClusterLogsAuto', Mandatory=$True)]
	[Parameter(ParameterSetName='ClusterLogsCustom', Mandatory=$True)]
	[String[]]$ClusterLogFiles,

	# Path to all generated files
	[Parameter()]
	[String]$NewClusterLogPath,

	# New merged cluster log file
	[Parameter()]
	[String]$MergedClusterLogName,

	# Date / Time of failover event. New merged log will start 1 hour before and end 2 hours after this time.
	[Parameter(ParameterSetName='ClusterNameAuto', Mandatory=$True)]
	[Parameter(ParameterSetName='ClusterLogsAuto', Mandatory=$True)]
	[String]$EventTime,

	# Date / Time for first log record
	[Parameter(ParameterSetName='ClusterNameCustom', Mandatory=$True)]
	[Parameter(ParameterSetName='ClusterLogsCustom', Mandatory=$True)]
	[String]$StartTime,

	# Date / Time for last log record
	[Parameter(ParameterSetName='ClusterNameCustom', Mandatory=$True)]
	[Parameter(ParameterSetName='ClusterLogsCustom', Mandatory=$True)]
	[String]$EndTime,

	# Specifies that the Event Logs should be included
	[Parameter()]
	[Switch]$IncludeEventLogs = $False,

	# Deletes source cluster log files from the cluster nodes after making local copies
	[Parameter()]
	[Switch]$RemoveSourceLogs = $False,

	# Specifies that the time stamp for each cluster log entry uses Greenwich Mean Time (GMT) otherwise it uses local time.
	[Parameter()]
	[Switch]$DontUseLocalTime = $False
)

<#

To manually create Cluster logs for Windows 2008 and and some Windows 2008 R2 do the following on all Cluster Nodes:
C:
cd\
md Temp
cd Temp
md ClusterLogs
cluster log /g /copy:ClusterLogs
cd ClusterLogs
dir

#>




# ---------------------------------------------------------------------------
Function Format-FileNameWithDate {
	# Function to create a file name with the date
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $False)]
		[String]$Prefix,
		[Parameter(Mandatory = $False)]
		[String]$Suffix = ".txt",
		[Parameter(Mandatory = $False)]
		[String]$DateFormat = "yyyy-MM-dd"
	)
	$TextDate = Get-Date -Format $DateFormat
	Return $Prefix + $TextDate + $Suffix
}
# ---------------------------------------------------------------------------
# Array of merged cluster log entries
$NewClusterLog = @()
# Hash of Cluster IPs and resolved names - This way each IP is resolved only one time
$ClusterIPs = @{}
# Calculate start and end times
If ($StartTime -ne "") {
	# StartTime provided
	$StartTime = [DateTime](Get-Date -Date $StartTime)
	If ($EndTime -ne "") {
		# EndTime provided
		$EndTime = [DateTime](Get-Date -Date $EndTime)
	} Else {
		# EndTime not provided
		$EndTime = Get-Date
	}
} ElseIf ($EventTime -ne "") {
	# EventTime provided
	$EventTime = [DateTime]$EventTime
	# 1 hour before EventTime
	$StartTime = (Get-Date -Date $EventTime).AddMinutes(-60)
	# 2 hours after EventTime
	$EndTime = (Get-Date -Date $EventTime).AddMinutes(120)
	$EventTimeText = Get-Date -Date $EventTime -Format "yyyy/MM/dd-HH:mm:ss.fff"
} Else {
	# No times provided so get last 14 days (20160 minutes)
	$StartTime = [DateTime](Get-Date).AddMinutes(-20160)
	$EndTime = Get-Date
}
$TimeSpan = [Int](New-TimeSpan -Start $StartTime -End (Get-Date)).TotalMinutes
# Convert start and end times to format used in the cluster logs
$StartTimeText = Get-Date -Date $StartTime -Format "yyyy/MM/dd-HH:mm:ss.fff"
$EndTimeText = Get-Date -Date $EndTime -Format "yyyy/MM/dd-HH:mm:ss.fff"
Write-Host
Write-Host "Time Span Information:" -ForegroundColor White -BackgroundColor DarkCyan
Write-Host ("`tStart Time  {0} - {1}" -f $StartTime, $StartTimeText) -ForegroundColor Cyan
If ($EventTime -ne $Null) {
	Write-Host ("`tEvent Time  {0} - {1}" -f $EventTime, $EventTimeText) -ForegroundColor Yellow
}
Write-Host ("`tEnd Time    {0} - {1}" -f $EndTime, $EndTimeText) -ForegroundColor Cyan
Write-Host
# Setup folder for local files
If ($NewClusterLogPath -eq "") {
	$NewClusterLogPath = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath("C:\Temp\{0}" -f $ClusterName)
} Else {
	$NewClusterLogPath = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($NewClusterLogPath)
}
New-Item -ItemType Directory -Path $NewClusterLogPath -Force | Out-Null
# Setup merged cluster log name
If ($MergedClusterLogName -eq "") {
	$MergedClusterLogName = Join-Path -Path $NewClusterLogPath -ChildPath $(Format-FileNameWithDate -Prefix "MergedClusterLog_" -Suffix ".csv" -DateFormat "yyyy-MM-dd_HH.mm")
}

# STILL NEED TO DEAL WITH SITUATION WHEN THERE IS ONLY ONE LOG FILE. RARE BUT POSSIBLE

# Generate or collect cluster logs
If ($ClusterLogFiles -ne "" -and $ClusterLogFiles -ne $Null) {
	# Collect pre-generated cluster logs
	$ClusterLogs = @()
	$ClusterLogs = Resolve-Path -Path $ClusterLogFiles | Select-Object -ExpandProperty ProviderPath | Sort-Object -Descending
	Write-Host "Cluster Log Files Found:" -ForegroundColor Black -BackgroundColor DarkYellow
	$ClusterLogs
	$TempNodeName = ($Clusterlogs[0] | Get-ChildItem).Name -Replace('_cluster.log', '')
	Write-Host "Temp Cluster Node Name:" -ForegroundColor Black -BackgroundColor DarkYellow
	$TempNodeName
	$ErrorAction = $ErrorActionPreference
	$ErrorActionPreference = "SilentlyContinue"
	$TempNodeName = ([System.Net.Dns]::GetHostEntry($TempNodeName).HostName).ToUpper()
	$ErrorActionPreference = $ErrorAction
	Write-Host "Temp Cluster Node FQDN:" -ForegroundColor Black -BackgroundColor DarkYellow
	$TempNodeName
	# Get cluster node names and IDs
	$ClusterNodes = Invoke-Command -ComputerName $TempNodeName -ScriptBlock {Get-ClusterNode} | Select-Object Name, ID, @{N="NodeFQDN";E={$Null}} | Sort-Object ID -Descending
	ForEach ($ClusterNode In $ClusterNodes) {
		If ([bool]($ClusterNode.Name -as [IPAddress])) {
			$IPAddress = $ClusterNode.Name
			$ErrorAction = $ErrorActionPreference
			$ErrorActionPreference = "SilentlyContinue"
			$ClusterNode.NodeFQDN = ([System.Net.Dns]::GetHostEntry($ClusterNode.Name).HostName).ToLower()
			$ErrorActionPreference = $ErrorAction
		} Else {
			$ErrorAction = $ErrorActionPreference
			$ErrorActionPreference = "SilentlyContinue"
			$IPAddress = $Null
			$IPAddress = [System.Net.Dns]::GetHostEntry($ClusterNode.Name) | Select-Object -ExpandProperty AddressList | Select-Object -ExpandProperty IPAddressToString | Where-Object {$_ -match "\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"} | Sort-Object | Select-Object -first 1
			$ClusterNode.NodeFQDN = ([System.Net.Dns]::GetHostEntry($ClusterNode.Name).HostName).ToLower()
			$ErrorActionPreference = $ErrorAction
		}
	}
	Write-Host "Cluster Nodes" -ForegroundColor White -BackgroundColor DarkCyan
	$ClusterNodes = Invoke-Command -ComputerName $ClusterName -ScriptBlock {Get-ClusterNode} | Select-Object Name, ID, @{N="NodeFQDN";E={$Null}} | Sort-Object Name -Descending
	$ClusterNodes | Select-Object @{N="NodeNumber";E={$_.ID}}, Name | Sort-Object ID | Format-Table -Auto
} ElseIf ($ClusterName -ne "") {
	# Generate cluster logs
	If ([bool]($ClusterName -as [IPAddress])) {
		$ErrorAction = $ErrorActionPreference
		$ErrorActionPreference = "SilentlyContinue"
		$IPAddress = $ClusterName
		$ClusterName = ([System.Net.Dns]::GetHostEntry($ClusterName).HostName).ToLower()
		$ErrorActionPreference = $ErrorAction
	} Else {
		$ErrorAction = $ErrorActionPreference
		$ErrorActionPreference = "SilentlyContinue"
		$IPAddress = $Null
		$IPAddress = [System.Net.Dns]::GetHostEntry($ClusterName) | Select-Object -ExpandProperty AddressList | Select-Object -ExpandProperty IPAddressToString | Where-Object {$_ -match "\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"} | Sort-Object | Select-Object -first 1
		$ClusterName = ([System.Net.Dns]::GetHostEntry($ClusterName).HostName).ToLower()
		$ErrorActionPreference = $ErrorAction
	}
	If ($IPAddress -ne $Null -and ($ClusterIPs.Contains($IPAddress) -eq $False -and $IPAddress -ne $ClusterName)) {
		$ClusterIPs.Add($IPAddress, (($ClusterName | Select-Object -First 1) -Replace('^*[\.](.*)$', '')).ToUpper())
	}
	# Get cluster node names and IDs
	Write-Host "Getting Logs from Cluster" -ForegroundColor White -BackgroundColor DarkCyan
	$ClusterNodes = Invoke-Command -ComputerName $ClusterName -ScriptBlock {Get-ClusterNode} | Select-Object Name, ID, @{N="NodeFQDN";E={$Null}} | Sort-Object ID
	$ClusterNodes | Select-Object @{N="Node#";E={$_.ID}}, @{N="NodeName";E={$_.Name}} | Format-Table -Auto
	$ClusterLogs = @()
	ForEach ($ClusterNode In $ClusterNodes) {
		If ([bool]($ClusterNode.Name -as [IPAddress])) {
			$IPAddress = $ClusterNode.Name
			$ErrorAction = $ErrorActionPreference
			$ErrorActionPreference = "SilentlyContinue"
			$ClusterNode.NodeFQDN = ([System.Net.Dns]::GetHostEntry($ClusterNode.Name).HostName).ToLower()
			$ErrorActionPreference = $ErrorAction
		} Else {
			$ErrorAction = $ErrorActionPreference
			$ErrorActionPreference = "SilentlyContinue"
			$IPAddress = $Null
			$IPAddress = [System.Net.Dns]::GetHostEntry($ClusterNode.Name) | Select-Object -ExpandProperty AddressList | Select-Object -ExpandProperty IPAddressToString | Where-Object {$_ -match "\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"} | Sort-Object | Select-Object -first 1
			$ClusterNode.NodeFQDN = ([System.Net.Dns]::GetHostEntry($ClusterNode.Name).HostName).ToLower()
			$ErrorActionPreference = $ErrorAction
		}

		If ($IPAddress -ne $Null -and ($ClusterIPs.Contains($IPAddress) -eq $False -and $IPAddress -ne $ClusterNode.NodeFQDN)) {
			$ClusterIPs.Add($IPAddress, (($ClusterNode.Name | Select-Object -First 1) -Replace('^*[\.](.*)$', '')).ToUpper())
		}
		Write-Host "Generating Cluster Log for Node"$ClusterNode.NodeFQDN -ForegroundColor Cyan -NoNewLine
		Write-Host " - This may take a few minutes" -ForegroundColor Yellow
		Write-Host
		If ($DontUseLocalTime -eq $False) {
			# Get cluster log using local date time
			$Results = Invoke-Command -ComputerName $ClusterNode.NodeFQDN -ScriptBlock {
				If ((Test-Path -Path C:\Temp\ClusterLogs) -eq $True) {
					# Delete existing logs if they exist
					Remove-Item C:\Temp\ClusterLogs\*_cluster.log -Force
				} Else {
					# Create C:\Temp\ClusterLogs
					New-Item -ItemType Directory -Path C:\Temp\ClusterLogs -Force
				}
				Get-ClusterLog -Node $Using:ClusterNode.Name -Destination C:\Temp\ClusterLogs -TimeSpan $Using:TimeSpan -UseLocalTime
			}
		} Else {
			# Get cluster logs using Greenwich Mean Time (GMT)
			$Results = Invoke-Command -ComputerName $ClusterNode.NodeFQDN -ScriptBlock {
				If ((Test-Path -Path C:\Temp\ClusterLogs) -eq $True) {
					# Delete existing logs if they exist
					Remove-Item C:\Temp\ClusterLogs\*_cluster.log -Force
				} Else {
					# Create C:\Temp\ClusterLogs
					New-Item -ItemType Directory -Path C:\Temp\ClusterLogs -Force
				}
				Get-ClusterLog -Node $Using:ClusterNode.Name -Destination C:\Temp\ClusterLogs -TimeSpan $Using:TimeSpan
			}
		}
		$SourceFiles = Resolve-Path -Path ("\\{0}\C$\Temp\ClusterLogs\*_cluster.log" -f $ClusterNode.NodeFQDN) | Select-Object -ExpandProperty ProviderPath
		$TargetFolder = $NewClusterLogPath
		Write-Host ("Copying Cluster Log From {0} to {1}" -f $ClusterNode.NodeFQDN, $NewClusterLogPath) -ForegroundColor Cyan
		ForEach ($SourceFile In $SourceFiles) {
		    If ((Test-Connection -ComputerName $ClusterNode.NodeFQDN -Quiet) -eq $True) {
				Write-Host ("`tCopying : {0}" -f $SourceFile) -ForegroundColor DarkGray
				Copy-Item -Path $SourceFile -Destination $TargetFolder -Force
			    If (Test-Path -Path (Join-Path -Path $TargetFolder -ChildPath ([System.IO.Path]::GetFileName($SourceFile)))) {
			    	Write-Host ("`tSuccess : {0}" -f (Join-Path -Path $TargetFolder -ChildPath ([System.IO.Path]::GetFileName($SourceFile)))) -ForegroundColor Green
			    } Else {
			    	Write-Host ("`tFailed  : {0}" -f (Join-Path -Path $TargetFolder -ChildPath ([System.IO.Path]::GetFileName($SourceFile)))) -ForegroundColor Red
			    }
			} Else {
				Write-Host ("Failed to contact {0}" -f $Server) -ForegroundColor Yellow -BackgroundColor DarkRed
			}
			Write-Host
		}
	}
	$ClusterLogs += Resolve-Path -Path ("{0}\*_cluster.log" -f $NewClusterLogPath) | Select-Object -ExpandProperty ProviderPath | Sort-Object -Descending
}

$ClusterNodes += "" | Select-Object @{N="Name";E={"NULL"}}, @{N="ID";E={0}}, @{N="NodeFQDN";E={"NULL"}}

$IPs = (Invoke-Command -ComputerName $ClusterNodes[0].NodeFQDN -ScriptBlock {(Get-ClusterResource | Where-Object {$_.Name -like "*IP Address*"} | Get-ClusterParameter | Where-Object {$_.Name -eq "Network" -or $_.Name -eq "Address"} | Select-Object Value)}).Value
0..($IPs.Count - 1) | ForEach {
	If ($_ % 2 -eq 0) {
		If ($ClusterIPs.Contains($IPs[$_+1]) -eq $False) {
			$ErrorAction = $ErrorActionPreference
			$ErrorActionPreference = "SilentlyContinue"
			$ClusterIPs.Add($IPs[$_+1], (($IPs[$_] | Select-Object -First 1) -Replace('^*[\.](.*)$', '')).ToUpper())
			$ErrorActionPreference = $ErrorAction
		}
	}
}
$IPs = Invoke-Command -ComputerName $ClusterNodes[0].NodeFQDN -ScriptBlock {Get-ClusterNetworkInterface | Select-Object Node, Address}
ForEach ($IP In $IPs) {
	If ($ClusterIPs.Contains($IP) -eq $False) {
		$ErrorAction = $ErrorActionPreference
		$ErrorActionPreference = "SilentlyContinue"
		$ClusterIPs.Add($IP.Address, (($IP.Node | Select-Object -First 1) -Replace('^*[\.](.*)$', '')).ToUpper())
		$ErrorActionPreference = $ErrorAction
	}
}
$IPs = $Null
$TempNodeName = $Null

# Collect Event Logs from each cluster node
If ($IncludeEventLogs -eq $True) {
	Write-Host "Collecting Event Logs" -ForegroundColor White -BackgroundColor DarkCyan
	ForEach ($ClusterNode In ($ClusterNodes | Where-Object {$_.ID -ne 0})) {
		Write-Host "`tNode"$ClusterNode.Name -ForegroundColor Cyan
		$NewClusterLog += Invoke-Command -ComputerName $ClusterNode.NodeFQDN -ScriptBlock {
			$EventLogs = @(
				"Application",
				"System",
				"Setup",
				"Microsoft-Windows-MsLbfoProvider/Operational"
			)
			$EventDetails = @()
			ForEach ($EventLog In $EventLogs) {
				#Write-Host "`t"$EventLog" ... " -ForegroundColor DarkGray -NoNewLine
				$EventDetails += Get-WinEvent -FilterHashTable @{LogName=$EventLog; StartTime=$Using:StartTime; EndTime=$Using:EndTime} -ErrorAction SilentlyContinue | Select-Object @{N="TimeStamp";E={Get-Date -Date $_.TimeCreated -Format "yyyy/MM/dd-HH:mm:ss.fff"}}, @{N="LineNumber";E={(([Int]$_.RecordId).ToString("0000000"))}}, @{N="NodeName";E={($_.MachineName -Replace('^*[\.](.*)$', '')).ToUpper()}}, @{N="NodeID";E={("Node {0}" -f $Using:ClusterNode.ID)}}, @{N="ProcessId";E={("[{0}]" -f ([Int]$_.ProcessId).ToString("00000000"))}}, @{N="ThreadId";E={("[{0}]" -f ([Int]$_.ThreadId).ToString("00000000"))}}, @{L="EntryType";E={Switch ($_.Level) {1 {"CRIT"} 2 {"ERR"} 3 {"WARN"} 4 {"INFO"} Default {"DBG"}}}}, @{N="Component";E={("{0}/{1}" -f $_.LogName, $_.ProviderName)}}, @{N="Message";E={($_.Message -Replace("[^\x20-\x7F]+", " ") -Replace("\s+", " ")).Trim()}} | Where-Object {$_.Message -ne ""}
				#Write-Host "Complete" -ForegroundColor DarkGray
			}
			$EventDetails
		}
		$NewClusterLog | Select-Object TimeStamp, LineNumber, NodeName, NodeID, ProcessID, ThreadID, EntryType, Component, Message | Export-CSV $MergedClusterLogName -Append -NoTypeInformation
		$NewClusterLog = @()
	}
}
# ---------------------------------------------------------------------------
# Start processing the cluster logs
$VerbosePreference = "Continue"
$DirectorNode = ""
ForEach ($Clusterlog In ($ClusterLogs | Sort)) {
	[System.GC]::Collect()
	# Begin cluster log merge
	$StartLogTime = Get-Date -Format "yyyy/MM/dd HH:mm:ss"
	Write-Host
	$ClusterLogShortName = Split-Path $ClusterLog -Leaf
	Write-Host "Start Processing $ClusterLogShortName at"(Get-Date) -ForegroundColor Cyan
	Write-Progress -Activity ("Reading log file "+$Clusterlog) -Status ("Progress: 0.0%") -PercentComplete 0
	$CurrentLog = Get-Content $Clusterlog -ReadCount 0
	Write-Host ("{0} was {1} lines before " -f $ClusterLogShortName, $CurrentLog.Count) -ForegroundColor DarkGray -NoNewLine
	$LineCounter = 0
	Do {
		$Done = $False
		If ($CurrentLog[$LineCounter].Length -gt 42) {
			$TimeStamp = ($CurrentLog[$LineCounter].SubString(19,24)).Trim()
			If ($TimeStamp -lt $StartTimeText) {
				$CurrentLog = $CurrentLog[$LineCounter..($CurrentLog.Length - 1)]
				$LineCounter = 0
			}
			If ($TimeStamp -gt $EndTimeText) {
				$CurrentLog = $CurrentLog[0..$LineCounter]
				$Done = $True
			}
		}
		$LineCounter += 250
	} Until ($LineCounter -ge $CurrentLog.Count -or $Done -eq $True)
	Write-Host ("and {0} after processing start and end times" -f $CurrentLog.Count) -ForegroundColor DarkGray
	$TotalLines = $CurrentLog.Count
	$LineNumber = 0
	$LineCounter = 0
	$PctCurrent = 0
	$PctLast = 0
	ForEach ($ClusterNode In $ClusterNodes) {
		If ($Clusterlog -like "*$($ClusterNode.Name)*") {
			$CurrentNodeName = $ClusterNode.Name
			$CurrentNodeID = ("Node {0}" -f $ClusterNode.ID)
		}
	}
	ForEach ($Line In $CurrentLog) {
		$LineNumber += 1
		$LineCounter += 1
		$TimeNow = Get-Date
		$Line = ($Line -Replace("\'","") -Replace("\]\[","] [")).Trim()
		If ($Line.Length -gt 45) {
			$TimeStamp = ($Line.SubString(19,24)).Trim()
			If ($TimeStamp -ge $StartTimeText -and $TimeStamp -le $EndTimeText -and ($Line.SubString(43,4)).Trim() -ne "[VER]") {
				$ProcessID = ("[{0}]" -f ($Line.SubString(0,8)).Trim())
				$ThreadID = ("[{0}]" -f ($Line.SubString(9,8)).Trim())
				$TimeStamp = ($Line.SubString(19,24)).Trim()
				$EntryType = ($Line.SubString(43,4)).Trim()
				If ($Line.Length -gt 48) {
					$Line = ($Line.SubString(48)).Trim()
					$Line = $Line -Replace('\]:', '] :') -Replace('\s+', ' ')
					$Component = $Null
					If ($Line.SubString(0,1) -eq '[') {
						Do {
							$TempString = [Regex]::Matches($Line, '(?<=^\[)(.*?)(?=\])') | Select-Object -ExpandProperty Value
							$Line = ($Line -Replace("^\["+$TempString+"\]","")).Trim()
							If ($TempString -ne $Null) {
								$Component += ("[{0}] " -f $TempString.Trim())
							}
						} While ($TempString -ne $Null)
						$Component = $Component.Trim()
						$Matches = [regex]::Matches($Line, "\d{1,3}(\.\d{1,3}){3}")
						If ($Matches.Count -gt 0) {
							ForEach ($Match In $Matches) {
								If ($ClusterIPs.Contains($Match.Value) -eq $True) {
									$DNSName = $ClusterIPs.($Match.Value)
									If ($DNSName -ne "") {
										$NewValue = ("[{0}] {1}" -f $DNSName, $Match.Value).Trim()
										$Line = $Line -Replace($Match.Value, $NewValue)
										$DoubleValue = [Regex]::Escape(("[{0}] [{1}]" -f $DNSName, $DNSName).Trim())
										$SingleValue = ("[{0}]" -f $DNSName).Trim()
										$Line = $Line -Replace($DoubleValue, $SingleValue)
									}
								} ElseIf ($Match.Value -ne "0.0.0.0" -and $Match.Value -ne "127.0.0.1" -and $Match.Value -notlike "169.254.*.*" -and $Match.Value -notlike "255.*.*.*" -and $Match.Value -notlike "*.*.*.0") {
									Try {
										$DNSName = ([System.Net.Dns]::GetHostbyAddress($Match.Value).HostName -Replace('^*[\.](.*)$', '')).ToUpper()
										If ($DNSName.Length -lt 3) {
											$DNSName = ""
										}
										$ClusterIPs.Add($Match.Value, ($DNSName | Select-Object -First 1))
										$NewValue = ("[{0}] {1}" -f $DNSName, $Match.Value).Trim()
										$Line = $Line -Replace($Match.Value, $NewValue)
										$DoubleValue = [Regex]::Escape(("[{0}] [{1}]" -f $DNSName, $DNSName).Trim())
										$SingleValue = ("[{0}]" -f $DNSName).Trim()
										$Line = $Line -Replace($DoubleValue, $SingleValue)
									} Catch {
										$DNSName = ""
										$ClusterIPs.Add($Match.Value, ($DNSName | Select-Object -First 1))
									}
								} Else {
									$ClusterIPs.Add($Match.Value, "")
								}
							}
						}
						# Add node name next to node number
						$Matches = [regex]::Matches($Line, " from \d{1,2}\b")
						If ($Matches.Count -gt 0) {
							ForEach ($Node In $ClusterNodes) {
								$Before = " from "+$Node.ID
								$After = " from Node "+$Node.ID
								$Line = $Line -Replace($Before, $After)
							}
						}
						$Matches = [regex]::Matches($Line, "node left unchanged at \d{1,2}")
						If ($Matches.Count -gt 0) {
							ForEach ($Node In $ClusterNodes) {
								$Before = ("node left unchanged at {0}" -f $Node.ID)
								$After = ("node left unchanged at Node {0}" -f $Node.ID)
								$Line = $Line -Replace($Before, $After)
							}
						}
						$Matches = [regex]::Matches($Line, "this node is not director, \d{1,2} is")
						If ($Matches.Count -gt 0) {
							ForEach ($Node In $ClusterNodes) {
								$Before = ("this node is not director, {0} is" -f $Node.ID)
								$After = ("this node is not director, Node {0} is" -f $Node.ID)
								$Line = $Line -Replace($Before, $After)
							}
						}
						$Matches = [regex]::Matches($Line, " from Node \d{1,2} to \d{1,2}\b")
						If ($Matches.Count -gt 0) {
							ForEach ($Node In $ClusterNodes) {
								$Before = " to "+$Node.ID
								$After = " to Node "+$Node.ID
								$Line = $Line -Replace($Before, $After)
							}
						}
						$Matches = [regex]::Matches($Line, "This node is director")
						If ($Matches.Count -gt 0) {
							$Before = "This node is director"
							$After = ("This node is director (Node {0})" -f $CurrentNodeID)
							$Line = $Line -Replace($Before, $After)
						}
						$Matches = [regex]::Matches($Line, "I am the leader")
						If ($Matches.Count -gt 0) {
							$Before = "I am the leader"
							$After = ("I am the leader (Node {0})" -f $CurrentNodeID)
							$Line = $Line -Replace($Before, $After)
						}
						$Matches = [regex]::Matches($Line, " for n\d{1,2}\b")
						If ($Matches.Count -gt 0) {
							ForEach ($Node In $ClusterNodes) {
								$Before = " for n"+$Node.ID
								$After = " for Node "+$Node.ID
								$Line = $Line -Replace($Before, $After)
							}
						}
						$Matches = [regex]::Matches($Line, "Node Disconnected \d{1,2}\b")
						If ($Matches.Count -gt 0) {
							ForEach ($Node In $ClusterNodes) {
								$Before = "Node Disconnected "+$Node.ID
								$After = "Disconnected Node "+$Node.ID
								$Line = $Line -Replace($Before, $After)
							}
						}
						$Matches = [regex]::Matches($Line, "[N|n]odes?? \d{1,2}\b")
						If ($Matches.Count -gt 0) {
							ForEach ($Node In $ClusterNodes) {
								$Before = "Node "+$Node.ID
								$After = "Node "+$Node.ID+" ["+$Node.Name+"]"
								$Line = $Line -Replace($Before, $After)
								$Before = "node "+$Node.ID
								$After = "Node "+$Node.ID+" ["+$Node.Name+"]"
								$Line = $Line -Replace($Before, $After)
								$Before = "nodes "+$Node.ID
								$After = "Node "+$Node.ID+" ["+$Node.Name+"]"
								$Line = $Line -Replace($Before, $After)
								$DoubleValue = ("\[{0}\] \[{1}\]" -f $Node.Name, $Node.Name).Trim()
								$SingleValue = ("[{0}]" -f $Node.Name).Trim()
								$Line = $Line -Replace($DoubleValue, $SingleValue)
							}
						}
						$Message = $Line
					} Else {
						# No component
						$Component = "[]"
						$Matches = [regex]::Matches($Line, "\d{1,3}(\.\d{1,3}){3}")
						If ($Matches.Count -gt 0) {
							ForEach ($Match In $Matches) {
								If ($ClusterIPs.Contains($Match.Value) -eq $True) {
									$DNSName = $ClusterIPs.($Match.Value)
									If ($DNSName -ne "") {
										$NewValue = ("[{0}] {1}" -f $DNSName, $Match.Value).Trim()
										$Line = $Line -Replace($Match.Value, $NewValue)
									}
								} ElseIf ($Match.Value -ne "0.0.0.0" -and $Match.Value -ne "127.0.0.1" -and $Match.Value -notlike "169.254.*.*" -and $Match.Value -notlike "255.*.*.*" -and $Match.Value -notlike "*.*.*.0") {
									Try {
										$DNSName = ([System.Net.Dns]::GetHostbyAddress($Match.Value).HostName -Replace('^*[\.](.*)$', '')).ToUpper()
										If ($DNSName.Length -lt 3) {
											$DNSName = ""
										}
										$ClusterIPs.Add($Match.Value, ($DNSName | Select-Object -First 1))
										$NewValue = ("[{0}] {1}" -f $DNSName, $Match.Value).Trim()
										$Line = $Line -Replace($Match.Value, $NewValue)
										$DoubleValue = [Regex]::Escape(("[{0}] [{1}]" -f $DNSName, $DNSName).Trim())
										$SingleValue = ("[{0}]" -f $DNSName).Trim()
										$Line = $Line -Replace($DoubleValue, $SingleValue)
									} Catch {
										$DNSName = ""
										$ClusterIPs.Add($Match.Value, ($DNSName | Select-Object -First 1))
									}
								} Else {
									$ClusterIPs.Add($Match.Value, "")
								}
							}
						}
						# Add node name next to node number
						$Matches = [regex]::Matches($Line, " from \d{1,2}\b")
						If ($Matches.Count -gt 0) {
							ForEach ($Node In $ClusterNodes) {
								$Before = " from "+$Node.ID
								$After = " from Node "+$Node.ID
								$Line = $Line -Replace($Before, $After)
							}
						}
						$Matches = [regex]::Matches($Line, "node left unchanged at \d{1,2}")
						If ($Matches.Count -gt 0) {
							ForEach ($Node In $ClusterNodes) {
								$Before = ("node left unchanged at {0}" -f $Node.ID)
								$After = ("node left unchanged at Node {0}" -f $Node.ID)
								$Line = $Line -Replace($Before, $After)
							}
						}
						$Matches = [regex]::Matches($Line, "this node is not director, \d{1,2} is")
						If ($Matches.Count -gt 0) {
							ForEach ($Node In $ClusterNodes) {
								$Before = ("this node is not director, {0} is" -f $Node.ID)
								$After = ("this node is not director, Node {0} is" -f $Node.ID)
								$Line = $Line -Replace($Before, $After)
							}
						}
						$Matches = [regex]::Matches($Line, " from Node \d{1,2} to \d{1,2}\b")
						If ($Matches.Count -gt 0) {
							ForEach ($Node In $ClusterNodes) {
								$Before = " to "+$Node.ID
								$After = " to Node "+$Node.ID
								$Line = $Line -Replace($Before, $After)
							}
						}
						$Matches = [regex]::Matches($Line, "This node is director")
						If ($Matches.Count -gt 0) {
							$Before = "This node is director"
							$After = ("This node is director (Node {0})" -f $CurrentNodeID)
							$Line = $Line -Replace($Before, $After)
						}
						$Matches = [regex]::Matches($Line, "I am the leader")
						If ($Matches.Count -gt 0) {
							$Before = "I am the leader"
							$After = ("I am the leader (Node {0})" -f $CurrentNodeID)
							$Line = $Line -Replace($Before, $After)
						}
						$Matches = [regex]::Matches($Line, " for n\d{1,2}\b")
						If ($Matches.Count -gt 0) {
							ForEach ($Node In $ClusterNodes) {
								$Before = " for n"+$Node.ID
								$After = " for Node "+$Node.ID
								$Line = $Line -Replace($Before, $After)
							}
						}
						$Matches = [regex]::Matches($Line, "Node Disconnected \d{1,2}\b")
						If ($Matches.Count -gt 0) {
							ForEach ($Node In $ClusterNodes) {
								$Before = "Node Disconnected "+$Node.ID
								$After = "Disconnected Node "+$Node.ID
								$Line = $Line -Replace($Before, $After)
							}
						}
						$Matches = [regex]::Matches($Line, "[N|n]odes?? \d{1,2}\b")
						If ($Matches.Count -gt 0) {
							ForEach ($Node In $ClusterNodes) {
								$Before = "Node "+$Node.ID
								$After = "Node "+$Node.ID+" ["+$Node.Name+"]"
								$Line = $Line -Replace($Before, $After)
								$Before = "node "+$Node.ID
								$After = "Node "+$Node.ID+" ["+$Node.Name+"]"
								$Line = $Line -Replace($Before, $After)
								$Before = "nodes "+$Node.ID
								$After = "Node "+$Node.ID+" ["+$Node.Name+"]"
								$Line = $Line -Replace($Before, $After)
								$DoubleValue = ("\[{0}\] \[{1}\]" -f $Node.Name, $Node.Name).Trim()
								$SingleValue = ("[{0}]" -f $Node.Name).Trim()
								$Line = $Line -Replace($DoubleValue, $SingleValue)
							}
						}
						$Message = $Line
					}
					$NewClusterLog += "" | Select-Object @{N="TimeStamp";E={$TimeStamp}}, @{N="LineNumber";E={(([Int]$LineNumber).ToString("0000000"))}}, @{N="NodeName";E={$CurrentNodeName}}, @{N="NodeID";E={$CurrentNodeID}}, @{N="ProcessID";E={$ProcessID}}, @{N="ThreadID";E={$ThreadID}}, @{N="EntryType";E={$EntryType}}, @{N="Component";E={$Component}}, @{N="Message";E={$Message}}
				}
			}
		} Else {
			If ($TimeStamp -ge $StartTimeText -and $TimeStamp -le $EndTimeText) {
				$Matches = [regex]::Matches($Line, "\d{1,3}(\.\d{1,3}){3}")
				If ($Matches.Count -gt 0) {
					ForEach ($Match In $Matches) {
						If ($ClusterIPs.Contains($Match.Value) -eq $True) {
							$DNSName = $ClusterIPs.($Match.Value)
							If ($DNSName -ne "") {
								$NewValue = ("[{0}] {1}" -f $DNSName, $Match.Value).Trim()
								$Line = $Line -Replace($Match.Value, $NewValue)
								$DoubleValue = [Regex]::Escape(("[{0}] [{1}]" -f $DNSName, $DNSName).Trim())
								$SingleValue = ("[{0}]" -f $DNSName).Trim()
								$Line = $Line -Replace($DoubleValue, $SingleValue)
							}
						} ElseIf ($Match.Value -ne "0.0.0.0" -and $Match.Value -ne "127.0.0.1" -and $Match.Value -notlike "169.254.*.*" -and $Match.Value -notlike "255.*.*.*" -and $Match.Value -notlike "*.*.*.0") {
							Try {
								$DNSName = ([System.Net.Dns]::GetHostbyAddress($Match.Value).HostName -Replace('^*[\.](.*)$', '')).ToUpper()
								If ($DNSName.Length -lt 3) {
									$DNSName = ""
								}
								$ClusterIPs.Add($Match.Value, ($DNSName | Select-Object -First 1))
								$NewValue = ("[{0}] {1}" -f $DNSName, $Match.Value).Trim()
								$Line = $Line -Replace($Match.Value, $NewValue)
								$DoubleValue = [Regex]::Escape(("[{0}] [{1}]" -f $DNSName, $DNSName).Trim())
								$SingleValue = ("[{0}]" -f $DNSName).Trim()
								$Line = $Line -Replace($DoubleValue, $SingleValue)
							} Catch {
								$DNSName = ""
								$ClusterIPs.Add($Match.Value, ($DNSName | Select-Object -First 1))
							}
						} Else {
							$ClusterIPs.Add($Match.Value, "")
						}
					}
				}
				# Add node name next to node number
				$Matches = [regex]::Matches($Line, " from \d{1,2}\b")
				If ($Matches.Count -gt 0) {
					ForEach ($Node In $ClusterNodes) {
						$Before = " from "+$Node.ID
						$After = " from Node "+$Node.ID
						$Line = $Line -Replace($Before, $After)
					}
				}
				$Matches = [regex]::Matches($Line, "node left unchanged at \d{1,2}")
				If ($Matches.Count -gt 0) {
					ForEach ($Node In $ClusterNodes) {
						$Before = ("node left unchanged at {0}" -f $Node.ID)
						$After = ("node left unchanged at Node {0}" -f $Node.ID)
						$Line = $Line -Replace($Before, $After)
					}
				}
				$Matches = [regex]::Matches($Line, "this node is not director, \d{1,2} is")
				If ($Matches.Count -gt 0) {
					ForEach ($Node In $ClusterNodes) {
						$Before = ("this node is not director, {0} is" -f $Node.ID)
						$After = ("this node is not director, Node {0} is" -f $Node.ID)
						$Line = $Line -Replace($Before, $After)
					}
				}
				$Matches = [regex]::Matches($Line, " from Node \d{1,2} to \d{1,2}\b")
				If ($Matches.Count -gt 0) {
					ForEach ($Node In $ClusterNodes) {
						$Before = " to "+$Node.ID
						$After = " to Node "+$Node.ID
						$Line = $Line -Replace($Before, $After)
					}
				}
				$Matches = [regex]::Matches($Line, "This node is director")
				If ($Matches.Count -gt 0) {
					$Before = "This node is director"
					$After = ("This node is director (Node {0})" -f $CurrentNodeID)
					$Line = $Line -Replace($Before, $After)
				}
				$Matches = [regex]::Matches($Line, "I am the leader")
				If ($Matches.Count -gt 0) {
					$Before = "I am the leader"
					$After = ("I am the leader (Node {0})" -f $CurrentNodeID)
					$Line = $Line -Replace($Before, $After)
				}
				$Matches = [regex]::Matches($Line, " for n\d{1,2}\b")
				If ($Matches.Count -gt 0) {
					ForEach ($Node In $ClusterNodes) {
						$Before = " for n"+$Node.ID
						$After = " for Node "+$Node.ID
						$Line = $Line -Replace($Before, $After)
					}
				}
				$Matches = [regex]::Matches($Line, "Node Disconnected \d{1,2}\b")
				If ($Matches.Count -gt 0) {
					ForEach ($Node In $ClusterNodes) {
						$Before = "Node Disconnected "+$Node.ID
						$After = "Disconnected Node "+$Node.ID
						$Line = $Line -Replace($Before, $After)
					}
				}
				$Matches = [regex]::Matches($Line, "[N|n]odes?? \d{1,2}\b")
				If ($Matches.Count -gt 0) {
					ForEach ($Node In $ClusterNodes) {
						$Before = "Node "+$Node.ID
						$After = "Node "+$Node.ID+" ["+$Node.Name+"]"
						$Line = $Line -Replace($Before, $After)
						$Before = "node "+$Node.ID
						$After = "Node "+$Node.ID+" ["+$Node.Name+"]"
						$Line = $Line -Replace($Before, $After)
						$Before = "nodes "+$Node.ID
						$After = "Node "+$Node.ID+" ["+$Node.Name+"]"
						$Line = $Line -Replace($Before, $After)
						$DoubleValue = ("\[{0}\] \[{1}\]" -f $Node.Name, $Node.Name).Trim()
						$SingleValue = ("[{0}]" -f $Node.Name).Trim()
						$Line = $Line -Replace($DoubleValue, $SingleValue)
					}
				}
				$Message = ($Line -Replace('\s+', ' ')).Trim()
				$NewClusterLog += "" | Select-Object @{N="TimeStamp";E={$TimeStamp}}, @{N="LineNumber";E={(([Int]$LineNumber).ToString("0000000"))}}, @{N="NodeName";E={$CurrentNodeName}}, @{N="NodeID";E={$CurrentNodeID}}, @{N="ProcessID";E={$ProcessID}}, @{N="ThreadID";E={$ThreadID}}, @{N="EntryType";E={$EntryType}}, @{N="Component";E={$Component}}, @{N="Message";E={$Message}}
			}
		}
		$PctCurrent = [Math]::Round((100/$TotalLines) * $LineNumber, 2)
		If ($PctCurrent -eq ($PctLast + .25)) {
			$ElapsedSec = (New-TimeSpan -Start $StartLogTime -End (Get-Date -Date $TimeNow)).TotalSeconds
			$RemainSec = ($ElapsedSec / $PctCurrent) * (100 - $PctCurrent)
			$EstimatedEndTime = (Get-Date -Date $TimeNow).AddSeconds($RemainSec)
			$LinesperSecond = $LineNumber / $ElapsedSec
			$MinutesToGo = [Math]::Floor((New-TimeSpan -Start (Get-Date -Date $TimeNow) -End $EstimatedEndTime).TotalMinutes)
			$SecondsToGo = ([Math]::Floor((New-TimeSpan -Start (Get-Date -Date $TimeNow) -End $EstimatedEndTime).TotalSeconds)) - ($MinutesToGo * 60)
			$Status = ("Node: {0} - Minutes Remaining: {1:0}:{2:00} - Lines per Second: {3:N0} - Line {4} of {5}" -f $CurrentNodeName, $MinutesToGo, $SecondsToGo, $LinesperSecond, $LineNumber, $TotalLines)
			Write-Progress -Activity $Status -Status ("Progress: {0:N2} %" -f $PctCurrent) -PercentComplete $PctCurrent
			$PctLast = $PctCurrent
		}
		If ($LineCounter -eq 5000) {
			$NewClusterLog | Select-Object TimeStamp, LineNumber, NodeName, NodeID, ProcessID, ThreadID, EntryType, Component, Message | Export-CSV $MergedClusterLogName -Append -NoTypeInformation
			$NewClusterLog = @()
			$LineCounter = 0
		}
	}
	$ElapsedSec = (New-TimeSpan -Start $StartLogTime -End (Get-Date -Date $TimeNow)).TotalSeconds
	$LinesperSecond = $TotalLines / $ElapsedSec
	$Status = ("Node: {0} - Minutes Remaining: 0:00 - Lines per Second: {1:N0} - Line {2} of {3}" -f $CurrentNodeName, $LinesperSecond, $TotalLines, $TotalLines)
	Write-Progress -Activity $Status -Status "Progress: 100 %" -PercentComplete 100
	Start-Sleep -Milliseconds 500
	Write-Progress -Activity $Status -Completed
	$NewClusterLog | Select-Object TimeStamp, NodeName, NodeID, EntryType, Component, Message, LineNumber, ProcessID, ThreadID | Export-CSV $MergedClusterLogName -Append -NoTypeInformation
	$NewClusterLog = @()
	$LineCounter = 0
	Write-Host "Finished Processing $ClusterLogShortName at"(Get-Date) -ForegroundColor Cyan
	Write-Host
}
Write-Host
Write-Host "Performing Sorting and Finalizing Merged Cluster Log"$MergedClusterLogName -ForegroundColor Cyan
$NewClusterLog = Import-CSV $MergedClusterLogName
$NewClusterLog = $NewClusterLog | Sort-Object TimeStamp, LineNumber
$NewClusterLog | Select-Object TimeStamp, NodeName, NodeID, EntryType, Component, Message, LineNumber, ProcessID, ThreadID | Export-CSV $MergedClusterLogName -NoTypeInformation
Write-Host
Write-Host "   Complete   " -ForegroundColor White -BackgroundColor DarkGreen
[System.GC]::Collect()
