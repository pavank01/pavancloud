﻿Param(

    [Parameter(Mandatory=$true)]
    [string]$serviceName,
    
    [Parameter(Mandatory=$false)]
    [string]$scriptExtensionVersion = "1.4",

    [Parameter(Mandatory=$false)]
    [switch]$detailed

)

$vmList = Get-AzureVM -ServiceName $serviceName 

foreach ($vm in $vmList) {

    $agentLogLocation = "\\$($vm.InstanceName).fastts.firstam.net\C$\WindowsAzure\Logs\Plugins\Microsoft.Compute.CustomScriptExtension\$scriptExtensionVersion\CustomScriptHandler.log"

    if ($detailed) {

        Write-Host "`n$($vm.InstanceName)`n---------------------------------------------------" -ForegroundColor Green

        $message = $vm.ResourceExtensionStatusList[1].ExtensionSettingStatus.SubStatusList[0].FormattedMessage.Message -replace "\\n", "`n"
        Write-Host $message -ForegroundColor White

        Write-Host "`n" -NoNewline

        $message = $vm.ResourceExtensionStatusList[1].ExtensionSettingStatus.SubStatusList[1].FormattedMessage.Message -replace "\\n", "`n"
        write-host $message -ForegroundColor Red

        Write-Host "`n" -NoNewline

    }
    
    if ($detailed) { Write-Host "Reading log from $agentLogLocation" -ForegroundColor Yellow }

    Write-Host "$($vm.InstanceName) " -NoNewline

    if (Test-Path -Path $agentLogLocation) { 

        $content = Get-Content -Path $agentLogLocation
        $failureCount = ($content | ? { $_ -match 'failed to complete' }).Count
        $message = "$failureCount Azure Custom Script Extension failures detected"
    
        if ($failureCount -eq 0) {

            $bgColor = 'Green'
    
        } Else {

            $bgColor = 'Red'

        }



    } Else {

        $message = "log file not available"
        $bgColor = 'Magenta'

    }

    Write-Host "$message" -BackgroundColor $bgColor -NoNewline
    Write-Host ".`n" -NoNewline

}
