[CmdletBinding()]
Param(
	# ComputerName to display
	[Parameter()]
	[String[]]$ComputerName = $Null,

	# UserName to display
	[Parameter()]
	[String[]]$UserName = $Null,

	[Parameter()]
	[Switch]$Quick
)

# Get-ChildItem -Path \\azuvputlazur001\Logs -Include azu*.* -Recurse -Force | Select-Object FullName, Name, LastWriteTime | Sort-Object LastWriteTime, Name -Descending

$Invocation = (Get-Variable MyInvocation -Scope 0).Value
$ScriptPath = Split-Path $Invocation.MyCommand.Path
$ScriptName = [io.path]::GetFileNameWithoutExtension($Invocation.MyCommand.Name)
$ServerBuildsFile = Join-Path -Path $ScriptPath -ChildPath ($ScriptName+".csv")
$ServerBuildsHash = @{}
$ServerBuildLogPath = "\\corp.firstam.com\Restricted\ServerOps-Admin\Scripts\Logs"
#$ServerBuildLogPath = "C:\Logs"
If ((Test-Path $ServerBuildsFile) -eq $True) {
	$ServerBuildsObject = Import-CSV $ServerBuildsFile
	ForEach ($Server In $ServerBuildsObject) {
		$ServerBuildsHash.Add($Server.ComputerName, $Server.UserName+'|'+$Server.BuildDate)
	}
}
If ($Quick -eq $False) {
	Write-Host "Getting Server Build Logs from"$ServerBuildLogPath -ForegroundColor Cyan
	$LogFiles = Get-ChildItem -Path $ServerBuildLogPath -Include *.log -Recurse -Force | Select-Object FullName, Name, LastWriteTime | Sort-Object LastWriteTime, Name -Descending
	$TotalLogFiles = $LogFiles.Count
	$NumberLength = ($TotalLogFiles.ToString()).Length
	Write-Host ("Reading {0} log files..." -f $TotalLogFiles) -ForegroundColor Cyan
	ForEach ($LogFile In $LogFiles) {
		$ReplaceText1 = [Regex]::Escape("<![LOG[Beginning build of ")
		$ReplaceText2 = [Regex]::Escape("]LOG]!><")
		$LogEntry = (Select-String -Path $LogFile.FullName -Pattern "Beginning build of" | Select-Object Line -Last 1).Line
		$LogEntry = ($LogEntry -Replace($ReplaceText1, '') -Replace(' on .* by ', ',') -Replace($ReplaceText2, '') -Replace('time=.*date=', ',') -Replace('\>', '') -Replace('"', '')).ToUpper()
		$LogEntry = $LogEntry.Split(",")
		If ($LogEntry[0].Trim() -ne "") {
			If ($ServerBuildsHash.ContainsKey($LogEntry[0]) -eq $True) {
				# Server entry exists so check if the new data is more recent
				$NewDate = Get-Date -Date $($LogEntry[2])
				$StoredDate = Get-Date -Date $(($ServerBuildsHash.Item($LogEntry[0]).Split('|'))[1])
				If ($NewDate -gt $StoredDate) {
					# New data is more recent
					$ServerBuildsHash.Set_Item($LogEntry[0], $LogEntry[1]+'|'+$LogEntry[2])
					Write-Host ("Added:  {0,-20}  {1,-20}  {2}" -f  $LogEntry[0], $LogEntry[1], $LogEntry[2]) -ForegroundColor Cyan
				} Else {
					# No change as existing server data is newer
				}
			} Else {
				# Add new entry for server name [0], user name [1], and date built [2]
				$ServerBuildsHash.Add($LogEntry[0], $LogEntry[1]+'|'+$LogEntry[2])
				Write-Host ("Added:  {0,-20}  {1,-20}  {2}" -f  $LogEntry[0], $LogEntry[1], $LogEntry[2]) -ForegroundColor Cyan
			}
		} Else {
			# No "Beginning build" line found so skipping
			#Write-Host ("Added {0} `t No Build Information Found" -f  $LogFile.Name) -ForegroundColor Cyan
		}
		#Write-Host "-----------------------------------------" -ForegroundColor White
	}
	#$ServerBuildsObject = $ServerBuildsHash.GetEnumerator() | Sort-Object Name
	$ServerBuildsObject = @()
	ForEach ($Server In $ServerBuildsHash.GetEnumerator()) {
		$TempObject = @()
		$TempObject = "" | Select-Object @{N="ComputerName";E={$Server.Name}}, @{N="UserName";E={($Server.Value).Split("|")[0]}}, @{N="BuildDate";E={($Server.Value).Split("|")[1]}}
		$ServerBuildsObject += $TempObject
	}
	$ServerBuildsObject | Sort-Object ComputerName | Export-CSV -Path $ServerBuildsFile -Force -NoTypeInformation
}
If ($ComputerName -ne $Null -and $UserName -eq $Null) {
	$ServerBuildsObject | Where-Object {$_.ComputerName -like "*$ComputerName*"} | Sort-Object ComputerName
} ElseIf ($ComputerName -eq $Null -and $UserName -ne $Null) {
	$ServerBuildsObject | Where-Object {$_.UserName -like "*$UserName*"} | Sort-Object ComputerName
} Else {
	$ServerBuildsObject | Where-Object {$_.ComputerName -like "*$ComputerName*" -and $_.UserName -like "*$UserName*"} | Sort-Object ComputerName
}



#$Servers = @("SNAVPTSEABCS001", "SNAPPAPPATAM012", "DFWPDAPPATAM001", "DFWVDSQLBMCC002", "SNAVPSQLBMCC002", "SNAVPAPPIMPC001", "DFWVPSQLORON001", "SNAPPPVSEVDI001", "SNAVPWEBRMAN002", "DFWVDSQLUWWB001")
#ForEach ($Server In $Servers) {
#	Write-Host $Server -ForegroundColor Cyan -BackgroundColor Magenta
#	.\GetServerBuilder.ps1 -Quick -ComputerName $Server | Format-Table -Auto
#}
