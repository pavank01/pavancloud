$AgeInMonths = 12
$Today = (Get-Date).Date
$CutOff = New-TimeSpan -Start $Today.AddMonths(-$AgeInMonths) -End $Today | Select-Object -ExpandProperty TotalDays
Write-Host "Will remove User Profiles older than $CutOff days" -ForegroundColor Cyan
# Specific exclusion list: Administrator / FAAdmin / DMZAdmin / Public / Default / SQL (SQL, MSDTS, Telemetry)
$DefaultExclusions = @("FAAdmin", "DMZAdmin", "Administrator", "Public", "All Users", "Default", "SQL", "MSDTS", "Telemetry", "ReportServer", "Classic", "NET", "LocalService", "NetworkService", "SystemProfile")
# ExcludeAccount will be a Parameter
$ExcludeAccount = $Null
If ($ExcludeAccount -eq $Null) {
	$ExcludeAccount = ""
}
$Exclusions = ($DefaultExclusions + $ExcludeAccount) | Where-Object {$_} | Sort-Object | Select-Object -Unique
$DefaultProfileFolder = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList" | Select-Object -ExpandProperty ProfilesDirectory) + "\"
Write-Host "User Profile Root:"$DefaultProfileFolder -ForegroundColor Cyan
Write-Host "Collecting all User Profiles (this could take some time)..." -ForegroundColor DarkGray
$AllProfiles = Get-WmiObject -Class Win32_UserProfile | Where-Object {$_.Special -eq $False -and $_.Loaded -eq $False} | Sort-Object LocalPath
Write-Host "User Profiles:"$AllProfiles.Count -ForegroundColor Cyan
Write-Host "Collecting all User Profile folders..." -ForegroundColor DarkGray
$AllProfileFolders = (Get-ChildItem "$DefaultProfileFolder*" | Select-Object @{L="FullName";E={(Get-Culture).TextInfo.ToTitleCase(($_.FullName).ToLower())}}) | Select-Object -ExpandProperty FullName
Write-Host "User Profile Folders:"$AllProfileFolders.Count -ForegroundColor Cyan
# Profiles to ignore - Will not process or even consider for deletion
$ProfilesToIgnore = @()
# Profiles to process for possible deletion
$ProfilesToProcess = @()
Write-Host "Processing the files in each User Profile folder (this will take some time)..." -ForegroundColor DarkGray
ForEach ($ProfileFolder In $AllProfileFolders) {
	$Found = $False
	If ($ProfileFolder -match "(\b[\w]+-[\w]+-[\w]+\b|[\s]+)") {
		$Found = $True
		$ProfilesToIgnore += $ProfileFolder
	}
	If ($Found -eq $False) {
		ForEach ($Exclusion In $Exclusions) {
			If ($ProfileFolder -like ("*{0}*" -f $Exclusion)) {
				$Found = $True
				$ProfilesToIgnore += $ProfileFolder
				Break
			}
		}
	}
	If ($Found -eq $False) {
		$ProfilesToProcess += $ProfileFolder
	}
}

Write-Host "----------------------------------------" -ForegroundColor Green
Write-Host ("{0} Profiles to Ignore" -f $ProfilesToIgnore.Count) -ForegroundColor Green
Write-Host "----------------------------------------" -ForegroundColor Green
$ProfilesToIgnore | ForEach {Write-Host "`t$_" -ForegroundColor DarkGreen}
Write-Host
Write-Host "----------------------------------------" -ForegroundColor DarkYellow
Write-Host ("{0} Profiles to consider for Deletion" -f $ProfilesToProcess.Count) -ForegroundColor DarkYellow
Write-Host "----------------------------------------" -ForegroundColor DarkYellow
$ProfilesToProcess | ForEach {Write-Host "`t$_" -ForegroundColor DarkYellow}

$ProfileAge = @()
ForEach ($ProfileFolder In $ProfilesToProcess) {
	Write-Host "Searching Folder"$ProfileFolder -ForegroundColor Cyan
	$ErrorActionPreference = "SilentlyContinue"
	$ProfileAge += (Get-ChildItem $ProfileFolder -ErrorAction SilentlyContinue -Force -Recurse -Exclude ntuser*.*, UsrClass.*, WinDirStat.* | Where-Object {$_.PSIsContainer -eq $False}) | Sort-Object LastWriteTime | Select-Object -Last 1 @{N="ProfileFolder";E={$ProfileFolder}}, @{N="UserID";E={$ProfileFolder -Replace([Regex]::Escape($DefaultProfileFolder),"").ToLower()}}, @{N="DaysOld";E={(New-TimeSpan -Start (Get-Date $_.LastWriteTime).Date -End $Today).TotalDays}}, LastWriteTime, @{L="LatestFile";E={$_.FullName}}
	$ErrorActionPreference = "Continue"
}
$ProfileAge | Sort LastWriteTime | Format-Table -Auto

$Accounts = $ProfileAge | Sort LastWriteTime | Where-Object {$_.DaysOld -gt $CutOff} | Select-Object @{N="UserID";E={(Get-Culture).TextInfo.ToTitleCase(($_.ProfileFolder -Replace("C:\\Users\\","")).ToLower())}}

Write-Host
Write-Host "----------------------------------------" -ForegroundColor Red
Write-Host ("{0} Profiles to Delete" -f $Accounts.Count) -ForegroundColor Red
Write-Host "----------------------------------------" -ForegroundColor Red

$Accounts | Format-Table -Auto

$Accounts = $Accounts | Sort-Object UserID

Write-Host 'Enter YES to Confirm Deletion'
$Confirm = Read-Host -Prompt 'Any other response will cancel the delete'
If ($Confirm -ne "YES") {
	Write-Host "Cancelled"
	Break
}
# ----------------------------------- #
# No changes are made to any profiles #
#      until after this point         #
# ----------------------------------- #

$Counter = $Accounts.Count
ForEach ($Account In $Accounts) {
	$FindAccount = $Account.UserID
	#$Profile = Get-WmiObject -Class Win32_UserProfile | Where-Object {$_.Special -eq $False -and $_.LocalPath -eq ("C:\Users\{0}" -f $FindAccount)}
	$Profile = $AllProfiles | Where-Object {$_.LocalPath -eq ("C:\Users\{0}" -f $FindAccount)}
	If ($Profile -ne $Null) {
		$ProfileName = (Get-Culture).TextInfo.ToTitleCase((($Profile.LocalPath.Split("\"))[2]).ToLower())
		Write-Host ("{0,5} Local User Profile {1} Has Been Found" -f $Counter, $ProfileName) -ForegroundColor Cyan
		If ($Profile.Loaded -eq $True) {
			$SessionID = ((QUser | Where-Object {$_ -like "*$FindProfile*"}) -Split ' +')[2]
			If ($SessionID -ne $Null) {
				Logoff $SessionID
				Write-Host ("{0,5} User {1} Has Been Logged Off" -f '', $ProfileName) -ForegroundColor Yellow
			}
		}
		$Profile.Delete()
		Write-Host ("{0,5} Local User Profile {1} Has Been Deleted" -f '', $ProfileName) -ForegroundColor Green
	} Else {
		Write-Host ("{0,5} Local User Profile {1} Not Found Or Ignored" -f $Counter, $FindAccount) -ForegroundColor DarkCyan
	}
	Write-Host
	$Counter = $Counter - 1
}

