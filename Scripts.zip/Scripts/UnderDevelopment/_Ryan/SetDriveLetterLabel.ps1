Function SetCustomTitleCase {
	Param (
		[String]$InputString
	)
	$Words = @(
		"AMP",
		"Archive",
		"Backup",
		"CLS",
		"Content",
		"Data",
		"Database",
		"Databases",
		"Dev",
		"Development",
		"Diagnostic",
		"Disk",
		"DMX",
		"DocPrep",
		"Drive",
		"DTC",
		"FAST",
		"For",
		"Imaging",
		"Imperva",
		"Index",
		"Install",
		"IQ",
		"Log",
		"Logs",
		"Misc",
		"Mount",
		"MSDTC",
		"Old",
		"Other",
		"PageFile",
		"PDF",
		"PerfLogs",
		"Prod",
		"Production",
		"Pure",
		"Quorum",
		"SQL",
		"SQLData",
		"Stage",
		"Staging",
		"Static",
		"System",
		"Temp",
		"TempDB",
		"Temporary",
		"TEN",
		"Test",
		"TRecS",
		"VMAX",
		"Vol",
		"Volume",
		"Web",
		"Workflow",
		"XIO"
	)
	ForEach ($Word In ($Words | Sort-Object)) {
		$InputString = $InputString -Replace($Word, $Word)
	}
	$InputString = $InputString -Replace('Iamging', 'Imaging')
	$InputString = $InputString -Replace('\:', ' ')
	$InputString = $InputString -Replace('\\', ' ')
	$InputString = $InputString.Trim()
	$InputString = $InputString -Replace('  ', ' ')
	$InputString = $InputString -Replace(' ', '_')
	$Pattern = '(^|[^a-zA-Z0-9])(\w)'
	$InputString = [RegEx]::Replace($InputString, $Pattern, {Param($Letter) $Letter.Value.ToUpper()})
	$InputString
}

$Drives = Get-ChildItem Function:[a-z]: -Name | Select-Object @{L="Letter";E={$_}}, @{L="Type";E={99}}, @{L="Label";E={$Null}}, @{L="Capacity";E={$Null}}, @{L="Notes";E={$Null}}, @{L="Number";E={$Null}}, @{L="DeviceID";E={$Null}} | Sort-Object Letter
$UsedDrives = Get-WmiObject -Class Win32_Volume | Where-Object {$_.DriveType -ne 2 -and $_.Label -ne "System Reserved"} | Select-Object @{L="Letter";E={$_.DriveLetter}}, @{L="Type";E={$_.DriveType}}, Label, @{L="Capacity";E={$_.Capacity/1MB}}, @{L="Notes";E={$Null}}, @{L="Number";E={$Null}}, @{L="DeviceID";E={$_.DeviceID}} | Sort-Object Type, Letter -Descending

$Counter = 0
ForEach ($Drive In $Drives) {
	$Counter += 1
	$Drive.Number = $Counter
	ForEach ($Used In $UsedDrives) {
		If ($Used.Letter -eq $Drive.Letter) {
			$Drive.Type = $Used.Type
			$Drive.Label = $Used.Label
			$Drive.Capacity = $Used.Capacity
			$Drive.Capacity = $Used.DeviceID
		}
	}
}
ForEach ($Used In $UsedDrives) {
	If ($Used.Letter -eq $Null) {
		$Drives += $Used
	}
}
$UsedDrives = $Null
$FreeDrives = $Drives | Where-Object {$_.Type -eq 99} | Sort-Object Letter -Descending
Write-Host
ForEach ($Drive In ($Drives | Where-Object {$_.Type -ne 99})) {
	$Done = $False
	$LastFree = $FreeDrives | Where-Object {$_.Type -eq 99 -and $_.Notes -eq $Null} | Select-Object -First 1
	If ($Drive.Type -eq 3 -and $Drive.Letter -eq "C:" -and $Drive.Label -ne "C_System") {
		# C: OS Drive
		$Label = $Drive.Label
		$DrvLetter = $($Drive.Letter)
		$ErrorActionPreference = "SilentlyContinue"
		$Drv = Get-WmiObject -Class Win32_Volume -Filter "DriveLetter = '$($DrvLetter)'"
		$LabelNew = "C_System"
		$Drv.Label = $LabelNew
		$Drv.Put() | Out-Null
		$ErrorActionPreference = "Continue"
		Write-Host ("{0} Drive label '{1}' changed to '{2}'" -f $DrvLetter, $Label, $LabelNew) -ForegroundColor Green
		$Drv = $Null
		$Done = $True
	}
	If ($Drive.Type -eq 5) {
		# CD / DVD Drives
		If ($Drive.Number -lt $LastFree.Number)	{
			$ErrorActionPreference = "SilentlyContinue"
			$Drv = Get-WmiObject -Class Win32_Volume -Filter "DriveType = 5 and DriveLetter = '$($Drive.Letter)'"
			If ($Drv -ne $Null) {
				$Drv.DriveLetter = $LastFree.Letter
				$Drv.Put() | Out-Null
				Write-Host ("DVD Drive '{0}' moved to '{1}'" -f $Drive.Letter, $LastFree.Letter) -ForegroundColor Green
				$FreeDrives | Where-Object {$_.Letter -eq $LastFree.Letter} | ForEach-Object {$_.Notes = "Moved from "+$($Drive.Letter)}
				$Drv = $Null
				$Drive.Notes = "Moved to "+$LastFree.Letter
			} Else {
				Write-Host ("DVD Drive '{0}' cannot be moved to '{1}' automatically" -f $Drive.Letter, $LastFree.Letter) -ForegroundColor Red
			}
			$ErrorActionPreference = "Continue"
		}
		$Done = $True
	}
	If ($Drive.Type -eq 3 -and ($Drive.Label -eq "New Volume" -or $Drive.Label -eq "New_Volume" -or $Drive.Label -eq "NewVolume" -or $Drive.Label -eq "Local Disk" -or $Drive.Label -eq "LocalDisk" -or $Drive.Label -eq " " -or $Drive.Label -eq "" -or $Drive.Label -eq $Null)) {
		# Fixed drives with the default label or no label
		$Label = $Drive.Label
		$DrvLetter = $($Drive.Letter)
		If ($Drive.Letter -ne $Null) {
			$ErrorActionPreference = "SilentlyContinue"
			$Drv = Get-WmiObject -Class Win32_Volume -Filter "DriveLetter = '$($DrvLetter)'"
			$DrvLetter = $DrvLetter -Replace("\:", "") -Replace(":", "")
			$LabelNew = ("{0}_Data" -f $DrvLetter)
			$Drv.Label = $LabelNew
			$Drv.Put() | Out-Null
			$ErrorActionPreference = "Continue"
		} Else {
			$ErrorActionPreference = "SilentlyContinue"
			$Drv = Get-WmiObject -Class Win32_Volume -Filter "DeviceID = '$($Drive.DeviceID)'"
			$DrvLetter = $DrvLetter -Replace("\:", "") -Replace(":", "")
			$LabelNew = "Data"
			$Drv.Label = $LabelNew
			$Drv.Put() | Out-Null
			$ErrorActionPreference = "Continue"
		}
		Write-Host ("Drive label '{0}' changed to '{1}'" -f $Label, $LabelNew) -ForegroundColor Green
		$Drv = $Null
		$Done = $True
	}
	If ($Drive.Type -eq 3 -and $Done -eq $False -and $Drive.Label -ne $Null) {
		# Fixed drives with labels that may need to be cleaned up
		$Label = $Drive.Label
		$LabelNew = SetCustomTitleCase $Label
		If ($Label -cne $LabelNew) {
			$ErrorActionPreference = "SilentlyContinue"
			$Drv = Get-WmiObject -Class Win32_Volume | Where-Object {$_.Label -eq $Label}
			$Drv.Label = $LabelNew
			$Drv.Put() | Out-Null
			$ErrorActionPreference = "Continue"
			Write-Host ("Drive label '{0}' changed to '{1}'" -f $Label, $LabelNew) -ForegroundColor Green
			$Drv = $Null
		}
	}
}
Write-Host
Write-Host " BEFORE " -ForegroundColor White -BackgroundColor DarkRed
$Drives | Where-Object {$_.Type -ne 99 -and $_.Label -ne "System Reserved"} | Sort-Object Letter, Type, Label | Format-Table Letter, Type, Label -Auto
Write-Host
Write-Host " AFTER " -ForegroundColor White -BackgroundColor DarkGreen
Get-WmiObject -Class Win32_Volume | Where-Object {$_.DriveType -ne 2 -and $_.Label -ne "System Reserved"} | Select-Object @{L="Letter";E={$_.DriveLetter}}, @{L="Type";E={$_.DriveType}}, Label | Sort-Object Letter, Label | Format-Table Letter, Type, Label -Auto
$Drives = $Null














#	If ($Drive.Type -eq 3 -and $Drive.Letter -eq "D:" -and $Drive.Label -ne "D_Data") {
#		$Drv = Get-WmiObject -Class Win32_Volume -Filter 'DriveLetter = "D:"'
#		$Drv.Label = "D_Data"
#		$Drv.Put() | Out-Null
#		Write-Host "D: Drive Label"$Drive.Label"changed to D_Data" -ForegroundColor Green
#		$Drv = $Null
#	}

#$DriveTypes = @{
#	"0"  = "Unknown";
#	"1"  = "No Root Directory";
#	"2"  = "Removable";
#	"3"  = "Local";
#	"4"  = "Network";
#	"5"  = "Optical";
#	"6"  = "RAM";
#	"99" = "NotUsed"
#}

## Rename X: to X_PerfLogs for FAST
#$DriveX = Get-WmiObject -Class Win32_Volume -Filter 'DriveLetter = "X:"'
#$DriveX.Label = "X_PerfLogs"
#$DriveX.Put() | Out-Null
#$DriveX = $Null
#Get-WmiObject -Class Win32_Volume -Filter 'NOT Label = "System Reserved"' | Select-Object @{Name="ComputerName";Expression={$_.PSComputerName}}, DriveLetter, DriveType, Label, @{Name="TotalSize";Expression={[Math]::Round($_.Capacity/1KB, 0)}}, @{Name="FreeSpace";Expression={[Math]::Round($_.FreeSpace/1KB, 0)}}, PageFilePresent, FileSystem, BootVolume, SystemVolume, BlockSize | Sort-Object DriveLetter, Label | Format-Table -Auto
#
#
#
#
#
#
#
#$Drives = Get-WmiObject -Class Win32_Volume | Where-Object {$_.Label -ne "System Reserved" -and $_.SystemVolume -ne $True -and ($_.DriveType -eq 3 -and ($_.Capacity/1MB) -ge 1024)} | Select-Object PSComputerName, DeviceID, DriveLetter, DriveType, Label, Capacity, FreeSpace, PageFilePresent, FileSystem, BootVolume, SystemVolume, BlockSize | Sort-Object DriveType, DriveLetter -Descending
#ForEach ($Drive In $Drives) {
#	If ($Drive.DriveType -eq 3 -and $Drive.Label -ne "") {
#		$Label = $Drive.Label
#		Write-Host $Label -ForegroundColor Yellow
#		$LabelNew = SetCustomTitleCase $Label
#		$Drv = Get-WmiObject -Class Win32_Volume | Where-Object {$_.Label -eq $Drive.Label}
#		$Drv.Label = $LabelNew
#		$Drv.Put() | Out-Null
#		$Drv = $Null
#		Write-Host $LabelNew -ForegroundColor Green
#		Write-Host
#	}
#}
#
#
#
#
## 0 = Unknown, 1 = No Root Directory, 2 = Removable Disk, 3 = Local Disk, 4 = Network Drive, 5 = CD/DVD, 6 = RAM Disk
#
#$DriveTypes = @{
#	0 = "Unknown";
#	1 = "No Root Directory";
#	2 = "Removable";
#	3 = "Local";
#	4 = "Network";
#	5 = "Optical";
#	6 = "RAM"
#}
#

#$Letters = Get-ChildItem Function:[a-z]: -Name



#$DriveTypes = @{
#	"0" = "Unknown";
#	"1" = "No Root Directory";
#	"2" = "Removable";
#	"3" = "Local";
#	"4" = "Network";
#	"5" = "Optical";
#	"6" = "RAM"
#}
#$Drives = Get-ChildItem Function:[c-z]: -Name | Select-Object @{L="Letter";E={$_}}, @{L="Type";E={"NotUsed"}} | Sort-Object Letter
#$UsedLetters = Get-WmiObject -Class Win32_Volume | Select-Object DriveLetter, DriveType | Where-Object {$_.DriveLetter -ne $Null} | Sort-Object DriveLetter
#ForEach ($Drive In $Drives) {
#	ForEach ($Used In $UsedLetters) {
#		If ($Used.DriveLetter -eq $Drive.Letter) {
#			$TempType = $Used.DriveType
#			$TempType = $DriveTypes.Get_Item("$TempType")
#			$Drive.Type = $TempType
#			$TempType = $Null
#		}
#	}
#}
#$Drives | Format-Table -Auto






#
#$OpticalDrives = Get-WmiObject -Class Win32_Volume -Filter 'NOT Label = "System Reserved" AND DriveType = 5' | Select-Object PSComputerName, DriveLetter, DriveType, Label, Capacity, FreeSpace, PageFilePresent, FileSystem, BootVolume, SystemVolume, BlockSize | Sort-Object DriveLetter
#$Letters = Get-WmiObject -Class Win32_Volume | Select-Object DriveLetter | Sort-Object DriveLetter
#If ($OpticalDrives.Count -gt 1) {
#
#}
#
#
#
#
#
#ForEach ($Drive In $Drives) {
#	If ($Drive.DriveType -eq 5 -and $Drive.DriveLetter -ne "Z:") {
#		$Drv = Get-WmiObject -Class Win32_Volume -Filter 'DriveType = 5'
#		$Drv.DriveLetter = "Z:"
#		$Drv.Put() | Out-Null
#		Write-Host "DVD drive"$Drive.DriveLetter"changed to Z:" -ForegroundColor Green
#		$Drv = $Null
#	}
#}
#
#
#
#
#<#
#  This script will change or remove the drive letter of all CDROM
#  & DVD Drives found. If changing the drive letters, it will start
#  from whatever is set as $LastDriveLetter, working backwards until
#  it finds an available drive letter.
#
#  Example 1: If you have 1 CDROM/DVD drive mounted as D: and there
#             is nothing using Z:, it will change the CDROM/DVD to
#             Z: However, if Z: is already in use, it will use Y:
#             instead, and so on.
#
#  Example 2: If you have 2 CDROM/DVD drives mounted as D: and E:,
#             it will change the CDROM/DVD on E: to Z: and D: to Y:.
#             However, if Z: or Y: are already in use, it will use
#             the next available drive letter.
#
#  The whole point is to get them out of the way so that they
#  don't interfere with DiskPart, etc.
#
#  Remember that if you're running the script from an MDT Task
#  Sequence, you're deployment share will already be mapped to Z:
#  drive, so you're CDROM/DVD drive will typically end up as Y:.
#
#  Syntax Examples:
#
#  - Run the script without parameters to default to Z as the
#    drive letter to start from:
#      ChangeCDRomDriveLetter.ps1
#
#  - To specify T as the drive letter to start from:
#      ChangeCDRomDriveLetter.ps1 -LastDriveLetter:t
#
#  - To remove the drive letter from existing CDROM/DVD drive(s):
#      ChangeCDRomDriveLetter.ps1 -Remove
#
#  Script Name: ChangeCDRomDriveLetter.ps1
#  Release 1.3
#  Written by Jeremy@jhouseconsulting.com 8th December 2014
#  Modified by Jeremy@jhouseconsulting.com 14th May 2016
#
##>
##-------------------------------------------------------------
#param([string]$LastDriveLetter,[switch]$Remove)
#
## Set Powershell Compatibility Mode
#Set-StrictMode -Version 2.0
#
## Enable verbose output
#$VerbosePreference = 'Continue'
#
#If ([String]::IsNullOrEmpty($LastDriveLetter)) {
#  $LastDriveLetter = "z"
#}
#
##-------------------------------------------------------------
#
#Get-WmiObject win32_logicaldisk -filter 'DriveType=5' | Sort-Object -property DeviceID -Descending | ForEach-Object {
#    Write-Host "Found CDROM drive on $($_.DeviceID)"
#    $a = mountvol $_.DeviceID /l
#    # Get first free drive letter starting from Z: and working backwards.
#    # Many scripts on the Internet recommend using the following line:
#    # $UseDriveLetter = Get-ChildItem function:[d-$LastDriveLetter]: -Name | Where-Object {-not (Test-Path -Path $_)} | Sort-Object -Descending | Select-Object -First 1
#    # However, if you run Test-Path on a CD-ROM or other drive letter
#    # without any media, it will return False even though the drive letter
#    # itself is in use. So to ensure accuracy we use the following line:
#    $UseDriveLetter = Get-ChildItem function:[d-$LastDriveLetter]: -Name | Where-Object { (New-Object System.IO.DriveInfo($_)).DriveType -eq 'NoRootDirectory' } | Sort-Object -Descending | Select-Object -First 1
#    If ($UseDriveLetter -ne $null -AND $UseDriveLetter -ne "") {
#      If ($Remove -eq $False) {
#        Write-Verbose "$UseDriveLetter is available to use"
#        Write-Verbose "Changing $($_.DeviceID) to $UseDriveLetter"
#      }
#      mountvol $_.DeviceID /d
#      Write-Verbose "Unmounted volume for $($_.DeviceID) completed with an exit code of $LastExitCode"
#      If ($Remove -eq $False) {
#        $a = $a.Trim()
#        mountvol $UseDriveLetter $a
#        Write-Verbose "Mounting volume to $UseDriveLetter completed with an exit code of $LastExitCode"
#      }
#    } else {
#      Write-Verbose "No available drive letters found."
#    }
#  }
#
#$ExitCode = 0
#Write-Verbose "Completed with an exit code of $ExitCode"
#Exit $ExitCode