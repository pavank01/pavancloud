# ---------------------------------------------------------------------------

[CmdletBinding()]
Param (
	[Parameter(Mandatory = $False,
	ValueFromPipeline = $True,
	Position = 0)]
	$ServerName = (Get-ChildItem Env:ComputerName).Value,

	[Parameter(Mandatory = $False)]
	$Credential = $Null
)

# Check this Out

# https://www.myotherpcisacloud.com/post/Getting-RDP-Sessions-with-Client-Computer-Name

# ---------------------------------------------------------------------------
Function Get-ElapsedTime {
<#
	.SYNOPSIS
		The Get-ElapsedTime function takes a date/time range and converts it to years,
		weeks, days, hours, minutes, seconds, and milliseconds

	.DESCRIPTION
		The Get-ElapsedTime function takes a date/time range and converts it to years,
		weeks, days, hours, minutes, seconds, and milliseconds

	.PARAMETER Start
		The starting date/time of the range to calculate

	.PARAMETER End
		The ending date/time of the range to calculate
		Current date/time (Default)

	.PARAMETER HighLevel
		Highest level of date/time to return

		NonZero (Default)
		Years
		Weeks
		Days
		Hours
		Seconds
		Milliseconds

	.PARAMETER LowLevel
		Lowest level of date/time to return

		Years
		Weeks
		Days
		Hours
		Seconds (Default)
		Milliseconds

	.PARAMETER LevelText
		Text to use for each level of date/time
		There must always be 7 elements

		" years / weeks / days / hours / minutes / seconds / milliseconds" (Default)
		"y /w /d /h /m /s /m"
		" yr, / wk, / dy, / hr, / mn, / sc, / ms"
		"y:/w:/d:/h:/m:/s:/m:/t"
		" year(s) / week(s) / day(s) / hour(s) / minute(s) / second(s) / millisecond(s)"

	.PARAMETER Delimiter
		Delimiter used to split LevelText
		Values will not be trimmed so spaces and other punctuation can be used
		"/" (Default)

	.PARAMETER NoText
		Do not show time span text after time values

		True:  4 13 34 56
		False: 4 days 13 hours 34 minutes 56 seconds (Default)

	.PARAMETER LeadingZero
		Make all time values 2 digits by adding a LeadingZero if required
		Milliseconds will be converted to 3 digits if required

		True:  04 days, 13 hours, 05 minutes, 09 seconds, 068 milliseconds
		False: 4 days, 13 hours, 5 minutes, 9 seconds, 68 milliseconds (Default)

	.PARAMETER Object
		Return an Object instead of the default String

	.OUTPUTS
		String (Default)
		Object

	.NOTES
		Written by Ryan Amsbury
		v0.5 - Alpha Testing
#>

	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory = $True,
				   ValueFromPipeline = $True,
				   Position = 0)]
		[DateTime]$Start,

		[Parameter(Mandatory = $False,
				   ValueFromPipeline = $True,
				   Position = 1)]
		[DateTime]$End = (Get-Date),

		[Parameter(Mandatory = $False)]
		[ValidateSet('NonZero', 'Years', 'Weeks', 'Days', 'Hours', 'Minutes', 'Seconds', 'Milliseconds', IgnoreCase = $True)]
		[string]$HighLevel = 'NonZero',

		[Parameter(Mandatory = $False)]
		[ValidateSet('Milliseconds', 'Seconds', 'Minutes', 'Hours', 'Days', 'Weeks', 'Years', IgnoreCase = $True)]
		[string]$LowLevel = 'Seconds',

		[Parameter(Mandatory = $False)]
		[String]$LevelText = ' years / weeks / days / hours / minutes / seconds / milliseconds',

		[Parameter(Mandatory = $False)]
		[String]$Delimiter = '/',

		[Parameter(Mandatory = $False)]
		[Switch]$NoText = $False,

		[Parameter(Mandatory = $False)]
		[Switch]$LeadingZero = $False,

		[Parameter(Mandatory = $False)]
		[Switch]$Object = $False
	)

	Begin {
		$LevelHash = @{
			'NonZero' = 8;
			'Years' = 7;
			'Weeks' = 6;
			'Days' = 5;
			'Hours' = 4;
			'Minutes' = 3;
			'Seconds' = 2;
			'Milliseconds' = 1;
		}
	} # Begin
	Process {
		If ($LevelHash.$HighLevel -lt $LevelHash.$LowLevel) {
			$HighLevel = 'NonZero'
		}
		$IncludeZero = $False
		$LevelTextArray = $LevelText -Split $Delimiter, 7, [StringSplitOptions]::"SimpleMatch"
		$TimeSpan = New-TimeSpan -Start $Start -End $End
		$Years = 0
		$Weeks = 0
		$Days = $TimeSpan.Days
		$Hours = $TimeSpan.Hours
		$Minutes = $TimeSpan.Minutes
		$Seconds = $TimeSpan.Seconds
		$Milliseconds = $TimeSpan.Milliseconds
		# Calculate years
		If ($LevelHash.$HighLevel -ge $LevelHash.Years) {
			If ($Days -gt 365) {
				# more than 1 year
				$Years = [Math]::Floor($Days / 365)
				If (($Days / 365) -gt $Years) {
					# there are extra days
					$Days = ($Days % 365) # returns the remainder of days
				} ElseIf (($Days / 365) -eq $Years) {
					# no more days
					$Days = 0
				}
			} ElseIf ($Days -lt -365) {
				# more than 1 year
				$Years = 0 - [Math]::Floor($Days / -365)
				If (($Days / -365) -gt $Years) {
					# there are extra days
					$Days = ($Days % -365) # returns the remainder of days
				} ElseIf (($Days / -365) -eq $Years) {
					# no more days
					$Days = 0
				}
			}
			If ($Days -eq 365) {
				# exactly 1 year
				$Years = 1
				$Days = 0
			}
			If ($Days -eq -365) {
				$Years = -1
				$Days = 0
			}
		}
		# Calculate weeks
		If ($LevelHash.$HighLevel -ge $LevelHash.Weeks) {
			If ($Days -gt 0) {
				# days left to process
				$Weeks = [Math]::Floor($Days / 7)
				If (($Days / 7) -gt $Weeks) {
					# there are extra days
					$Days = ($Days % 7) # returns the remainder of days
				} ElseIf (($Days / 7) -eq $Weeks) {
					# no more days
					$Days = 0
				}
			} ElseIf ($Days -lt 0) {
				# days left to process
				$Weeks = 0 - [Math]::Floor($Days / -7)
				If (($Days / -7) -gt $Weeks) {
					# there are extra days
					$Days = ($Days % -7) # returns the remainder of days
				} ElseIf (($Days / -7) -eq $Weeks) {
					# no more days
					$Days = 0
				}
			}
			If ($Days -eq 7) {
				# exactly 1 week
				$Weeks = 1
				$Days = 0
			}
			If ($Days -eq -7) {
				# exactly 1 week
				$Weeks = -1
				$Days = 0
			}
		}
		If ($LeadingZero -eq $True) {
			$Years = "{0:D2}" -f [int]$Years
			$Weeks = "{0:D2}" -f [int]$Weeks
			$Days = "{0:D2}" -f [int]$Days
			$Hours = "{0:D2}" -f [int]$Hours
			$Minutes = "{0:D2}" -f [int]$Minutes
			$Seconds = "{0:D2}" -f [int]$Seconds
			$Milliseconds = "{0:D3}" -f [int]$Milliseconds
		}

		$ElapsedTime = @()
		$TempElapsed = New-Object System.Object
		$TempElapsed | Add-Member -Type NoteProperty -Name Years -Value ([String]$Years)
		$TempElapsed | Add-Member -Type NoteProperty -Name YearsText -Value ([String]$LevelTextArray[0])
		$TempElapsed | Add-Member -Type NoteProperty -Name Weeks -Value ([String]$Weeks)
		$TempElapsed | Add-Member -Type NoteProperty -Name WeeksText -Value ([String]$LevelTextArray[1])
		$TempElapsed | Add-Member -Type NoteProperty -Name Days -Value ([String]$Days)
		$TempElapsed | Add-Member -Type NoteProperty -Name DaysText -Value ([String]$LevelTextArray[2])
		$TempElapsed | Add-Member -Type NoteProperty -Name Hours -Value ([String]$Hours)
		$TempElapsed | Add-Member -Type NoteProperty -Name HoursText -Value ([String]$LevelTextArray[3])
		$TempElapsed | Add-Member -Type NoteProperty -Name Minutes -Value ([String]$Minutes)
		$TempElapsed | Add-Member -Type NoteProperty -Name MinutesText -Value ([String]$LevelTextArray[4])
		$TempElapsed | Add-Member -Type NoteProperty -Name Seconds -Value ([String]$Seconds)
		$TempElapsed | Add-Member -Type NoteProperty -Name SecondsText -Value ([String]$LevelTextArray[5])
		$TempElapsed | Add-Member -Type NoteProperty -Name Milliseconds -Value ([String]$Milliseconds)
		$TempElapsed | Add-Member -Type NoteProperty -Name MillisecondsText -Value ([String]$LevelTextArray[6])
		$ElapsedTime += $TempElapsed

		$Years = $Null
		$Weeks = $Null
		$Days = $Null
		$Hours = $Null
		$Minutes = $Null
		$Seconds = $Null
		$Milliseconds = $Null

		Switch ($ElapsedTime) {
			{ (([Int]$_.Years -gt 0) -or ($LevelHash.$HighLevel -eq 7)) -and (($LevelHash.$HighLevel -ge 7) -and ($LevelHash.$LowLevel -le 7)) }
				{
					If ($NoText -eq $True) {
						$Years = $_.Years + ' '
					} Else {
						$Years = $_.Years + $_.YearsText
					}
					$IncludeZero = $True
				}

			{ ((([Int]$_.Weeks -gt 0) -or ($LevelHash.$HighLevel -eq 6) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 6) -and ($LevelHash.$LowLevel -le 6))) }
				{
					If ($NoText -eq $True) {
						$Weeks = $_.Weeks + ' '
					} Else {
						$Weeks = $_.Weeks + $_.WeeksText
					}
					$IncludeZero = $True
				}

			{ ((([Int]$_.Days -gt 0) -or ($LevelHash.$HighLevel -eq 5) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 5) -and ($LevelHash.$LowLevel -le 5))) }
				{
					If ($NoText -eq $True) {
						$Days = $_.Days + ' '
					} Else {
						$Days = $_.Days + $_.DaysText
					}
					$IncludeZero = $True
				}

			{ ((([Int]$_.Hours -gt 0) -or ($LevelHash.$HighLevel -eq 4) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 4) -and ($LevelHash.$LowLevel -le 4))) }
				{
					If ($NoText -eq $True) {
						$Hours = $_.Hours + ' '
					} Else {
						$Hours = $_.Hours + $_.HoursText
					}
					$IncludeZero = $True
				}

			{ ((([Int]$_.Minutes -gt 0) -or ($LevelHash.$HighLevel -eq 3) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 3) -and ($LevelHash.$LowLevel -le 3))) }
				{
					If ($NoText -eq $True) {
						$Minutes = $_.Minutes + ' '
					} Else {
						$Minutes = $_.Minutes + $_.MinutesText
					}
					$IncludeZero = $True
				}

			{ ((([Int]$_.Seconds -gt 0) -or ($LevelHash.$HighLevel -eq 2) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 2) -and ($LevelHash.$LowLevel -le 2))) }
				{
					If ($NoText -eq $True) {
						$Seconds = $_.Seconds + ' '
					} Else {
						$Seconds = $_.Seconds + $_.SecondsText
					}
				}

			{ ((([Int]$_.Milliseconds -gt 0) -or ($LevelHash.$HighLevel -eq 1) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 1) -and ($LevelHash.$LowLevel -le 1))) }
				{
					If ($NoText -eq $True) {
						$Milliseconds = $_.Milliseconds + ' '
					} Else {
						$Milliseconds = $_.Milliseconds + $_.MillisecondsText
					}
					$IncludeZero = $True
				}
		}
		If ($Object -eq $True) {
			Return $ElapsedTime
		} Else {
			Return "$Years$Weeks$Days$Hours$Minutes$Seconds$Milliseconds".Trim()
		}
	} # Process
	End {
	} # End
}
# ---------------------------------------------------------------------------

If ($Credential -eq $Null -and $Env:UserName.SubString($Env:UserName.Length - 2) -ne "-A") {
	$Credential = Get-Credential
}
ForEach ($Server In ($ServerName | Sort-Object)) {
	$UserSessions = @()
	If ((Test-Connection -ComputerName $Server -Count 1 -Quiet) -eq $False) {
		$TempSession = New-Object PSObject
		Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "ComputerName" -Value ([String]$Server)
		Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "UserName" -Value ([String]"CONNECTION ERROR")
		Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionID" -Value ([Int]0)
		Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionType" -Value ([String]"")
		Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionState" -Value ([String]"")
		Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionStart" -Value ([String]"")
		Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionDuration" -Value ([String]"")
		Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "IdleStart" -Value ([String]"")
		Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "IdleDuration" -Value ([String]"")
		$UserSessions += $TempSession
		$TempSession = $Null
	} Else {
		$ErrorMsg = $Null
		$QUserOutput = $Null
		If ($Credential -eq $Null) {
			If ($Server -like "*"+(Get-ChildItem Env:ComputerName).Value+"*") {
				$QUserOutput = Invoke-Command {QUser} -ErrorAction SilentlyContinue -ErrorVariable ErrorMsg
			} Else {
				$QUserOutput = Invoke-Command {QUser} -ComputerName $Server -ErrorAction SilentlyContinue -ErrorVariable ErrorMsg
			}
		} Else {
			If ($Server -like "*"+(Get-ChildItem Env:ComputerName).Value+"*") {
				$QUserOutput = Invoke-Command {QUser} -Credential $Credential -ErrorAction SilentlyContinue -ErrorVariable ErrorMsg
			} Else {
				$QUserOutput = Invoke-Command {QUser} -ComputerName $Server -Credential $Credential -ErrorAction SilentlyContinue -ErrorVariable ErrorMsg
			}
		}
		If ($QUserOutput -eq $Null) {
			If ($ErrorMsg -like "*No User exists*") {
				$TempSession = New-Object PSObject
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "ComputerName" -Value ([String]$Server)
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "UserName" -Value ([String]"NO USER SESSIONS")
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionID" -Value ([Int]0)
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionType" -Value ([String]"")
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionState" -Value ([String]"")
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionStart" -Value ([String]"")
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionDuration" -Value ([String]"")
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "IdleStart" -Value ([String]"")
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "IdleDuration" -Value ([String]"")
				$UserSessions += $TempSession
				$TempSession = $Null
			} Else {
				$TempSession = New-Object PSObject
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "ComputerName" -Value ([String]$Server)
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "UserName" -Value ([String]"UNKNOWN ERROR")
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionID" -Value ([Int]0)
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionType" -Value ([String]"")
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionState" -Value ([String]"")
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionStart" -Value ([String]"")
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionDuration" -Value ([String]"")
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "IdleStart" -Value ([String]"")
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "IdleDuration" -Value ([String]"")
				$UserSessions += $TempSession
				$TempSession = $Null
			}
		} Else {
			ForEach ($QUser In ($QUserOutput | Where-Object {$_ -notlike "*SESSIONNAME*"})) {
				$TempSession = New-Object PSObject
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "ComputerName" -Value ([String]$Server)
				$UserName = ($QUser.SubString(1,22)).Trim()
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "UserName" -Value ([String]$UserName)
				# Session Types (Session Name)
				# BLANK
				# console
				# rdp-tcp#0
				# ica-tcp#0
				# What else?
				$SessionType = ($QUser.SubString(23,19)).Trim()
				If ($SessionType -like "") {
					$SessionType = "n/a"
				}
				If ($SessionType -eq "console") {
					$SessionType = "Console"
				}
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionType" -Value ([String]$SessionType)
				$SessionID = ($QUser.SubString(42,4)).Trim()
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionID" -Value ([Int]$SessionID)
				$SessionState = ($QUser.SubString(46,8)).Trim()
				If ($SessionState -eq "Disc") {
					$SessionState = "Disconnected"
				} Else {
					$SessionState = "Connected"
				}
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionState" -Value ([String]$SessionState)
				$SessionIdle = ($QUser.SubString(54,11)).Trim()
				If ($SessionIdle -eq "." -or $SessionIdle -eq "none") {
					Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "IdleStart" -Value ([String]"")
					Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "IdleDuration" -Value ([String]"0m")
				} Else {
					If ($SessionIdle -notlike "*:*") {
						$IdleCount = 1
					}
					If ($SessionIdle -like "*:*") {
						$IdleCount = 2
					}
					If ($SessionIdle -like "*+*") {
						$IdleCount = 3
					}
					$Temp = $SessionIdle.Replace('+', ':')
					$Temp = $Temp.Split(':')
					Switch ($IdleCount) {
						1 {
							$IdleDate = (Get-Date).Addminutes(([Int]$Temp[0] * -1))
						}
						2 {
							$IdleDate = (Get-Date).AddHours(([Int]$Temp[0] * -1)).Addminutes(([Int]$Temp[1] * -1))
						}
						3 {
							$IdleDate = (Get-Date).AddDays(([Int]$Temp[0] * -1)).AddHours(([Int]$Temp[1] * -1)).Addminutes(([Int]$Temp[2] * -1))
						}
					}
					$IdleStart = Get-Date ($IdleDate) -Format "MM/dd/yyyy HH:mm tt"
					Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "IdleStart" -Value ([String]$IdleStart)
					$IdleDuration = Get-ElapsedTime -Start $IdleDate -LowLevel Minutes -LevelText "y /w /d /h /m /s /ms"
					If ($IdleDuration -eq "") {
						Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "IdleDuration" -Value ([String]"0m")
					} Else {
						Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "IdleDuration" -Value ([String]$IdleDuration)
					}
				}
				$SessionStart = Get-Date ($QUser.SubString(65)).Trim() -Format "MM/dd/yyyy HH:mm tt"
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionStart" -Value ([String]$SessionStart)
				$SessionDuration = Get-ElapsedTime -Start $SessionStart -LowLevel Minutes -LevelText "y /w /d /h /m /s /ms"
				Add-Member -InputObject $TempSession -MemberType NoteProperty -Name "SessionDuration" -Value ([String]$SessionDuration)
				$UserSessions += $TempSession
				$TempSession = $Null
			}
		}
	}
	$UserSessions | Sort-Object UserName, SessionStart | Select-Object ComputerName, UserName, SessionID, SessionType, SessionState, SessionStart, SessionDuration, IdleStart, IdleDuration
}





# Other ways to get similar information
#$Servers = "DFWVDAPPSOLR001", "DFWVDAPPSOLR002", "DFWVDAPPSOLR003"
#$Credential = Get-Credential
#ForEach ($Server In $Servers) {
#	$Processes = Invoke-Command {Get-Process | Where-Object {$_.Name -eq "Explorer"} | Select-Object Name, ID, SessionID, StartTime} -ComputerName $Server -Credential $Credential | Select-Object ID, SessionID, StartTime, @{Name="ServerName";Expression={$_.PSComputerName}}
#	ForEach ($Process In $Processes) {
#		$Owner = (Get-WmiObject Win32_Process | Where-Object {$_.Handle -eq $Process.ID} | Select-Object @{Name="Owner";Expression={$_.GetOwner().User}}).Owner
#		Write-Host ("{0} {1} {2} {3}" -f $Process.ServerName, $Process.SessionID, $Process.StartTime, $Owner)
#	}
#}
