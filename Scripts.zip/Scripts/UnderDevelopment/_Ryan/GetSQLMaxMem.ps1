$Server = (Get-ChildItem Env:ComputerName).Value
Invoke-Command -ComputerName $Server -ScriptBlock {
	# ---------------------------------------------------------------------------
	Function Get-TimeElapsed {
		[CmdletBinding()]
		Param ([Parameter(Mandatory = $True,
						  Position = 0,
						  ValueFromPipeline = $True)]
			[System.TimeSpan]$TimeSpan,
			[Parameter(Mandatory = $False)]
			[Switch]$ShowMS = $False
		)
		Switch ($TimeSpan) { { $_.days -eq 1 } { $Days = "1 Day" }
			{ $_.days -gt 1 } { $Days = [string]$_.days + " Days" }
			{ $_.hours -eq 1 } { $Hrs = "1 Hour" }
			{ $_.hours -gt 1 } { $Hrs = [string]$_.hours + " Hours" }
			{ $_.Minutes -eq 1 } { $Mins = "1 Minute" }
			{ $_.Minutes -gt 1 } { $Mins = [string]$_.minutes + " Minutes" }
			{ $_.Seconds -eq 1 } { $Secs = "1 Second" }
			{ $_.Seconds -gt 1 } { $Secs = [string]$_.seconds + " Seconds" }
			{ $_.Milliseconds -eq 1 } { $MSecs = "1 Millisecond" }
			{ $_.Milliseconds -gt 1 } { $MSecs = [string]$_.Milliseconds + " Milliseconds" }
		}
		If ($ShowMS -eq $True) {
			Return "$Days $Hrs $Mins $Secs $MSecs".Trim()
		} Else {
			Return "$Days $Hrs $Mins $Secs".Trim()
		}
	}
	# ---------------------------------------------------------------------------
	# Get SQL Counters
	$MaxSamples = 10
	$SQLMemory = @()
	$CounterNames = @(
		"Memory Manager\Target Server Memory (KB)",
		"Memory Manager\Total Server Memory (KB)"
		"Buffer Manager\Buffer cache hit ratio",
		"Buffer Manager\Page life expectancy"
	)
	$Instances = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
	ForEach ($Instance In $Instances) {
		ForEach ($CounterName In $CounterNames) {
			If ($Instance -eq "MSSQLSERVER") {
				$FullCounterName = "\SQLSERVER`:$CounterName"
			} Else {
				$FullCounterName = "\MSSQL`$$Instance`:$CounterName"
			}
			If ($FullCounterName -like "*Page life expectancy*" -or $FullCounterName -like "*Buffer cache hit ratio*") {
				Write-Host ("Instance: {0,-15} Samples: {1,-4} Counter: {2}" -f $Instance, $MaxSamples, $CounterName) -ForegroundColor Cyan
				$CounterData = (Get-Counter -Counter "$FullCounterName" -MaxSamples $MaxSamples | Select-Object -ExpandProperty CounterSamples | Select-Object CookedValue | Measure-Object -Property CookedValue -Average | Select-Object  @{N="Average";E={[Math]::Round($_.Average, 2, "AwayFromZero")}}).Average
				$CounterData
			} Else {
				Write-Host ("Instance: {0,-15} Samples: {1,-4} Counter: {2}" -f $Instance, "1", $CounterName) -ForegroundColor Cyan
				$CounterData = (Get-Counter -Counter "$FullCounterName").CounterSamples[0].CookedValue
				$CounterData
			}
			$FullCounterName = $FullCounterName -Replace("(KB)", "MB")

			If ($CounterData -ne $Null) {
				$TempObject = New-Object PSObject
				#$CounterValue = $CounterData.CounterSamples[0].CookedValue
				$CounterValue = $CounterData
				If ($FullCounterName -like "*(MB)*") {
					$CounterValue = [Math]::Round($CounterValue/1KB, 0, "AwayFromZero")
				}
				If ($FullCounterName -like "*Page life expectancy*") {
					$CounterValue = Get-TimeElapsed -TimeSpan (New-TimeSpan -Minute $CounterValue)
				}
				If ($FullCounterName -like "*Buffer cache hit ratio*") {
					$CounterValue = ("{0} %" -f $CounterValue)
				}
				Add-Member -InputObject $TempObject -MemberType NoteProperty -Name "CounterName" -Value ([String]$FullCounterName)
				Add-Member -InputObject $TempObject -MemberType NoteProperty -Name "CounterValue" -Value ($CounterValue)
				$SQLMemory += $TempObject
				$TempObject = $Null
			} Else {
				$TempObject = New-Object PSObject
				Add-Member -InputObject $TempObject -MemberType NoteProperty -Name "CounterName" -Value ([String]$FullCounterName)
				Add-Member -InputObject $TempObject -MemberType NoteProperty -Name "CounterValue" -Value ([String]"No Data")
				$SQLMemory += $TempObject
				$TempObject = $Null
			}
		}
	}

	$SystemDetails = Get-WmiObject -Class Win32_OperatingSystem | Select-Object @{N="ServerName";E={$_.__Server}}, @{N="WindowsVersion";E={$_.Caption.Replace('�', '')}}, @{N="SP";E={$_.ServicePackMajorVersion}}, @{N="OSBit";E={$_.OSArchitecture -Replace('\-bit', '')}}, @{N="DomainName";E={$Null}}, @{N="WorkgroupName";E={$Null}}, @{N="HardwareModel";E={$Null}}, @{N="MemoryTotalGB";E={[Math]::Round($_.TotalVisibleMemorySize/1MB, 0, "AwayFromZero")}}, @{N="MemoryUsedGB";E={[Math]::Round(($_.TotalVisibleMemorySize - $_.FreePhysicalMemory)/1MB, 1, "AwayFromZero")}}, @{N="MemoryFreeGB";E={[Math]::Round(($_.FreePhysicalMemory)/1MB, 1, "AwayFromZero")}}, @{N="ProcessorModel";E={$Null}}, @{N="PhysicalCoresPerProcessor";E={$Null}}, @{N="LogicalCoresPerProcessor";E={$Null}}, @{N="TotalLogicalCores";E={$Null}}, @{N="Drive";E={$Null}}, @{N="DriveLabel";E={$Null}}, @{N="DriveTotalGB";E={$Null}}, @{N="DriveUsedGB";E={$Null}}, @{N="DriveFreeGB";E={$Null}}, @{N="AutoPageFileSize";E={$Null}}, @{N="PageFileTotalGB";E={$Null}}, @{N="PageFileUsedGB";E={$Null}}, @{N="PageFilePeakGB";E={$Null}}, @{N="DateBuilt";E={$_.ConvertToDateTime($_.InstallDate)}}, @{N="DateBooted";E={$_.ConvertToDateTime($_.LastBootUpTime)}}, @{N="LocalDate";E={$_.ConvertToDateTime($_.LocalDateTime)}}

	$Win32_ComputerSystem = Get-WmiObject -Class Win32_ComputerSystem | Select-Object @{N="AutoPageFileSize";E={$_.AutomaticManagedPagefile}}, @{N="DomainName";E={If ($_.PartOfDomain -eq $True) {($_.Domain).ToLower()} Else {$Null}}}, @{N="WorkgroupName";E={If ($_.PartOfDomain -eq $False) {($_.Workgroup).ToUpper()} Else {$Null}}}, @{N="HardwareModel";E={(($_.Manufacturer -Replace('\, Inc\.', ''))+" "+$_.Model) -Replace('\b(\w+)\s+\1\b', '$1')}}, @{N="TotalLogicalCores";E={$_.NumberOfLogicalProcessors}}

	$Win32_Processor = Get-WmiObject -Class Win32_Processor | Select-Object @{N="ProcessorModel";E={$_.Name -Replace('\(R\)', ' ') -Replace('\(TM\)', ' ') -Replace(' CPU ', ' ') -Replace(' Processor ', ' ') -Replace('\-\s+', '-') -Replace('\s+', ' ')}}, @{N="PhysicalCoresPerProcessor";E={$_.NumberOfCores}}, @{N="LogicalCoresPerProcessor";E={$_.NumberOfLogicalProcessors}} -Unique

	$Win32_PageFileUsage = Get-WmiObject -Class Win32_PageFileUsage | Select-Object @{N="PageFileTotalGB";E={[Math]::Round($_.AllocatedBaseSize/1KB, 0)}}, @{N="PageFileUsedGB";E={[Math]::Round($_.CurrentUsage/1KB, 1)}}, @{N="PageFilePeakGB";E={[Math]::Round($_.PeakUsage/1KB, 1)}}

	$Win32_Volume = Get-WmiObject -Class Win32_Volume | Where-Object {$_.DriveType -eq 3 -and $_.DriveLetter -eq 'C:'} | Select-Object @{N="Drive";E={$_.DriveLetter}}, @{N="DriveLabel";E={$_.Label}}, @{N="DriveTotalGB";E={[Math]::Round($_.Capacity/1GB, 0)}}, @{N="DriveUsedGB";E={[Math]::Round(($_.Capacity - $_.Freespace)/1GB, 1)}}, @{N="DriveFreeGB";E={[Math]::Round($_.Freespace/1GB, 1)}}

	$SystemDetails.DomainName = $Win32_ComputerSystem.DomainName
	$SystemDetails.WorkgroupName = $Win32_ComputerSystem.WorkgroupName
	$SystemDetails.HardwareModel = $Win32_ComputerSystem.HardwareModel
	$SystemDetails.ProcessorModel = $Win32_Processor.ProcessorModel
	$SystemDetails.PhysicalCoresPerProcessor = $Win32_Processor.PhysicalCoresPerProcessor
	$SystemDetails.LogicalCoresPerProcessor = $Win32_Processor.LogicalCoresPerProcessor
	$SystemDetails.TotalLogicalCores = $Win32_ComputerSystem.TotalLogicalCores
	$SystemDetails.Drive = $Win32_Volume.Drive
	$SystemDetails.DriveLabel = $Win32_Volume.DriveLabel
	$SystemDetails.DriveTotalGB = $Win32_Volume.DriveTotalGB
	$SystemDetails.DriveUsedGB = $Win32_Volume.DriveUsedGB
	$SystemDetails.DriveFreeGB = $Win32_Volume.DriveFreeGB
	$SystemDetails.AutoPageFileSize = $Win32_ComputerSystem.AutoPageFileSize
	$SystemDetails.PageFileTotalGB = $Win32_PageFileUsage.PageFileTotalGB
	$SystemDetails.PageFileUsedGB = $Win32_PageFileUsage.PageFileUsedGB
	$SystemDetails.PageFilePeakGB = $Win32_PageFileUsage.PageFilePeakGB

	If ($SystemDetails.DomainName -ne $Null) {
		$SystemDetails | Format-List ServerName, DomainName, WindowsVersion, SP, OSBit, HardwareModel, MemoryTotalGB, MemoryUsedGB, MemoryFreeGB, ProcessorModel, PhysicalCoresPerProcessor, LogicalCoresPerProcessor, TotalLogicalCores, Drive, DriveLabel, DriveTotalGB, DriveUsedGB, DriveFreeGB, AutoPageFileSize, PageFileTotalGB, PageFileUsedGB, PageFilePeakGB, DateBuilt, DateBooted, LocalDate
	} Else {
		$SystemDetails | Format-List ServerName, WorkgroupName, WindowsVersion, SP, OSBit, HardwareModel, MemoryTotalGB, MemoryUsedGB, MemoryFreeGB, ProcessorModel, PhysicalCoresPerProcessor, LogicalCoresPerProcessor, TotalLogicalCores, Drive, DriveLabel, DriveTotalGB, DriveUsedGB, DriveFreeGB, AutoPageFileSize, PageFileTotalGB, PageFileUsedGB, PageFilePeakGB, DateBuilt, DateBooted, LocalDate
	}

	$SQLMemory | Sort-Object CounterName | Format-Table -Auto

	$SQLTotalMaxMemory = (($SQLMemory | Where {$_.Countername -like "*Target Server Memory*"}) | Measure-Object CounterValue -sum).Sum
	$SQLTotalUsedMemory = (($SQLMemory | Where {$_.Countername -like "*Total Server Memory*"}) | Measure-Object CounterValue -sum).Sum

	$MaxMemoryForOtherApps = ($SystemDetails.MemoryTotalGB * 1024) - $SQLTotalMaxMemory
	$CurrentMemoryForOtherApps = ($SystemDetails.MemoryTotalGB * 1024) - $SQLTotalUsedMemory

	If ($CurrentMemoryForOtherApps -lt 4096) {
		Write-Host "SQL Currently Used Memory (MB) ="$SQLTotalUsedMemory -ForegroundColor Yellow
		Write-Host "Current Memory Available to Windows and Applications after SQL Used (MB) ="$CurrentMemoryForOtherApps -ForegroundColor Yellow
		Write-Host "This system will have issues as SQL is using too much memory right now" -ForegroundColor Yellow
	} Else {
		Write-Host "SQL Currently Used Memory (MB) ="$SQLTotalUsedMemory -ForegroundColor Cyan
		Write-Host "Current Memory Available to Windows and Applications after SQL Used (MB) ="$CurrentMemoryForOtherApps -ForegroundColor Cyan
	}
	Write-Host
	If ($MaxMemoryForOtherApps -lt 4096) {
		Write-Host "SQL Max Memory (MB) ="$SQLTotalMaxMemory -ForegroundColor Yellow
		Write-Host "Max Memory Available to Windows and Applications after SQL Max (MB) ="$MaxMemoryForOtherApps -ForegroundColor Yellow
		Write-Host "This system will have issues if SQL uses the maximum memory currently configured" -ForegroundColor Yellow
	} Else {
		Write-Host "SQL Max Memory (MB) ="$SQLTotalMaxMemory -ForegroundColor Cyan
		Write-Host "Max Memory Available to Windows and Applications after SQL Max (MB) ="$MaxMemoryForOtherApps -ForegroundColor Cyan
	}
	Write-Host
}


