
$SQLVersionsHash = @{
	"8.0" = "SQL Server 2000";
	"9.0" = "SQL Server 2005";
	"10.0" = "SQL Server 2008";
	"10.1" = "SQL Server 2008 (SP1)";
	"10.2" = "SQL Server 2008 (SP2)";
	"10.3" = "SQL Server 2008 (SP3)";
	"10.4" = "SQL Server 2008 (SP4)";
	"10.50" = "SQL Server 2008 R2";
	"10.51" = "SQL Server 2008 R2 (SP1)";
	"10.52" = "SQL Server 2008 R2 (SP2)";
	"10.53" = "SQL Server 2008 R2 (SP3)";
	"10.54" = "SQL Server 2008 R2 (SP4)";
	"11.0" = "SQL Server 2012";
	"11.1" = "SQL Server 2012 (SP1)";
	"11.2" = "SQL Server 2012 (SP2)";
	"11.3" = "SQL Server 2012 (SP3)";
	"11.4" = "SQL Server 2012 (SP4)";
	"12.0" = "SQL Server 2014";
	"12.1" = "SQL Server 2014 (SP1)";
	"12.2" = "SQL Server 2014 (SP2)";
	"12.3" = "SQL Server 2014 (SP3)";
	"12.4" = "SQL Server 2014 (SP4)";
	"13.0" = "SQL Server 2016";
	"13.1" = "SQL Server 2016 (SP1)";
	"13.2" = "SQL Server 2016 (SP2)";
	"13.3" = "SQL Server 2016 (SP3)";
	"13.4" = "SQL Server 2016 (SP4)";
	"17.0" = "SQL Server 2017"
}
$SQLVersions = Import-CSV .\GetSQLVersion.csv


$ComputerName = (Get-WmiObject Win32_ComputerSystem -Property Name).Name
$InstalledInstances = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server").InstalledInstances
$Instances = @()
ForEach ($InstalledInstance in $InstalledInstances) {
	$TempInstance = @()
	$InstancePath = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL").$InstalledInstance
	$SQLEdition = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$InstancePath\Setup").Edition
	$SQLBinRoot = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$InstancePath\Setup").SQLBinRoot
	$SQLVersionNumber = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$InstancePath\Setup").PatchLevel
	$SQLFile = Get-ChildItem -Path ($SQLBinRoot+'\sqlservr.exe')
	$FileVersionInfo = $SQLFile | Select-Object -ExpandProperty VersionInfo
	$SQLVersionArray = $SQLVersionNumber.Split("\.")
	$SQLShortVersion = ("{0}.{1}" -f [Int]$SQLVersionArray[0], [Int]$SQLVersionArray[1])
	$FileVersion = ("{0}.{1}.{2}.{3}" -f ($FileVersionInfo.FileMajorPart).ToString("#0"), ($FileVersionInfo.FileMinorPart).ToString("#0"), ($FileVersionInfo.FileBuildPart).ToString("#0"), ($FileVersionInfo.FilePrivatePart).ToString("#0"))
	$Split = $Null
	$FileVersion = [RegEx]::Replace($FileVersion, '(\d+)', {Invoke-Expression $Args[0]})
	If (([regex]::Matches($FileVersion, "\.")).Count -eq 2) {
		$Split = $FileVersion.ToString().Split(".")
		[Version]$FileVersion = ($Split[0], $Split[1], $Split[2], 0 -Join '.').Trim('.')
	} Else {
		$Split = $FileVersion.ToString().Split(".")
		[Version]$FileVersion = ($Split[0], $Split[1], $Split[2], $Split[3] -Join '.').Trim('.')
	}
	If ($FileVersionInfo.FileDescription -like "*64 Bit*") {
		$ProductBit = "(64 Bit)"
	} Else {
		$ProductBit = "(32 Bit)"
	}
	ForEach ($SQLVersion In $SQLVersions) {
		If ($SQLVersion.FileVersion -eq $FileVersion.ToString()) {
			$SQLVersionNumber = $SQLVersion.BuildVersion
			$SQLVersionName = ("{0} {1} {2}" -f $SQLVersion.Description, $SQLEdition, $ProductBit)

		}

	}
	$TcpPort = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$InstancePath\MSSQLServer\SuperSocketNetLib\Tcp\IPAll").TcpPort
	If ($TcpPort -gt 0) {
		$Port = [Int]$TcpPort
	} Else {
		$Port = [Int](Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$InstancePath\MSSQLServer\SuperSocketNetLib\Tcp\IPAll").TcpDynamicPorts
	}
	If ($Port -eq 0) {
		$Port = "N/A"
	}
	$TempInstance += "" | Select-Object @{L="ComputerName";E={$ComputerName}}, @{L="SQLVersionName";E={$SQLVersionName}}, @{L="SQLServerVersion";E={$SQLVersionNumber}}, @{L="SQLFileVersion";E={$FileVersion}}, @{L="InstanceName";E={$InstalledInstance}}, @{L="InstancePort";E={$Port}}
	$Instances += $TempInstance
}
$Instances | Sort-Object InstanceName | Format-Table -Auto

