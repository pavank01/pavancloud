Function Test-PsRemoting {
    Param(
        [Parameter(Mandatory = $True)]
        [String]$ComputerName,

        [Parameter(Mandatory = $False)]
        [Switch]$Quiet = $False
    )
	If ([bool]($ComputerName -as [IPAddress])) {
		# Get FQDN from IP
		$IPAddress = $ComputerName
		$ErrorAction = $ErrorActionPreference
		$ErrorActionPreference = "SilentlyContinue"
		Try {
			$ComputerName = [System.Net.Dns]::GetHostbyAddress($ComputerName).HostName
		} Catch {

		}
		$ErrorActionPreference = $ErrorAction
	} Else {
		# Get first IPv4 addrress
		Try {
			$IPAddress = [System.Net.Dns]::GetHostAddresses($ComputerName) | Select-Object -ExpandProperty IPAddressToString | Where-Object {$_ -match "\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"} | Sort-Object | Select-Object -first 1
		} Catch {
			$IPAddress = $ComputerName
		}
		$ErrorAction = $ErrorActionPreference
		$ErrorActionPreference = "SilentlyContinue"
		Try {
			$ComputerName = [System.Net.Dns]::GetHostbyAddress($IPAddress).HostName
		} Catch {

		}
		$ErrorActionPreference = $ErrorAction
	}
    Try {
        $ExecutionPolicy = Invoke-Command -ComputerName $ComputerName { Get-ExecutionPolicy } -ErrorAction Stop
		If ($Quiet -eq $False) {
	        Write-Host
	        Write-Host ("PS-Remoting is enabled for {0} ({1})" -f $ComputerName, $IPAddress) -ForegroundColor Green
	        Write-Host
	        Write-Host ("The PowerShell execution policy on {0} ({1}) is {2}" -f $ComputerName, $IPAddress, $ExecutionPolicy.Value) -ForegroundColor Green
		} Else {
			# Success so send True
			$True
		}
    }
    Catch {
		If ($Quiet -eq $False) {
	        Write-Host
	        Write-Host ("Remoting to {0} ({1}) returned an error:" -f $ComputerName, $IPAddress) -ForegroundColor Yellow
	        Write-Host
	        Write-Host $_ -ForegroundColor Yellow
	        Write-Host
	        Write-Host ("PS-Remoting is disabled for {0} ({1})" -f $ComputerName, $IPAddress) -ForegroundColor Yellow
	    } Else {
			# Failed so send False
			$False
	    }
    }
}

