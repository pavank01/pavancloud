[CmdletBinding()]
Param (
	# Display: Return colored console output instead of an object
	[Parameter()]
	[Switch]$Display
)

$ErrorAction = $ErrorActionPreference
$ErrorActionPreference = "SilentlyContinue"

$Results = @()

$WMIComputerSystem = Get-WmiObject Win32_ComputerSystem -Property Name, PartOfDomain, DomainRole, Domain, Workgroup
If ($WMIComputerSystem.PartOfDomain -eq $True) {
	$ComputerName = ($WMIComputerSystem.Name).ToUpper()+'.'+($WMIComputerSystem.Domain).ToLower()
} Else {
	$ComputerName = ($WMIComputerSystem.Name).ToUpper()+'.'+($WMIComputerSystem.Workgroup).ToLower()
}

If ((Get-Module -Name ActiveDirectory).Name -eq "ActiveDirectory") {
	Import-Module ActiveDirectory
	$Server = (Get-ADForest | Select-Object -ExpandProperty RootDomain | Get-ADDomain | Select-Object -Property PDCEmulator).PDCEmulator
} ElseIf ($WMIComputerSystem.Domain -eq "corp.firstam.com") {
	# CORP PDC
	$Server = "SNAPPDCGCORP002.corp.firstam.com"
} ElseIf ($WMIComputerSystem.Domain -eq "fastts.firstam.net") {
	# FASTTS PDC
	$Server = "SNAPPDCGFAST001.fastts.firstam.net"
} Else {
	$Server = (Get-ChildItem Env:UserDnsDomain).Value
}

Function Get-TimeDrift {
    Param ($NTPServer)
	$StartOfEpoch=New-Object DateTime(1900,1,1,0,0,0,[DateTimeKind]::Utc)

	[Byte[]]$NtpData = ,0 * 48
	$NtpData[0] = 0x1B    # NTP Request header in first byte

	$Socket = New-Object Net.Sockets.Socket([Net.Sockets.AddressFamily]::InterNetwork,
	                                        [Net.Sockets.SocketType]::Dgram,
	                                        [Net.Sockets.ProtocolType]::Udp)
	$Socket.Connect($NTPServer,123)
	$t1 = Get-Date    # Start of transaction... the clock is ticking...
	[Void]$Socket.Send($NtpData)
	[Void]$Socket.Receive($NtpData)
	$t4 = Get-Date    # End of transaction time
	$Socket.Close()

	$LocalTime = Get-Date

	$IntPart = [BitConverter]::ToUInt32($NtpData[43..40],0)   # t3
	$FracPart = [BitConverter]::ToUInt32($NtpData[47..44],0)
	$t3ms = $IntPart * 1000 + ($FracPart * 1000 / 0x100000000)

	$IntPart = [BitConverter]::ToUInt32($NtpData[35..32],0)   # t2
	$FracPart = [BitConverter]::ToUInt32($NtpData[39..36],0)
	$t2ms = $IntPart * 1000 + ($FracPart * 1000 / 0x100000000)

	$t1ms = ([TimeZoneInfo]::ConvertTimeToUtc($t1) - $StartOfEpoch).TotalMilliseconds
	$t4ms = ([TimeZoneInfo]::ConvertTimeToUtc($t4) - $StartOfEpoch).TotalMilliseconds

	$Offset = (($t2ms - $t1ms) + ($t3ms-$t4ms))/2

	$ServerTime = Get-Date -Date ($StartOfEpoch.AddMilliseconds($t4ms + $Offset).ToLocalTime())

	$ServerTimeText = Get-Date -Date $ServerTime -Format "yyyy/MM/dd HH:mm:ss.fff"
	$LocalTimeText = Get-Date -Date $LocalTime -Format "yyyy/MM/dd HH:mm:ss.fff"

	Return ((Get-Date -Date $ServerTimeText) - (Get-Date -Date $LocalTimeText)).TotalMilliseconds
}

$TestCount = 100
$AvgMS = [Math]::Round(((1..$TestCount | ForEach {Get-TimeDrift -NTPServer $Server} | Group-Object | Sort-Object Count -Descending).Count), 0, "AwayFromZero")

$LocalTime = Get-Date
$ServerTime = (Get-Date -Date $LocalTime).AddMilliseconds($AvgMS)

$LocalTimeText = Get-Date -Date $LocalTime -Format "yyyy/MM/dd HH:mm:ss.fff"
$ServerTimeText = Get-Date -Date $ServerTime -Format "yyyy/MM/dd HH:mm:ss.fff"

$Results += "" | Select-Object @{N="ComputerName";E={$ComputerName}}, @{N="ComputerTime";E={$LocalTimeText}}, @{N="DomainController";E={$Server}}, @{N="DomainTime";E={$ServerTimeText}}, @{N="AverageDriftMS";E={$AvgMS}}
If ($Display -eq $True) {
	Write-Host
	Write-Host $ComputerName" (LocalHost)" -ForegroundColor White
	Write-Host $LocalTimeText -ForegroundColor Cyan
	Write-Host
	Write-Host $Server" (PDC)" -ForegroundColor White
	Write-Host $ServerTimeText -ForegroundColor Cyan
	Write-Host
	#Write-Host $AvgMS -ForegroundColor Cyan -BackgroundColor DarkMagenta
	#Write-Host
	If ($AvgMS -eq 0) {
		Write-Host ("{0} is the SAME as {1}" -f $ComputerName, $Server) -ForegroundColor Green
	} ElseIf ($AvgMS -gt 0) {
		Write-Host ("{0} is {1} ms SLOWER than {2}" -f $ComputerName, $AvgMS, $Server) -ForegroundColor Yellow
	} Else {
		Write-Host ("{0} is {1} ms FASTER than {2}" -f $ComputerName, ([Math]::ABS($AvgMS)), $Server) -ForegroundColor Magenta
	}
} Else {
	$Results
}
$ErrorActionPreference = $ErrorAction

<#

1..20 | ForEach {.\GetTimeDrift.ps1} | Format-Table -Auto

net stop w32time
net start w32time
w32tm /config /syncfromflags:domhier /update
Start-Sleep -Seconds 5
w32tm /query /status
#>
