$PageFileDetails = @()
$ComputerSystem = Get-WmiObject -Class Win32_ComputerSystem | Select-Object Name, @{Name="MemoryMB";Expression={[Math]::Round($_.TotalPhysicalMemory/1MB,0)}}, Manufacturer, Model
$OperatingSystem = Get-WmiObject -Class Win32_OperatingSystem | Select-Object Caption, @{Name="LastBootUpTime";Expression={$_.ConvertToDateTime($_.LastBootUpTime)}}, OSArchitecture, ServicePackMajorVersion, @{Name="MemoryTotalGB";Expression={[Math]::Round($_.TotalVisibleMemorySize/1MB, 1)}}, @{Name="MemoryUsedGB";Expression={[Math]::Round(($_.TotalVisibleMemorySize - $_.FreePhysicalMemory)/1MB, 1)}}, @{Name="FreeSwapMB";Expression={$_.FreeSpaceInPagingFiles}}
$DiskVolumes = Get-WmiObject -Class Win32_Volume | Where-Object {$_.DriveType -eq 3 -and $_.DriveLetter -ne $Null} | Select-Object @{Name="ServerName";Expression={$_.__Server}}, Label, Name, @{Name="CapacityMB";Expression={[Math]::Round($_.Capacity/1MB,0)}}, @{Name="FreeSpaceMB";Expression={[Math]::Round($_.Freespace/1MB,0)}}, PageFilePresent
$PageFiles = Get-WmiObject -Class Win32_PageFileUsage | Select-Object @{Name="PageFileName";Expression={$_.Name}}, @{Name="PageFileSizeMB";Expression={$_.AllocatedBaseSize}}, @{Name="CurrentUsageMB";Expression={$_.CurrentUsage}}, @{Name="PeakUsageMB";Expression={$_.PeakUsage}}, @{Label="PageFileCreated";Expression={$_.ConvertToDateTime($_.InstallDate)}}
$PageFileSettings = Get-WmiObject -Class Win32_PageFileSetting | Select-Object Name, InitialSize, MaximumSize
$Temp = $Null
$Temp = $OperatingSystem.Caption -Replace ("Microsoft", " ")
$Temp = $Temp -Replace ("Server", " ")
$Temp = $Temp -Replace ("\s{2,}", " ")
$OperatingSystem.Caption = $Temp.Trim()
$Temp = $Null
If ($OperatingSystem.ServicePackMajorVersion -gt 0) {
	$OperatingSystem.Caption = $OperatingSystem.Caption+" SP"+$OperatingSystem.ServicePackMajorVersion
}
ForEach ($DiskVolume In $DiskVolumes) {
	If ($DiskVolume.PageFilePresent -eq $True) {
		ForEach ($PageFile In $PageFiles) {
			If ($PageFile.PageFileName -like $DiskVolume.Name+"*") {
				$DiskTemp = New-Object PSObject
				Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "ServerName" -Value ([String]$ComputerSystem.Name)
				Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "WindowsVersion" -Value ([String]$OperatingSystem.Caption)
				Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "LastBootUpTime" -Value ([DateTime]$OperatingSystem.LastBootUpTime)
				Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "MemoryTotalGB" -Value ([Int]$OperatingSystem.MemoryTotalGB)
				Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "MemoryUsedGB" -Value ([Int]$OperatingSystem.MemoryUsedGB)
				Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "Drive" -Value ([String]$DiskVolume.Name)
				Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "Label" -Value ([String]$DiskVolume.Label)
				Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "TotalMB" -Value ([Int]$DiskVolume.CapacityMB)
				Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "FreeMB" -Value ([Single]$DiskVolume.FreeSpaceMB)
				Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "PageFilePresent" -Value ([Bool]$DiskVolume.PageFilePresent)
				Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "PageFileName" -Value ([String]$PageFile.PageFileName)
				Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "PageFileSizeMB" -Value ([Int]$PageFile.PageFileSizeMB)
				Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "CurrentUsageMB" -Value ([Single]$PageFile.CurrentUsageMB)
				Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "PeakUsageMB" -Value ([Single]$PageFile.PeakUsageMB)
				Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "PageFileCreated" -Value ([DateTime]$PageFile.PageFileCreated)
				$PageFileDetails += $DiskTemp
			}
		}
	} Else {
		$DiskTemp = New-Object PSObject
		Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "ServerName" -Value ([String]$ComputerSystem.Name)
		Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "WindowsVersion" -Value ([String]$OperatingSystem.Caption)
		Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "LastBootUpTime" -Value ([DateTime]$OperatingSystem.LastBootUpTime)
		Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "MemoryTotalGB" -Value ([Int]$OperatingSystem.MemoryTotalGB)
		Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "MemoryUsedGB" -Value ([Int]$OperatingSystem.MemoryUsedGB)
		Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "Drive" -Value ([String]$DiskVolume.Name)
		Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "Label" -Value ([String]$DiskVolume.Label)
		Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "TotalMB" -Value ([Int]$DiskVolume.CapacityMB)
		Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "FreeMB" -Value ([Single]$DiskVolume.FreeSpaceMB)
		Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "PageFilePresent" -Value ([Bool]$DiskVolume.PageFilePresent)
		Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "PageFileName" -Value $Null
		Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "PageFileSizeMB" -Value 0
		Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "CurrentUsageMB" -Value 0
		Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "PeakUsageMB" -Value 0
		Add-Member -InputObject $DiskTemp -MemberType NoteProperty -Name "PageFileCreated" -Value $Null
		$PageFileDetails += $DiskTemp
	}
}
$PageFileDetails | Sort-Object ServerName, Drive | Format-Table ServerName, WindowsVersion, LastBootUpTime, MemoryTotalGB, MemoryUsedGB, Drive, Label, TotalMB, FreeMB, PageFileName, PageFileSizeMB, CurrentUsageMB, PeakUsageMB, PageFileCreated -Auto










<#

I'm scripting a check for pagefile status utilizing PowerShell. On Windows 2000/2003 machines a user can choose between 3 pagefile options via the windows virtual Memory dialog:

Custom Size
System Managed Size
No paging file

I can successfully determine which of these options are selected by doing a:

$PageFileInfo = Get-WmiObject Win32_PageFileSetting  -ComputerName .

Custom Size - returns $PageFileInfo.MaximumSize that is non-zero
System Managed Size - returns $PageFileInfo.MaximumSize that is zero
No paging file - returns null for $PageFileInfo

My issue is that on a Windows 2008 server, there is a 4th option:

Automatically manage paging file size for all drives

and unfortunately, in this instance $PageFileInfo returns null, just as if No Paging file was selected.

I've attempted utilizing the following, all which return null on my test 2008 server when Automatically manage paging file size for all drives is selected:

Get-WmiObject Win32_PageFileSetting  -ComputerName .
Get-WmiObject Win32_PageFile  -ComputerName .
Get-WmiObject -Query 'SELECT * FROM meta_class WHERE __this ISA "Win32_PageFileSetting"'
How can I determine when Automatically manage paging file size for all drives is selected? am I going about this in a sane manner?



Collect Page File Server Configurations
29 / 09 / 2011
A client asked me to write a script to gather the page file configurations for ever server in their domain.  At first thought, I was like this will be a piece of cake.  I can use Win32_PageFile WMI class but the class has been deprecated. At second glance, not that difficult just some understanding of the differences between each OS (2008 R2 and 2000) and which WMI classes to use.

First let�s start with server 2008.  There is the default configuration to "Automatically manage paging file size for all drives."  This is not available in server 2003 or 2000 and can be found in Win32_ComputerSystem under AutomaticManagedPagefile.  If this is set to true, paging is automatically managed by the OS and the WMI class Win32_PageFileSetting is never created within the OS.

If it is set to false, you can query Win32_PageFileSetting and gather information from that class which includes initial and max page file sizes.

On server 2003, �Automatically manage page file sizes for all drives� isn�t an option so Win32_PageFileSetting is always available.

Here are a few links to articles I used:

http://www.planetmps.com/Essentials/Properties/CIMV2/ms_409/Win32/Win32_ComputerSystem.html

http://msdn.microsoft.com/en-us/library/aa394245(v=VS.85).aspx

http://msdn.microsoft.com/en-us/library/aa394246(v=VS.85).aspx

http://msdn.microsoft.com/en-us/library/aa394243(v=VS.85).aspx

The script queries AD and loops through a list of servers and exports data to an Excel document.

##################################################################################
##    This script is used to query every server for their page file configs
##    1. Connect to the domain using ADSI
##  2. Opens Excel, Add a workbook and deletes default workbooks 2 and 3
##  3. Builds Array of Values to display in header
##  4. Creates Excel Header
##    5. Loop through each server
##    6. Collect data on each server
##  7. Exports array to Excel
##  8. Autofit Excel columns
##  9. Get Time and Date
##  10. Save Workbook
##    Script written by Brady Randolph of RBA Consulting 9/29/2011
##################################################################################

##  1. Connect to the domain using ADSI
$objDomain = [adsi] (�LDAP://OU=Servers,OU=Company,dc=domain,dc=corp�)
$objSearcher = New-Object System.DirectoryServices.DirectorySearcher
$objSearcher.SearchRoot = $objDomain
$objSearcher.PageSize = 1000
$objSearcher.Filter = �(objectClass=Computer)�
$colResults = $objSearcher.FindAll()

##  2. Opens Excel, Add a workbook and deletes default workbooks 2 and 3
    $excel = new-object -comobject excel.application
    $excel.visible = $true
    $workbook = $excel.workbooks.add()
    $workbook.WorkSheets.item(3).delete()
    $workbook.WorkSheets.item(2).delete()
    #Names the worksheet
    $workbook.WorkSheets.item(1).Name = "Servers"
    $sheet = $workbook.WorkSheets.Item("Servers")

    $lineStyle = "microsoft.office.interop.excel.xlLineStyle" -as [type]
    $colorIndex = "microsoft.office.interop.excel.xlColorIndex" -as [type]
    $borderWeight = "microsoft.office.interop.excel.xlBorderWeight" -as [type]
    $chartType = "microsoft.office.interop.excel.xlChartType" -as [type]

    ##  3. Builds Array of Values to display in header
    $Borders = @("Server","Pagefile Location","Automanaged","Pagefile Size","RAM Size","PF Initial Size","PF Max Size","System Drive Free Space","Data Drive Free Space")
    $b = 1

    ##  4. Creates Excel Header
    Foreach ($item in $Borders) {
        $sheet.cells.item(1,$b).interior.ColorIndex = 1
        $sheet.cells.item(1,$b).font.bold = $true
        $sheet.cells.item(1,$b).font.colorindex = 2
        $sheet.cells.item(1,$b).borders.LineStyle = $lineStyle::xlContinuous
        $sheet.cells.item(1,$b).borders.ColorIndex = $colorIndex::xlColorIndexAutomatic
        #$sheet.cells.item(1,$b).borders.Weight = $borderWeight::xlMedium
        $sheet.cells.item(1,$b) = $item
        $b = $b + 1
    }
    $x = 2

##    5. Loop through each server
foreach ($i in $colResults){
    # Set variables to null
    $Server = $null;$PageFileLocation = $null;$SystemManaged = $null;$PageFileSize = $null;$physicalmem = $null;$SysDriveFreeSpace = $null;$DDriveFreeSpace = $null;
    $PFInitial = $null;$PFMax = $null;
    # Set server name to a string
    [string]$server = $i.properties.name
    $OS_Ver = $i.Properties.operatingsystem
    If (($OS_Ver -like "*server*") -and (Test-Connection -ComputerName $server -Count �2�)){
        $os = get-wmiobject Win32_OperatingSystem -ComputerName $server
        # Verify if server is 2008 R2 because AutomaticManagedPagefile isn�t an property 2000 and 2003
        if ($os.Version -like "6.1*")  {
            $SystemManaged  = Get-WmiObject -ComputerName $server -Class Win32_ComputerSystem | % {$_.AutomaticManagedPagefile}
            if ($SystemManaged -eq "True"){

            ##  6. Collect data on each server
                $physicalmem = gwmi -computer $server Win32_ComputerSystem | % {[Math]::round($_.TotalPhysicalMemory/1MB,0)}
                #$SystemManaged  = Get-WmiObject -ComputerName $server -Class Win32_ComputerSystem | % {$_.AutomaticManagedPagefile}
                $PF = gwmi -computer $server Win32_PageFileUsage
                $PageFileLocation = $PF.Name; $PageFileSize = $PF.AllocatedBaseSize
                $LogicalDrives = Get-WmiObject Win32_logicaldisk -ComputerName $server -Filter "DriveType=�3�"
                    Foreach ($drive in $LogicalDrives) {
                        If ($drive.DeviceID -eq �c:�){$SysDriveFreeSpace = [Math]::round($drive.FreeSpace / 1GB,0)}
                        elseif ($drive.DeviceID -eq �d:�){$DDriveFreeSpace = [Math]::round($drive.FreeSpace / 1GB,0)}
                        elseif ($drive.DeviceID -eq �s:�){$SysDriveFreeSpace = [Math]::round($drive.FreeSpace / 1GB,0)}
                        elseif ($drive.DeviceID -eq �t:�){$DDriveFreeSpace = [Math]::round($drive.FreeSpace / 1GB,0)}
                    }

                $values = @($Server,$PageFileLocation,$SystemManaged,$PageFileSize,$physicalmem,$PFInitial,$PFMax,$SysDriveFreeSpace,$DDriveFreeSpace)
                            $y = 1

                            ##  7. Exports array to Excel
                            foreach ($val in $values) {
                                #Add Values to row x and column y
                                $sheet.cells.item($x,$y) = $val
                                #increase column by 1
                                $y = $y + 1}
            }
            else{

            ##  6. Collect data on each server
                $physicalmem = gwmi -computer $server Win32_ComputerSystem | % {[Math]::round($_.TotalPhysicalMemory/1MB,0)}
                #$SystemManaged  = Get-WmiObject -ComputerName $server -Class Win32_ComputerSystem | % {$_.AutomaticManagedPagefile}
                $PF = gwmi -computer $server Win32_PageFileUsage
                $PageFileLocation = $PF.Name; $PageFileSize = $PF.AllocatedBaseSize
                $LogicalDrives = Get-WmiObject Win32_logicaldisk -ComputerName $server -Filter "DriveType=�3�"
                    Foreach ($drive in $LogicalDrives) {
                        If ($drive.DeviceID -eq �c:�){$SysDriveFreeSpace = [Math]::round($drive.FreeSpace / 1GB,0)}
                        elseif ($drive.DeviceID -eq �d:�){$DDriveFreeSpace = [Math]::round($drive.FreeSpace / 1GB,0)}
                        elseif ($drive.DeviceID -eq �s:�){$SysDriveFreeSpace = [Math]::round($drive.FreeSpace / 1GB,0)}
                        elseif ($drive.DeviceID -eq �t:�){$DDriveFreeSpace = [Math]::round($drive.FreeSpace / 1GB,0)}
                    }
                $PageFileSetting = Get-WmiObject Win32_PageFileSetting -ComputerName $server
                $PFInitial = $PageFileSetting.InitialSize; $PFMax = $PageFileSetting.MaximumSize
                $values = @($Server,$PageFileLocation,$SystemManaged,$PageFileSize,$physicalmem,$PFInitial,$PFMax,$SysDriveFreeSpace,$DDriveFreeSpace)
                            $y = 1

                            ##  7. Exports array to Excel
                            foreach ($val in $values) {
                                #Add Values to row x and column y
                                $sheet.cells.item($x,$y) = $val
                                #increase column by 1
                                $y = $y + 1}
            }

            $x = $x + 1
        }
        Else{

        ##  6. Collect data on each server
            $physicalmem = gwmi -computer $server Win32_ComputerSystem | % {[Math]::round($_.TotalPhysicalMemory/1MB,0)}
            #$SystemManaged  = Get-WmiObject -ComputerName $server -Class Win32_ComputerSystem | % {$_.AutomaticManagedPagefile}
            $PF = gwmi -computer $server Win32_PageFileUsage
            $PageFileLocation = $PF.Name; $PageFileSize = $PF.AllocatedBaseSize
            $LogicalDrives = Get-WmiObject Win32_logicaldisk -ComputerName $server -Filter "DriveType=�3�"
                Foreach ($drive in $LogicalDrives) {
                    If ($drive.DeviceID -eq �c:�){$SysDriveFreeSpace = [Math]::round($drive.FreeSpace / 1GB,0)}
                    elseif ($drive.DeviceID -eq �d:�){$DDriveFreeSpace = [Math]::round($drive.FreeSpace / 1GB,0)}
                    elseif ($drive.DeviceID -eq �s:�){$SysDriveFreeSpace = [Math]::round($drive.FreeSpace / 1GB,0)}
                    elseif ($drive.DeviceID -eq �t:�){$DDriveFreeSpace = [Math]::round($drive.FreeSpace / 1GB,0)}
                }
            $PageFileSetting = Get-WmiObject Win32_PageFileSetting -ComputerName $server
            $PFInitial = $PageFileSetting.InitialSize; $PFMax = $PageFileSetting.MaximumSize
            $values = @($Server,$PageFileLocation,$SystemManaged,$PageFileSize,$physicalmem,$PFInitial,$PFMax,$SysDriveFreeSpace,$DDriveFreeSpace)
                        $y = 1

                        ##  7. Exports array to Excel
                        foreach ($val in $values) {
                            #Add Values to row x and column y
                            $sheet.cells.item($x,$y) = $val
                            #increase column by 1
                            $y = $y + 1}
            $x = $x + 1
            }
    }
}
## 8.  Autofit Excel columns
$range = $sheet.usedRange
$range.EntireColumn.AutoFit() | out-null

##  9. Get Time and Date
$date = Get-Date -Format "yyyyMMd"
$time = Get-Date -Format "HHms"

##  10. Save Workbook
$strPath = "c:\temp\ServerPageFiles-$date-$time.xls"
$excel.ActiveWorkbook.SaveAs($strPath)
$excel.quit()
spps -n excel

#>