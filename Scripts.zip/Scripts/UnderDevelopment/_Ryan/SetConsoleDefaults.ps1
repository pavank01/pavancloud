Function Set-ConsoleDefaults {
<#
	.SYNOPSIS
		Set-ConsoleDefaults allows for quick and consistent customization of the PowerShell/CMD console.

	.DESCRIPTION
		Set-ConsoleDefaults allows for quick and consistent customization of the PowerShell/CMD console.
		* Allows extensive customization of the console from command line or script
		* Defaults to settings that most Admins make when running PowerShell the first time
		* Updates the Registry to change the defaults for the system
		* Recreates all the PowerShell/CMD shortcuts to force the use of the settings in the Registry

		The color names listed are the names for each of the 16 color numbers.
		When using color in the PowerShell console the number or name can be used. The CMD console only uses the number.
		The visible color associated with the number/name may vary based on the ColorSet selected.

			0 = Black         8  = DarkGray
			1 = DarkBlue      9  = Blue
			2 = DarkGreen     10 = Green
			3 = DarkCyan      11 = Cyan
			4 = DarkRed       12 = Red
			5 = DarkMagenta   13 = Magenta
			6 = DarkYellow    14 = Yellow
			7 = Gray          15 = White

			Please see the links below for color samples to help create custom ColorSets.
			http://www.computerhope.com/htmcolor.htm
			http://palettegenerator.com

	.PARAMETER ColorSet
		Specifies one of several named color sets to use for the console.
		Choices are Default, PowerShellDefault, Muted, Espresso, Modern, Flat, Pastel, Gruvbox, Dark, ColorBlind, and Custom
		Custom requires parameters Color00 through Color15. Any not specified will come from the existing system default.

	.PARAMETER FontName
		The name of the font to use.
		Choices are Consolas, Lucida_Console

	.PARAMETER FontSize
		The point size of the font to use.
		Choices are 10, 12, 14, 16, 18, 20

	.PARAMETER Width
		The percentage of screen width to use for the console size.
		Choices are 10 ... 100

	.PARAMETER Height
		The percentage of screen height to use for the console size.
		Choices are 10 ... 100

	.PARAMETER HistoryBufferSize
		The size of the command history buffer (number of commands).

	.PARAMETER HistoryBuffers
		The number of command history buffers.

	.PARAMETER DiscardDuplicates
		Discard duplicate commands in the current command history buffer.

	.PARAMETER DisableInsertMode
		Disable Insert Mode on the command line in the console.
		If disabled then new characters entered on the command line will overwrite the next character.

	.PARAMETER DisableQuickEdit
		Disable Quick Edit Mode in the console.
		If disabled then the mouse cannot be used to select / paste text to / from the clipboard.

	.PARAMETER CursorSize
		Sets the size (percentage) of the cursor in Insert Mode.
		In Overwrite Mode the cursor will be approximately 3x the size of Insert Mode.
		Choices are 1 ... 32

	.PARAMETER ConsoleTop
		Sets the top edge position of the console window in pixels

	.PARAMETER ConsoleLeft
		Sets the left edge position of the console window in pixels

	.PARAMETER PSForeground
		Sets the foreground (text) color to use in the PowerShell console.
		Can be the color number from 0 ... 15 or the color name
		Defaults to the color specified by the ColorSet

	.PARAMETER PSBackground
		Sets the background color to use in the PowerShell console.
		Can be the color number from 0 ... 15 or the color name
		Defaults to the color specified by the ColorSet

	.PARAMETER CMDForeground
		Sets the foreground (text) color to use in the Command (DOS) console.
		Can be the color number from 0 ... 15 or the color name
		Defaults to the color specified by the ColorSet

	.PARAMETER CMDBackground
		Sets the background color to use in the Command (DOS) console.
		Can be the color number from 0 ... 15 or the color name
		Defaults to the color specified by the ColorSet

	.PARAMETER Color00
		Color 0 = Black
		Sets a custom color to the specified color number using HTML RGB hex triplet format.
		HTML RGB hex triplet format is #RRGGBB where RR=Red, GG=Green, BB=Blue.
		Each color is from decimal 0 ... 255 in hex format 00 ... FF and starts with a # (pound symbol).

		Example of a pale yellow:
			Integer:
				Red=255 Green=236 Blue=139
			Hex:
				Red=FF Green=EC Blue=8B
			HTML Hex:
				#FFEC8B

	.PARAMETER Color01
		Color 1 = DarkBlue
		See Color00 parameter for details.

	.PARAMETER Color02
		Color 2 = DarkGreen
		See Color00 parameter for details.

	.PARAMETER Color03
		Color 3 = DarkCyan
		See Color00 parameter for details.

	.PARAMETER Color04
		Color 4 = DarkRed
		See Color00 parameter for details.

	.PARAMETER Color05
		Color 5 = DarkMagenta
		See Color00 parameter for details.

	.PARAMETER Color06
		Color 6 = DarkYellow
		See Color00 parameter for details.

	.PARAMETER Color07
		Color 7 = Gray
		See Color00 parameter for details.

	.PARAMETER Color08
		Color 8 = DarkGray
		See Color00 parameter for details.

	.PARAMETER Color09
		Color 9 = Blue
		See Color00 parameter for details.

	.PARAMETER Color10
		Color 10 = Green
		See Color00 parameter for details.

	.PARAMETER Color11
		Color 11 = Cyan
		See Color00 parameter for details.

	.PARAMETER Color12
		Color 12 = Red
		See Color00 parameter for details.

	.PARAMETER Color13
		Color 13 = Magenta
		See Color00 parameter for details.

	.PARAMETER Color14
		Color 14 = Yellow
		See Color00 parameter for details.

	.PARAMETER Color15
		Color 15 = White
		See Color00 parameter for details.

	.OUTPUTS
		None

	.NOTES
		Written by Ryan Amsbury
		v0.5 - Beta Testing

		The core if this script is based on code written by Craig Landis.
		"Set console settings based on detected screen resolution"
		http://gallery.technet.microsoft.com/Set-console-settings-based-37ec9927
#>

	[CmdletBinding()]
	Param (
		# Color Set
		[Parameter(Mandatory = $False)]
		[ValidateSet("Default", "DefaultBright", "DefaultDark", "PowerShellDefault", "Muted", "Espresso", "Modern", "Flat", "Pastel", "Gruvbox", "Dark", "ColorBlind", "Custom")]
		[String]$ColorSet = "Default",

		# Font Name
		[Parameter(Mandatory = $False)]
		[ValidateSet("Consolas", "Lucida_Console")]
		[String]$FontName = "Lucida_Console",

		# Font Size
		[Parameter(Mandatory = $False)]
		[ValidateSet(10, 12, 14, 16, 18, 20)]
		[Int]$FontSize = 14,

		# Console width as % of screen width
		[Parameter(Mandatory = $False)]
		[ValidateRange(10, 100)]
		[Int]$Width = 99,

		# Console heigh as % of screen height
		[Parameter(Mandatory = $False)]
		[ValidateRange(10, 100)]
		[Int]$Height = 99,

		# Command history buffer size
		[Parameter(Mandatory = $False)]
		[Int]$HistoryBufferSize = 100,

		# Command history buffer count
		[Parameter(Mandatory = $False)]
		[Int]$HistoryBuffers = 4,

		# Discard old duplicates in command history
		[Parameter(Mandatory = $False)]
		[Switch]$DiscardDuplicates = $False,

		# Disable insert mode
		[Parameter(Mandatory = $False)]
		[Switch]$DisableInsertMode = $False,

		# Disable quick edit mode
		[Parameter(Mandatory = $False)]
		[Switch]$DisableQuickEdit = $False,

		# Cursor size in % of line height
		[Parameter(Mandatory = $False)]
		[ValidateRange(1, 32)]
		[Int]$CursorSize = 9,

		# Console window top edge position in pixels
		[Parameter(Mandatory = $False)]
		[Int]$ConsoleTop = 0,

		# Console window left edge position in pixels
		[Parameter(Mandatory = $False)]
		[Int]$ConsoleLeft = 0,

		# PowerShell foreground (text) color
		[Parameter(Mandatory = $False)]
		[ValidateSet(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, "Black", "DarkBlue", "DarkGreen", "DarkCyan", "DarkRed", "DarkMagenta", "DarkYellow", "DarkGray", "Gray", "Blue", "Green", "Cyan", "Red", "Magenta", "Yellow", "White")]
		$PSForeground = 0,

		# PowerShell background color
		[Parameter(Mandatory = $False)]
		[ValidateSet(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, "Black", "DarkBlue", "DarkGreen", "DarkCyan", "DarkRed", "DarkMagenta", "DarkYellow", "DarkGray", "Gray", "Blue", "Green", "Cyan", "Red", "Magenta", "Yellow", "White")]
		$PSBackground = 0,

		# CMD foreground (text) color
		[Parameter(Mandatory = $False)]
		[ValidateSet(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, "Black", "DarkBlue", "DarkGreen", "DarkCyan", "DarkRed", "DarkMagenta", "DarkYellow", "DarkGray", "Gray", "Blue", "Green", "Cyan", "Red", "Magenta", "Yellow", "White")]
		$CMDForeground = 0,

		# CMD background color
		[Parameter(Mandatory = $False)]
		[ValidateSet(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, "Black", "DarkBlue", "DarkGreen", "DarkCyan", "DarkRed", "DarkMagenta", "DarkYellow", "DarkGray", "Gray", "Blue", "Green", "Cyan", "Red", "Magenta", "Yellow", "White")]
		$CMDBackground = 0,

		# Color 0 = Black
		[Parameter(Mandatory = $False)]
		[ValidatePattern("#[A-Fa-f0-9]{6}|[A-Fa-f0-9]{6}")]
		[String]$Color00 = $Null,

		# Color 1 = DarkBlue
		[Parameter(Mandatory = $False)]
		[ValidatePattern("#[A-Fa-f0-9]{6}|[A-Fa-f0-9]{6}")]
		[String]$Color01 = $Null,

		# DarkGreen
		[Parameter(Mandatory = $False)]
		[ValidatePattern("#[A-Fa-f0-9]{6}|[A-Fa-f0-9]{6}")]
		[String]$Color02 = $Null,

		# DarkCyan
		[Parameter(Mandatory = $False)]
		[ValidatePattern("#[A-Fa-f0-9]{6}|[A-Fa-f0-9]{6}")]
		[String]$Color03 = $Null,

		# DarkRed
		[Parameter(Mandatory = $False)]
		[ValidatePattern("#[A-Fa-f0-9]{6}|[A-Fa-f0-9]{6}")]
		[String]$Color04 = $Null,

		# DarkMagenta
		[Parameter(Mandatory = $False)]
		[ValidatePattern("#[A-Fa-f0-9]{6}|[A-Fa-f0-9]{6}")]
		[String]$Color05 = $Null,

		# DarkYellow
		[Parameter(Mandatory = $False)]
		[ValidatePattern("#[A-Fa-f0-9]{6}|[A-Fa-f0-9]{6}")]
		[String]$Color06 = $Null,

		# Gray
		[Parameter(Mandatory = $False)]
		[ValidatePattern("#[A-Fa-f0-9]{6}|[A-Fa-f0-9]{6}")]
		[String]$Color07 = $Null,

		# DarkGray
		[Parameter(Mandatory = $False)]
		[ValidatePattern("#[A-Fa-f0-9]{6}|[A-Fa-f0-9]{6}")]
		[String]$Color08 = $Null,

		# Blue
		[Parameter(Mandatory = $False)]
		[ValidatePattern("#[A-Fa-f0-9]{6}|[A-Fa-f0-9]{6}")]
		[String]$Color09 = $Null,

		# Green
		[Parameter(Mandatory = $False)]
		[ValidatePattern("#[A-Fa-f0-9]{6}|[A-Fa-f0-9]{6}")]
		[String]$Color10 = $Null,

		# Cyan
		[Parameter(Mandatory = $False)]
		[ValidatePattern("#[A-Fa-f0-9]{6}|[A-Fa-f0-9]{6}")]
		[String]$Color11 = $Null,

		# Red
		[Parameter(Mandatory = $False)]
		[ValidatePattern("#[A-Fa-f0-9]{6}|[A-Fa-f0-9]{6}")]
		[String]$Color12 = $Null,

		# Magenta
		[Parameter(Mandatory = $False)]
		[ValidatePattern("#[A-Fa-f0-9]{6}|[A-Fa-f0-9]{6}")]
		[String]$Color13 = $Null,

		# Yellow
		[Parameter(Mandatory = $False)]
		[ValidatePattern("#[A-Fa-f0-9]{6}|[A-Fa-f0-9]{6}")]
		[String]$Color14 = $Null,

		# White
		[Parameter(Mandatory = $False)]
		[ValidatePattern("#[A-Fa-f0-9]{6}|[A-Fa-f0-9]{6}")]
		[String]$Color15 = $Null
	)
	Function RGBtoBGR {
		# Convert from #RRGGBB to 0xBBGGRR
		Param ($TempColor)
		'0x'+$TempColor.SubString(5, 2)+$TempColor.SubString(3, 2)+$TempColor.SubString(1, 2)
	}
	Function BGRtoRGB {
		# Convert from 0xBBGGRR to #RRGGBB
		Param ($TempColor)
		$TempColor = ([System.Convert]::ToString($TempColor,16)).PadLeft(6,"0")
		'#'+$TempColor.SubString(4, 2)+$TempColor.SubString(2, 2)+$TempColor.SubString(0, 2)
	}
	Function IsNumeric {
		# Returns $True if $TempValue can be evaluated as a number even if quoted
		# Returns $False if $TempValue cannot be evaluated as a number
		Param ($TempValue)
		Add-Type -Assembly Microsoft.VisualBasic
		[Microsoft.VisualBasic.Information]::IsNumeric($TempValue)
	}
	# --------------------------------------------------------------------------
	# Change to $True for shortcuts (.lnk) to be updated in addition to the registry changes.
	# Creates backups (*.lnk.bak) before changing the existing shortcut.
	$UpdateShortcuts = $True

	# If $True, keeps the backup *.lnk.bak files. If $False, removes the backup *.lnk.bak files.
	$KeepBackupShortcuts = $False

	# Colors are specified using HTML RGB hex triplet format.
	# HTML RGB hex triplet format is #RRGGBB where RR=Red, GG=Green, BB=Blue.
	# Each color is from decimal 0 ... 255 in hex format 00 ... FF and starts with a '#'.

	# In the Registry they are stored as a DWORD of Hex 0x00BBGGRR
	# PowerShellBlue is RR=1 GG=36 BB=86, HTML:#012456, Hex:0x562401, DWORD:5645313

	# Please see the links below for color samples to help create custom ColorSets.
	# http://www.computerhope.com/htmcolor.htm
	# http://palettegenerator.com
	# http://www.psyclops.com/tools/rgb/

	# Number  = Name        = R_% G_% B_%
	# Color00 = Black       =  00  00  00
	# Color01 = DarkBlue    =  00  00  50
	# Color02 = DarkGreen   =  00  50  00
	# Color03 = DarkCyan    =  00  50  50
	# Color04 = DarkRed     =  50  00  00
	# Color05 = DarkMagenta =  50  00  50
	# Color06 = DarkYellow  =  50  50  50
	# Color07 = Gray        =  75  75  75
	# Color08 = DarkGray    =  50  50  50
	# Color09 = Blue        =  00  00 100
	# Color10 = Green       =  00 100  00
	# Color11 = Cyan        =  00 100 100
	# Color12 = Red         = 100  00  00
	# Color13 = Magenta     = 100  00 100
	# Color14 = Yellow      = 100 100  00
	# Color15 = White       = 100 100 100

	# PSForeground  = PowerShell Foreground
	# PSBackground  = PowerShell Background
	# CMDForeground = Command Foreground
	# CMDBackground = Command Background

	#   0%    0  #00
	#  10%   26  #1A
	#  20%   51  #33
	# --------------
	#  25%   64  #40
	#  30%   77  #4D
	#  40%  102  #66
	# --------------
	#  50%  128  #80
	#  60%  154  #9A
	#  70%  179  #B3
	# --------------
	#  75%  192  #C0
	#  80%  205  #CD
	#  90%  230  #E6
	# 100%  255  #FF

	# Remember to add new names to the ColorSet parameter's validation set
	$ColorSets = @{
		"PowerShellDefault" = @{
			# This is the Microsoft default color set for PowerShell
			# Uses DarkMagenta (06) as off-white for foreground text color
			# Uses DarkYellow (05) as PowerShell Blue for background color
			"Color00"      = "#000000";  "Color08"       = "#808080";
			"Color01"      = "#000080";  "Color09"       = "#0000ff";
			"Color02"      = "#008000";  "Color10"       = "#00ff00";
			"Color03"      = "#008080";  "Color11"       = "#00ffff";
			"Color04"      = "#800000";  "Color12"       = "#ff0000";
			"Color05"      = "#012456";  "Color13"       = "#ff00ff";
			"Color06"      = "#eeedf0";  "Color14"       = "#ffff00";
			"Color07"      = "#c0c0c0";  "Color15"       = "#ffffff";
			"PSForeground" = 6;          "CMDForeground" = 7;
			"PSBackground" = 5;          "CMDBackground" = 0
		}
		# This is a slightly altered version of the default PowerShell color set with correct colors
		# DarkBlue (now PowerShell Blue), DarkMagenta (was PowerShell Blue), and DarkYellow (was off-White)
		# Changed Text color from DarkYellow to Gray
		# Changed Background color from DarkMagenta to DarkBlue
		# Color = 50% 100% | Gray = 50% 75% | B/W = 0% 100% | PowerShell Blue
		"Default" = @{
			"Color00"      = "#000000";  "Color08"       = "#808080";
			"Color01"      = "#123456";  "Color09"       = "#0000ff";
			"Color02"      = "#008000";  "Color10"       = "#00ff00";
			"Color03"      = "#008080";  "Color11"       = "#00ffff";
			"Color04"      = "#800000";  "Color12"       = "#ff0000";
			"Color05"      = "#800080";  "Color13"       = "#ff00ff";
			"Color06"      = "#808000";  "Color14"       = "#ffff00";
			"Color07"      = "#c0c0c0";  "Color15"       = "#ffffff";
			"PSForeground" = 7;          "CMDForeground" = 7;
			"PSBackground" = 1;          "CMDBackground" = 0
		}
		# Color = 70% 100% | Gray = 70% 80% | B/W = 0% 100%
		"DefaultBright" = @{
			"Color00"      = "#000000";  "Color08"       = "#b3b3b3";
			"Color01"      = "#0000b3";  "Color09"       = "#0000ff";
			"Color02"      = "#00b300";  "Color10"       = "#00ff00";
			"Color03"      = "#00b3b3";  "Color11"       = "#00ffff";
			"Color04"      = "#b30000";  "Color12"       = "#ff0000";
			"Color05"      = "#b300b3";  "Color13"       = "#ff00ff";
			"Color06"      = "#b3b300";  "Color14"       = "#ffff00";
			"Color07"      = "#cdcdcd";  "Color15"       = "#ffffff";
			"PSForeground" = 7;          "CMDForeground" = 7;
			"PSBackground" = 1;          "CMDBackground" = 0
		}
		# Color = 50% 80% | Gray = 50% 80% | B/W = 0% 100%
		"DefaultDark" = @{
			"Color00"      = "#000000";  "Color08"       = "#808080";
			"Color01"      = "#000080";  "Color09"       = "#0000cd";
			"Color02"      = "#008000";  "Color10"       = "#00cd00";
			"Color03"      = "#008080";  "Color11"       = "#00cdcd";
			"Color04"      = "#800000";  "Color12"       = "#cd0000";
			"Color05"      = "#800080";  "Color13"       = "#cd00cd";
			"Color06"      = "#808000";  "Color14"       = "#cdcd00";
			"Color07"      = "#cdcdcd";  "Color15"       = "#ffffff";
			"PSForeground" = 7;          "CMDForeground" = 7;
			"PSBackground" = 1;          "CMDBackground" = 0
		}
		"ColorBlind" = @{
			"Color00"      = "#000000";  "Color08"       = "#7F4C69";
			"Color01"      = "#044266";  "Color09"       = "#0773b3";
			"Color02"      = "#03513A";  "Color10"       = "#069f73";
			"Color03"      = "#3D7796";  "Color11"       = "#5cb4e4";
			"Color04"      = "#843B19";  "Color12"       = "#d36027";
			"Color05"      = "#99681A";  "Color13"       = "#e79f26";
			"Color06"      = "#A3992F";  "Color14"       = "#f1e545";
			"Color07"      = "#cc79a7";  "Color15"       = "#ffffff";
			"PSForeground" = 7;          "CMDForeground" = 7;
			"PSBackground" = 1;          "CMDBackground" = 0
		}
		"Muted" = @{
			"Color00"      = "#000000";  "Color08"       = "#808080";
			"Color01"      = "#123456";  "Color09"       = "#1874cd";
			"Color02"      = "#006400";  "Color10"       = "#00cd66";
			"Color03"      = "#53868b";  "Color11"       = "#87ceeb";
			"Color04"      = "#8b0000";  "Color12"       = "#ee2c2c";
			"Color05"      = "#473c8b";  "Color13"       = "#836fff";
			"Color06"      = "#cd950c";  "Color14"       = "#ffec8b";
			"Color07"      = "#c0c0c0";  "Color15"       = "#ffffff";
			"PSForeground" = 7;          "CMDForeground" = 7;
			"PSBackground" = 1;          "CMDBackground" = 0
		}
		"Dark" = @{
			"Color00"      = "#000000";  "Color08"       = "#404040";
			"Color01"      = "#091A2C";  "Color09"       = "#000080";
			"Color02"      = "#004000";  "Color10"       = "#008000";
			"Color03"      = "#004040";  "Color11"       = "#008080";
			"Color04"      = "#400000";  "Color12"       = "#800000";
			"Color05"      = "#400040";  "Color13"       = "#800080";
			"Color06"      = "#404000";  "Color14"       = "#808000";
			"Color07"      = "#606060";  "Color15"       = "#808080";
			"PSForeground" = 7;          "CMDForeground" = 7;
			"PSBackground" = 1;          "CMDBackground" = 0
		}
		"Modern" = @{
			"Color00"      = "#19222c";  "Color08"       = "#545f5f";
			"Color01"      = "#17476d";  "Color09"       = "#3598dc";
			"Color02"      = "#166436";  "Color10"       = "#2fcc71";
			"Color03"      = "#0c5a4a";  "Color11"       = "#1bbc9d";
			"Color04"      = "#742018";  "Color12"       = "#e84c3d";
			"Color05"      = "#4f2664";  "Color13"       = "#9c59b8";
			"Color06"      = "#b97708";  "Color14"       = "#f1c40f";
			"Color07"      = "#72767a";  "Color15"       = "#ecf0f1";
			"PSForeground" = 7;          "CMDForeground" = 15;
			"PSBackground" = 0;          "CMDBackground" = 0
		}
		"Flat" = @{
			"Color00"      = "#2b2b2b";  "Color08"       = "#7f8c8d";
			"Color01"      = "#2c3e50";  "Color09"       = "#2980b9";
			"Color02"      = "#2d5036";  "Color10"       = "#8eb021";
			"Color03"      = "#5e4534";  "Color11"       = "#d5c295";
			"Color04"      = "#79302a";  "Color12"       = "#ef717a";
			"Color05"      = "#5e345e";  "Color13"       = "#745ec5";
			"Color06"      = "#a35e00";  "Color14"       = "#ffa800";
			"Color07"      = "#bdc3c7";  "Color15"       = "#ecf0f1";
			"PSForeground" = 7;          "CMDForeground" = 7;
			"PSBackground" = 1;          "CMDBackground" = 0
		}
		"Espresso" = @{
			"Color00"      = "#271d14";  "Color08"       = "#966859";
			"Color01"      = "#44525c";  "Color09"       = "#7a8391";
			"Color02"      = "#343b18";  "Color10"       = "#b1c796";
			"Color03"      = "#68330a";  "Color11"       = "#e29063";
			"Color04"      = "#5d1b0d";  "Color12"       = "#ad3418";
			"Color05"      = "#67545b";  "Color13"       = "#998693";
			"Color06"      = "#c67202";  "Color14"       = "#f0db71";
			"Color07"      = "#c9b88d";  "Color15"       = "#fefefe";
			"PSForeground" = 7;          "CMDForeground" = 7;
			"PSBackground" = 0;          "CMDBackground" = 0
		}
		"Pastel" = @{
			"Color00"      = "#0C0C0C";  "Color08"       = "#545f5f";
			"Color01"      = "#0F243E";  "Color09"       = "#548DD4";
			"Color02"      = "#4F6128";  "Color10"       = "#C3D69B";
			"Color03"      = "#205867";  "Color11"       = "#92CDDC";
			"Color04"      = "#632423";  "Color12"       = "#D99694";
			"Color05"      = "#3F3151";  "Color13"       = "#B2A2C7";
			"Color06"      = "#974806";  "Color14"       = "#FAC08F";
			"Color07"      = "#7F7F7F";  "Color15"       = "#D8D8D8";
			"PSForeground" = 7;          "CMDForeground" = 7;
			"PSBackground" = 1;          "CMDBackground" = 0
		}
		"Gruvbox" = @{
			# https://github.com/morhetz/gruvbox
			"Color00"      = "#282828";  "Color08"       = "#928374";
			"Color01"      = "#458588";  "Color09"       = "#83a598";
			"Color02"      = "#98971a";  "Color10"       = "#b8bb26";
			"Color03"      = "#689d6a";  "Color11"       = "#8ec07c";
			"Color04"      = "#cc241d";  "Color12"       = "#fb4934";
			"Color05"      = "#b16286";  "Color13"       = "#d3869b";
			"Color06"      = "#d79921";  "Color14"       = "#fabd2f";
			"Color07"      = "#d5c4a1";  "Color15"       = "#fbf1c7";
			"PSForeground" = 7;          "CMDForeground" = 7;
			"PSBackground" = 0;          "CMDBackground" = 0
		}
		"Custom" = @{
			# Do not change
			"Color00"      = "#000000";  "Color08"       = "#808080";
			"Color01"      = "#123456";  "Color09"       = "#0000ff";
			"Color02"      = "#008000";  "Color10"       = "#00ff00";
			"Color03"      = "#008080";  "Color11"       = "#00ffff";
			"Color04"      = "#800000";  "Color12"       = "#ff0000";
			"Color05"      = "#800080";  "Color13"       = "#ff00ff";
			"Color06"      = "#808000";  "Color14"       = "#ffff00";
			"Color07"      = "#c0c0c0";  "Color15"       = "#ffffff";
			"PSForeground" = 7;          "CMDForeground" = 7;
			"PSBackground" = 1;          "CMDBackground" = 0
		}
	}

	# Color00       = Black
	# Color01       = DarkBlue
	# Color02       = DarkGreen
	# Color03       = DarkCyan
	# Color04       = DarkRed
	# Color05       = DarkMagenta
	# Color06       = DarkYellow
	# Color07       = Gray
	# Color08       = DarkGray
	# Color09       = Blue
	# Color10       = Green
	# Color11       = Cyan
	# Color12       = Red
	# Color13       = Magenta
	# Color14       = Yellow
	# Color15       = White

	$ColorValues = @{
		"Black"       = 0;
		"DarkBlue"    = 1;
		"DarkGreen"   = 2;
		"DarkCyan"    = 3;
		"DarkRed"     = 4;
		"DarkMagenta" = 5;
		"DarkYellow"  = 6;
		"Gray"        = 7;
		"DarkGray"    = 8;
		"Blue"        = 9;
		"Green"       = 10;
		"Cyan"        = 11;
		"Red"         = 12;
		"Magenta"     = 13;
		"Yellow"      = 14;
		"White"       = 15
	}

	# https://support.microsoft.com/en-us/kb/247815
	# KB247815 - Necessary Criteria for Fonts to Be Available in a PowerShell \ Command Console
	#
	# SUMMARY
	#
	# For fonts to be available for use in a PowerShell (powershell.exe) \ Command (cmd.exe) console
	# (on the Fonts tab in the Properties dialog box), the fonts must meet certain criteria.
	#
	# The fonts must meet the following criteria to be available in a command session window:
	#
	# The font must be a fixed-pitch font.
	# The font cannot be an italic font.
	# The font cannot have a negative A or C space.
	# If it is a TrueType font, it must be FF_MODERN.
	# If it is not a TrueType font, it must be OEM_CHARSET.
	# Additional criteria for Asian installations:
	#
	# If it is not a TrueType font, the face name must be "Terminal."
	# If it is an Asian TrueType font, it must also be an Asian character set.
	# In Windows 2000, the installation of Console Fonts is no longer automated.
	# This was done to give the console window greater stability in multi-language environments.
	# An unsupported work around is available by adding the following font specific entries:
	#
	# Add a String Value
	# Name=0
	# Data=Font Name
	#
	# Into the following registry:
	#
	# HKLM\Software\Microsoft\WindowsNT\CurrentVersion\Console\TrueTypeFont
	# The name needs to be incremented with "0" for each additional font (ie: 0, 00, 000, 0000, 00000).
	#
	# Data must exactly match the font's name, without the " (TrueType)" appended to the name, in the following registry location:
	# HKLM\Software\Microsoft\WindowsNT\CurrentVersion\Fonts
	#
	# $AllFonts = Get-Item "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Fonts" | Select-Object -Expand Property | Sort-Object | ForEach {($_.Replace('(TrueType)', '')).Trim()}

	# The spaces in font names have been removed to make the -FontName parameter easier to use
	# The correct name must be used in the Registry

	$Fonts = @{
		"Consolas" = @{
			"Name" = "Consolas";
			10 = @{
				"Height"  = 10;
				"Width"   =  5
			}
			12 = @{
				"Height" = 12;
				"Width"  =  6
			}
			14 = @{
				"Height" = 14;
				"Width"  =  7
			}
			16 = @{
				"Height" = 16;
				"Width"  =  8
			}
			18 = @{
				"Height" = 18;
				"Width"  =  8
			}
			20 = @{
				"Height" = 20;
				"Width"  =  9
			}
		}
		"Lucida_Console" = @{
			"Name" = "Lucida Console";
			10 = @{
				"Height" = 10;
				"Width"  =  6
			}
			12 = @{
				"Height" = 12;
				"Width"  =  7
			}
			14 = @{
				"Height" = 14;
				"Width"  =  8
			}
			16 = @{
				"Height" = 16;
				"Width"  = 10
			}
			18 = @{
				"Height" = 18;
				"Width"  = 11
			}
			20 = @{
				"Height" = 20;
				"Width"  = 12
			}
		}
	}
	## If ColorSet Custom is used then pull any unspecified colors from the Registry
	If ($ColorSet -eq "Custom") {
		If ($Color00 -eq $Null -or $Color00 -eq "") {
			$Color00 = BGRtoRGB (Get-ItemProperty -Path HKCU:Console).ColorTable00
		} ElseIf ($Color00 -match "^[A-Fa-f0-9]{6}") {
			$Color00 = '#'+$Color00
		}
		If ($Color01 -eq $Null -or $Color01 -eq "") {
			$Color01 = BGRtoRGB (Get-ItemProperty -Path HKCU:Console).ColorTable01
		} ElseIf ($Color01 -match "^[A-Fa-f0-9]{6}") {
			$Color01 = '#'+$Color01
		}
		If ($Color02 -eq $Null -or $Color02 -eq "") {
			$Color02 = BGRtoRGB (Get-ItemProperty -Path HKCU:Console).ColorTable02
		} ElseIf ($Color02 -match "^[A-Fa-f0-9]{6}") {
			$Color02 = '#'+$Color02
		}
		If ($Color03 -eq $Null -or $Color03 -eq "") {
			$Color03 = BGRtoRGB (Get-ItemProperty -Path HKCU:Console).ColorTable03
		} ElseIf ($Color03 -match "^[A-Fa-f0-9]{6}") {
			$Color03 = '#'+$Color03
		}
		If ($Color04 -eq $Null -or $Color04 -eq "") {
			$Color04 = BGRtoRGB (Get-ItemProperty -Path HKCU:Console).ColorTable04
		} ElseIf ($Color04 -match "^[A-Fa-f0-9]{6}") {
			$Color04 = '#'+$Color04
		}
		If ($Color05 -eq $Null -or $Color05 -eq "") {
			$Color05 = BGRtoRGB (Get-ItemProperty -Path HKCU:Console).ColorTable05
		} ElseIf ($Color05 -match "^[A-Fa-f0-9]{6}") {
			$Color05 = '#'+$Color05
		}
		If ($Color06 -eq $Null -or $Color06 -eq "") {
			$Color06 = BGRtoRGB (Get-ItemProperty -Path HKCU:Console).ColorTable06
		} ElseIf ($Color06 -match "^[A-Fa-f0-9]{6}") {
			$Color06 = '#'+$Color06
		}
		If ($Color07 -eq $Null -or $Color07 -eq "") {
			$Color07 = BGRtoRGB (Get-ItemProperty -Path HKCU:Console).ColorTable07
		} ElseIf ($Color07 -match "^[A-Fa-f0-9]{6}") {
			$Color07 = '#'+$Color07
		}
		If ($Color08 -eq $Null -or $Color08 -eq "") {
			$Color08 = BGRtoRGB (Get-ItemProperty -Path HKCU:Console).ColorTable08
		} ElseIf ($Color08 -match "^[A-Fa-f0-9]{6}") {
			$Color08 = '#'+$Color08
		}
		If ($Color09 -eq $Null -or $Color09 -eq "") {
			$Color09 = BGRtoRGB (Get-ItemProperty -Path HKCU:Console).ColorTable09
		} ElseIf ($Color09 -match "^[A-Fa-f0-9]{6}") {
			$Color09 = '#'+$Color09
		}
		If ($Color10 -eq $Null -or $Color10 -eq "") {
			$Color10 = BGRtoRGB (Get-ItemProperty -Path HKCU:Console).ColorTable10
		} ElseIf ($Color10 -match "^[A-Fa-f0-9]{6}") {
			$Color10 = '#'+$Color10
		}
		If ($Color11 -eq $Null -or $Color11 -eq "") {
			$Color11 = BGRtoRGB (Get-ItemProperty -Path HKCU:Console).ColorTable11
		} ElseIf ($Color11 -match "^[A-Fa-f0-9]{6}") {
			$Color11 = '#'+$Color11
		}
		If ($Color12 -eq $Null -or $Color12 -eq "") {
			$Color12 = BGRtoRGB (Get-ItemProperty -Path HKCU:Console).ColorTable12
		} ElseIf ($Color12 -match "^[A-Fa-f0-9]{6}") {
			$Color12 = '#'+$Color12
		}
		If ($Color13 -eq $Null -or $Color13 -eq "") {
			$Color13 = BGRtoRGB (Get-ItemProperty -Path HKCU:Console).ColorTable13
		} ElseIf ($Color13 -match "^[A-Fa-f0-9]{6}") {
			$Color13 = '#'+$Color13
		}
		If ($Color14 -eq $Null -or $Color14 -eq "") {
			$Color14 = BGRtoRGB (Get-ItemProperty -Path HKCU:Console).ColorTable14
		} ElseIf ($Color14 -match "^[A-Fa-f0-9]{6}") {
			$Color14 = '#'+$Color14
		}
		If ($Color15 -eq $Null -or $Color15 -eq "") {
			$Color15 = BGRtoRGB (Get-ItemProperty -Path HKCU:Console).ColorTable15
		} ElseIf ($Color15 -match "^[A-Fa-f0-9]{6}") {
			$Color15 = '#'+$Color15
		}
	}

	# HKCU\Console has the default values, and HCKU\Console\<window title> has settings for a console window with that window title.
	# These values are not used if a shortcut (.lnk) file itself has console settings defined in it.

	$Paths = @(`
	"HKCU:Console",`
	"HKCU:Console\%SystemRoot%_SysWOW64_WindowsPowerShell_v1.0_powershell.exe",`
	"HKCU:Console\%SystemRoot%_SysWOW64_cmd.exe",`
	"HKCU:Console\%SystemRoot%_System32_WindowsPowerShell_v1.0_powershell.exe",`
	"HKCU:Console\%SystemRoot%_System32_cmd.exe",`
	"HKCU:Console\Command Prompt",`
	"HKCU:Console\Windows PowerShell (x86)",`
	"HKCU:Console\Windows PowerShell"`
	)

	# Settings in a shortcut override settings in the registry
	# Since there is no way to edit the console settings in an existing shortcut,
	# the simplest way is to delete the existing one, create a new one, and it will use the registry settings
	# By default, the script will first backup the existing shortcuts, if they exist, before creating a new one.

	$Shortcuts = @(`
	"$ENV:ALLUSERSPROFILE\Microsoft\Windows\Start Menu\Programs\Accessories\Windows PowerShell\Windows PowerShell (x86).lnk",`
	"$ENV:ALLUSERSPROFILE\Microsoft\Windows\Start Menu\Programs\Accessories\Windows PowerShell\Windows PowerShell.lnk",`
	"$ENV:ALLUSERSPROFILE\Microsoft\Windows\Start Menu\Programs\Administrative Tools\Windows PowerShell (x86).lnk",`
	"$ENV:ALLUSERSPROFILE\Microsoft\Windows\Start Menu\Programs\Administrative Tools\Windows PowerShell.lnk",`
	"$ENV:ALLUSERSPROFILE\Microsoft\Windows\Start Menu\Programs\System Tools\Windows PowerShell.lnk",`
	"$ENV:ALLUSERSPROFILE\Start Menu\Programs\Accessories\Windows PowerShell\Windows PowerShell (x86).lnk",`
	"$ENV:ALLUSERSPROFILE\Start Menu\Programs\Accessories\Windows PowerShell\Windows PowerShell.lnk",`
	"$ENV:USERPROFILE\AppData\Roaming\Microsoft\Internet Explorer\Quick Launch\User Pinned\StartMenu\Command Prompt.lnk",`
	"$ENV:USERPROFILE\AppData\Roaming\Microsoft\Internet Explorer\Quick Launch\User Pinned\StartMenu\Windows PowerShell.lnk",`
	"$ENV:USERPROFILE\AppData\Roaming\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\Windows PowerShell.lnk",`
	"$ENV:USERPROFILE\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Accessories\Command Prompt.lnk",`
	"$ENV:USERPROFILE\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\System Tools\Command Prompt.lnk"`
	)

	# Unlike some other methods, this method will get the correct screen resolution even in an RDP session.
	[void][System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
	$ScreenHeight = [Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Height
	$ScreenWidth = [Windows.Forms.Screen]::PrimaryScreen.WorkingArea.Width

	[Int]$NewHeight = [Math]::Floor(((($ScreenHeight * ($Height / 100)) - $ConsoleTop) - 40) / $Fonts.$FontName.$FontSize.Height)
	[Int]$NewWidth = [Math]::Floor(((($ScreenWidth * ($Width / 100)) - $ConsoleLeft) - 40) / $Fonts.$FontName.$FontSize.Width)

	# WindowSize is Vertical/Height character count by Horizontal/Width character count in Hex (0xVertHorz)
	$NewWindowSize = [System.Convert]::ToInt32(('0x{0:X4}' -f $NewHeight)+('{0:X4}' -f $NewWidth),16)

	# BufferSize is Vertical/Height character count by Horizontal/Width character count in Hex (0xVertHorz)
	# Always vertical BufferSize of 9999 but setting horizontal BufferSize to match horizontal WindowSize
	$NewBufferSize = [System.Convert]::ToInt32(('0x{0:X4}' -f 9999)+('{0:X4}' -f $NewWidth),16)

	# Create the registry keys if they do not exist
	$Paths | ForEach-Object {
	    If (!(Test-Path $_)) {
	        New-Item -Path $_ -ItemType Registry -Force | Out-Null
	    }
	}

	# Console Registry Key Details
	# https://technet.microsoft.com/en-us/library/cc978570.aspx

	# Set console settings in the registry
	$Paths | ForEach-Object {
	    # Configure window size and buffer size registry values based on values defined earlier in the script
	    New-ItemProperty -Path $_ -Name WindowSize -Value $NewWindowSize -PropertyType DWORD -Force | Out-Null
	    New-ItemProperty -Path $_ -Name ScreenBufferSize -Value $NewBufferSize -PropertyType DWORD -Force | Out-Null

	    # Configure color tables
		If ($ColorSet -eq "Custom") {
		    New-ItemProperty -Path $_ -Name ColorTable00 -Value $(RGBtoBGR $Color00) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable01 -Value $(RGBtoBGR $Color01) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable02 -Value $(RGBtoBGR $Color02) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable03 -Value $(RGBtoBGR $Color03) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable04 -Value $(RGBtoBGR $Color04) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable05 -Value $(RGBtoBGR $Color05) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable06 -Value $(RGBtoBGR $Color06) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable07 -Value $(RGBtoBGR $Color07) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable08 -Value $(RGBtoBGR $Color08) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable09 -Value $(RGBtoBGR $Color09) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable10 -Value $(RGBtoBGR $Color10) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable11 -Value $(RGBtoBGR $Color11) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable12 -Value $(RGBtoBGR $Color12) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable13 -Value $(RGBtoBGR $Color13) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable14 -Value $(RGBtoBGR $Color14) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable15 -Value $(RGBtoBGR $Color15) -PropertyType DWORD -Force | Out-Null
		} Else {
		    New-ItemProperty -Path $_ -Name ColorTable00 -Value $(RGBtoBGR $ColorSets.$ColorSet.Color00) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable01 -Value $(RGBtoBGR $ColorSets.$ColorSet.Color01) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable02 -Value $(RGBtoBGR $ColorSets.$ColorSet.Color02) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable03 -Value $(RGBtoBGR $ColorSets.$ColorSet.Color03) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable04 -Value $(RGBtoBGR $ColorSets.$ColorSet.Color04) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable05 -Value $(RGBtoBGR $ColorSets.$ColorSet.Color05) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable06 -Value $(RGBtoBGR $ColorSets.$ColorSet.Color06) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable07 -Value $(RGBtoBGR $ColorSets.$ColorSet.Color07) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable08 -Value $(RGBtoBGR $ColorSets.$ColorSet.Color08) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable09 -Value $(RGBtoBGR $ColorSets.$ColorSet.Color09) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable10 -Value $(RGBtoBGR $ColorSets.$ColorSet.Color10) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable11 -Value $(RGBtoBGR $ColorSets.$ColorSet.Color11) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable12 -Value $(RGBtoBGR $ColorSets.$ColorSet.Color12) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable13 -Value $(RGBtoBGR $ColorSets.$ColorSet.Color13) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable14 -Value $(RGBtoBGR $ColorSets.$ColorSet.Color14) -PropertyType DWORD -Force | Out-Null
		    New-ItemProperty -Path $_ -Name ColorTable15 -Value $(RGBtoBGR $ColorSets.$ColorSet.Color15) -PropertyType DWORD -Force | Out-Null
		}

	    # Configure font
	    New-ItemProperty -Path $_ -Name FaceName -Value $Fonts.$FontName.Name -Force | Out-Null
	    New-ItemProperty -Path $_ -Name FontSize -Value $([System.Convert]::ToInt32(('0x{0:X4}' -f $Fonts.$FontName.$FontSize.Height)+('{0:X4}' -f $Fonts.$FontName.$FontSize.Width),16)) -PropertyType DWORD -Force | Out-Null
	    New-ItemProperty -Path $_ -Name FontFamily -Value 0x36 -PropertyType DWORD -Force | Out-Null # 0x0=Raster Fonts 0x48=TrueType Fonts - What is 0x36?
	    New-ItemProperty -Path $_ -Name FontWeight -Value 0x190 -PropertyType DWORD -Force | Out-Null # 0=Normal 1=Bold - What is 0x190?

	    # Configure window position, history buffer size, history buffers, delete history duplicates, insert mode, and quick edit
	    New-ItemProperty -Path $_ -Name CursorSize -Value $([System.Convert]::ToInt32($CursorSize,16)) -PropertyType DWORD -Force | Out-Null
	    New-ItemProperty -Path $_ -Name WindowPosition -Value $([System.Convert]::ToInt32(('0x{0:X4}' -f $ConsoleTop)+('{0:X4}' -f $ConsoleLeft),16)) -PropertyType DWORD -Force | Out-Null # Horizontal/X pixels by Vertical/Y pixels in Hex (0xHorzVert)
	    New-ItemProperty -Path $_ -Name HistoryBufferSize -Value $([System.Convert]::ToInt32(('0x{0:X8}' -f $HistoryBufferSize),16)) -PropertyType DWORD -Force | Out-Null
	    New-ItemProperty -Path $_ -Name NumberOfHistoryBuffers -Value $([System.Convert]::ToInt32(('0x{0:X8}' -f $HistoryBuffers),16)) -PropertyType DWORD -Force | Out-Null
		If ($DiscardDuplicates -eq $True) {
			# Discard duplicate command history
		    New-ItemProperty -Path $_ -Name HistoryNoDup -Value $('0x1') -PropertyType DWORD -Force | Out-Null # 1=True 0=False
		} Else {
			# Keep duplicate command history
		    New-ItemProperty -Path $_ -Name HistoryNoDup -Value $('0x0') -PropertyType DWORD -Force | Out-Null # 1=True 0=False
		}
		If ($DisableInsertMode -eq $True) {
			# Disable Insert Mode
	    	New-ItemProperty -Path $_ -Name InsertMode -Value $('0x0') -PropertyType DWORD -Force | Out-Null # 1=True 0=False
		} Else {
	    	# Enable Insert Mode
	    	New-ItemProperty -Path $_ -Name InsertMode -Value $('0x1') -PropertyType DWORD -Force | Out-Null # 1=True 0=False
		}
		If ($DisableQuickEdit -eq $True) {
			# Disable Quick Edit Mode
		    New-ItemProperty -Path $_ -Name QuickEdit -Value $('0x0') -PropertyType DWORD -Force | Out-Null # 1=True 0=False
		} Else {
			# Enable Quick Edit Mode
			New-ItemProperty -Path $_ -Name QuickEdit -Value $('0x1') -PropertyType DWORD -Force | Out-Null # 1=True 0=False
		}

		If ($ColorSet -eq "Custom") {
			If ((IsNumeric($PSForeground)) -eq $False) {
				$PSForeground = $ColorValues.$PSForeground
			}
			If ((IsNumeric($PSBackground)) -eq $False) {
				$PSBackground = $ColorValues.$PSBackground
			}
			If ((IsNumeric($CMDForeground)) -eq $False) {
				$CMDForeground = $ColorValues.$CMDForeground
			}
			If ((IsNumeric($CMDBackground)) -eq $False) {
				$CMDBackground = $ColorValues.$CMDBackground
			}
		} Else {
			If ((IsNumeric($ColorSets.$ColorSet.PSForeground)) -eq $False) {
				$ColorSets.$ColorSet.Set_Item("PSForeground", $ColorValues.($ColorSets.$ColorSet.PSForeground))
			}
			If ((IsNumeric($ColorSets.$ColorSet.PSBackground)) -eq $False) {
				$ColorSets.$ColorSet.Set_Item("PSBackground", $ColorValues.($ColorSets.$ColorSet.PSBackground))
			}
			If ((IsNumeric($ColorSets.$ColorSet.CMDForeground)) -eq $False) {
				$ColorSets.$ColorSet.Set_Item("CMDForeground", $ColorValues.($ColorSets.$ColorSet.CMDForeground))
			}
			If ((IsNumeric($ColorSets.$ColorSet.CMDBackground)) -eq $False) {
				$ColorSets.$ColorSet.Set_Item("CMDBackground", $ColorValues.($ColorSets.$ColorSet.CMDBackground))
			}
		}

	    If ($_ -match "System32_WindowsPowerShell" -or $_ -match "PowerShell" -or $_ -eq "HKCU:Console") {
	        # Configure PowerShell windows regular text/background and reverses them for the popup text/background
	        If ($PSForeground -eq $PSBackground) {
	        	# Use PowerShell defaults from ColorSet
	        	New-ItemProperty -Path $_ -Name ScreenColors -Value $([System.Convert]::ToInt32(('0x{0:X7}' -f $ColorSets.$ColorSet.PSBackground)+('{0:X1}' -f $ColorSets.$ColorSet.PSForeground),16)) -PropertyType DWORD -Force | Out-Null
	        	New-ItemProperty -Path $_ -Name PopupColors -Value $([System.Convert]::ToInt32(('0x{0:X7}' -f $ColorSets.$ColorSet.PSForeground)+('{0:X1}' -f $ColorSets.$ColorSet.PSBackground),16)) -PropertyType DWORD -Force | Out-Null
	        } Else {
	        	New-ItemProperty -Path $_ -Name ScreenColors -Value $([System.Convert]::ToInt32(('0x{0:X7}' -f $PSBackground)+('{0:X1}' -f $PSForeground),16)) -PropertyType DWORD -Force | Out-Null
	        	New-ItemProperty -Path $_ -Name PopupColors -Value $([System.Convert]::ToInt32(('0x{0:X7}' -f $PSForeground)+('{0:X1}' -f $PSBackground),16)) -PropertyType DWORD -Force | Out-Null
	        }
	    }
	    If ($_ -match "system32_cmd" -or $_ -match "Command Prompt") {
	        # Configures CMD windows regular text/background and reverses them for the popup text/background
	        If ($CMDForeground -eq $CMDBackground) {
	        	# Use CMD defaults from ColorSet
	        	New-ItemProperty -Path $_ -Name ScreenColors -Value $([System.Convert]::ToInt32(('0x{0:X7}' -f $ColorSets.$ColorSet.CMDBackground)+('{0:X1}' -f $ColorSets.$ColorSet.CMDForeground),16)) -PropertyType DWORD -Force | Out-Null
	        	New-ItemProperty -Path $_ -Name PopupColors -Value $([System.Convert]::ToInt32(('0x{0:X7}' -f $ColorSets.$ColorSet.CMDForeground)+('{0:X1}' -f $ColorSets.$ColorSet.CMDBackground),16)) -PropertyType DWORD -Force | Out-Null
	        } Else {
	        	New-ItemProperty -Path $_ -Name ScreenColors -Value $([System.Convert]::ToInt32(('0x{0:X7}' -f $CMDBackground)+('{0:X1}' -f $CMDForeground),16)) -PropertyType DWORD -Force | Out-Null
	        	New-ItemProperty -Path $_ -Name PopupColors -Value $([System.Convert]::ToInt32(('0x{0:X7}' -f $CMDForeground)+('{0:X1}' -f $CMDBackground),16)) -PropertyType DWORD -Force | Out-Null
	    	}
	    }
	}

	$WSShell = New-Object -ComObject WScript.Shell

	If ($UpdateShortcuts) {
	    $Shortcuts | ForEach-Object {
	        If (Test-Path $_) {
	            # Copy instead of rename as renaming creates orphaned Start Menu/Taskbar links
	            Copy-Item -Path $_ -Destination "$_.bak" -Force

	            # If $BackupShortcuts is true, check that the backup was created before removing the existing one
	            Remove-Item -Path $_ -Force
	            $Shortcut = $WSShell.CreateShortCut($_)

	            If ($_ -match "PowerShell") {
	                $Shortcut.Description = "Windows PowerShell"
	                $Shortcut.TargetPath  = "%SystemRoot%\system32\WindowsPowerShell\v1.0\powershell.exe"
	                #$Shortcut.Arguments   = "-nologo"
	                #$Shortcut.HotKey      = "CTRL+SHIFT+P"
	            } Else {
	                $Shortcut.Description = "Command Prompt"
	                $Shortcut.TargetPath  = "%windir%\system32\cmd.exe"
	            }

	            $Shortcut.WorkingDirectory = "%HOMEDRIVE%%HOMEPATH%"
	            #$Shortcut.WorkingDirectory = "%SystemDrive%\"
	            $Shortcut.WindowStyle      = 1 # 1 = Normal
	            $Shortcut.Save()

	            If ($KeepBackupShortcuts -eq $False) {
	                If (Test-Path "$_.bak") {
	                    Remove-Item -Path "$_.bak" -Force
	                }
	            }
	        }
	    }
	}

	# Open a new PowerShell window which will use the new settings
	Start-Process "$PSHome\PowerShell.exe"

	# Close the current PowerShell window
	If ($Host.Name -eq 'ConsoleHost') {
	    Stop-Process $PID
	}
}


#$Host.UI.RawUI.BackgroundColor = ($bckgrnd = 'DarkBlue')
#$Host.UI.RawUI.ForegroundColor = 'White'
#$Host.PrivateData.ErrorForegroundColor = 'Red'
#$Host.PrivateData.ErrorBackgroundColor = $bckgrnd
#$Host.PrivateData.WarningForegroundColor = 'Magenta'
#$Host.PrivateData.WarningBackgroundColor = $bckgrnd
#$Host.PrivateData.DebugForegroundColor = 'Yellow'
#$Host.PrivateData.DebugBackgroundColor = $bckgrnd
#$Host.PrivateData.VerboseForegroundColor = 'Green'
#$Host.PrivateData.VerboseBackgroundColor = $bckgrnd
#$Host.PrivateData.ProgressForegroundColor = 'Cyan'
#$Host.PrivateData.ProgressBackgroundColor = $bckgrnd
