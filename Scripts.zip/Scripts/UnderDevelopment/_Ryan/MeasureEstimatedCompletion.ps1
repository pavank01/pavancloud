Function Measure-EstimatedCompletion {
<#
	.SYNOPSIS
		The Measure-EstimatedCompletion function takes a starting time and percent completed
		and estimates the time it will complete.

	.DESCRIPTION
		The Measure-EstimatedCompletion function takes a starting time and percent completed
		and estimates the time it will complete. It can also estimate time of completion if
		the time of the percent is known but is sometime prior to running the function.

	.PARAMETER StartTime
		The starting time. Accepts any valid date time combination.

	.PARAMETER PercentComplete
		The percent completed

	.PARAMETER TimeAtPercent
		The time when process was at PercentComplete. Accepts any valid date time combination.
		Defaults to the time the function is called but can be set to a different time

	.EXAMPLE
		Measure-EstimatedCompletion -StartTime "2:14:21 pm" -PercentComplete 20

		Thursday, October 06, 2016 10:12:49 PM
		If the current time is Thursday, October 06, 2016 03:50:01 PM

	.EXAMPLE
		Measure-EstimatedCompletion -StartTime "2:14:21 pm" -PercentComplete 20 -TimeAtPercent "2:22:09 pm"
		Thursday, October 06, 2016 2:53:21 PM

		Notice the difference between this result and example 1

	.EXAMPLE
		Measure-EstimatedCompletion -StartTime "Thursday, October 06, 2016 14:14:21" -PercentComplete 81 -TimeAtPercent "2016/10/06 14:45:09"
		Thursday, October 06, 2016 2:52:22 PM

	.OUTPUTS
		Object

	.NOTES
		Written by Ryan Amsbury
		v1.1
#>
	Param(
		[Parameter(Mandatory=$True)]
		[DateTime]$StartTime,

		[Parameter(Mandatory=$True)]
		[Decimal]$PercentComplete,

		[Parameter(Mandatory=$False)]
		[DateTime]$TimeAtPercent = (Get-Date)
	)
	$ElapsedSec = ($TimeAtPercent - $StartTime).TotalSeconds
	$RemainSec = ($ElapsedSec / $PercentComplete) * (100 - $PercentComplete)
	$CompletionTime = [DateTime](Get-Date $TimeAtPercent).AddSeconds($RemainSec)
	$TimeElapsed = Get-ElapsedTime -Start $StartTime -End $TimeAtPercent -HighLevel NonZero -LowLevel Seconds
	$TimeElapsedCompletion = Get-ElapsedTime -Start $StartTime -End $CompletionTime -HighLevel NonZero -LowLevel Seconds
	$TimeDetails = New-Object PSObject
	Add-Member -InputObject $TimeDetails -MemberType NoteProperty -Name "StartTime" -Value $StartTime
	Add-Member -InputObject $TimeDetails -MemberType NoteProperty -Name "TimeAtPercent" -Value $TimeAtPercent
	Add-Member -InputObject $TimeDetails -MemberType NoteProperty -Name "CompletionTime" -Value $CompletionTime
	Add-Member -InputObject $TimeDetails -MemberType NoteProperty -Name "PercentComplete" -Value $PercentComplete
	Add-Member -InputObject $TimeDetails -MemberType NoteProperty -Name "TimeElapsed" -Value $TimeElapsed
	Add-Member -InputObject $TimeDetails -MemberType NoteProperty -Name "TimeElapsedCompletion" -Value $TimeElapsedCompletion
	$TimeDetails
}
