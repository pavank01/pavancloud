<#
.SYNOPSIS
 A PowerShell script to manage current TLS settings

.DESCRIPTION
  A PowerShell script to manage current TLS settings by setting TLS to best practices or resetting all TLS back to server default.
  Disabled Protocols: Multi-Protocol Unified Hello, PCT 1.0, SSL 2.0, SSL 3.0, TLS 1.0
  Disabled Ciphers: NULL, DES 56/56, RC2 128/128, RC2 40/128, RC2 56/128, RC4 40/128, RC4 56/128, RC4 64/128, RC4 128/128, Triple DES 168/168
  Enabled Protocols: TLS 1.1, TLS 1.2
  Enabled Ciphers: AES 128/128, AES 256/256

.PARAMETER Enable_FAstandard
  Sets TLS to current best practices (First American Standard).
  - Enabled Protocols: TLS 1.1, TLS 1.2
  - Enabled Ciphers: AES 128/128, AES 256/256
  - Disables all others

.PARAMETER TLS10_Enable_Server
  ENABLES the TLS 1.0 protocol for server communications only
  Enabling TLS 1.0 server is not a First American Standard

.PARAMETER TLS10_Disable_Server
  DISABLES the TLS 1.0 protocol for server communications only

.PARAMETER TLS10_Enable_Client
  ENABLES the TLS 1.0 protocol for client communications only
  Enabling TLS 1.0 client is not a First American Standard

.PARAMETER TLS10_Disable_Client
  DISABLES the TLS 1.0 protocol for client communications only

.PARAMETER OsTlsDefault
  Removes all TLS settings putting server back to server defaults.
  ** This is VERY UNSECURE and the First American Standard should be applied after this option has been used.

.EXAMPLE
  .\Set-TLSSecurity-2008.ps1 -Enable_FAstandard

  PS C:\>.\Set-TLSSecurity-2008.ps1 -TLS10_Enable_Server

  PS C:\>.\Set-TLSSecurity-2008.ps1 -TLS10_Enable_Client

  PS C:\>.\Set-TLSSecurity-2008.ps1 -OsTlsDefault
#>

[CmdletBinding()]
Param (
    [Parameter()]
    [Switch]$Enable_FAstandard,

    [Parameter()]
    [Switch]$TLS10_Enable_Server,

    [Parameter()]
    [Switch]$TLS10_Disable_Server,

    [Parameter()]
    [Switch]$TLS10_Enable_Client,

    [Parameter()]
    [Switch]$TLS10_Disable_Client,

    [Parameter()]
    [Switch]$OsTlsDefault
)


# 03/02/2018 - Fixed comments and displayed text for TLS 1.0 to be accurate
# 11/12/2018 - Added parameters, removed reboot, and made this script only function on Windows 2008 / 2008 R2


# Get Windows version
$OSInfo = Get-WmiObject -Class Win32_OperatingSystem -ErrorAction SilentlyContinue | Select-Object @{L="OperatingSystem";E={($_.Caption -Replace('Microsoft',' ') -Replace('Server',' ') -Replace('[^\x20-\x7E]+', ' ') -Replace('\s+', ' ')).Trim()}}, @{L="OS";E={($_.Caption -Replace('Microsoft',' ') -Replace('Windows',' ') -Replace('Server',' ') -Replace('Standard',' ') -Replace('Enterprise',' ') -Replace('Datacenter',' ') -Replace('Essentials',' ') -Replace('Foundation',' ') -Replace('[^\x20-\x7E]+', ' ') -Replace('\s+', '')).Trim()}}
# ----------------------------------------------------------------------------
# Windows 2008 or Windows 2008R2
If ($OSInfo.OS -eq "2008" -or $OSInfo.OS -eq "2008R2") {
	# Perform TLS Security changes
	Write-Host
	Write-Host "Performing TLS Security changes on"$OSInfo.OperatingSystem -ForegroundColor Green
	Write-Host
} Else {
	# Do not perform TLS Security changes
	Write-Host
	Write-Host "Not performing TLS Security changes" -ForegroundColor Yellow
	Write-Host "Please use Set-TLSSecurity.ps1 for"$OSInfo.OperatingSystem -ForegroundColor Yellow
	Write-Host
	Break
}
If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(            [Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host
    Write-Host "The current Windows PowerShell session is not running as Administrator."
    Write-Host "Start Windows PowerShell by using the Run as Administrator option."
    Write-Host
    Break
}

If (1 -ne $PSBoundParameters.Count) {

    Write-Host ""
    Write-Host " You must use only one switch at a time ..." -ForegroundColor Yellow
    Write-Host ""
    Write-Host 'SYNTAX' -ForegroundColor White
    Write-Host ' Set-TLSSecurity-2008 { -Enable_FAstandard | -TLS10_Enable_Server | -TLS10_Disable_Server | -TLS10_Enable_Client | -TLS10_Disable_Client | -OsTlsDefault }' -ForegroundColor White
    Write-Host ""
    Write-Host ""
    Write-host " See Get-Help cmdlet to display more information about this application: " -ForegroundColor White
    Write-Host ""
    Write-Host ' Get-Help .\Set-TLSSecurity-2008 ' -ForegroundColor White
    Write-Host ""

    exit 1

}

Write-Host '****** Saving Registry *******'
Write-Host '--------------------------------------------------------------------------------'

$timestamp = Get-Date -Format s | foreach {$_ -replace ":", "."}
$TARGETDIR = 'C:\_SvrOpsBackup'
if(!(Test-Path -Path $TARGETDIR )){
    New-Item -ItemType directory -Path $TARGETDIR
}

Reg export HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL $TARGETDIR\Schannel_$timestamp.txt
Reg export HKLM\SOFTWARE\Policies\Microsoft\Cryptography\Configuration $TARGETDIR\Cryptography_$timestamp.txt


Write-Host 'Registry has been saved to' $TARGETDIR
Write-Host '--------------------------------------------------------------------------------'

If ($OsTlsDefault -eq $False) {
	# START - Set system to best practice or custom TLS 1.0 settings

	Write-Host 'Configuring IIS with SSL/TLS Deployment Best Practices...'
	Write-Host '--------------------------------------------------------------------------------'

	# Disable TLS 1.0 Server
	If ($Enable_FAstandard -eq $True -or $TLS10_Disable_Server -eq $True) {
		# Add and Disable TLS 1.0 for server SCHANNEL communications
		New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -name 'Enabled' -value 0 -PropertyType 'DWord' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
		Write-Host 'TLS 1.0 Server has been disabled.'
	}
	# Disable TLS 1.0 Client
	If ($Enable_FAstandard -eq $True -or $TLS10_Disable_Client -eq $True) {
		# Add and Disable TLS 1.0 for client SCHANNEL communications
		New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -name 'Enabled' -value 0 -PropertyType 'DWord' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
		Write-Host 'TLS 1.0 client has been disabled.'
	}

	# Enable TLS 1.0 Server
	If ($TLS10_Enable_Server -eq $True) {
		# Add and Disable TLS 1.0 for server SCHANNEL communications
		New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null
		Write-Host 'TLS 1.0 Server has been enabled.'
	}

	# Enable TLS 1.0 Client
	If ($TLS10_Enable_Client -eq $True) {
		# Add and Disable TLS 1.0 for client SCHANNEL communications
		New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null
		Write-Host 'TLS 1.0 client has been enabled.'
	}

	If ($Enable_FAstandard -eq $True) {

		# Add and Enable TLS 1.1 for client and server SCHANNEL communications
		New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' -Force | Out-Null
		New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null
		Write-Host 'TLS 1.1 has been enabled.'

		# Add and Enable TLS 1.2 for client and server SCHANNEL communications
		New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -Force | Out-Null
		New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null
		Write-Host 'TLS 1.2 has been enabled.'

		# Disable Multi-Protocol Unified Hello
		New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null
		Write-Host 'Multi-Protocol Unified Hello has been disabled.'

		# Disable PCT 1.0
		New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server' -name 'Enabled' -value 0 -PropertyType 'DWord' -Force | Out-Null
		Write-Host 'PCT 1.0 has been disabled.'

		# Disable SSL 2.0 (PCI Compliance)
		New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -name 'Enabled' -value 0 -PropertyType 'DWord' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
		Write-Host 'SSL 2.0 has been disabled.'

		# Disable SSL 3.0 (PCI Compliance) and enable "Poodle" protection
		New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -name 'Enabled' -value 0 -PropertyType 'DWord' -Force | Out-Null
		New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
		Write-Host 'SSL 3.0 has been disabled.'


		# Re-create the ciphers key.
		New-Item 'HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers' -Force | Out-Null

		# Disable insecure/weak ciphers.
		$insecureCiphers = @(
	        'NULL',
	        'DES 56/56',
	        'RC2 128/128',
	        'RC2 40/128',
	        'RC2 56/128',
	        'RC4 40/128',
	        'RC4 56/128',
	        'RC4 64/128',
	        'RC4 128/128',
	        'Triple DES 168'
		)
		Foreach ($insecureCipher in $insecureCiphers) {
		  $key = (Get-Item HKLM:\).OpenSubKey('SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers', $true).CreateSubKey($insecureCipher)
		  $key.SetValue('Enabled', 0, 'DWord')
		  $key.close()
		  Write-Host "Weak cipher $insecureCipher has been disabled."
		}

		# Enable new secure ciphers.
		# - RC4: It is recommended to disable RC4, but you may lock out WinXP/IE8 if you enforce this. This is a requirement for FIPS 140-2.
		$secureCiphers = @(
		  'AES 128/128',
		  'AES 256/256'
		)
		Foreach ($secureCipher in $secureCiphers) {
		  $key = (Get-Item HKLM:\).OpenSubKey('SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers', $true).CreateSubKey($secureCipher)
		  New-ItemProperty -path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\$secureCipher" -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
		  $key.close()
		  Write-Host "Strong cipher $secureCipher has been enabled."
		}

		# Set hashes configuration.
			New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\MD5' -Force | Out-Null
			New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\MD5' -name Enabled -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

			New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA' -Force | Out-Null
			New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA' -name Enabled -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

			New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA256' -Force | Out-Null
			New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA256' -name Enabled -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

			New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA384' -Force | Out-Null
			New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA384' -name Enabled -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

			New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA512' -Force | Out-Null
			New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA512' -name Enabled -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

		# Set KeyExchangeAlgorithms configuration.
			New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\Diffie-Hellman' -Force | Out-Null
			New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\Diffie-Hellman' -name Enabled -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

			New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\ECDH' -Force | Out-Null
			New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\ECDH' -name Enabled -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

			New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\PKCS' -Force | Out-Null
			New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\PKCS' -name Enabled -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

		# Set cipher suites order as secure as possible (Enables Perfect Forward Secrecy).
		$cipherSuitesOrder = @(
			'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P521',
			'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P384',
			'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P256',
			'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P521',
			'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P384',
			'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P256',
			'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P521',
			'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P384',
			'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P256',
			'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P521',
			'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P384',
			'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P256',
			'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384_P521',
			'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384_P384',
			'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P521',
			'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P384',
			'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P256',
			'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384_P521',
			'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384_P384',
			'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P521',
			'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P384',
			'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P256',
			'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P521',
			'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P384',
			'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P256',
			'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P521',
			'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P384',
			'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P256',
			'TLS_RSA_WITH_AES_256_GCM_SHA384',
			'TLS_RSA_WITH_AES_128_GCM_SHA256',
			'TLS_RSA_WITH_AES_256_CBC_SHA256',
			'TLS_RSA_WITH_AES_128_CBC_SHA256',
			'TLS_RSA_WITH_AES_256_CBC_SHA',
			'TLS_RSA_WITH_AES_128_CBC_SHA'
		)
		$cipherSuitesAsString = [string]::join(',', $cipherSuitesOrder)
		New-ItemProperty -path 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' -name 'Functions' -value $cipherSuitesAsString -PropertyType 'String' -Force | Out-Null
	}
	# END - Set system to best practice or custom TLS 1.0 settings
} Else {
	# START - Set system to OS defaults

    Write-Host '--------------------------------------------------------------------------------------' -ForegroundColor Yellow
    Write-Host '              ** Resetting TLS to WEAK and INSECURE Defaults **' -ForegroundColor Yellow
    Write-Host '--------------------------------------------------------------------------------------' -ForegroundColor Yellow

    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers' -Force > $null
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\CipherSuites' -Force > $null
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes' -Force > $null
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms' -Force > $null
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols' -Force > $null

    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client' -Force > $null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client' -name DisabledByDefault -value 1 -PropertyType 'DWord' > $null

    New-Item 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' -Force > $null

    Write-Host 'All Ciphers Cleared' -ForegroundColor Yellow
    Write-Host 'All CipherSuites Cleared' -ForegroundColor Yellow
    Write-Host 'All Hashes Cleared' -ForegroundColor Yellow
    Write-Host 'All KeyExchangeAlgorithms Cleared' -ForegroundColor Yellow
    Write-Host 'All Protocols Cleared' -ForegroundColor Yellow
    Write-Host 'Deafult SSLv2 Enabled' -ForegroundColor Yellow
    Write-Host 'CipherSuite Order Cleared' -ForegroundColor Yellow

    Write-Host '--------------------------------------------------------------------------------------' -ForegroundColor Yellow
    Write-Host '        ** TLS Security Settings have been set to WEAK and INSECURE Defaults **' -ForegroundColor Yellow
    Write-Host '--------------------------------------------------------------------------------------' -ForegroundColor Yellow
	# END - Set system to OS defaults
}
Write-Host '--------------------------------------------------------------------------------'
Write-Host ' This server must be rebooted for these settings to become active.'
Write-Host ' After the system has been rebooted you can verify the settings.'
Write-Host '--------------------------------------------------------------------------------'

