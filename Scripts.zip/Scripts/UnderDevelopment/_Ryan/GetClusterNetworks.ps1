[CmdletBinding()]
Param (
	# Path: File with computer name or names
	[Parameter(Mandatory = $True)]
	[String]$Path
)
# ---------------------------------------------------------------------------
Function Format-FileNameWithDate {
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $False)]
		[String]$Prefix,
		[Parameter(Mandatory = $False)]
		[String]$Suffix = ".txt",
		[Parameter(Mandatory = $False)]
		[String]$DateFormat = "yyyy-MM-dd"
	)
	$TextDate = Get-Date -Format $DateFormat
	Return $Prefix + $TextDate + $Suffix
}# ---------------------------------------------------------------------------
Function Test-Null($String) {
	If ($String -eq $Null -or $String -eq "") {
		$True
	} Else {
		$False
	}
}
# ---------------------------------------------------------------------------

$ResultsCSV = Format-FileNameWithDate -Prefix ".\GetClusterNetworks_" -Suffix ".csv" -DateFormat "yyyyMMdd-HHmmss"
$HasFailed = $False

# The user did not provide a list of computers to process - Exit Script
If (Test-Null($Path) -eq $True) {
	Write-Host "Please provide a list of computers to process" -ForegroundColor Yellow -BackgroundColor DarkRed
	$HasFailed = $True
}

# The user provided a list of computers to process
If ($Path -ne '' -and $HasFailed -eq $False) {
	# The user provided the list of computers to process in a text file
	If ((Test-Path -Path $Path) -eq $True) {
		# File exists so import the computer list
		Write-Host "Importing computer names from $Path"
		$Servers = Get-Content -Path $Path | Sort-Object | ForEach-Object {($_ -Replace('^*[\.](.*)$', '')).ToUpper()}
	} Else {
		# Specified file does not exist - Exit Script
		Write-Host "File not found: $Path" -ForegroundColor Yellow -BackgroundColor DarkRed
		$HasFailed = $True
	}
}

If ($HasFailed -eq $True) {
	Break
} Else {
	# Make sure the server is online (ping) and get the correct Domain
	$DomainNames = @("fastts.firstam.net", "corp.firstam.com", "datatrace.local", "datatree.local", "intl.crop.firstam.com", "itxprod.ad")
	$ServersResponding = @()
	$ServersNotResponding = @()
	ForEach ($Server In $Servers) {
		$IsOnline = $False
		# Try each server with each Domain and exit ForEach on first success
		ForEach ($DomainName In $DomainNames) {
			$TempServerName = ("{0}.{1}" -f $Server, $DomainName)
			If (Test-Connection $TempServerName -Quiet -Count 1) {
				# Server is online
				Write-Host "$TempServerName is Online" -ForegroundColor Green
				$ServersResponding += $TempServerName
				$IsOnline = $True
				Break
			} ElseIf (Test-Connection $TempServerName -Quiet -Count 2) {
				# Double check with 2 pings if server did not respond to 1 ping
				Write-Host "$TempServerName is Online" -ForegroundColor Cyan
				$ServersResponding += $TempServerName
				$IsOnline = $True
				Break
			}
		}
		# Server did not respond on any Domain
		If ($IsOnline -eq $False) {
			Write-Host "$Server is OFFLINE" -ForegroundColor Red
			$ServersNotResponding += $Server
		}
	}

	# Run the ScriptBlock on each server that is responding
	$Results = @()
	$Results = Invoke-Command -ComputerName $ServersResponding -ScriptBlock {
		# Create empty objects to hold data
		$ServerIPs = @()
		$ClusterNetworkResults = @()
		# Get NIC details
		$NetIPs = Get-NetIpConfiguration | Select-Object ComputerName, InterfaceAlias, InterfaceDescription, IPv4Address, InterfaceIndex
		# Get NIC IP details
		$IPAddresses = $NetIPs | Select-Object -Expand IPv4Address | Select-Object InterfaceAlias, IPAddress, @{N="SubnetMask";E={''+[IPAddress]"$(4.GB-!!$_.PrefixLength-shl32-$_.PrefixLength)"}}, PrefixLength, InterfaceIndex
		# Get Cluster network details
		$ClusterNets = Get-ClusterNetwork | ForEach {$_ | Select-Object *} | Select-Object @{N="ClusterName";E={$_.Cluster}}, @{N="ClusterNetwork";E={$_.Name}}, @{N="NetworkState";E={$_.State}}, @{N="NetworkAddress";E={$_.Address}}, Role, @{N="ClusterNetworkRole";E={$Null}}

		# Build the ServerIPs object with the data from the objects NetIPs and IPAddresses
		ForEach ($NetIP In $NetIPs) {
			ForEach ($IPAddress In $IPAddresses) {
				If ($NetIP.InterfaceIndex -eq $IPAddress.InterfaceIndex) {
					$ServerIPs += "" | Select-Object @{N="ComputerName";E={$NetIP.ComputerName}}, @{N="InterfaceName";E={$NetIP.InterfaceAlias}}, @{N="InterfaceDescription";E={$NetIP.InterfaceDescription}}, @{N="IPAddress";E={$IPAddress.IPAddress}}, @{N="SubnetMask";E={$IPAddress.SubnetMask}}, @{N="NetworkAddress";E={[IPaddress](([IPAddress]$IPAddress.IPAddress).Address -band ([IPAddress]$IPAddress.SubnetMask).Address) | Select-Object -Expand IPAddressToString}}
				}
			}
		}

		# Convert the numeric Role to text we can understand
		ForEach ($ClusterNet In $ClusterNets) {
			$ClusterNet.ClusterNetworkRole = Switch ($ClusterNet.Role) {
				0 {"No Cluster Communication"
					Continue
				}
				1 {"Only Cluster Communication"
					Continue
				}
				2 {"Invalid Value : 2"
					# this should never happen
					Continue
				}
				3 {"Client and Cluster Communication"
					Continue
				}
				Default {"Invalid Value :"+$ClusterNet.Role
					# this should never happen
				}
			}
		}

		# Build the Results object with the combined data from the objects ServerIPs and ClusterNets
		ForEach ($ServerIP In $ServerIPs) {
			ForEach ($ClusterNet In $ClusterNets) {
				If ($ServerIP.NetworkAddress -eq $ClusterNet.NetworkAddress) {
					$ClusterNetworkResults += "" | Select-Object @{N="ComputerName";E={$ServerIP.ComputerName}}, @{N="InterfaceName";E={$ServerIP.InterfaceName}}, @{N="InterfaceDescription";E={$ServerIP.InterfaceDescription}}, @{N="IPAddress";E={$ServerIP.IPAddress}}, @{N="SubnetMask";E={$ServerIP.SubnetMask}}, @{N="ClusterName";E={$ClusterNet.ClusterName}}, @{N="ClusterNetwork";E={$ClusterNet.ClusterNetwork}}, @{N="NetworkState";E={$ClusterNet.NetworkState}}, @{N="NetworkAddress";E={$ClusterNet.NetworkAddress}}, @{N="ClusterNetworkRole";E={$ClusterNet.ClusterNetworkRole}}
				}
			}
		}

		# Output the final object
		$ClusterNetworkResults | Sort-Object ComputerName, InterfaceAlias
	} | Select-Object ComputerName, @{N="Status";E={"Online"}}, InterfaceName, InterfaceDescription, IPAddress, SubnetMask, ClusterName, ClusterNetwork, NetworkState, NetworkAddress, ClusterNetworkRole

	# Add servers that did not respond to the $Results
	ForEach ($NotResponding In $ServersNotResponding) {
		$Results += "" | Select-Object @{N="ComputerName";E={$NotResponding}}, @{N="Status";E={"Offline"}}, @{N="InterfaceName";E={$Null}}, @{N="InterfaceDescription";E={$Null}}, @{N="IPAddress";E={$Null}}, @{N="SubnetMask";E={$Null}}, @{N="ClusterName";E={"N/A"}}, @{N="ClusterNetwork";E={$Null}}, @{N="NetworkState";E={$Null}}, @{N="NetworkAddress";E={$Null}}, @{N="ClusterNetworkRole";E={$Null}}
	}

	# Add any servers that did respond but did not return results
	$MissingServers = Compare-Object -ReferenceObject ($Results | Select-Object @{L="ComputerName";E={$_.ComputerName -Replace('^*[\.](.*)$', '')}} -Unique | Select-Object -Expand ComputerName) -DifferenceObject $Servers -PassThru
	ForEach ($MissingServer In $MissingServers) {
		$Results += "" | Select-Object @{N="ComputerName";E={$MissingServer}}, @{N="Status";E={"No Response"}}, @{N="InterfaceName";E={$Null}}, @{N="InterfaceDescription";E={$Null}}, @{N="IPAddress";E={$Null}}, @{N="SubnetMask";E={$Null}}, @{N="ClusterName";E={"N/A"}}, @{N="ClusterNetwork";E={$Null}}, @{N="NetworkState";E={$Null}}, @{N="NetworkAddress";E={$Null}}, @{N="ClusterNetworkRole";E={$Null}}
	}

	# Output the results to screen
	$Results | Sort-Object ClusterName, ComputerName | Select-Object ClusterName, ComputerName, Status, InterfaceName, IPAddress, ClusterNetwork, NetworkState, ClusterNetworkRole | Format-Table -Auto

	# Output the results to file
	$Results | Sort-Object ClusterName, ComputerName | Select-Object ClusterName, ComputerName, Status, InterfaceName, InterfaceDescription, IPAddress, SubnetMask, ClusterNetwork, NetworkState, NetworkAddress, ClusterNetworkRole | Export-CSV $ResultsCSV -NoTypeInformation

}



