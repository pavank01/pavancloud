Function Get-Colors
{
	$Foreground = $Host.UI.RawUI.ForegroundColor
	$Background = $Host.UI.RawUI.BackgroundColor
	Write-Host
	ForEach ($Color In ([enum]::GetValues([ConsoleColor]))) {
		Write-Host (" {0,2} | {1,11} | " -f $($Color.Value__), $Color) -NoNewLine
		Write-Host "COLOR  " -ForegroundColor $Color -NoNewLine
		Write-Host "`t`t" -BackgroundColor $Color -NoNewLine
		Write-Host "  " -NoNewLine
		If ($Color -eq $Foreground) {
			Write-Host " Foreground " -ForegroundColor $Background -BackgroundColor $Foreground
		} ElseIf ($Color -eq $Background) {
			Write-Host " Background " -ForegroundColor $Background -BackgroundColor $Foreground
		} Else {
			Write-Host
		}
	}

	Write-Host
	$ColorList = @(
		"Black"
		"DarkBlue"
		"DarkGreen"
		"DarkCyan"
		"DarkRed"
		"DarkMagenta"
		"DarkYellow"
		"Gray"
		"DarkGray"
		"Blue"
		"Green"
		"Cyan"
		"Red"
		"Magenta"
		"Yellow"
		"White"
	)
	$ColorNum = 0
	ForEach ($BGColor in $ColorList) {
		Write-Host (" {0,2} | {1,11} | " -f $ColorNum, $BGColor) -NoNewline
		ForEach ($FGColor in $ColorList) {
			Write-Host " $FGColor |" `
				-BackgroundColor $BGColor `
				-ForegroundColor $FGColor `
				-NoNewline
		}
		Write-Host
		$ColorNum = $ColorNum + 1
	}
	Write-Host
}

