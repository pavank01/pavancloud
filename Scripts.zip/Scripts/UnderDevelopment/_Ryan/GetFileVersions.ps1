[CmdletBinding()]
Param ()
# GetFileVersions.ps1

# THINGS TO DO
#
# Need to allow processing in PowerShell v2.0 (Get-ChildItem does not support -Directory or -File in v2)
#
# FileName parameter for output file
# Path parameter for output file
# Recurse folders parameter
# Root folders parameter
# Exclude folders parameter
# Verbose, Debug, Silent parameter
#
#
# ---------------------------------------------------------------------------
Function Format-FileNameWithDate {
	Param (
		[String]$Prefix,
		[String]$Suffix,
		[String]$DateFormat
	)
	If ($DateFormat -eq $Null -or $DateFormat -eq "") {
		$DateFormat = "yyyy-MM-dd"
	}
	$TextDate = Get-Date -Format $DateFormat
	Return $Prefix+$TextDate+$Suffix
}
# ---------------------------------------------------------------------------
Function Write-Activity {
	[CmdletBinding()]
	Param(
		[Parameter(Mandatory=$False,Position=0)]
		[String[]]$Text = "",

		[Parameter(Mandatory=$False,Position=1)]
		[String]$ForegroundColor = [Console]::ForegroundColor,

		[Parameter(Mandatory=$False,Position=2)]
		[String]$BackgroundColor = [Console]::BackgroundColor,

		[Parameter(Mandatory=$False,Position=3)]
		[Switch]$NoNewLine = $False,

		[Parameter(Mandatory=$False,Position=4)]
		[ValidateSet("Verbose", "Debug")]
		[String]$Level = $Null
	)
	Begin {
		$MyDebug = $DebugPreference -ne 'SilentlyContinue'
		$MyVerbose = $VerbosePreference -ne 'SilentlyContinue'
	}
	Process {
		If ($Level -ne $Null) {
			If (($Level.ToUpper() -eq "VERBOSE" -and $MyVerbose -eq $True) -or ($Level.ToUpper() -eq "VERBOSE" -and $MyDebug -eq $True)) {
				If ($NoNewLine -eq $True) {
					Write-Host $Text -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor -NoNewLine
				} Else {
					Write-Host $Text -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor
				}
			} ElseIf ($Level.ToUpper() -eq "DEBUG" -and $MyDebug -eq $True) {
				If ($NoNewLine -eq $True) {
					Write-Host $Text -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor -NoNewLine
				} Else {
					Write-Host $Text -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor
				}
			}
		}
	}
	End {}
}
# ---------------------------------------------------------------------------
# Standardizes many company names
$CompanyNamesClean = @{
	"Acer Laboratories Inc." = "Acer"
	"Actipro Software LLC" = "Actipro"
	"Adaptec" = "Adaptec"
	"Adaptec, Inc." = "Adaptec"
	"Adobe" = "Adobe"
	"Adobe Systems" = "Adobe"
	"Adobe Systems Incorporated" = "Adobe"
	"Adobe Systems, Inc." = "Adobe"
	"Agere" = "Agere"
	"Agere Systems" = "Agere"
	"Altiris, Inc." = "Altiris"
	"Amazon Web Services" = "Amazon"
	"Amazon.com, Inc" = "Amazon"
	"Advanced Micro Devices" = "AMD"
	"Advanced Micro Devices Inc." = "AMD"
	"Advanced Micro Devices, Inc." = "AMD"
	"AMD" = "AMD"
	"AMD Technologies Inc." = "AMD"
	"Andrea Electronics Corporation" = "Andrea Electronics"
	"Apache" = "Apache"
	"Apache Software Foundation" = "Apache"
	"ASUSTeKcomputer.Inc" = "ASUSTeK"
	"Atheros" = "Atheros"
	"Atheros Communications, Inc." = "Atheros"
	"ATI" = "ATI"
	"ATI Technologies Inc." = "ATI"
	"ATI Technologies, Inc." = "ATI"
	"Attunity Ltd" = "Attunity"
	"Attunity Ltd." = "Attunity"
	"AVerMedia TECHNOLOGIES, Inc." = "AVerMedia"
	"AVM" = "AVM"
	"AVM Berlin" = "AVM"
	"AVM GmbH" = "AVM"
	"Blue Sky Software Corporation." = "Blue Sky"
	"Bricolsoft LLC" = "Bricolsoft"
	"Broadcom Corporation" = "Broadcom"
	"Brocade Communications Systems, Inc." = "Brocade"
	"Brother" = "Brother"
	"Brother Industries Ltd." = "Brother"
	"Brother Industries, Ltd." = "Brother"
	"Brother Industries,Ltd." = "Brother"
	"CACE Technologies, Inc." = "CACE Technologies"
	"CANON" = "Canon"
	"CANON INC." = "Canon"
	"Cisco Systems" = "Cisco"
	"Cisco Systems, Inc." = "Cisco"
	"Citrix Systems, Inc." = "Citrix"
	"CMD Technologies" = "CMD Technologies"
	"CMD Technology, Inc." = "CMD Technologies"
	"Compaq" = "Compaq"
	"Compaq Computer Corp." = "Compaq"
	"Compaq Computer Corporation" = "Compaq"
	"Conexant" = "Conexant"
	"Conexant Systems, Inc." = "Conexant"
	"Creative" = "Creative"
	"Creative Technology Ltd." = "Creative"
	"The cURL library, http://curl.haxx.se/" = "cURL Library"
	"DameWare Development LLC" = "DameWare"
	"DameWare Development, LLC" = "DameWare"
	"Developer Express Inc." = "Developer Express"
	"Dolby Laboratories" = "Dolby"
	"Dolby Laboratories, Inc." = "Dolby"
	"DTS" = "DTS"
	"DTS, Inc" = "DTS"
	"Eastman Kodak Company" = "Eastman Kodak"
	"Eicon Networks" = "Eicon Networks"
	"Eicon Networks Corporation" = "Eicon Networks"
	"EMC Corp. 2013-2014" = "EMC"
	"EMC Corporation" = "EMC"
	"Emulex" = "Emulex"
	"Emulex Corporation" = "Emulex"
	"The GLib developer community" = "GLib Developer Community"
	"Guidance Software" = "Guidance Software"
	"Guidance Software Inc." = "Guidance Software"
	"Hauppauge Computer Works" = "Hauppauge"
	"Hauppauge Computer Works, Inc." = "Hauppauge"
	"Hewlett Packard" = "HP"
	"Hewlett Packard Co." = "HP"
	"Hewlett Packard Company" = "HP"
	"Hewlett Packard Corporation" = "HP"
	"Hewlett-Packard" = "HP"
	"Hewlett-Packard Co." = "HP"
	"Hewlett-Packard Company" = "HP"
	"Hewlett-Packard Corporation" = "HP"
	"Hewlett-Packard Development Co." = "HP"
	"Hewlett-Packard Development Company, L.P." = "HP"
	"Hewlett-Packard Development Group, L.P." = "HP"
	"HP" = "HP"
	"hk29 software services" = "HK29 Software"
	"IBM" = "IBM"
	"IBM Corporation" = "IBM"
	"InstallShield Software Corporation" = "InstallShield"
	"Intel" = "Intel"
	"Intel Corp./ICP vortex GmbH" = "Intel"
	"Intel Corporation" = "Intel"
	"Kyocera" = "Kyocera"
	"Kyocera Corporation" = "Kyocera"
	"LANDesk Software, Inc." = "LANDesk"
	"Lexmark" = "Lexmark"
	"Lexmark International Inc." = "Lexmark"
	"Lexmark International, Inc." = "Lexmark"
	"Lexmark International, Inc. 2001-2009" = "Lexmark"
	"Lexmark, International" = "Lexmark"
	"Lingsoft Inc." = "Lingsoft"
	"LSI" = "LSI"
	"LSI Corp" = "LSI"
	"LSI Corporation" = "LSI"
	"LSI Corporation, Inc." = "LSI"
	"Lumanate, Inc." = "Lumanate"
	"Macrovision" = "Macrovision"
	"Macrovision Corporation" = "Macrovision"
	"Macrovision Corporation, Macrovision Europe Limited, and Macrovision Japan and Asia K.K." = "Macrovision"
	"Marvell" = "Marvell"
	"Mellanox" = "Mellanox"
	"[Microsoft Corporation !!! !!! !]" = "Microsoft"
	"Microsoft" = "Microsoft"
	"Microsoft Corp." = "Microsoft"
	"Microsoft Corporation" = "Microsoft"
	"Microsoft SQL Server Escalation Services" = "Microsoft"
	"Microsoft SQL Server Escalation Support" = "Microsoft"
	"Microsoft SQL Server Support Escalation Services" = "Microsoft"
	"Windows Codename Longhorn DDK provider" = "Microsoft"
	"Windows Win 7 DDK provider" = "Microsoft"
	"Motorola" = "Motorola"
	"Motorola Inc." = "Motorola"
	"Neterion" = "Neterion"
	"Neterion Inc" = "Neterion"
	"Nvidia" = "Nvidia"
	"NVIDIA Corporation" = "Nvidia"
	"NXP Semiconductors" = "NXP Semiconductors"
	"NXP Semiconductors Germany GmbH" = "NXP Semiconductors"
	"NXP Semiconductors GmbH" = "NXP Semiconductors"
	"OMNIKEY" = "OMNIKEY"
	"OMNIKEY AG" = "OMNIKEY"
	"Open Source Software community LGPL" = "Open Source Software"
	"Open Source Software community project" = "Open Source Software"
	"Open Text Corporation" = "Open Text Corporation"
	"The OpenSSL Project, http://www.openssl.org/" = "OpenSSL"
	"Oracle Corporation" = "Oracle"
	"PDF Tools AG (http://www.pdf-tools.com)" = "PDF Tools"
	"pdfforge GmbH" = "PDFForge"
	"Philips Semiconductors GmbH" = "Philips Semiconductors"
	"Promise Technology" = "Promise Technology"
	"QLogic" = "QLogic"
	"QLogic Corp." = "QLogic"
	"QLogic Corporation" = "QLogic"
	"QLogic, Corp." = "QLogic"
	"2010 Quest Software, Inc." = "Quest"
	"Quest Software" = "Quest"
	"Quest Software Inc" = "Quest"
	"Quest Software Inc." = "Quest"
	"Quest Software, Inc" = "Quest"
	"Quest Software, Inc." = "Quest"
	"Ralink" = "Ralink"
	"Ralink Technology Corp." = "Ralink"
	"Ralink Technology, Corp." = "Ralink"
	"Real Sound Lab SIA" = "Real Sound Lab"
	"Realsil Semiconductor Corporation" = "Realsil Semiconductor"
	"Realtek" = "Realtek"
	"Realtek Corporation" = "Realtek"
	"RealTek Semicoductor Corp." = "Realtek"
	"Realtek Semiconductor" = "Realtek"
	"Realtek Semiconductor Corp." = "Realtek"
	"Realtek Semiconductor Corporation" = "Realtek"
	"Realtek Semiconductor Crop." = "Realtek"
	"Ricoh" = "Ricoh"
	"Ricoh Co., Ltd." = "Ricoh"
	"RSA - The Security Division of EMC" = "RSA Security"
	"RSA Security Inc." = "RSA Security"
	"RSA Security, Inc" = "RSA Security"
	"Samsung" = "Samsung"
	"Scalable Software, Inc." = "Scalable Software"
	"SCM Microsystems" = "SCM Microsystems"
	"SCM Microsystems, Inc." = "SCM Microsystems"
	"Seiko Epson" = "Seiko Epson"
	"SEIKO EPSON Corp." = "Seiko Epson"
	"SEIKO EPSON CORPORATION" = "Seiko Epson"
	"Seiko Epson Corporation." = "Seiko Epson"
	"ServerEngines Corporation" = "ServerEngines"
	"Sharp" = "Sharp"
	"Sharp Corporation" = "Sharp"
	"Simon Tatham" = "Simon Tatham"
	"Silicon Integrated Systems" = "SiS"
	"Silicon Integrated Systems Corp." = "SiS"
	"SiS" = "SiS"
	"Sonic Focus, Inc." = "Sonic Focus"
	"Sony Corporation" = "Sony"
	"SRS Labs, Inc." = "SRS Labs"
	"Sun Microsystems, Inc." = "Sun"
	"Symantec" = "Symantec"
	"Symantec Corporation" = "Symantec"
	"Symantec Inc." = "Symantec"
	"Synaptics Incorporated" = "Synaptics"
	"Synopsys, Inc." = "Synopsys"
	"Sysinternals - www.sysinternals.com" = "Sysinternals"
	"Systems Internals" = "Sysinternals"
	"Tarma Software Research Pty Ltd" = "Tarma"
	"TechSmith Corporation" = "TechSmith"
	"TOSHIBA" = "Toshiba"
	"TOSHIBA Corporation" = "Toshiba"
	"TOSHIBA CORPORATION." = "Toshiba"
	"TOSHIBA TEC CORPORATION" = "Toshiba"
	"Trolltech AS" = "Trolltech"
	"VIA Technologies" = "VIA Technologies"
	"VIA Technologies Inc.,Ltd" = "VIA Technologies"
	"VIA Technologies, Inc." = "VIA Technologies"
	"Virage Logic Corporation / Sonic Focus" = "Virage Logic"
	"ViXS Systems Inc." = "ViXS Systems"
	"VMware" = "VMware"
	"VMware, Inc." = "VMware"
	"Waves Audio Ltd." = "Waves Audio"
	"Xceed Software Inc (450) 442-2626 support@xceedsoft.com www.xceedsoft.com" = "Xceed"
	"Xerox Corporation" = "Xerox"
}
# ---------------------------------------------------------------------------

Write-Activity ("{0} - Start" -f (Get-Date)) -Level Verbose

$RootPaths = "C:\Windows"
$Excludes = "C:\Windows\Assembly", "C:\Windows\Diagnostics", "C:\Windows\Downloaded", "C:\Windows\inf", "C:\Windows\Logs", "C:\Windows\Microsoft.NET\Assembly", "C:\Windows\SoftwareDistribution", "C:\Windows\System32\Downlevel", "C:\Windows\System32\DriverStore\FileRepository", "C:\Windows\SysWOW64\Downlevel", "C:\Windows\SysWOW64\DriverStore\FileRepository", "C:\Windows\WinSXS", "C:\Windows\Temp"
$ScriptPath = "C:\Scripts\FileVersions"
If (!(Test-Path -Path $ScriptPath)) {
	New-Item $ScriptPath -Type Directory | Out-Null
}
$ServerName = Get-WmiObject -Class Win32_ComputerSystem | Select-Object Name, @{Label="FQDN"; Expression={($_.Name+"."+$_.Domain).ToLower()}}
$FileVersions = @()
$AllFolders = New-Object System.Collections.ArrayList
$BaseFolders = New-Object System.Collections.ArrayList
$Total = $RootPaths.Count
$Counter = 0
$PctLast = 0
$PctCurrent = 0
Write-Activity ("{0} - Collecting All Folders From {1:N0} Root Paths" -f (Get-Date), $RootPaths.Count) -Level Verbose
Write-Activity $RootPaths -ForegroundColor Yellow -Level Debug
Write-Activity ("{0}% " -f $PctCurrent) -ForegroundColor Green -NoNewLine -Level Verbose
ForEach ($RootPath In $RootPaths) {
	Get-ChildItem $RootPath -Recurse -Directory -ErrorAction SilentlyContinue | Select-Object FullName | Sort-Object FullName | ForEach {$AllFolders.Add($_.FullName)} | Out-Null
	$Counter += 1
	$PctCurrent = [Math]::Abs([Math]::Round((100/$Total) * $Counter))
	If ($PctCurrent -ge ($PctLast + 5)) {
		Write-Activity ("{0}% " -f $PctCurrent) -ForegroundColor Green -NoNewLine -Level Verbose
		$PctLast = $PctCurrent
	}
}
Write-Activity -Level Verbose
Write-Activity ("{0} - {1:N0} Folders Found" -f (Get-Date), $AllFolders.Count) -Level Verbose
$BaseFolders = {$AllFolders | Sort-Object}.Invoke()
$Total = $AllFolders.Count
$Counter = 0
$PctLast = 0
$PctCurrent = 0
Write-Activity ("{0} - Excluding {1:N0} Root Folders" -f (Get-Date), $Excludes.Count) -Level Verbose
If ($PSBoundParameters['Verbose'] -eq $True) {
	Foreach ($Exclude In $Excludes) {
		Write-Host "`t"$Exclude -ForegroundColor Yellow
	}
}
Write-Activity ("{0}% " -f $PctCurrent) -ForegroundColor Green -NoNewLine -Level Verbose
ForEach ($Folder In $AllFolders) {
	ForEach ($Exclude In $Excludes) {
		If ($Folder -Match [RegEx]::Escape($Exclude)+".*") {
			$BaseFolders.Remove($Folder) | Out-Null
			Break
		}
	}
	$Counter += 1
	$PctCurrent = [Math]::Abs([Math]::Round((100/$Total) * $Counter))
	If ($PctCurrent -ge ($PctLast + 5)) {
		Write-Activity ("{0}% " -f $PctCurrent) -ForegroundColor Green -NoNewLine -Level Verbose
		$PctLast = $PctCurrent
	}
}
Write-Activity -Level Verbose
$BaseFolders = {$BaseFolders | Select-Object -Unique}.Invoke()
Write-Activity ("{0} - Total {1:N0} Folders Excluded" -f (Get-Date), ($AllFolders.Count - $BaseFolders.Count)) -Level Verbose
$AllFolders = $Null
$Files = $Null
$Total = $BaseFolders.Count
$Counter = 0
$PctLast = 0
$PctCurrent = 0
Write-Activity ("{0} - Collecting Files From {1:N0} Folders" -f (Get-Date), $BaseFolders.Count) -Level Verbose
Write-Activity ("{0}% " -f $PctCurrent) -ForegroundColor Green -NoNewLine -Level Verbose
ForEach ($Folder In $BaseFolders) {
	$Folder = $Folder+"\*"
	$TempFiles = Get-ChildItem -Path "$Folder" -File -Include *.exe, *.dll, *.sys | Select-Object FullName, DirectoryName, Name, Extension, LastWriteTime, Length, VersionInfo | Sort-Object FullName
	If ($TempFiles.Count -gt 0) {
		$Files += {$TempFiles}.Invoke()
	}
	$TempFiles = $Null
	$Counter += 1
	$PctCurrent = [Math]::Abs([Math]::Round((100/$Total) * $Counter))
	If ($PctCurrent -ge ($PctLast + 5)) {
		Write-Activity ("{0}% " -f $PctCurrent) -ForegroundColor Green -NoNewLine -Level Verbose
		$PctLast = $PctCurrent
	}
}
Write-Activity -Level Verbose
#$ErrorAction = $ErrorActionPreference
#$ErrorActionPreference = "SilentlyContinue"
$Total = $Files.Count
$Counter = 0
$PctLast = 0
$PctCurrent = 0
Write-Activity ("{0} - Processing The Details Of {1:N0} Files" -f (Get-Date), $Files.Count) -Level Verbose
Write-Activity ("{0}% " -f $PctCurrent) -ForegroundColor Green -NoNewLine -Level Verbose
ForEach ($File In $Files) {
	$Sha1 = $Null
	$Hash = $Null
	$FileHash = $Null
	$FileVersionInfo = $Null
	$FileVersion = $Null
	$CombinedVersion = $Null
	$ProductVersion = $Null
	$ProductVersionOriginal = $Null
	$CompanyName = $Null
	$ProductName = $Null
	$FileDescription = $Null
	$FullFileDescription = $Null
	$Temp1 = $Null
	$Temp2 = $Null
	$Temp3 = $Null
	$Temp4 = $Null
	$Sha1 = New-Object System.Security.Cryptography.SHA1CryptoServiceProvider
	$Hash = [System.BitConverter]::ToString($Sha1.ComputeHash([System.IO.File]::ReadAllBytes($File.FullName)))
	$FileHash = $Hash -Replace("-")
	$FileVerTemp = New-Object PSObject
	Add-Member -InputObject $FileVerTemp -MemberType NoteProperty -Name "ServerName" -Value ([String]$ServerName.Name)
	Add-Member -InputObject $FileVerTemp -MemberType NoteProperty -Name "FullName" -Value ([String]$File.FullName)
#	Add-Member -InputObject $FileVerTemp -MemberType NoteProperty -Name "FolderName" -Value ([String]$File.DirectoryName)
#	Add-Member -InputObject $FileVerTemp -MemberType NoteProperty -Name "FileName" -Value ([String]$File.Name)
#	Add-Member -InputObject $FileVerTemp -MemberType NoteProperty -Name "FileExtension" -Value ([String]($File.Extension).ToLower())
	Add-Member -InputObject $FileVerTemp -MemberType NoteProperty -Name "FileHash" -Value ([String]$FileHash)
	Add-Member -InputObject $FileVerTemp -MemberType NoteProperty -Name "FileDate" -Value ([DateTime]$File.LastWriteTime)
	Add-Member -InputObject $FileVerTemp -MemberType NoteProperty -Name "FileSize" -Value ([Long]$File.Length)
	$FileVersionInfo = $File | Select-Object -Expand VersionInfo
	$FileVersion = ("{0}.{1}.{2}.{3}" -f ($FileVersionInfo.FileMajorPart).ToString("#0"), ($FileVersionInfo.FileMinorPart).ToString("#0"), ($FileVersionInfo.FileBuildPart).ToString("#0"), ($FileVersionInfo.FilePrivatePart).ToString("#0"))
	$ProductVersion = $FileVersionInfo.ProductVersion
	$ProductVersionOriginal = $ProductVersion
	$Temp1 = $ProductVersion
	$ProductVersion = $ProductVersion -Replace('^\s+', ' ') -Replace('\s+$', ' ')
	If ($ProductVersion -eq "" -or $ProductVersion -eq " " -or $ProductVersion -eq $Null) {
		$ProductVersion = $FileVersion
	}
	# replace ', ' and ',' and '-' and '(' and ')' and ' .' with a '.' and trim all leading/trailing spaces
	$ProductVersion = ($ProductVersion -Replace(' \.', '.') -Replace('\, ', '.') -Replace('\,', '.') -Replace('\-', '.') -Replace('\(', '.') -Replace('\)', '.') -Replace('\|', ' ')).Trim()
	# treat all values like numbers - this removes leading zeros
	$ProductVersion = [RegEx]::Replace($ProductVersion, '(\d+)', {Invoke-Expression $Args[0]})
	$Temp2 = $ProductVersion
	If (([regex]::Matches($ProductVersion, "\.")).count -ne 0 -and $FileVersion -notlike "$ProductVersion*") {
		# replace anything that is *not* a digit or a '.' with a ' ' (space) and trim all leading/trailing spaces
		$ProductVersion = ($ProductVersion -Replace('[^\d.]', ' ') -Replace('^\D+', ' ') -Replace('\D+$', ' ')).Trim()
		$Temp3 = $ProductVersion
		# remove everything after the first ' ' (space) and trim all leading/trailing spaces
		$ProductVersion = ($ProductVersion -Replace('^*[\s](.*)$', '')).Trim()
		$Temp4 = $ProductVersion
		# remove extra (more than 4) version fields
		$VerParts = ([regex]::Matches($ProductVersion, "\.")).count
		If ($VerParts -gt 3) {
			$ArrayVersion = $ProductVersion.Split(".")
			$ProductVersion = ($ArrayVersion[0], $ArrayVersion[1], $ArrayVersion[2], $ArrayVersion[3] -Join '.').Trim('.')
			$ArrayVersion = $Null
		}
	}
	If ($FileVersion -eq $ProductVersion -or $FileVersion -like "$ProductVersion*" -or $ProductVersion -like "$FileVersion*") {
		$CombinedVersion = $FileVersion
	} Else {
		$CombinedVersion = ("{0} ({1})" -f $FileVersion, $ProductVersion)
	}
	If ([RegEx]::Replace($ProductVersionOriginal, '(\d+)', {Invoke-Expression $Args[0]}) -ne $ProductVersion -and $ProductVersion -ne "0.0.0.0") {
		Write-Activity -Level Debug
		Write-Activity "`tFILE  : "$File.FullName -ForegroundColor Yellow -Level Debug
		Write-Activity ("`tORIGV : [{0}]" -f $ProductVersionOriginal) -ForegroundColor Cyan -Level Debug
		Write-Activity ("`tTEMP2 : [{0}]" -f $Temp2) -ForegroundColor Magenta -Level Debug
		Write-Activity ("`tTEMP3 : [{0}]" -f $Temp3) -ForegroundColor Magenta -Level Debug
		Write-Activity ("`tTEMP4 : [{0}]" -f $Temp4) -ForegroundColor Magenta -Level Debug
		Write-Activity "`tPRODV : "$ProductVersion -ForegroundColor White -Level Debug
		Write-Activity "`tCOMBV : "$CombinedVersion -ForegroundColor Gray -Level Debug
	}
	# Remove any character not between Space (Hex 20) and Tilde (Hex 7E)
	$CompanyName = $FileVersionInfo.CompanyName -Replace '[^\x20-\x7E]+', ''
	# Replace (R) with a single space
	$CompanyName = $CompanyName.Replace('(R)', ' ')
	# Replace (C) with a single space
	$CompanyName = $CompanyName.Replace('(C)', ' ')
	# Replace (TM) with a single space
	$CompanyName = $CompanyName.Replace('(TM)', ' ')
	# Replace (CM) with a single space
	$CompanyName = $CompanyName.Replace('(CM)', ' ')
	# Replace - with a single space
	$CompanyName = $CompanyName.Replace('-', ' ')
	# Remove all spaces from beginning / end
	$CompanyName = $CompanyName.Trim()
	# Replace 3 spaces with single space
	$CompanyName = $CompanyName -Replace '   ', ' '
	# Replace 2 spaces with single space
	$CompanyName = $CompanyName -Replace '  ', ' '
	# Sometimes it needs an extra double space replaced
	$CompanyName = $CompanyName -Replace '  ', ' '
	If ($CompanyNamesClean[$CompanyName] -ne $Null) {
		$CompanyName = $CompanyNamesClean[$CompanyName]
	}
	$ProductName = $FileVersionInfo.ProductName -Replace '[^\x20-\x7E]+', ''
	$ProductName = $ProductName.Replace('(R)', ' ')
	$ProductName = $ProductName.Replace('(C)', ' ')
	$ProductName = $ProductName.Replace('(TM)', ' ')
	$ProductName = $ProductName.Trim()
	$ProductName = $ProductName -Replace '   ', ' '
	$ProductName = $ProductName -Replace '  ', ' '
	If ($CompanyName -ne "Microsoft" -and ($ProductName -like "*Microsoft Windows*" -or $ProductName -like "*Windows Operating*")) {
		$ProductName = "Windows"
	}

	$FileDescription = $FileVersionInfo.FileDescription -Replace '[^\x20-\x7E]+', ''
	$FileDescription = $FileDescription.Replace('(R)', ' ')
	$FileDescription = $FileDescription.Replace('(C)', ' ')
	$FileDescription = $FileDescription.Replace('(TM)', ' ')
	$FileDescription = $FileDescription.Trim()
	$FileDescription = $FileDescription -Replace '   ', ' '
	$FileDescription = $FileDescription -Replace '  ', ' '

	($CompanyName+" "+$ProductName+" "+$FileDescription).Split() | Select-Object -Unique | ForEach {$FullFileDescription = ($FullFileDescription+' '+$_).Trim()}

	Add-Member -InputObject $FileVerTemp -MemberType NoteProperty -Name "CombinedVersion" -Value ([String]$CombinedVersion)
#	Add-Member -InputObject $FileVerTemp -MemberType NoteProperty -Name "FileVersion" -Value ([Version]$FileVersion)
#	Add-Member -InputObject $FileVerTemp -MemberType NoteProperty -Name "ProductVersion" -Value ([String]$ProductVersion)
#	Add-Member -InputObject $FileVerTemp -MemberType NoteProperty -Name "ProductVersionOriginal" -Value ([String]$ProductVersionOriginal)
#	Add-Member -InputObject $FileVerTemp -MemberType NoteProperty -Name "CompanyName" -Value ([String]$CompanyName)
#	Add-Member -InputObject $FileVerTemp -MemberType NoteProperty -Name "ProductName" -Value ([String]$ProductName)
#	Add-Member -InputObject $FileVerTemp -MemberType NoteProperty -Name "FileDescription" -Value ([String]$FileDescription)
	Add-Member -InputObject $FileVerTemp -MemberType NoteProperty -Name "FullFileDescription" -Value ([String]$FullFileDescription)
	$FileVersions += $FileVerTemp
	$Counter += 1
	$PctCurrent = [Math]::Abs([Math]::Round((100/$Total) * $Counter))
	If ($PctCurrent -ge ($PctLast + 5)) {
		Write-Activity ("{0}% " -f $PctCurrent) -ForegroundColor Green -NoNewLine -Level Verbose
		$PctLast = $PctCurrent
	}
}
Write-Activity -Level Verbose
#$ErrorActionPreference = $ErrorAction
# ---------------------------------------------------------------------------
# Save full results
$FileName = Join-Path -Path $ScriptPath -ChildPath ("GetFileVersions_"+$ServerName.Name+"_")
$ExportFileName = Format-FileNameWithDate -Prefix $FileName -Suffix ".csv" -DateFormat "yyyy-MM-dd_HHmm"
Write-Activity ("{0} - Saving File Details To {1}" -f (Get-Date), $ExportFileName) -Level Verbose
#$FileVersions | Sort-Object FullName | Select-Object ServerName, FullName, FolderName, FileName, FileExtension, FileHash, FileSize, FileDate, CombinedVersion, FileVersion, ProductVersion, ProductVersionOriginal, FullFileDescription, CompanyName, ProductName, FileDescription | Export-CSV $ExportFileName -NoTypeInformation
$FileVersions | Sort-Object FullName | Select-Object ServerName, FullName, FileHash, FileSize, FileDate, CombinedVersion, FullFileDescription | Export-CSV $ExportFileName -NoTypeInformation
Write-Activity ("{0} - End" -f (Get-Date)) -Level Verbose

