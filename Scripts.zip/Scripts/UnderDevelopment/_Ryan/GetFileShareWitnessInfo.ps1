# Get File Share Witness

# Server list
$Servers = @("DFWVPCLSCLCC001", "SNAVPCLSTFSX011", "DFWVPCLSCLCC001", "SNAVPSQLIMDM004", "DFWVDSQLDWTK004", "FSHQDAL09SSQL09", "DFWVDSQLTANM001", "FSHQDAL09SSQL09", "DFWVDSQLTANM001", "DFWVDSQLTANM001", "SNAVPSQLTANM001", "FSHQSNA09SSQL09", "FSHQDAL09SSQL09", "FSHQDAL09SSQL09", "FSHQSNA09SSQL09", "SNAVPCLSSFNC001", "SNAVPCLSCLCC001", "SNAVPCLSSFNC001", "DFWVDSQLDWTK004", "DFWVDSQLDWTK004", "AZUVPSQLCOPO003", "AZUVPSQLCOPO004", "DFWPDCLSFAST015", "DFWPDCLSSPDP005", "DFWVCCLSNCOP001", "DFWVDCLSFASS001", "DFWVDCLSLVIS004", "DFWVDCLSPROJ001", "DFWVDCLSSFNC001", "DFWVDCLSSHPT001", "DFWVDCLSTFSX011", "DFWVDCLSWLNK011", "DFWVDCLSWLNK012", "DFWVDSQLDWTK004", "DFWVDSQLTANM001", "DFWVPCLSCLCC001", "FAHQSNA09SCLS39", "FAHQSNA09SCLS40", "FAHQSNA09SCLS41", "FSHQSNA09SCLS01", "FSHQSNA09SCLS02", "SNAPPCLSFAST011", "SNAPPCLSFAST012", "SNAPPCLSFAST013", "SNAPPCLSFAST014", "SNAPPCLSFAST015", "SNAPPCLSFAST016", "SNAPPCLSNRTR002", "SNAPPCLSSPDP005", "SNAPPCLSSPDP006", "SNAPPCLSSTAI001", "SNAPPCLSSTAI002", "SNAVCCLSRPAB001", "SNAVPCLSCLCC001", "SNAVPCLSCOPO001", "SNAVPCLSFASS001", "SNAVPCLSLVIS004", "SNAVPCLSTFSX011", "SNAVPCLSWLNK012", "SNAVPSQLDWTK004")

#$Servers = @("DFWVCCLSNCOP001", "DFWVDCLSFASS001", "DFWVDCLSLVIS004", "DFWVDCLSSFNC001", "DFWVDCLSSHPT001", "DFWVDCLSTFSX011", "DFWVDCLSWLNK011", "DFWVDCLSWLNK012", "DFWVDSQLDWTK004", "DFWVDSQLTANM001", "DFWVPCLSCLCC001", "SNAVCCLSRPAB001", "SNAVPCLSCLCC001", "SNAVPCLSCOPO001", "SNAVPCLSFASS001", "SNAVPCLSLVIS004", "SNAVPCLSTFSX011", "SNAVPCLSWLNK012", "SNAVPSQLDWTK004")

$Servers = $Servers | Sort-Object | Select-Object -Unique

# Possible Domains to check for the servers
$DomainNames = @("corp.firstam.com", "fastts.firstam.net", "datatrace.local", "datatree.local", "intl.corp.firstam.com", "itxprod.ad", "automation.com", "ext1.local", "faequity.com", "fahw.com", "fim.local", "trust.firstam.com")

# Make sure the server is online (ping) and get the correct Domain
$ServersResponding = @()
$ServersNotResponding = @()
ForEach ($Server In $Servers) {
	$IsOnline = $False
	# Try each server with each Domain and exit ForEach on first success
	ForEach ($DomainName In $DomainNames) {
		$TempServerName = ("{0}.{1}" -f $Server, $DomainName)
		If (Test-Connection $TempServerName -Quiet -Count 1) {
			# Server is online
			Write-Host "$TempServerName is Online" -ForegroundColor Green
			$ServersResponding += $TempServerName
			$IsOnline = $True
			Break
		} ElseIf (Test-Connection $TempServerName -Quiet -Count 2) {
			# Double check with 2 pings if server did not respond to 1 ping
			Write-Host "$TempServerName is Online" -ForegroundColor Cyan
			$ServersResponding += $TempServerName
			$IsOnline = $True
			Break
		}
	}
	# Server did not respond on any Domain
	If ($IsOnline -eq $False) {
		Write-Host "$Server is OFFLINE" -ForegroundColor Red
		$ServersNotResponding += $Server
	}
}

# Run the ScriptBlock on each server that is responding
$Results = @()
$Results = Invoke-Command -ComputerName $ServersResponding -ScriptBlock {
	# Get OS version
	$OperatingSystem = Get-WmiObject -Class Win32_OperatingSystem | Select-Object @{N="OperatingSystem";E={($_.Caption -Replace('Microsoft',' ') -Replace('Server',' ') -Replace('[^\x20-\x7E]+', ' ') -Replace('\s+', ' ')).Trim()}} | Select-Object -Expand OperatingSystem
	If ($OperatingSystem -like "*2008*") {
		# Windows 2008 / 2008 R2 so we cannot execute PowerShell Cluster commands
		$ClusterDetails = "" | Select-Object @{N="ComputerName";E={(Get-ChildItem Env:ComputerName).Value}}, @{N="ClusterName";E={(Get-ChildItem Env:ComputerName).Value}}, @{N="OperatingSystem";E={$OperatingSystem}}, @{N="Status";E={"Online"}}, @{N="FileShareWitness";E={"Cannot Get Cluster Information due to old Windows version"}}
	} Else {
		# Windows 2012 or higher so we can execute PowerShell Cluster commands
		$ClusterDetails = Get-Cluster | Get-ClusterResource | Where-Object {$_.Resourcetype -eq "File Share Witness"} | Get-ClusterParameter | Where-Object {$_.Name -eq "SharePath"} | Select-Object @{N="ComputerName";E={(Get-ChildItem Env:ComputerName).Value}}, @{N="ClusterName";E={$Null}}, @{N="OperatingSystem";E={$OperatingSystem}}, @{N="Status";E={"Online"}}, @{N="FileShareWitness";E={($_.Value).ToLower()}}
		$ClusterDetails.ClusterName = (Get-Cluster | Select-Object -Expand Name).ToUpper()
	}
	# Return the results back to Invoke-Command
	$ClusterDetails
}

# Add servers that did not respond to the $Results
ForEach ($NotResponding In $ServersNotResponding) {
	$Results += "" | Select-Object @{N="ComputerName";E={$NotResponding}}, @{N="ClusterName";E={$Null}}, @{N="OperatingSystem";E={"N/A"}}, @{N="Status";E={"Offline"}}, @{N="FileShareWitness";E={"N/A"}}
}

# Add any servers that did respond but did not return results
$MissingServers = Compare-Object -ReferenceObject ($Results | Select-Object @{L="ComputerName";E={$_.ComputerName -Replace('^*[\.](.*)$', '')}} -Unique | Select-Object -Expand ComputerName) -DifferenceObject $Servers -PassThru
ForEach ($MissingServer In $MissingServers) {
	$Results += "" | Select-Object @{N="ComputerName";E={$MissingServer}}, @{N="ClusterName";E={$Null}}, @{N="OperatingSystem";E={"N/A"}}, @{N="Status";E={"No Response"}}, @{N="FileShareWitness";E={"N/A"}}
}

# Output the results to screen
$Results | Sort-Object ClusterName | Select-Object ClusterName, OperatingSystem, Status, FileShareWitness -Unique | Format-Table -Auto



<#

ClusterName     OperatingSystem            Status FileShareWitness
-----------     ---------------            ------ ----------------
AZUCPCVNCOPO001 Windows 2016 Datacenter    Online \\azuvpfilazur001\witness\copo\azucpcvncopo001
FAHQSNA09SCLS39 Windows 2008 R2 Enterprise Online Cannot Get Cluster Information due to old Windows version
FAHQSNA09SCLS40 Windows 2008 R2 Enterprise Online Cannot Get Cluster Information due to old Windows version
FAHQSNA09SCLS41 Windows 2008 R2 Enterprise Online Cannot Get Cluster Information due to old Windows version
FSHQSNA09SCLS01 Windows 2008 R2 Enterprise Online Cannot Get Cluster Information due to old Windows version
FSHQSNA09SCLS02 Windows 2008 R2 Enterprise Online Cannot Get Cluster Information due to old Windows version
SNACPCVNCLCC001 Windows 2016 Standard      Online \\corp.firstam.com\apps\microsoft clusters\fsw\ccc\snacpcvnclcc001
SNACPCVNCOPO001 Windows 2012 R2 Standard   Online \\corp.firstam.com\apps\microsoft clusters\fsw\copo\snacpcvncopo001
SNACPCVNDWTK001 Windows 2016 Standard      Online \\corp.firstam.com\apps\microsoft clusters\fsw\dwtk\snacpcvndwtk001
SNACPCVNFASS001 Windows 2016 Standard      Online \\corp.firstam.com\apps\microsoft clusters\fsw\fn\snacpcvnfass001
SNACPCVNFAST011 Windows 2012 R2 Standard   Online \\azuvpfilfast001\fast_prod_fp_quorum
SNACPCVNFAST012 Windows 2012 R2 Standard   Online \\azuvpfilfast001\fast_prod_wf_quorum
SNACPCVNFAST013 Windows 2012 R2 Standard   Online \\azuvpfilfast001\fast_prod_fa_quorum
SNACPCVNFSHQ003 Windows 2012 R2 Standard   Online \\corp.firstam.com\apps\microsoft clusters\fsw\fastsearch\snacpcvnfshq003
SNACPCVNIMDM005 Windows 2012 R2 Standard   Online \\corp.firstam.com\apps\microsoft clusters\fsw\mdm\snacpcvnimdm005
SNACPCVNLVIS002 Windows 2012 R2 Standard   Online \\corp.firstam.com\apps\microsoft clusters\fsw\lvis\snacpcvnlvis002
SNACPCVNSPDP005 Windows 2012 R2 Standard   Online \\azuvpfilfast001\spdp_prod_quorum
SNACPCVNSTAI001 Windows 2012 R2 Standard   Online \\azuvpfilfast001\sai_prod_quorum
SNACPCVNTANM001 Windows 2012 R2 Standard   Online \\corp.firstam.com\apps\microsoft clusters\fsw\tanium\snacpcvntanm001
SNACPCVNTFSX011 Windows 2012 R2 Standard   Online \\corp.firstam.com\apps\microsoft clusters\fsw\tfs\snacpcvntfsx011
SNACPCVNWLNK011 Windows 2012 R2 Standard   Online \\fahqwrv01dfil01\wlnk-sql-quorum
SNAVCCVNNCOP001 Windows 2012 R2 Standard   Online \\corp.firstam.com\apps\microsoft clusters\fsw\ncop\snavccvnncop001
SNAVCCVNRPAB001 Windows 2012 R2 Standard   Online \\corp.firstam.com\apps\microsoft clusters\fsw\rpab\snavccvnrpab001
SNAVCCVNSFNC001 Windows 2012 R2 Standard   Online \\fahqwrv01dfil01\sfnc-sql-quorum
SNAVPCVNPROJ001 Windows 2012 R2 Standard   Online \\fahqwrv01dfil01\proj_2013-quorum
SNAVPCVNSHPT001 Windows 2012 R2 Standard   Online \\fahqwrv01dfil01\sharepoint2013prod

#>



# Get MAC Address for all NICs

#$Servers = @("AZUVPSQLCOPO003", "AZUVPSQLCOPO004", "DFWPDCLSFAST015", "DFWPDCLSSPDP005", "SNAPPCLSFAST011", "SNAPPCLSFAST012", "SNAPPCLSFAST013", "SNAPPCLSFAST014", "SNAPPCLSFAST015", "SNAPPCLSFAST016", "SNAPPCLSNRTR002", "SNAPPCLSSPDP005", "SNAPPCLSSPDP006", "SNAPPCLSSTAI001", "SNAPPCLSSTAI002")

#$Servers = @("DFWVCCLSNCOP001", "DFWVDCLSFASS001", "DFWVDCLSLVIS004", "DFWVDCLSSFNC001", "DFWVDCLSSHPT001", "DFWVDCLSTFSX011", "DFWVDCLSWLNK011", "DFWVDCLSWLNK012", "DFWVDSQLDWTK004", "DFWVDSQLTANM001", "DFWVPCLSCLCC001", "SNAVCCLSRPAB001", "SNAVPCLSCLCC001", "SNAVPCLSCOPO001", "SNAVPCLSFASS001", "SNAVPCLSLVIS004", "SNAVPCLSTFSX011", "SNAVPCLSWLNK012", "SNAVPSQLDWTK004")

$Servers = $Servers | Sort-Object | Select-Object -Unique

$DomainNames = @("corp.firstam.com", "fastts.firstam.net", "datatrace.local", "datatree.local", "intl.corp.firstam.com", "itxprod.ad", "automation.com", "ext1.local", "faequity.com", "fahw.com", "fim.local", "trust.firstam.com")

$ServersResponding = @()
$ServersNotResponding = @()
ForEach ($Server In $Servers) {
	$IsOnline = $False
	ForEach ($DomainName In $DomainNames) {
		$TempServerName = ("{0}.{1}" -f $Server, $DomainName)
		If (Test-Connection $TempServerName -Quiet -Count 1) {
			Write-Host "$TempServerName is Online" -ForegroundColor Green
			$ServersResponding += $TempServerName
			$IsOnline = $True
			Break
		} ElseIf (Test-Connection $TempServerName -Quiet -Count 2) {
			Write-Host "$TempServerName is Online" -ForegroundColor Cyan
			$ServersResponding += $TempServerName
			$IsOnline = $True
			Break
		}
	}
	If ($IsOnline -eq $False) {
		Write-Host "$Server is OFFLINE" -ForegroundColor Red
		$ServersNotResponding += $Server
	}
}

Invoke-Command -ComputerName $ServersResponding -ScriptBlock {
	$Win32_NetworkAdapter = @()
	$Win32_NetworkAdapter = Get-WmiObject -Class Win32_NetworkAdapter |
						Where-Object {$_.MACAddress -ne $Null -and ($_.NetConnectionStatus -eq 2 -or $_.NetConnectionStatus -eq 7) -and ($_.Caption -notlike "*RAS*" -and $_.Caption -notlike "*Bluetooth*" -and $_.Caption -notlike "*Virtual WiFi*")} |
						Select-Object @{L="ComputerName";E={(Get-ChildItem Env:ComputerName).Value}}, Index, InterfaceIndex, Caption, MACAddress, Manufacturer, NetConnectionID, NetConnectionStatus, NetEnabled, @{L="SpeedMBits";E={$_.Speed/1000000}}, @{L="ThisNIC";E={$($_.PSComputerName+' '+$_.Caption+' '+$_.MACAddress)}} |
						Sort-Object NetConnectionID |
						Sort-Object ThisNIC
	$Win32_NetworkAdapter | Select-Object ComputerName, NetConnectionID, MACAddress
} | Select-Object ComputerName, NetConnectionID, MACAddress | Sort-Object ComputerName, NetConnectionID | Format-Table -Auto




<#
ComputerName    NetConnectionID       MACAddress
------------    ---------------       ----------
AZUVPSQLCOPO003 Ethernet 2            00:0D:3A:37:DF:F9
AZUVPSQLCOPO004 Ethernet 2            00:0D:3A:3A:DC:97
DFWPDCLSFAST015 DFW-Prod              58:20:B1:EA:84:FC
DFWPDCLSFAST015 Primary - Team01      58:20:B1:EA:84:FC
DFWPDCLSFAST015 Secondary - Team01    5C:B9:01:E0:19:54
DFWPDCLSSPDP005 DFW-Prod              9C:DC:71:DB:81:0C
DFWPDCLSSPDP005 Primary - Team01      9C:DC:71:DB:88:3C
DFWPDCLSSPDP005 Secondary - Team01    9C:DC:71:DB:81:0C
DFWVCCLSNCOP001 Production            00:50:56:B1:1B:8C
DFWVDCLSFASS001 Prod                  00:50:56:B1:29:0A
DFWVDCLSLVIS004 Backup                00:50:56:B1:11:35
DFWVDCLSLVIS004 Prod                  00:50:56:B1:2B:E3
DFWVDCLSPROJ001 Primary               00:50:56:B1:57:B5
DFWVDCLSSFNC001 Ethernet              00:50:56:B1:57:7F
DFWVDCLSSHPT001 Prod                  00:50:56:B1:5D:3F
DFWVDCLSTFSX011 Prod                  00:50:56:B1:10:F8
DFWVDCLSWLNK011 Prod                  00:50:56:B1:58:6F
DFWVDCLSWLNK012 Prod                  00:50:56:B1:2F:2B
DFWVDSQLDWTK004 Prod                  00:50:56:B1:18:8C
DFWVDSQLTANM001 Ethernet              00:50:56:B1:36:50
DFWVPCLSCLCC001 Ethernet0             00:50:56:B1:B1:CC
FAHQSNA09SCLS39 NIC01 - Production    44:1E:A1:06:51:5A
FAHQSNA09SCLS39 NIC02 - Heartbeat     44:1E:A1:06:51:5C
FAHQSNA09SCLS39 NIC03 - Production    44:1E:A1:06:51:5A
FAHQSNA09SCLS39 NIC04 - Backup        44:1E:A1:06:51:60
FAHQSNA09SCLS39 TEAM01 - Production   44:1E:A1:06:51:5A
FAHQSNA09SCLS40 NIC01 - Production    78:E3:B5:00:07:20
FAHQSNA09SCLS40 NIC02 - Production    78:E3:B5:00:07:20
FAHQSNA09SCLS40 NIC03 - Heartbeat     78:E3:B5:00:07:22
FAHQSNA09SCLS40 NIC04 - Backup        78:E3:B5:00:07:23
FAHQSNA09SCLS40 TEAM01-Production     78:E3:B5:00:07:20
FAHQSNA09SCLS41 NIC01 - Production    44:1E:A1:4C:0E:A4
FAHQSNA09SCLS41 NIC02 - Heartbeat     44:1E:A1:4C:0E:A5
FAHQSNA09SCLS41 NIC03 - Production    44:1E:A1:4C:0E:A4
FAHQSNA09SCLS41 NIC04 - Backup        44:1E:A1:4C:0E:A7
FAHQSNA09SCLS41 TEAM01 - Production   44:1E:A1:4C:0E:A4
FSHQSNA09SCLS01 Heartbeat             2C:76:8A:55:5F:2F
FSHQSNA09SCLS01 Local Area Connection 14:02:EC:67:BE:EC
FSHQSNA09SCLS01 NIC01 - Prod          14:02:EC:67:BE:EC
FSHQSNA09SCLS01 Team01 - Production   14:02:EC:67:BE:EC
FSHQSNA09SCLS02 Heartbeat             2C:76:8A:55:5D:63
FSHQSNA09SCLS02 Local Area Connection 14:02:EC:67:BD:EC
FSHQSNA09SCLS02 NIC01- Prod           14:02:EC:67:BD:EC
FSHQSNA09SCLS02 Team01 - Production   14:02:EC:67:BD:EC
SNAPPCLSFAST011 Primary - Team01      58:20:B1:EA:87:64
SNAPPCLSFAST011 Secondary - Team01    58:20:B1:EA:87:6C
SNAPPCLSFAST011 SNA-PROD              58:20:B1:EA:87:64
SNAPPCLSFAST012 Primary - Team01      5C:B9:01:E0:61:A4
SNAPPCLSFAST012 Secondary - Team01    58:20:B1:EA:87:5C
SNAPPCLSFAST012 SNA-PROD              58:20:B1:EA:87:5C
SNAPPCLSFAST013 Primary - Team01      58:20:B1:EA:86:84
SNAPPCLSFAST013 Secondary - Team01    58:20:B1:EB:69:C4
SNAPPCLSFAST013 SNA-PROD              58:20:B1:EB:69:C4
SNAPPCLSFAST014 Primary - Team01      5C:B9:01:E0:7D:D4
SNAPPCLSFAST014 Secondary - Team01    58:20:B1:EA:87:1C
SNAPPCLSFAST014 SNA-Prod              58:20:B1:EA:87:1C
SNAPPCLSFAST015 Primary - Team01      58:20:B1:EB:69:AC
SNAPPCLSFAST015 Secondary - Team01    58:20:B1:EA:82:14
SNAPPCLSFAST015 SNA-Prod              58:20:B1:EA:82:14
SNAPPCLSFAST016 Primary - Team01      5C:B9:01:E0:5D:F4
SNAPPCLSFAST016 Secondary - Team01    58:20:B1:EB:69:34
SNAPPCLSFAST016 SNA-Prod              58:20:B1:EB:69:34
SNAPPCLSNRTR002 Primary - Team01      9C:DC:71:69:97:A4
SNAPPCLSNRTR002 Secondary - Team01    9C:DC:71:69:98:C4
SNAPPCLSNRTR002 SNA-Prod              9C:DC:71:69:97:A4
SNAPPCLSSPDP005 Primary - Team01      9C:DC:71:D8:56:04
SNAPPCLSSPDP005 Secondary - Team01    9C:DC:71:D7:7D:6C
SNAPPCLSSPDP005 SNA-Prod              9C:DC:71:D7:7D:6C
SNAPPCLSSPDP006 Primary - Team01      9C:DC:71:D8:73:FC
SNAPPCLSSPDP006 Secondary - Team01    9C:DC:71:D8:4C:24
SNAPPCLSSPDP006 SNA-Prod              9C:DC:71:D8:4C:24
SNAPPCLSSTAI001 Primary - Team01      9C:DC:71:D7:AA:F4
SNAPPCLSSTAI001 Secondary - Team01    9C:DC:71:D7:AA:1C
SNAPPCLSSTAI001 SNA-Prod              9C:DC:71:D7:AA:1C
SNAPPCLSSTAI002 Primary - Team01      9C:DC:71:6B:73:D4
SNAPPCLSSTAI002 Secondary - Team01    9C:DC:71:6B:73:FC
SNAPPCLSSTAI002 SNA-Prod              9C:DC:71:6B:73:FC
SNAVCCLSRPAB001 Backup                00:50:56:B0:25:E7
SNAVCCLSRPAB001 Primary               00:50:56:B0:2F:41
SNAVPCLSCLCC001 Ethernet0             00:50:56:B0:A6:7A
SNAVPCLSCOPO001 Ethernet              00:50:56:B0:4E:93
SNAVPCLSFASS001 Prod1                 00:50:56:B0:52:B3
SNAVPCLSLVIS004 Backup                00:50:56:B0:7A:C4
SNAVPCLSLVIS004 Prod                  00:50:56:B0:4E:97
SNAVPCLSTFSX011 Backup                00:50:56:B0:20:64
SNAVPCLSTFSX011 Prod                  00:50:56:B0:76:AE
SNAVPCLSWLNK012 Backup                00:50:56:B0:4E:3C
SNAVPCLSWLNK012 Prod                  00:50:56:B0:77:39
SNAVPSQLDWTK004 Prod                  00:50:56:B0:53:1B
#>
