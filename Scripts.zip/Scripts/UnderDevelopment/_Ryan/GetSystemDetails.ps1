[CmdletBinding()]
Param (
	# ComputerName: Computer name or array of computer names
	[Parameter()]
	[String[]]$ComputerName = $Null,

	# Path: File with computer name or names
	[Parameter()]
	[String]$Path = $Null,

	# Path: File with computer name or names
	[Parameter()]
	[String]$OutputPath = $Null
)
# ---------------------------------------------------------------------------
Function Format-FileNameWithDate {
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $False)]
		[String]$Prefix,
		[Parameter(Mandatory = $False)]
		[String]$Suffix = ".txt",
		[Parameter(Mandatory = $False)]
		[String]$DateFormat = "yyyy-MM-dd"
	)
	$TextDate = Get-Date -Format $DateFormat
	Return $Prefix + $TextDate + $Suffix
}
# ---------------------------------------------------------------------------
Function Test-Null($String) {
	If ([String]::IsNullOrEmpty($String) -eq $True) {
		$True
	} Else {
		$False
	}
}
# ---------------------------------------------------------------------------

If ($OutputPath -eq $Null -or $OutputPath -eq '') {
	$ResultsCSV = Format-FileNameWithDate -Prefix ".\GetSystemDetails_" -Suffix ".csv" -DateFormat "yyyyMMdd-HHmmss"
} Else {
	$ResultsCSV = Format-FileNameWithDate -Prefix ("{0}_" -f $OutputPath) -Suffix ".csv" -DateFormat "yyyyMMdd-HHmmss"
}

$HasFailed = $False

# The user did not provide a list of computers to process - Exit Script
If ([String]::IsNullOrEmpty($ComputerName) -eq $True -and [String]::IsNullOrEmpty($Path) -eq $True) {
	Write-Host "Please provide a list of computers to process" -ForegroundColor Yellow -BackgroundColor DarkRed
	$HasFailed = $True
}

# The user provided two lists of computers to process - Exit Script
If ([String]::IsNullOrEmpty($ComputerName) -eq $False -and [String]::IsNullOrEmpty($Path) -eq $False -and $HasFailed -eq $False) {
	Write-Host "Please provide only one list of computers to process. Both ComputerName and Path have values" -ForegroundColor Yellow -BackgroundColor DarkRed
	$HasFailed = $True
}

# The user provided a list of computers to process
If ([String]::IsNullOrEmpty($Path) -eq $False -and $HasFailed -eq $False) {
	# The user provided the list of computers to process in a text file
	If ((Test-Path -Path $Path) -eq $True) {
		# File exists so import the computer list
		Write-Host "Importing computer names from $Path"
		$ComputerName = @(Get-Content -Path $Path | ForEach {$_ -Replace('^*[\.](.*)$', '').ToUpper()} | Sort-Object | Select-Object -Unique)
	} Else {
		# Specified file does not exist - Exit Script
		Write-Host "File not found: $Path" -ForegroundColor Yellow -BackgroundColor DarkRed
		$HasFailed = $True
	}
} ElseIf ($ComputerName -ne '' -and $HasFailed -eq $False)  {
	# The user provided the list of computers to process on the command line
	$ComputerName = @($ComputerName | ForEach {$_ -Replace ('^*[\.](.*)$', '').ToUpper()} | Sort-Object | Select-Object -Unique)
}

If ($HasFailed -eq $True) {
	Break
} Else {
	$DomainNames = @("fastts.firstam.net", "corp.firstam.com", "datatrace.local", "datatree.local", "intl.crop.firstam.com", "itxprod.ad")

	$ServersResponding = @()
	$ServersNotResponding = @()
	ForEach ($Server In ($ComputerName | Sort-Object)) {
		$IsOnline = $False
		ForEach ($DomainName In $DomainNames) {
			$TempServerName = ("{0}.{1}" -f $Server.ToUpper(), $DomainName.ToLower())
			If (Test-Connection $TempServerName -Quiet -Count 1) {
				Write-Host "$TempServerName is Online" -ForegroundColor Green
				$ServersResponding += $TempServerName
				$IsOnline = $True
				Break
			}
		}
		If ($IsOnline -eq $False) {
			Write-Host "$Server is OFFLINE" -ForegroundColor Red
			$ServersNotResponding += $Server
		}
	}
	# Begin processing of individual computers
	$Results = Invoke-Command -ComputerName $ServersResponding -ErrorAction SilentlyContinue -ScriptBlock {

		$ProcessingStartTime = Get-Date
		# ---------------------------------------------------------------------------
		Function Get-ElapsedTime {
		<#
			.SYNOPSIS
				The Get-ElapsedTime function takes a date/time range and converts it to years,
				weeks, days, hours, minutes, seconds, and milliseconds

			.DESCRIPTION
				The Get-ElapsedTime function takes a date/time range and converts it to years,
				weeks, days, hours, minutes, seconds, and milliseconds. Does not process months
				at this time due to the complexity of the varying lengths and Leap Years.

			.PARAMETER Start
				The starting date/time of the range to calculate

			.PARAMETER End
				The ending date/time of the range to calculate
				Current date/time (Default)

			.PARAMETER HighLevel
				Highest level of date/time to return

				NonZero (Default)
				Years
				Weeks
				Days
				Hours
				Seconds
				Milliseconds

			.PARAMETER LowLevel
				Lowest level of date/time to return

				Years
				Weeks
				Days
				Hours
				Seconds (Default)
				Milliseconds

			.PARAMETER LevelText
				Text to use for each level of date/time
				There must always be 7 elements

				" years / weeks / days / hours / minutes / seconds / milliseconds" (Default)
				"y /w /d /h /m /s /m"
				" yr, / wk, / dy, / hr, / mn, / sc, / ms"
				"y:/w:/d:/h:/m:/s./m"
				" year(s) / week(s) / day(s) / hour(s) / minute(s) / second(s) / millisecond(s)"

			.PARAMETER Delimiter
				Delimiter used to split LevelText
				Values will not be trimmed so spaces and other punctuation can be used
				"/" (Default)

			.PARAMETER NoText
				Do not show time span text after time values

				True:  4 13 34 56
				False: 4 days 13 hours 34 minutes 56 seconds (Default)

			.PARAMETER LeadingZero
				Make all time values at least 2 digits by adding a LeadingZero if required
				Milliseconds will be converted to 3 digits if required

				True:  04 days, 13 hours, 05 minutes, 09 seconds, 068 milliseconds
				False: 4 days, 13 hours, 5 minutes, 9 seconds, 68 milliseconds (Default)

			.PARAMETER Object
				Return an Object instead of the default String

			.OUTPUTS
				String (Default)
				Object

			.NOTES
				Written by Ryan Amsbury
				v0.6
		#>
			[CmdletBinding()]
			Param
			(
				[Parameter(Mandatory = $True,
						   ValueFromPipeline = $True,
						   Position = 0)]
				[DateTime]$Start,

				[Parameter(Mandatory = $False,
						   ValueFromPipeline = $True,
						   Position = 1)]
				[DateTime]$End = (Get-Date),

				[Parameter(Mandatory = $False)]
				[ValidateSet('NonZero', 'Years', 'Weeks', 'Days', 'Hours', 'Minutes', 'Seconds', 'Milliseconds', IgnoreCase = $True)]
				[string]$HighLevel = 'NonZero',

				[Parameter(Mandatory = $False)]
				[ValidateSet('Milliseconds', 'Seconds', 'Minutes', 'Hours', 'Days', 'Weeks', 'Years', IgnoreCase = $True)]
				[string]$LowLevel = 'Seconds',

				[Parameter(Mandatory = $False)]
				[String]$LevelText = ' years / weeks / days / hours / minutes / seconds / milliseconds',

				[Parameter(Mandatory = $False)]
				[String]$Delimiter = '/',

				[Parameter(Mandatory = $False)]
				[Switch]$NoText = $False,

				[Parameter(Mandatory = $False)]
				[Switch]$LeadingZero = $False,

				[Parameter(Mandatory = $False)]
				[Switch]$Object = $False
			)

			Begin {
				$LevelHash = @{
					'NonZero' = 8;
					'Years' = 7;
					'Weeks' = 6;
					'Days' = 5;
					'Hours' = 4;
					'Minutes' = 3;
					'Seconds' = 2;
					'Milliseconds' = 1;
				}
			} # Begin
			Process {
				If ($LevelHash.$HighLevel -lt $LevelHash.$LowLevel) {
					$HighLevel = 'NonZero'
				}
				$IncludeZero = $False
				$LevelTextArray = $LevelText -Split $Delimiter, 7, [StringSplitOptions]::"SimpleMatch"
				$TimeSpan = New-TimeSpan -Start $Start -End $End
				$Years = 0
				$Weeks = 0
				$Days = $TimeSpan.Days
				$Hours = $TimeSpan.Hours
				$Minutes = $TimeSpan.Minutes
				$Seconds = $TimeSpan.Seconds
				$Milliseconds = $TimeSpan.Milliseconds
				# Calculate years
				If ($LevelHash.$HighLevel -ge $LevelHash.Years) {
					If ($Days -gt 365) {
						# more than 1 year
						$Years = [Math]::Floor($Days / 365)
						If (($Days / 365) -gt $Years) {
							# there are extra days
							$Days = ($Days % 365) # returns the remainder of days
						} ElseIf (($Days / 365) -eq $Years) {
							# no more days
							$Days = 0
						}
					} ElseIf ($Days -lt -365) {
						# more than 1 year
						$Years = 0 - [Math]::Floor($Days / -365)
						If (($Days / -365) -gt $Years) {
							# there are extra days
							$Days = ($Days % -365) # returns the remainder of days
						} ElseIf (($Days / -365) -eq $Years) {
							# no more days
							$Days = 0
						}
					}
					If ($Days -eq 365) {
						# exactly 1 year
						$Years = 1
						$Days = 0
					}
					If ($Days -eq -365) {
						$Years = -1
						$Days = 0
					}
				}
				# Calculate weeks
				If ($LevelHash.$HighLevel -ge $LevelHash.Weeks) {
					If ($Days -gt 0) {
						# days left to process
						$Weeks = [Math]::Floor($Days / 7)
						If (($Days / 7) -gt $Weeks) {
							# there are extra days
							$Days = ($Days % 7) # returns the remainder of days
						} ElseIf (($Days / 7) -eq $Weeks) {
							# no more days
							$Days = 0
						}
					} ElseIf ($Days -lt 0) {
						# days left to process
						$Weeks = 0 - [Math]::Floor($Days / -7)
						If (($Days / -7) -gt $Weeks) {
							# there are extra days
							$Days = ($Days % -7) # returns the remainder of days
						} ElseIf (($Days / -7) -eq $Weeks) {
							# no more days
							$Days = 0
						}
					}
					If ($Days -eq 7) {
						# exactly 1 week
						$Weeks = 1
						$Days = 0
					}
					If ($Days -eq -7) {
						# exactly 1 week
						$Weeks = -1
						$Days = 0
					}
				}
				If ($LeadingZero -eq $True) {
					$Years = "{0:D2}" -f [int]$Years
					$Weeks = "{0:D2}" -f [int]$Weeks
					$Days = "{0:D2}" -f [int]$Days
					$Hours = "{0:D2}" -f [int]$Hours
					$Minutes = "{0:D2}" -f [int]$Minutes
					$Seconds = "{0:D2}" -f [int]$Seconds
					$Milliseconds = "{0:D3}" -f [int]$Milliseconds
				}

				$ElapsedTime = @()
				$TempElapsed = New-Object System.Object
				$TempElapsed | Add-Member -Type NoteProperty -Name Years -Value ([String]$Years)
				$TempElapsed | Add-Member -Type NoteProperty -Name Weeks -Value ([String]$Weeks)
				$TempElapsed | Add-Member -Type NoteProperty -Name Days -Value ([String]$Days)
				$TempElapsed | Add-Member -Type NoteProperty -Name Hours -Value ([String]$Hours)
				$TempElapsed | Add-Member -Type NoteProperty -Name Minutes -Value ([String]$Minutes)
				$TempElapsed | Add-Member -Type NoteProperty -Name Seconds -Value ([String]$Seconds)
				$TempElapsed | Add-Member -Type NoteProperty -Name Milliseconds -Value ([String]$Milliseconds)
				$TempElapsed | Add-Member -Type NoteProperty -Name YearsText -Value ([String]$LevelTextArray[0])
				$TempElapsed | Add-Member -Type NoteProperty -Name WeeksText -Value ([String]$LevelTextArray[1])
				$TempElapsed | Add-Member -Type NoteProperty -Name DaysText -Value ([String]$LevelTextArray[2])
				$TempElapsed | Add-Member -Type NoteProperty -Name HoursText -Value ([String]$LevelTextArray[3])
				$TempElapsed | Add-Member -Type NoteProperty -Name MinutesText -Value ([String]$LevelTextArray[4])
				$TempElapsed | Add-Member -Type NoteProperty -Name SecondsText -Value ([String]$LevelTextArray[5])
				$TempElapsed | Add-Member -Type NoteProperty -Name MillisecondsText -Value ([String]$LevelTextArray[6])
				$ElapsedTime += $TempElapsed

				$Years = $Null
				$Weeks = $Null
				$Days = $Null
				$Hours = $Null
				$Minutes = $Null
				$Seconds = $Null
				$Milliseconds = $Null

				Switch ($ElapsedTime) {
					{ (([Int]$_.Years -gt 0) -or ($LevelHash.$HighLevel -eq 7)) -and (($LevelHash.$HighLevel -ge 7) -and ($LevelHash.$LowLevel -le 7)) }
						{
							If ($NoText -eq $True) {
								$Years = $_.Years + ' '
							} Else {
								$Years = $_.Years + $_.YearsText
							}
							$IncludeZero = $True
						}

					{ ((([Int]$_.Weeks -gt 0) -or ($LevelHash.$HighLevel -eq 6) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 6) -and ($LevelHash.$LowLevel -le 6))) }
						{
							If ($NoText -eq $True) {
								$Weeks = $_.Weeks + ' '
							} Else {
								$Weeks = $_.Weeks + $_.WeeksText
							}
							$IncludeZero = $True
						}

					{ ((([Int]$_.Days -gt 0) -or ($LevelHash.$HighLevel -eq 5) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 5) -and ($LevelHash.$LowLevel -le 5))) }
						{
							If ($NoText -eq $True) {
								$Days = $_.Days + ' '
							} Else {
								$Days = $_.Days + $_.DaysText
							}
							$IncludeZero = $True
						}

					{ ((([Int]$_.Hours -gt 0) -or ($LevelHash.$HighLevel -eq 4) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 4) -and ($LevelHash.$LowLevel -le 4))) }
						{
							If ($NoText -eq $True) {
								$Hours = $_.Hours + ' '
							} Else {
								$Hours = $_.Hours + $_.HoursText
							}
							$IncludeZero = $True
						}

					{ ((([Int]$_.Minutes -gt 0) -or ($LevelHash.$HighLevel -eq 3) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 3) -and ($LevelHash.$LowLevel -le 3))) }
						{
							If ($NoText -eq $True) {
								$Minutes = $_.Minutes + ' '
							} Else {
								$Minutes = $_.Minutes + $_.MinutesText
							}
							$IncludeZero = $True
						}

					{ ((([Int]$_.Seconds -gt 0) -or ($LevelHash.$HighLevel -eq 2) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 2) -and ($LevelHash.$LowLevel -le 2))) }
						{
							If ($NoText -eq $True) {
								$Seconds = $_.Seconds + ' '
							} Else {
								$Seconds = $_.Seconds + $_.SecondsText
							}
						}

					{ ((([Int]$_.Milliseconds -gt 0) -or ($LevelHash.$HighLevel -eq 1) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 1) -and ($LevelHash.$LowLevel -le 1))) }
						{
							If ($NoText -eq $True) {
								$Milliseconds = $_.Milliseconds + ' '
							} Else {
								$Milliseconds = $_.Milliseconds + $_.MillisecondsText
							}
							$IncludeZero = $True
						}
				}
				If ($Object -eq $True) {
					Return $ElapsedTime
				} Else {
					Return "$Years$Weeks$Days$Hours$Minutes$Seconds$Milliseconds".Trim()
				}
			} # Process
			End {
			} # End
		}
		# ---------------------------------------------------------------------------

		$LocalResults = "" | Select-Object @{N="ComputerName";E={(Get-ChildItem Env:ComputerName).Value}}, @{N="OperatingSystem";E={$Null}}, @{N="SP";E={$Null}}, @{N="Version";E={$Null}}, @{N="OSArchitecture";E={$Null}}, @{N="WindowsShell";E={$Null}}, @{N="Language";E={$Null}}, @{N="PowerPlan";E={$Null}}, @{N="LastReboot";E={$Null}}, @{N="UpTime";E={$Null}}, @{N="BuildDate";E={$Null}}, @{N="BuildAge";E={$Null}}, @{N="LocalDate";E={$Null}}, @{N="TimeZone";E={$Null}}, @{N="MemoryTotalGB";E={$Null}}, @{N="MemoryUsedGB";E={$Null}}, @{N="MemoryFreeGB";E={$Null}}, @{N="PageFileName";E={$Null}}, @{N="PageFileTotalGB";E={$Null}}, @{N="PageFileCurrentGB";E={$Null}}, @{N="PageFilePeakGB";E={$Null}}, @{N="AutomaticManagedPagefile";E={$Null}}, @{N="CrashDumpType";E={$Null}}, @{N="CrashDumpFile";E={$Null}}, @{N="SystemRole";E={$Null}}, @{N="Domain";E={$Null}}, @{N="Workgroup";E={$Null}}, @{N="HardwareModel";E={$Null}}, @{N="HardwareSerialNumber";E={$Null}}, @{N="BIOSVersion";E={$Null}}, @{N="BIOSDate";E={$Null}},  @{N="ProcessorModel";E={$Null}}, @{N="Processors";E={$Null}}, @{N="PhysicalCoresPerProcessor";E={$Null}}, @{N="LogicalCoresPerProcessor";E={$Null}}, @{N="TotalLogicalCores";E={$Null}}, @{N="ProcessorLoad";E={$Null}}, @{N="MaxClockSpeed";E={$Null}}, @{N="CurrentClockSpeed";E={$Null}}, @{N="FirewallDomain";E={$Null}}, @{N="FirewallPrivate";E={$Null}}, @{N="FirewallPublic";E={$Null}}, @{N="SymantecVersion";E={$Null}}, @{N="SymantecDefinitions";E={$Null}}, @{N="SymantecPolicy";E={$Null}}, @{N="PSVersion";E={$Null}}, @{N="ProcessingTime";E={$Null}}

		$PSVersion = $PSVersionTable.PSVersion
		$LocalResults.PSVersion = ("{0}.{1}" -f $PSVersion.Major, $PSVersion.Minor)

		$ThisTime = [System.DateTime]::Now
		If ([System.TimeZoneInfo]::Local.IsDaylightSavingTime($ThisTime)) {
			$TimeZone = [System.TimeZoneInfo]::Local.DaylightName
		} Else {
			$TimeZone = [System.TimeZoneInfo]::Local.StandardName
		}
		$LocalResults.TimeZone = $TimeZone

		$Win32_OperatingSystem = @()
		$Win32_OperatingSystem = Get-WmiObject -Class Win32_OperatingSystem |
						Select-Object @{N="OperatingSystem";E={($_.Caption -Replace('Microsoft',' ') -Replace('Server',' ') -Replace('[^\x20-\x7E]+', ' ') -Replace('\s+', ' ')).Trim()}}, @{N="SP";E={$_.ServicePackMajorVersion}}, Version, @{N="BuildDate";E={Get-Date -Date ([Management.ManagementDateTimeConverter]::ToDateTime($_.InstallDate)) -Format "MM/dd/yyyy"}}, @{N="LastReboot";E={Get-Date -Date ([Management.ManagementDateTimeConverter]::ToDateTime($_.LastBootUpTime)) -Format "MM/dd/yyyy hh:mm:ss tt"}}, @{N="LocalDate";E={Get-Date -Date ([Management.ManagementDateTimeConverter]::ToDateTime($_.LocalDateTime)) -Format "MM/dd/yyyy hh:mm:ss tt"}}, OSArchitecture, @{N="MemoryTotalGB";E={[Math]::Round($_.TotalVisibleMemorySize/1MB, 0)}}, @{N="MemoryUsedGB";E={[Math]::Round(($_.TotalVisibleMemorySize - $_.FreePhysicalMemory)/1MB, 1)}}, @{L="MemoryFreeGB";E={[Math]::Round($_.FreePhysicalMemory/1MB, 1)}}
		$LocalResults.OperatingSystem = $Win32_OperatingSystem.OperatingSystem
		$LocalResults.SP = $Win32_OperatingSystem.SP
		$LocalResults.Version = $Win32_OperatingSystem.Version
		$LocalResults.LastReboot = $Win32_OperatingSystem.LastReboot
		$LocalResults.UpTime = Get-ElapsedTime -Start $Win32_OperatingSystem.LastReboot -LowLevel Seconds
		$LocalResults.BuildDate = $Win32_OperatingSystem.BuildDate
		$LocalResults.BuildAge = Get-ElapsedTime -Start $Win32_OperatingSystem.BuildDate -LowLevel Weeks
		$LocalResults.LocalDate = $Win32_OperatingSystem.LocalDate
		$LocalResults.OSArchitecture = $Win32_OperatingSystem.OSArchitecture
		$LocalResults.MemoryTotalGB = $Win32_OperatingSystem.MemoryTotalGB
		$LocalResults.MemoryUsedGB = $Win32_OperatingSystem.MemoryUsedGB
		$LocalResults.MemoryFreeGB = $Win32_OperatingSystem.MemoryFreeGB

		$Win32_ComputerSystem = @()
		$Win32_ComputerSystem = @()
		$Win32_ComputerSystem = Get-WmiObject -Class Win32_ComputerSystem |
							Select-Object AutomaticManagedPagefile, PartOfDomain, Workgroup, @{N="Domain";E={($_.Domain).ToLower()}}, DomainRole, @{N="HardwareModel";E={(((("{0} {1}" -f $_.Manufacturer, $_.Model) -Replace("Hewlett Packard", "HP") -Replace '[^a-zA-Z0-9]', ' ').Split(' ') | Select-Object -Unique | Where-Object {$_} | ForEach {$_.Trim()}) -Join(' ')) -Replace("VMware Inc Virtual Platform", "VMware Virtual Machine") -Replace("Microsoft Corporation Virtual Machine", "Microsoft Virtual Machine") -Replace(" Gen8", " G8") -Replace(" Gen9", " G9")}}, @{N="Processors";E={$_.NumberOfProcessors}}, @{N="TotalLogicalCores";E={$_.NumberOfLogicalProcessors}}
		$LocalResults.AutomaticManagedPagefile = $Win32_ComputerSystem.AutomaticManagedPagefile
		$LocalResults.HardwareModel = $Win32_ComputerSystem.HardwareModel
		$LocalResults.Processors = $Win32_ComputerSystem.Processors
		$LocalResults.TotalLogicalCores = $Win32_ComputerSystem.TotalLogicalCores
		If ($Win32_ComputerSystem.PartOfDomain -eq $True) {
			$LocalResults.Domain = $Win32_ComputerSystem.Domain
			$LocalResults.Workgroup = "N/A"
			Switch ($Win32_ComputerSystem.DomainRole) {
				0	{$LocalResults.SystemRole = "Standalone Workstation"}
				1	{$LocalResults.SystemRole = "Member Workstation"}
				2	{$LocalResults.SystemRole = "Standalone Server"}
				3	{$LocalResults.SystemRole = "Member Server"}
				4	{$LocalResults.SystemRole = "Domain Controller"}
				5	{$LocalResults.SystemRole = "Domain Controller"}
			}
		} Else {
			$LocalResults.Workgroup = $Win32_ComputerSystem.Workgroup
			$LocalResults.Domain = "N/A"
			$LocalResults.SystemRole = "N/A"
		}

		$Cultures = @()
		$Cultures = Get-Culture | Select-Object @{N="Language";E={$_.DisplayName}}
		$LocalResults.Language = $Cultures.Language

		$CrashDumps = @()
		$CrashDumps = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\CrashControl" | Select-Object @{N="CrashDumpFile";E={($_.DumpFile).ToLower()}}, @{N="CrashDumpType";E={Switch ($_.CrashDumpEnabled) {0 {"No Memory Dump";Break} 1 {"Complete Memory Dump";Break} 2 {"Kernel Memory Dump";Break} 3 {"Small Memory Dump";Break} 4 {"Small Memory Dump";Break} 7 {"Kernel Memory Dump"}}}}
		$LocalResults.CrashDumpType = $CrashDumps.CrashDumpType
		$LocalResults.CrashDumpFile = $CrashDumps.CrashDumpFile

		$AntiVirus = @()
		$AntiVirus = Get-ItemProperty "HKLM:\SOFTWARE\Symantec\Symantec Endpoint Protection\CurrentVersion\public-opstate" -ErrorAction SilentlyContinue | Select-Object @{N="SymantecVersion";E={$_.DeployRunningVersion}}, @{N="SymantecDefinitions";E={$_.LatestVirusDefsDate+' r'+$_.LatestVirusDefsRevision}}
		If ($AntiVirus.SymantecDefinitions -eq " r") {
			$AntiVirus.SymantecDefinitions = "Unknown"
		}
		$LocalResults.SymantecVersion = $AntiVirus.SymantecVersion
		$LocalResults.SymantecDefinitions = $AntiVirus.SymantecDefinitions

		$AntiVirusPolicy = @()
		$AntiVirusPolicy = Get-ItemProperty "HKLM:\SOFTWARE\Wow6432Node\Symantec\Symantec Endpoint Protection\SMC\SYLINK\SyLink" -ErrorAction SilentlyContinue | Select-Object @{N="SymantecPolicy";E={If (($_.CurrentGroup -Replace( '(?s)^.*\\', '')) -eq "FAF Servers") {"Balanced"} Else {($_.CurrentGroup -Replace( '(?s)^.*\\', ''))}}}
		If ($AntiVirusPolicy -eq $Null) {
			$AntiVirusPolicy = Get-ItemProperty "HKLM:\SOFTWARE\Symantec\Symantec Endpoint Protection\SMC\SYLINK\SyLink" -ErrorAction SilentlyContinue | Select-Object @{N="SymantecPolicy";E={If (($_.CurrentGroup -Replace( '(?s)^.*\\', '')) -eq "FAF Servers") {"Balanced"} Else {($_.CurrentGroup -Replace( '(?s)^.*\\', '')).Trim()}}}
		}
		If ($AntiVirusPolicy.SymantecPolicy -eq $Null -or $AntiVirusPolicy.SymantecPolicy -eq '') {
			$AntiVirusPolicy.SymantecPolicy = "Unknown"
		}
		$LocalResults.SymantecPolicy = $AntiVirusPolicy.SymantecPolicy

		$PowerPlans = @()
		$PowerPlans = Get-WmiObject -NameSpace root\cimv2\power -Class Win32_PowerPlan | Where-Object {$_.IsActive -eq $True} | Select-Object @{N="PowerPlan";E={$_.ElementName}}
		$LocalResults.PowerPlan = $PowerPlans.PowerPlan

		$Win32_OptionalFeature = @()
		$Win32_OptionalFeature = Get-WMIObject -Class Win32_OptionalFeature | Where-Object {$_.Name -eq 'Server-Gui-Shell'} | Select-Object @{N="WindowsShell";E={If ($_.InstallState -eq 2) {'Core'} Else {'Full GUI'}}}
		If ($Win32_OptionalFeature -eq $Null -or $Win32_OptionalFeature -eq "") {
			$LocalResults.WindowsShell = "N/A"
		} Else {
			$LocalResults.WindowsShell = $Win32_OptionalFeature.WindowsShell
		}

		$Win32_PageFileUsage = @()
		$Win32_PageFileUsage = Get-WmiObject -Class Win32_PageFileUsage |
							Select-Object @{N="PageFileName";E={($_.Name).ToLower()}}, @{N="PageFileTotalGB";E={[Math]::Round($_.AllocatedBaseSize/1KB, 0)}}, @{N="PageFileCurrentGB";E={[Math]::Round($_.CurrentUsage/1KB, 1)}}, @{N="PageFilePeakGB";E={[Math]::Round($_.PeakUsage/1KB, 1)}}
		$LocalResults.PageFileName = $Win32_PageFileUsage.PageFileName
		$LocalResults.PageFileTotalGB = $Win32_PageFileUsage.PageFileTotalGB
		$LocalResults.PageFileCurrentGB = $Win32_PageFileUsage.PageFileCurrentGB
		$LocalResults.PageFilePeakGB = $Win32_PageFileUsage.PageFilePeakGB

		$Win32_Processor = @()
		$Win32_Processor = Get-WmiObject -Class Win32_Processor |
							Select-Object MaxClockSpeed, CurrentClockSpeed, @{N="ProcessorModel";E={$_.Name -Replace('\(R\)', ' ') -Replace('\(TM\)', ' ') -Replace(' CPU ', ' ') -Replace(' Processor ', ' ') -Replace('\s+', ' ')}}, @{N="PhysicalCoresPerProcessor";E={$_.NumberOfCores}}, @{N="LogicalCoresPerProcessor";E={$_.NumberOfLogicalProcessors}} -Unique
		$LocalResults.ProcessorModel = $Win32_Processor.ProcessorModel
		$LocalResults.MaxClockSpeed = $Win32_Processor.MaxClockSpeed
		$LocalResults.CurrentClockSpeed = $Win32_Processor.MaxClockSpeed
		$LocalResults.PhysicalCoresPerProcessor = $Win32_Processor.PhysicalCoresPerProcessor
		$LocalResults.LogicalCoresPerProcessor = $Win32_Processor.LogicalCoresPerProcessor

		$LocalResults.$ProcessorLoad = (Get-Counter -Counter "\Processor(_Total)\% Processor Time" -SampleInterval 1 -MaxSamples 5 | Select-Object -ExpandProperty CounterSamples | Select-Object CookedValue | Measure-Object -Property CookedValue -Average | Select-Object @{N="Average";E={[Math]::Round($_.Average, 2, "AwayFromZero")}}) | Select-Object -Expand Average

		$Win32_BIOS = @()
		$Win32_BIOS = Get-WmiObject -Class Win32_BIOS |
							Select-Object @{N="BIOSDate";E={Get-Date -Date ([Management.ManagementDateTimeConverter]::ToDateTime($_.ReleaseDate)) -Format "MM/dd/yyyy"}}, @{N="HardwareSerialNumber";E={($_.SerialNumber -Replace('\s+', '')).ToUpper()}}, @{N="BIOSVersion";E={[RegEx]::Replace($_.SMBIOSBIOSVersion, '(\d+)', {Invoke-Expression $Args[0]})}}
		$LocalResults.BIOSDate = $Win32_BIOS.BIOSDate
		$LocalResults.HardwareSerialNumber = $Win32_BIOS.HardwareSerialNumber
		$LocalResults.BIOSVersion = $Win32_BIOS.BIOSVersion

		If ((Get-Service MpsSvc).Status -eq "Stopped") {
			$LocalResults.FirewallDomain = "Stopped"
			$LocalResults.FirewallPrivate = "Stopped"
			$LocalResults.FirewallPublic = "Stopped"
		} ElseIf ($PSVersion.Major -gt 2 -and $LocalResults.OperatingSystem -notlike "*2008*") {
			# PowerShell v3 and Windows 2012 and higher
			$Firewalls = @()
			$Firewalls = Get-NetFirewallProfile -All | Select-Object @{N="FirewallProfile";E={$_.Name}}, @{N="FirewallEnabled";E={Switch ($_.Enabled) {$True {"Enabled"} $False {"Disabled"}}}}
			ForEach ($Firewall In $Firewalls) {
				Switch ($Firewall.FirewallProfile) {
					"Domain" {
						$LocalResults.FirewallDomain = $Firewall.FirewallEnabled
						Break
					}
					"Private" {
						$LocalResults.FirewallPrivate = $Firewall.FirewallEnabled
						Break
					}
					"Public" {
						$LocalResults.FirewallPublic = $Firewall.FirewallEnabled
						Break
					}
				}
			}
		} Else {
			# PowerShell v2 and Windows 2008 / 2008 R2
			$NetSH = netsh.exe advfirewall show allprofiles | Select-String -SimpleMatch Profile, State
			For ($Counter = 0; $Counter -lt 6; $Counter += 2) {
				$FirewallName = ($NetSH[$Counter] | Select-String -SimpleMatch 'Profile Settings') -Replace('^*.Profile Settings:','')
				$FirewallName = $FirewallName.Trim()
				If ($NetSH[$Counter + 1] -match 'ON') {
					$FirewallState = "Enabled"
				} Else {
					$FirewallState = "Disabled"
				}
				Switch ($FirewallName) {
					Domain {
						$LocalResults.FirewallDomain = $FirewallState
						Break
					}
					Private {
						$LocalResults.FirewallPrivate = $FirewallState
						Break
					}
					Public {
						$LocalResults.FirewallPublic = $FirewallState
						Break
					}
				}
			}
		}
		$LocalResults.ProcessingTime = Get-ElapsedTime -Start $ProcessingStartTime -LowLevel Seconds
		$LocalResults

	} | Select-Object ComputerName, OperatingSystem, SP, Version, OSArchitecture, WindowsShell, Language, PowerPlan, LastReboot, UpTime, BuildDate, BuildAge, LocalDate, TimeZone, MemoryTotalGB, MemoryUsedGB, MemoryFreeGB, PageFileName, PageFileTotalGB, PageFileCurrentGB, PageFilePeakGB, AutomaticManagedPagefile, CrashDumpType, CrashDumpFile, SystemRole, Domain, Workgroup, HardwareModel, HardwareSerialNumber, BIOSVersion, BIOSDate, ProcessorModel, Processors, PhysicalCoresPerProcessor, LogicalCoresPerProcessor, TotalLogicalCores, ProcessorLoad, MaxClockSpeed, CurrentClockSpeed, FirewallDomain, FirewallPrivate, FirewallPublic, SymantecVersion, SymantecDefinitions, SymantecPolicy, PSVersion, ProcessingTime

	# End processing of individual computers
 	$Results | Sort-Object ComputerName | Export-CSV $ResultsCSV -NoTypeInformation
 	$Results | Sort-Object ComputerName | Format-Table ComputerName, OperatingSystem, SP, OSArchitecture, HardwareModel, LastReboot, UpTime, BuildAge -Autosize
}
