
#                                        #
# Aa Bb Cc Dd Ee Ff Gg Hh Ii Jj Kk Ll Mm #
# Nn Oo Pp Qq Rr Ss Tt Uu Vv Ww Xx Yy Zz #
# 0123456789   0Oo   1lI                 #
# ~!@$%^&*_+|`-=\/(){}[]<>:;?,."'#"      #
#                                        #
# Aa Bb Cc Dd Ee Ff Gg Hh Ii Jj Kk Ll Mm
# Nn Oo Pp Qq Rr Ss Tt Uu Vv Ww Xx Yy Zz
# 0123456789   0Oo   1lI
# ~!@$%^&*_+|`-=\/(){}[]<>:;?,."'#"
# Italic Testing
# d
# 9
# y
# f
# =!
# !=



# ---------------------------------------------------------------------------
Function Convert-UserIDToSID {
	Param (
		[Parameter(Mandatory = $True)]
		[String]$UserID
	)
	$UserID = $UserID.Trim()
	Try {
		$SecurityIdentifier = New-Object System.Security.Principal.NTAccount($UserID)
		$Account = $SecurityIdentifier.Translate([System.Security.Principal.SecurityIdentifier])
		Return $Account.Value
	} Catch {
		Return $Null
	}
}
# ---------------------------------------------------------------------------
Function Convert-SIDToUserID {
	Param (
		[Parameter(Mandatory = $True)]
		[String]$SID
	)
	$SID = ($SID -Replace("\*", "")).Trim()
	If ($SID.Length -ge 7 -and $SID.SubString(0,2) -eq "S-") {
		Try {
			$SecurityIdentifier = New-Object System.Security.Principal.SecurityIdentifier($SID)
			$Account = $SecurityIdentifier.Translate([System.Security.Principal.NTAccount])
			Return $Account.Value
		} Catch {
			Return $Null
		}
	} Else {
		Return $Null
	}
}
# ---------------------------------------------------------------------------
Function Get-FQDN {
	Param (
		[Parameter(Mandatory=$True, Position = 0)]
		[String[]]$ComputerName
	)
	ForEach ($Computer In $ComputerName) {
		$ErrorAction = $ErrorActionPreference
		$ErrorActionPreference = "SilentlyContinue"
		$Computer = [System.Net.Dns]::GetHostEntry($Computer).HostName
		$ErrorActionPreference = $ErrorAction
		If ([bool]($Computer -as [IPAddress])) {
			$ErrorAction = $ErrorActionPreference
			$ErrorActionPreference = "SilentlyContinue"
			$Computer = [System.Net.Dns]::GetHostbyAddress($Computer).HostName
			$ErrorActionPreference = $ErrorAction
		}
		$Computer
	}
}
# ---------------------------------------------------------------------------
Function Exit-WithCode {
	Param (
		[Parameter(Mandatory=$True)]
		[Int]$ExitCode
	)
	$Host.SetShouldExit($ExitCode)
	Exit
}
# ---------------------------------------------------------------------------
Filter Convert-IP2Decimal($IPAddress) {
	([IPAddress][String]([IPAddress]$IPAddress)).Address
}
# ---------------------------------------------------------------------------
Function Get-SpecialFolder {
	Param (
		[Parameter()]
		[ValidateSet("AdminTools", "ApplicationData", "CDBurning", "CommonAdminTools", "CommonApplicationData", "CommonDesktopDirectory", "CommonDocuments", "CommonMusic", "CommonOemLinks", "CommonPictures", "CommonProgramFiles", "CommonProgramFilesX86", "CommonPrograms", "CommonStartMenu", "CommonStartup", "CommonTemplates", "CommonVideos", "Cookies", "Desktop", "DesktopDirectory", "Favorites", "Fonts", "History", "InternetCache", "LocalApplicationData", "LocalizedResources", "MyComputer", "MyDocuments", "MyMusic", "MyPictures", "MyVideos", "NetworkShortcuts", "Personal", "PrinterShortcuts", "ProgramFiles", "ProgramFilesX86", "Programs", "Recent", "Resources", "SendTo", "StartMenu", "Startup", "System", "SystemX86", "Templates", "UserProfile", "Windows")]
		[String]$Name
	)
	$SpecialFolders = [Environment+SpecialFolder]::GetNames([Environment+SpecialFolder])
	$FolderList = @()
	ForEach ($SpecialFolder In $SpecialFolders) {
		If ([Environment]::GetFolderPath($SpecialFolder) -ne "") {
			$FolderList += "" | Select-Object @{L="Name";E={$SpecialFolder}}, @{L="Path";E={[Environment]::GetFolderPath($SpecialFolder)}}
		}
	}
	$FolderList = $FolderList | Sort-Object Name, Path
	If ($Name) {
		($FolderList | Where-Object {$_.Name -eq $Name} | Select-Object Path).Path
	} Else {
		$FolderList
	}
}
# ---------------------------------------------------------------------------
Function Get-Round {
	# This performs the standard rounding we are used to instead of the PowerShell default
	# PowerShell default is Round Half to Even
	#     Rounds to the nearest even whole number
	#         23.5 = 24, 24.5 = 24; while -23.5 = -24, 24.5 = -24
	# Round Half Away from Zero
	#     Rounds to the nearest whole number
	#         23.5 = 24, 24.5 = 25; while -23.5 = -24, -24.5 = -25
	Param(
		[Parameter(Mandatory=$True, Position = 0)]
		[Decimal]$Number,
		[Parameter(Mandatory=$False, Position = 1)]
		[Int]$Digits = 0
	)
	[Math]::Round($Number, $Digits, "AwayFromZero")
}
# ---------------------------------------------------------------------------
Function Get-AbsolutePath ($Path) {
    # System.IO.Path.Combine has two properties making it necessary here:
    #   1) correctly deals with situations where $Path (the second term) is an absolute path
    #   2) correctly deals with situations where $Path (the second term) is relative
    # (join-path) commandlet does not have this first property
    $Path = [System.IO.Path]::Combine( (($pwd).Path), ($Path) )
    # this piece strips out any relative path modifiers like '..' and '.'
    $Path = [System.IO.Path]::GetFullPath($Path)
    Return $Path
}
# ---------------------------------------------------------------------------
Function Format-Path {
	Param(
		[Parameter(Mandatory=$True)]
		[String]$Path,

		[Parameter()]
		[Switch]$NoTrailingSlash = $True,

		[Parameter()]
		[Switch]$TrailingSlash = $False
	)
	If ([System.IO.Path]::GetExtension($Path) -eq $Null -or [System.IO.Path]::GetExtension($Path) -eq "") {
		$Path = $Path.Trim() -Replace "\\$"
		If ($TrailingSlash -eq $True) {
			$Path = $Path + '\'
		}
	}
	$Path
}
# ---------------------------------------------------------------------------
Function Get-RegistryKeyPropertiesAndValues {
	Param(
		[Parameter(Mandatory=$True)]
		[String]$Path
	)
	Push-Location
	Set-Location -Path $Path
	Get-Item . | Select-Object -ExpandProperty Property | ForEach-Object {
	New-Object PSObject -Property @{"Property" = $_;
	"Value" = (Get-ItemProperty -Path . -Name $_).$_}}
	Pop-Location
}
# ---------------------------------------------------------------------------
Function Get-OSDetails {
	Param(
		[Parameter(Mandatory=$False)]
		[String[]]$ComputerName
	)
	$Results = Invoke-Command -ComputerName $ComputerName -ScriptBlock {
		$WMIOperatingSystem = Get-WmiObject -Class Win32_OperatingSystem | Select-Object @{L="ComputerName";E={If ($_.PSComputerName) {$_.PSComputerName} Else {$_.CSName}}}, @{L="Domain";E={$Null}}, @{L="OperatingSystem";E={($_.Caption -Replace('Microsoft',' ') -Replace('Server',' ') -Replace('Standard',' ') -Replace('Enterprise',' ') -Replace('Datacenter',' ') -Replace('Pro',' ') -Replace('[^\x20-\x7E]+', ' ') -Replace('\s+', ' ')).Trim()}}, @{L="Edition";E={($_.Caption -Replace('Microsoft',' ') -Replace('Windows',' ') -Replace('Server',' ') -Replace('R2',' ') -Replace('[^\x41-\x7A]+', ' ') -Replace('\s+', ' ')).Trim()}}, @{L="SP";E={If ($_.ServicePackMinorVersion -gt 0) {"{0}.{1}" -f $_.ServicePackMajorVersion, $_.ServicePackMinorVersion} Else {$_.ServicePackMajorVersion}}}, @{L="Version";E={($_.Version -Replace($_.BuildNumber,"")).TrimEnd(".")}}, @{L="Build";E={$_.BuildNumber}}, @{L="Release";E={$Null}}, @{L="OSArchitecture";E={$_.OSArchitecture -Replace('\-bit', '')}}, @{L="Type";E={$Null}}
		$Type = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").InstallationType
		If ($Type -eq "Client") {
			$WMIOperatingSystem.Type = "Workstation"
		} Else {
			$WMIOperatingSystem.Type = $Type
		}
		$ReleaseID = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").ReleaseID
		If ($ReleaseID -gt 0) {
			$WMIOperatingSystem.Release = $ReleaseID
		} Else {
			$WMIOperatingSystem.Release = 0
		}
		$WMIComputerSystem = Get-WmiObject Win32_ComputerSystem -Property PartOfDomain, Domain, Workgroup
		If ($WMIComputerSystem.PartOfDomain -eq $True) {
			$WMIOperatingSystem.Domain = ($WMIComputerSystem.Domain).ToLower()
		} Else {
			$WMIOperatingSystem.Domain = ($WMIComputerSystem.Workgroup).ToUpper()
		}
		Return $WMIOperatingSystem
	}
	$Results | Sort-Object ComputerName
}
# ---------------------------------------------------------------------------
Function Get-ScriptName {
	[io.path]::GetFileNameWithoutExtension($MyInvocation.MyCommand.Definition)
}
# ---------------------------------------------------------------------------
Function Get-ScriptDirectory {
	Split-Path $Script:MyInvocation.MyCommand.Path
}
# ---------------------------------------------------------------------------
Function Get-EnvVariable {
	Param(
		[Parameter()]
		[String]$EnvVar
	)
	If ($EnvVar -eq "") {
		Get-ChildItem Env:
	} Else {
		(Get-ChildItem Env:$EnvVar).Value
	}
}
# ---------------------------------------------------------------------------
Function Get-Matches($String, $RegEx) {
	If ($String -match $RegEx) {
		$Matches[1..($Matches.Count - 1)]
	} Else {
		@()
	}
}
# ---------------------------------------------------------------------------
Function Test-Null($String) {
	If ($String -eq $Null -or $String -eq "") {
		$True
	} Else {
		$False
	}
}
# ---------------------------------------------------------------------------
Function Convert-ToTileCase($String) {
	(Get-Culture).TextInfo.ToTitleCase($String.ToLower())
}
# ---------------------------------------------------------------------------
Function Format-FileNameWithDate {
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $False)]
		[String]$Prefix,
		[Parameter(Mandatory = $False)]
		[String]$Suffix = ".txt",
		[Parameter(Mandatory = $False)]
		[String]$DateFormat = "yyyy-MM-dd"
	)
	$TextDate = Get-Date -Format $DateFormat
	Return $Prefix + $TextDate + $Suffix
}
# ---------------------------------------------------------------------------
Function Get-CenteredString {
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $True, Position = 0)]
		[string]$Message,
		[Parameter(Mandatory = $False)]
		[Int]$Length = 80
	)
	Begin { }
	Process {
		$LengthOf = $Message.Length
		If ($Length -le $LengthOf) {
			Return $Message.SubString(0,$Length)
		} Else {
			$LengthBefore = [Math]::Round(($Length / 2) - [Math]::Round(($Message.Length / 2)))
			$LengthAfter = $Length - ($LengthBefore + $LengthOf)
			If ($LengthBefore -gt $LengthAfter) {
				$Temp = $LengthAfter
				$LengthAfter = $LengthBefore
				$LengthBefore = $Temp
			}
			If (($LengthAfter - $LengthBefore) -gt 1) {
				$LengthBefore = $LengthBefore + 1
				$LengthAfter = $LengthAfter - 1
			}
			$NewMessage = ''.PadLeft($LengthBefore, ' ')
			$NewMessage = $NewMessage + $Message
			$NewMessage = $NewMessage + ''.PadRight($LengthAfter, ' ')
			Return $NewMessage
		}
	}
	End { }
}
# ---------------------------------------------------------------------------
Function Write-Centered {
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $False, Position = 0)]
		[string]$Text,
		[Parameter(Mandatory = $False)]
		[Int]$Length = ([Console]::WindowWidth - 1),
		[Parameter(Mandatory = $False)]
		[string]$ForegroundColor = [Console]::ForegroundColor,
		[Parameter(Mandatory = $False)]
		[string]$BackgroundColor = [Console]::BackgroundColor
	)
	Begin { }
	Process {
		$LengthOf = $Text.Length
		If ($Length -le $LengthOf) {
			Write-Host $Text -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor
		} Else {
			$LengthBefore = [Math]::Round(($Length / 2) - [Math]::Round(($Text.Length / 2)))
			$LengthAfter = $Length - ($LengthBefore + $LengthOf)
			If ($LengthBefore -gt $LengthAfter) {
				$Temp = $LengthAfter
				$LengthAfter = $LengthBefore
				$LengthBefore = $Temp
			}
			If (($LengthAfter - $LengthBefore) -gt 1) {
				$LengthBefore = $LengthBefore + 1
				$LengthAfter = $LengthAfter - 1
			}
			$NewText = ''.PadLeft($LengthBefore, ' ')
			$NewText = $NewText + $Text
			$NewText = $NewText + ''.PadRight($LengthAfter, ' ')
			Write-Host $NewText -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor
		}
	}
	End { }
}
# ---------------------------------------------------------------------------
Function Get-TimeElapsed {
	[CmdletBinding()]
	Param ([Parameter(Mandatory = $True,
					  Position = 0,
					  ValueFromPipeline = $True)]
		[System.TimeSpan]$TimeSpan,
		[Parameter(Mandatory = $False)]
		[Switch]$ShowMS = $False
	)
	Switch ($TimeSpan) {
		{ $_.days -eq 1 } { $Days = "1 Day" }
		{ $_.days -gt 1 } { $Days = [string]$_.days + " Days" }
		{ $_.hours -eq 1 } { $Hrs = "1 Hour" }
		{ $_.hours -gt 1 } { $Hrs = [string]$_.hours + " Hours" }
		{ $_.Minutes -eq 1 } { $Mins = "1 Minute" }
		{ $_.Minutes -gt 1 } { $Mins = [string]$_.minutes + " Minutes" }
		{ $_.Seconds -eq 1 } { $Secs = "1 Second" }
		{ $_.Seconds -gt 1 } { $Secs = [string]$_.seconds + " Seconds" }
		{ $_.Milliseconds -eq 1 } { $MSecs = "1 Millisecond" }
		{ $_.Milliseconds -gt 1 } { $MSecs = [string]$_.Milliseconds + " Milliseconds" }
	}
	If ($ShowMS -eq $True) {
		Return "$Days $Hrs $Mins $Secs $MSecs".Trim()
	} Else {
		Return "$Days $Hrs $Mins $Secs".Trim()
	}
}
# ---------------------------------------------------------------------------
Function Get-Colors
{
	$Foreground = $Host.UI.RawUI.ForegroundColor
	$Background = $Host.UI.RawUI.BackgroundColor
	Write-Host
	ForEach ($Color In ([enum]::GetValues([ConsoleColor]))) {
		Write-Host (" {0,2} | {1,11} | " -f $($Color.Value__), $Color) -NoNewLine
		Write-Host "COLOR  " -ForegroundColor $Color -NoNewLine
		Write-Host "`t`t" -BackgroundColor $Color -NoNewLine
		Write-Host "  " -NoNewLine
		If ($Color -eq $Foreground) {
			Write-Host " Foreground " -ForegroundColor $Background -BackgroundColor $Foreground
		} ElseIf ($Color -eq $Background) {
			Write-Host " Background " -ForegroundColor $Background -BackgroundColor $Foreground
		} Else {
			Write-Host
		}
	}

	Write-Host
	$ColorList = @(
		"Black"
		"DarkBlue"
		"DarkGreen"
		"DarkCyan"
		"DarkRed"
		"DarkMagenta"
		"DarkYellow"
		"Gray"
		"DarkGray"
		"Blue"
		"Green"
		"Cyan"
		"Red"
		"Magenta"
		"Yellow"
		"White"
	)
	$ColorNum = 0
	ForEach ($BGColor in $ColorList) {
		Write-Host (" {0,2} | {1,11} | " -f $ColorNum, $BGColor) -NoNewline
		ForEach ($FGColor in $ColorList) {
			Write-Host " $FGColor |" `
				-BackgroundColor $BGColor `
				-ForegroundColor $FGColor `
				-NoNewline
		}
		Write-Host
		$ColorNum = $ColorNum + 1
	}
	Write-Host
}
# ---------------------------------------------------------------------------
Function Format-Color {
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $True, ValueFromPipeline = $True)]
		[String]$InputData,

		[Parameter(Mandatory = $True)]
		[HashTable]$Colors,

		[Parameter(Mandatory = $False)]
		[Switch] $SimpleMatch
	)
	# Example
	# $TestData | Format-Table -AutoSize | Out-String | Format-Color -Colors @{"Type: " = "Black,DarkGray"; "Domain Admins" = ",DarkMagenta"; "^AccountExpirationDate\s+: [\w]" = "Black,DarkYellow"}

	$BlankCount = 0
	$ErrorAction = $ErrorActionPreference
	$DefaultFGColor = $Host.UI.RawUI.ForegroundColor
	$DefaultBGColor = $Host.UI.RawUI.BackgroundColor
	$Lines = (($InputData | Out-String) -replace "`r", "") -Split "`n"
	ForEach ($Line In $Lines) {
		If ($Line.Trim() -eq $Null -or $Line.Trim() -eq "") {
			$BlankCount = $BlankCount + 1
		} Else {
			$BlankCount = 0
		}
		If ($BlankCount -lt 2) {
			$FGColor = ''
			$BGColor = ''
			$Colored = $False
			ForEach ($Pattern In $Colors.Keys) {
				If (!$SimpleMatch -and $Line -match $Pattern) {
					$CurrentColors = $Colors[$Pattern].Split(",")
					$ErrorActionPreference = "SilentlyContinue"
					$CurrentColors[0] = $CurrentColors[0].Trim()
					$CurrentColors[1] = $CurrentColors[1].Trim()
					$ErrorActionPreference = $ErrorAction
					If ($CurrentColors[0] -eq "" -or $CurrentColors[0] -eq $Null) {
						$FGColor = $DefaultFGColor
					} Else {
						$FGColor = $CurrentColors[0]
					}
					If ($CurrentColors[1] -eq "" -or $CurrentColors[1] -eq $Null) {
						$BGColor = $DefaultBGColor
					} Else {
						$BGColor = $CurrentColors[1]
					}
					$Colored = $True
				}
				ElseIf ($SimpleMatch -and $Line -like $Pattern) {
					$CurrentColors = $Colors[$Pattern].Split(",")
					$ErrorActionPreference = "SilentlyContinue"
					$CurrentColors[0] = $CurrentColors[0].Trim()
					$CurrentColors[1] = $CurrentColors[1].Trim()
					$ErrorActionPreference = $ErrorAction
					If ($CurrentColors[0] -eq "" -or $CurrentColors[0] -eq $Null) {
						$FGColor = $DefaultFGColor
					} Else {
						$FGColor = $CurrentColors[0]
					}
					If ($CurrentColors[1] -eq "" -or $CurrentColors[1] -eq $Null) {
						$BGColor = $DefaultBGColor
					} Else {
						$BGColor = $CurrentColors[1]
					}
					$Colored = $True
				}
			}
			If ($Colored -eq $True) {
				Write-Host $Line -ForegroundColor $FGColor -BackgroundColor $BGColor
			} Else {
				Write-Host $Line
			}
		}
	}
}
# ---------------------------------------------------------------------------
Function Format-Bytes {
<#
	.SYNOPSIS
	Converts Bytes to KB, MB, GB, TB, or PB
	.DESCRIPTION
	Format-Bytes takes a bytes sized input and formats it to be KB, MB, GB, TB, or PB depending on its size.
	.PARAMETER $Bytes
	The number of Bytes to convert to KB, MB, GB, TB, or PB.
	.EXAMPLE
	Format-Bytes 123456789

	Output: 117.74 MB
	.EXAMPLE
	$x = (123456,456789456,789456123456)
	$x | Format-Bytes

	Output:
	120.56 KB
	435.63 MB
	735.24 GB
	.INPUTS
	A number of any type.
	.OUTPUTS
	A number converted to a string with it's type identifier.
#>
	Param (
		[Parameter(ValueFromPipeline = $True, Mandatory = $True)]
		[Float[]]$InputBytes,
		[Parameter(ValueFromPipeline = $True, Mandatory = $False)]
		[Int[]]$Places = 1,
		[Parameter(ValueFromPipeline = $True, Mandatory = $False)]
		[Boolean[]]$HideZero = $False
	)
	Begin {
	}
	Process {
		ForEach ($Bytes In $InputBytes) {
			If ($Bytes -lt 1KB) {
				$ConvBytes = $Bytes
				$Scale = "B"
			}
			If ($Bytes -ge 1KB) {
				$ConvBytes = $Bytes/1KB
				$Scale = "KB"
			}
			If ($Bytes -ge 1MB) {
				$ConvBytes = $Bytes/1MB
				$Scale = "MB"
			}
			If ($Bytes -ge 1GB) {
				$ConvBytes = $Bytes/1GB
				$Scale = "GB"
			}
			If ($Bytes -ge 1TB) {
				$ConvBytes = $Bytes/1TB
				$Scale = "TB"
			}
			If ($Bytes -ge 1PB) {
				$ConvBytes = $Bytes/1PB
				$Scale = "PB"
			}
		}
		$ConvBytes = "{0:N$Places}" -f $ConvBytes
		If ($ConvBytes.EndsWith(".0") -And $HideZeros -eq $True) {
			[Int]$ConvBytes = $ConvBytes
		}
		Return "$ConvBytes $Scale"
	}
	End {
	}
}
# ---------------------------------------------------------------------------
Function ConvertTo-RomanNumeral {
  <#
	.SYNOPSIS
		Converts a number to a Roman numeral.
	.DESCRIPTION
		Converts a number - in the range of 1 to 3,999 - to a Roman numeral.
	.PARAMETER Number
		An integer in the range 1 to 3,999.
	.INPUTS
		System.Int32
	.OUTPUTS
		System.String
	.EXAMPLE
		ConvertTo-RomanNumeral -Number (Get-Date).Year
	.EXAMPLE
		(Get-Date).Year | ConvertTo-RomanNumeral
  #>
	[CmdletBinding()]
	[OutputType([string])]
	Param
	(
		[Parameter(Mandatory = $true,
				   HelpMessage = "Enter an integer in the range 1 to 3,999",
				   ValueFromPipeline = $true,
				   Position = 0)]
		[ValidateRange(1, 3999)]
		[int]$Number
	)

	Begin {
		$DecimalToRoman = @{
			Thousands = "", "M", "MM", "MMM"
			Hundreds = "", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM"
			Tens = "", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC"
			Ones = "", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"
		}

		$column = @{
			Thousands = 0
			Hundreds = 1
			Tens = 2
			Ones = 3
		}
	}
	Process {
		[int[]]$digits = $Number.ToString().PadLeft(4, "0").ToCharArray() |
		ForEach-Object { [Char]::GetNumericValue($_) }

		$RomanNumeral = ""
		$RomanNumeral += $DecimalToRoman.Thousands[$digits[$column.Thousands]]
		$RomanNumeral += $DecimalToRoman.Hundreds[$digits[$column.Hundreds]]
		$RomanNumeral += $DecimalToRoman.Tens[$digits[$column.Tens]]
		$RomanNumeral += $DecimalToRoman.Ones[$digits[$column.Ones]]

		$RomanNumeral
	}
	End {
	}
}
# ---------------------------------------------------------------------------
function ConvertFrom-RomanNumeral {
  <#
	.SYNOPSIS
		Converts a roman numeral to a number.
	.DESCRIPTION
		Converts a roman numeral - in the range of I..MMMCMXCIX - to a number.
	.PARAMETER Numeral
		A roman numeral in the range I..MMMCMXCIX (1..3,999).
	.INPUTS
		System.String
	.OUTPUTS
		System.Int32
	.NOTES
		Requires PowerShell version 3.0
	.EXAMPLE
		ConvertFrom-RomanNumeral -Numeral MMXIV
	.EXAMPLE
		"MMXIV" | ConvertFrom-RomanNumeral
  #>
	[CmdletBinding()]
	[OutputType([int])]
	Param
	(
		[Parameter(Mandatory = $true,
				   HelpMessage = "Enter a roman numeral in the range I..MMMCMXCIX",
				   ValueFromPipeline = $true,
				   Position = 0)]
		[ValidatePattern("(?x)^
						 M{0,3}  # Thousands
				(CM|CD|D?C{0,3}) # Hundreds
				(XC|XL|L?X{0,3}) # Tens
				(IX|IV|V?I{0,3}) # Ones
				$")]
		[string]$Numeral
	)

	Begin {
		# This must be an [ordered] hashtable
		$RomanToDecimal = [ordered]@{
			M = 1000
			CM = 900
			D = 500
			CD = 400
			C = 100
			XC = 90
			L = 50
			X = 10
			IX = 9
			V = 5
			IV = 4
			I = 1
		}
	}
	Process {
		$roman = $Numeral + '$'
		$value = 0

		do {
			foreach ($key in $RomanToDecimal.Keys) {
				if ($key.Length -eq 1) {
					if ($key -match $roman.Substring(0, 1)) {
						$value += $RomanToDecimal.$key
						$roman = $roman.Substring(1)
						break
					}
				} else {
					if ($key -match $roman.Substring(0, 2)) {
						$value += $RomanToDecimal.$key
						$roman = $roman.Substring(2)
						break
					}
				}
			}
		} until ($roman -eq '$')

		$value
	}
	End {
	}
}
# ---------------------------------------------------------------------------
Function Get-ElapsedTime {
<#
	.SYNOPSIS
		The Get-ElapsedTime function takes a date/time range and converts it to years,
		weeks, days, hours, minutes, seconds, and milliseconds

	.DESCRIPTION
		The Get-ElapsedTime function takes a date/time range and converts it to years,
		weeks, days, hours, minutes, seconds, and milliseconds. Does not process months
		at this time due to the complexity of the varying lengths and Leap Years.

	.PARAMETER Start
		The starting date/time of the range to calculate

	.PARAMETER End
		The ending date/time of the range to calculate
		Current date/time (Default)

	.PARAMETER HighLevel
		Highest level of date/time to return

		NonZero (Default)
		Years
		Weeks
		Days
		Hours
		Seconds
		Milliseconds

	.PARAMETER LowLevel
		Lowest level of date/time to return

		Years
		Weeks
		Days
		Hours
		Seconds (Default)
		Milliseconds

	.PARAMETER LevelText
		Text to use for each level of date/time
		There must always be 7 elements

		" years / weeks / days / hours / minutes / seconds / milliseconds" (Default)
		"y /w /d /h /m /s /m"
		" yr, / wk, / dy, / hr, / mn, / sc, / ms"
		"y:/w:/d:/h:/m:/s./m"
		" year(s) / week(s) / day(s) / hour(s) / minute(s) / second(s) / millisecond(s)"

	.PARAMETER Delimiter
		Delimiter used to split LevelText
		Values will not be trimmed so spaces and other punctuation can be used
		"/" (Default)

	.PARAMETER NoText
		Do not show time span text after time values

		True:  4 13 34 56
		False: 4 days 13 hours 34 minutes 56 seconds (Default)

	.PARAMETER LeadingZero
		Make all time values at least 2 digits by adding a LeadingZero if required
		Milliseconds will be converted to 3 digits if required

		True:  04 days, 13 hours, 05 minutes, 09 seconds, 068 milliseconds
		False: 4 days, 13 hours, 5 minutes, 9 seconds, 68 milliseconds (Default)

	.PARAMETER Object
		Return an Object instead of the default String

	.OUTPUTS
		String (Default)
		Object

	.NOTES
		Written by Ryan Amsbury
		v0.6
#>
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory = $True,
				   ValueFromPipeline = $True,
				   Position = 0)]
		[DateTime]$Start,

		[Parameter(Mandatory = $False,
				   ValueFromPipeline = $True,
				   Position = 1)]
		[DateTime]$End = (Get-Date),

		[Parameter(Mandatory = $False)]
		[ValidateSet('NonZero', 'Years', 'Weeks', 'Days', 'Hours', 'Minutes', 'Seconds', 'Milliseconds', IgnoreCase = $True)]
		[string]$HighLevel = 'NonZero',

		[Parameter(Mandatory = $False)]
		[ValidateSet('Milliseconds', 'Seconds', 'Minutes', 'Hours', 'Days', 'Weeks', 'Years', IgnoreCase = $True)]
		[string]$LowLevel = 'Seconds',

		[Parameter(Mandatory = $False)]
		[String]$LevelText = ' years / weeks / days / hours / minutes / seconds / milliseconds',

		[Parameter(Mandatory = $False)]
		[String]$Delimiter = '/',

		[Parameter(Mandatory = $False)]
		[Switch]$NoText = $False,

		[Parameter(Mandatory = $False)]
		[Switch]$LeadingZero = $False,

		[Parameter(Mandatory = $False)]
		[Switch]$Object = $False
	)

	Begin {
		$LevelHash = @{
			'NonZero' = 8;
			'Years' = 7;
			'Weeks' = 6;
			'Days' = 5;
			'Hours' = 4;
			'Minutes' = 3;
			'Seconds' = 2;
			'Milliseconds' = 1;
		}
	} # Begin
	Process {
		If ($LevelHash.$HighLevel -lt $LevelHash.$LowLevel) {
			$HighLevel = 'NonZero'
		}
		$IncludeZero = $False
		$LevelTextArray = $LevelText -Split $Delimiter, 7, [StringSplitOptions]::"SimpleMatch"
		$TimeSpan = New-TimeSpan -Start $Start -End $End
		$Years = 0
		$Weeks = 0
		$Days = $TimeSpan.Days
		$Hours = $TimeSpan.Hours
		$Minutes = $TimeSpan.Minutes
		$Seconds = $TimeSpan.Seconds
		$Milliseconds = $TimeSpan.Milliseconds
		# Calculate years
		If ($LevelHash.$HighLevel -ge $LevelHash.Years) {
			If ($Days -gt 365) {
				# more than 1 year
				$Years = [Math]::Floor($Days / 365)
				If (($Days / 365) -gt $Years) {
					# there are extra days
					$Days = ($Days % 365) # returns the remainder of days
				} ElseIf (($Days / 365) -eq $Years) {
					# no more days
					$Days = 0
				}
			} ElseIf ($Days -lt -365) {
				# more than 1 year
				$Years = 0 - [Math]::Floor($Days / -365)
				If (($Days / -365) -gt $Years) {
					# there are extra days
					$Days = ($Days % -365) # returns the remainder of days
				} ElseIf (($Days / -365) -eq $Years) {
					# no more days
					$Days = 0
				}
			}
			If ($Days -eq 365) {
				# exactly 1 year
				$Years = 1
				$Days = 0
			}
			If ($Days -eq -365) {
				$Years = -1
				$Days = 0
			}
		}
		# Calculate weeks
		If ($LevelHash.$HighLevel -ge $LevelHash.Weeks) {
			If ($Days -gt 0) {
				# days left to process
				$Weeks = [Math]::Floor($Days / 7)
				If (($Days / 7) -gt $Weeks) {
					# there are extra days
					$Days = ($Days % 7) # returns the remainder of days
				} ElseIf (($Days / 7) -eq $Weeks) {
					# no more days
					$Days = 0
				}
			} ElseIf ($Days -lt 0) {
				# days left to process
				$Weeks = 0 - [Math]::Floor($Days / -7)
				If (($Days / -7) -gt $Weeks) {
					# there are extra days
					$Days = ($Days % -7) # returns the remainder of days
				} ElseIf (($Days / -7) -eq $Weeks) {
					# no more days
					$Days = 0
				}
			}
			If ($Days -eq 7) {
				# exactly 1 week
				$Weeks = 1
				$Days = 0
			}
			If ($Days -eq -7) {
				# exactly 1 week
				$Weeks = -1
				$Days = 0
			}
		}
		If ($LeadingZero -eq $True) {
			$Years = "{0:D2}" -f [int]$Years
			$Weeks = "{0:D2}" -f [int]$Weeks
			$Days = "{0:D2}" -f [int]$Days
			$Hours = "{0:D2}" -f [int]$Hours
			$Minutes = "{0:D2}" -f [int]$Minutes
			$Seconds = "{0:D2}" -f [int]$Seconds
			$Milliseconds = "{0:D3}" -f [int]$Milliseconds
		}

		$ElapsedTime = @()
		$TempElapsed = New-Object System.Object
		$TempElapsed | Add-Member -Type NoteProperty -Name Years -Value ([String]$Years)
		$TempElapsed | Add-Member -Type NoteProperty -Name Weeks -Value ([String]$Weeks)
		$TempElapsed | Add-Member -Type NoteProperty -Name Days -Value ([String]$Days)
		$TempElapsed | Add-Member -Type NoteProperty -Name Hours -Value ([String]$Hours)
		$TempElapsed | Add-Member -Type NoteProperty -Name Minutes -Value ([String]$Minutes)
		$TempElapsed | Add-Member -Type NoteProperty -Name Seconds -Value ([String]$Seconds)
		$TempElapsed | Add-Member -Type NoteProperty -Name Milliseconds -Value ([String]$Milliseconds)
		$TempElapsed | Add-Member -Type NoteProperty -Name YearsText -Value ([String]$LevelTextArray[0])
		$TempElapsed | Add-Member -Type NoteProperty -Name WeeksText -Value ([String]$LevelTextArray[1])
		$TempElapsed | Add-Member -Type NoteProperty -Name DaysText -Value ([String]$LevelTextArray[2])
		$TempElapsed | Add-Member -Type NoteProperty -Name HoursText -Value ([String]$LevelTextArray[3])
		$TempElapsed | Add-Member -Type NoteProperty -Name MinutesText -Value ([String]$LevelTextArray[4])
		$TempElapsed | Add-Member -Type NoteProperty -Name SecondsText -Value ([String]$LevelTextArray[5])
		$TempElapsed | Add-Member -Type NoteProperty -Name MillisecondsText -Value ([String]$LevelTextArray[6])
		$ElapsedTime += $TempElapsed

		$Years = $Null
		$Weeks = $Null
		$Days = $Null
		$Hours = $Null
		$Minutes = $Null
		$Seconds = $Null
		$Milliseconds = $Null

		Switch ($ElapsedTime) {
			{ (([Int]$_.Years -gt 0) -or ($LevelHash.$HighLevel -eq 7)) -and (($LevelHash.$HighLevel -ge 7) -and ($LevelHash.$LowLevel -le 7)) }
				{
					If ($NoText -eq $True) {
						$Years = $_.Years + ' '
					} Else {
						$Years = $_.Years + $_.YearsText
					}
					$IncludeZero = $True
				}

			{ ((([Int]$_.Weeks -gt 0) -or ($LevelHash.$HighLevel -eq 6) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 6) -and ($LevelHash.$LowLevel -le 6))) }
				{
					If ($NoText -eq $True) {
						$Weeks = $_.Weeks + ' '
					} Else {
						$Weeks = $_.Weeks + $_.WeeksText
					}
					$IncludeZero = $True
				}

			{ ((([Int]$_.Days -gt 0) -or ($LevelHash.$HighLevel -eq 5) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 5) -and ($LevelHash.$LowLevel -le 5))) }
				{
					If ($NoText -eq $True) {
						$Days = $_.Days + ' '
					} Else {
						$Days = $_.Days + $_.DaysText
					}
					$IncludeZero = $True
				}

			{ ((([Int]$_.Hours -gt 0) -or ($LevelHash.$HighLevel -eq 4) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 4) -and ($LevelHash.$LowLevel -le 4))) }
				{
					If ($NoText -eq $True) {
						$Hours = $_.Hours + ' '
					} Else {
						$Hours = $_.Hours + $_.HoursText
					}
					$IncludeZero = $True
				}

			{ ((([Int]$_.Minutes -gt 0) -or ($LevelHash.$HighLevel -eq 3) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 3) -and ($LevelHash.$LowLevel -le 3))) }
				{
					If ($NoText -eq $True) {
						$Minutes = $_.Minutes + ' '
					} Else {
						$Minutes = $_.Minutes + $_.MinutesText
					}
					$IncludeZero = $True
				}

			{ ((([Int]$_.Seconds -gt 0) -or ($LevelHash.$HighLevel -eq 2) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 2) -and ($LevelHash.$LowLevel -le 2))) }
				{
					If ($NoText -eq $True) {
						$Seconds = $_.Seconds + ' '
					} Else {
						$Seconds = $_.Seconds + $_.SecondsText
					}
				}

			{ ((([Int]$_.Milliseconds -gt 0) -or ($LevelHash.$HighLevel -eq 1) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 1) -and ($LevelHash.$LowLevel -le 1))) }
				{
					If ($NoText -eq $True) {
						$Milliseconds = $_.Milliseconds + ' '
					} Else {
						$Milliseconds = $_.Milliseconds + $_.MillisecondsText
					}
					$IncludeZero = $True
				}
		}
		If ($Object -eq $True) {
			Return $ElapsedTime
		} Else {
			Return "$Years$Weeks$Days$Hours$Minutes$Seconds$Milliseconds".Trim()
		}
	} # Process
	End {
	} # End
}
# ---------------------------------------------------------------------------
Function Test-Port {
	Param(
		[Parameter(Mandatory=$True, Position=0)]
		[String]$ComputerName,

		[Parameter(Mandatory=$True, Position=1)]
		[Int]$Port,

		[Parameter(Mandatory=$False)]
		[Switch]$NoPortDetails = $False
	)
	$ComputerName = $ComputerName.ToLower()
	# IANA.org has a full list of *officially assigned* ports that this script
	# can use. Download the CSV formatted list (service-names-port-numbers.csv)
	# from the URL below and put it in the script folder. When run the script
	# will read the CSV, clean up the data, then save as IANAPorts.csv.
	#
	# IANA.org CSV Port List
	# http://www.iana.org/assignments/service-names-port-numbers/service-names-port-numbers.csv
	#
	# Assigned System Ports and User Ports SHOULD NOT be used without or prior to IANA registration, as per [RFC6335]
	#
	# Ports 0-1023 are System Ports
	# System Ports are assigned by IETF process for standards-track protocols, as per [RFC6335]
	#
	# Ports 1024-49151 are User Ports
	# User Ports are assigned by IANA using the "IETF Review" process, the "IESG Approval" process, or the "Expert Review" process, as per [RFC6335]
	#
	# Ports 49152-65535 are Dynamic and/or Private
	# Dynamic and/or Private Ports are not assigned
	#
	# IANAPorts.csv will be used to display port details if it exists
	# If both files exist the script will update IANAPorts.csv if required
	# If neither file exists the script will run but not display port details
	$IANAPortsFile = ".\IANAPorts.csv"
	$IANAPortsSourceFile = ".\service-names-port-numbers.csv"
	Function ProcessPortsFile {
		$IANAPorts = @()
		Write-Host "Processing IANA.org Officially Assigned Ports List . . ." -ForegroundColor Yellow
		$IANAPortList = Import-CSV $IANAPortsSourceFile | Where-Object {$_."Port Number" -ne "" -and $_."Transport Protocol" -eq "tcp"} | Select-Object @{Name="Protocol";Expression={$_."Transport Protocol"}}, @{Name="Port";Expression={$_."Port Number"}}, @{Name="ServiceName";Expression={$_."Service Name"}}, Description
		ForEach ($IANAPort In $IANAPortList) {
			If ($IANAPort.Port -like "*-*") {
				$IANAPort.Port = $IANAPort.Port -Replace('-', '..')
				$PortRanges = Invoke-Expression -Command $IANAPort.Port
				ForEach ($PortRange In $PortRanges) {
				$PortSort = ([Int]$PortRange).ToString("00000")
					$PortTemp = New-Object PSObject
					Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "Protocol" -Value ([String]$IANAPort.Protocol)
					Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "Port" -Value ([Int]$PortRange)
					Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "PortSort" -Value ([String]$PortSort)
					Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "ServiceName" -Value ([String]$IANAPort.ServiceName)
					Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "Description" -Value ([String]$IANAPort.Description)
					If ($IANAPort.ServiceName -eq " " -or $IANAPort.ServiceName -eq "" -or $IANAPort.ServiceName -eq $Null) {
						$PortTemp.ServiceName = [String]$IANAPort.Description
					}
					If ($IANAPort.Description -eq " " -or $IANAPort.Description -eq "" -or $IANAPort.Description -eq $Null) {
						$PortTemp.Description = [String]$IANAPort.ServiceName
					}
					$IANAPorts += $PortTemp
				}
			} Else {
				$PortSort = ([Int]$IANAPort.Port).ToString("00000")
				$PortTemp = New-Object PSObject
				Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "Protocol" -Value ([String]$IANAPort.Protocol)
				Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "Port" -Value ([Int]$IANAPort.Port)
				Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "PortSort" -Value ([String]$PortSort)
				Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "ServiceName" -Value ([String]$IANAPort.ServiceName)
				Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "Description" -Value ([String]$IANAPort.Description)
				If ($IANAPort.ServiceName -eq " " -or $IANAPort.ServiceName -eq "" -or $IANAPort.ServiceName -eq $Null) {
					$PortTemp.ServiceName = [String]$IANAPort.Description
				}
				If ($IANAPort.Description -eq " " -or $IANAPort.Description -eq "" -or $IANAPort.Description -eq $Null) {
					$PortTemp.Description = [String]$IANAPort.ServiceName
				}
				$IANAPorts += $PortTemp
			}
		}
		$IANAPorts | Sort-Object PortSort, ServiceName | Export-Csv -Path $IANAPortsFile -Force -NoTypeInformation
	}
	# Does the $IANAPortsFile exist
	If ((Test-Path $IANAPortsFile) -eq $True -And ($NoPortDetails -eq $False)) {
		$IANAPortsExists = $True
		$IANAPortsModified = Get-Item $IANAPortsFile | ForEach {$_.LastWriteTime}
	} Else {
		$IANAPortsExists = $False
		$IANAPortsModified = $Null
	}
	# Does the $IANAPortsSourceFile exist
	If ((Test-Path $IANAPortsSourceFile) -eq $True -And ($NoPortDetails -eq $False)) {
		$IANAPortsSourceExists = $True
		$IANAPortsSourceModified = Get-Item $IANAPortsSourceFile | ForEach {$_.LastWriteTime}
	} Else {
		$IANAPortsSourceExists = $False
		$IANAPortsSourceModified = $Null
	}

	If (($IANAPortsExists -eq $False -and $IANAPortsSourceExists -eq $True) -and $IANAPorts -eq $Null) {
		ProcessPortsFile
		$IANAPortsExists = $True
		$IANAPortsModified = Get-Item $IANAPortsFile | ForEach {$_.LastWriteTime}
	}

	If ($IANAPortsSourceModified -gt $IANAPortsModified) {
		ProcessPortsFile
		$IANAPortsExists = $True
	}

	If ($IANAPortsExists -eq $True) {
		$IANAPorts = Import-CSV $IANAPortsFile
	}

	If ((Test-Connection -ComputerName $ComputerName -Count 1 -Quiet) -eq $False) {
		Write-Host
		Write-Host ("Server {0} Is Not Responding - Testing Of Port TCP/{1} Is Not Possible" -f $ComputerName.ToUpper(), $Port) -ForegroundColor Red
		Write-Host
		Break
	}

	If ([bool]($ComputerName -as [IPAddress])) {
		$IPAddress = $ComputerName

		$ErrorAction = $ErrorActionPreference
		$ErrorActionPreference = "SilentlyContinue"
		$ComputerName = [System.Net.Dns]::GetHostbyAddress($ComputerName).HostName
		$ErrorActionPreference = $ErrorAction

#		$RemoteServer = $ComputerName
	} Else {
		# Get first IPv4 addrress
		$IPAddress = [System.Net.Dns]::GetHostAddresses($ComputerName) | Select-Object -ExpandProperty IPAddressToString | Where-Object {$_ -match "\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"} | Sort-Object | Select-Object -first 1
		$ErrorAction = $ErrorActionPreference
		$ErrorActionPreference = "SilentlyContinue"
		$ComputerName = [System.Net.Dns]::GetHostbyAddress($IPAddress).HostName
		$ErrorActionPreference = $ErrorAction

#		$RemoteServer = $ComputerName
	}
	$PortTest = New-Object System.Net.Sockets.TcpClient
#	Write-Host "Server Name:"$ComputerName
#	Write-Host "IP Address :"$IPAddress
	Try {
		If ($IANAPorts -ne $Null) {
			$Result = $Null
			If ($Port -in 0..1023) {
				$Result = ("`nPort TCP/{0} - SYSTEM PORT - Assigned by Internet Engineering Task Force (IETF) [RFC6335]" -f $Port)
			}
			If ($Port -in 1024..49151) {
				$Result = ("`nPort TCP/{0} - USER PORT - Assigned by Internet Assigned Numbers Authority (IANA) [RFC6335]" -f $Port)
			}
			If ($Port -in 49152..65535) {
				$Result = ("`nPort TCP/{0} - DYNAMIC/PRIVATE PORT" -f $Port)
			}
			Write-Host $Result -ForegroundColor Blue
			$Result = $Null
			$IANAPorts | Where-Object {$_.Port -eq $Port} | ForEach {$Result = $Result+("Port {0}/{1} - {2} [{3}]`n" -f ($_.Protocol).ToUpper(), $_.Port, $_.Description, $_.ServiceName)}
			If ($Result -ne $Null) {
				Write-Host $Result -ForegroundColor Cyan
			}
		}
		$PortTest.Connect($ComputerName, $Port)
		Write-Host
		If ($ComputerName -eq $IPAddress) {
			Write-Host ("Connection To {0} On Port TCP/{1} Succeeded" -f $ComputerName, $Port) -ForegroundColor Green
		} Else {
			Write-Host ("Connection To {0} ({1}) On Port TCP/{2} Succeeded" -f $ComputerName, $IPAddress, $Port) -ForegroundColor Green
		}
	}
	Catch {
		Write-Host
		If ($ComputerName -eq $IPAddress) {
			Write-Host ("Connection To {0} On Port TCP/{1} Failed" -f $ComputerName, $Port) -ForegroundColor Red
		} Else {
			Write-Host ("Connection To {0} ({1}) On Port TCP/{2} Failed" -f $ComputerName, $IPAddress, $Port) -ForegroundColor Red
		}
	}
	Finally {
		$ErrorAction = $ErrorActionPreference
		$ErrorActionPreference = "SilentlyContinue"
		$PortTest.Dispose()
		$PortTest.Close()
		$ErrorActionPreference = $ErrorAction
		Write-Host
	}
}
# ---------------------------------------------------------------------------
Function Measure-EstimatedCompletion {
<#
	.SYNOPSIS
		The Measure-EstimatedCompletion function takes a starting time and percent completed
		and estimates the time it will complete.

	.DESCRIPTION
		The Measure-EstimatedCompletion function takes a starting time and percent completed
		and estimates the time it will complete. It can also estimate time of completion if
		the time of the percent is known but is sometime prior to running the function.

	.PARAMETER StartTime
		The starting time. Accepts any valid date time combination.

	.PARAMETER PercentComplete
		The percent completed

	.PARAMETER TimeAtPercent
		The time when process was at PercentComplete. Accepts any valid date time combination.
		Defaults to the time the function is called but can be set to a different time

	.EXAMPLE
		Measure-EstimatedCompletion -StartTime "2:14:21 pm" -PercentComplete 20

		Thursday, October 06, 2016 10:12:49 PM
		If the current time is Thursday, October 06, 2016 03:50:01 PM

	.EXAMPLE
		Measure-EstimatedCompletion -StartTime "2:14:21 pm" -PercentComplete 20 -TimeAtPercent "2:22:09 pm"
		Thursday, October 06, 2016 2:53:21 PM

		Notice the difference between this result and example 1

	.EXAMPLE
		Measure-EstimatedCompletion -StartTime "Thursday, October 06, 2016 14:14:21" -PercentComplete 81 -TimeAtPercent "2016/10/06 14:45:09"
		Thursday, October 06, 2016 2:52:22 PM

	.OUTPUTS
		Object

	.NOTES
		Written by Ryan Amsbury
		v1.1
#>
	Param(
		[Parameter(Mandatory=$True)]
		[DateTime]$StartTime,

		[Parameter(Mandatory=$True)]
		[Decimal]$PercentComplete,

		[Parameter(Mandatory=$False)]
		[DateTime]$TimeAtPercent = (Get-Date)
	)
	$ElapsedSec = ($TimeAtPercent - $StartTime).TotalSeconds
	$RemainSec = ($ElapsedSec / $PercentComplete) * (100 - $PercentComplete)
	$CompletionTime = [DateTime](Get-Date $TimeAtPercent).AddSeconds($RemainSec)
	$TimeElapsed = Get-ElapsedTime -Start $StartTime -End $TimeAtPercent -HighLevel NonZero -LowLevel Seconds
	$TimeElapsedCompletion = Get-ElapsedTime -Start $StartTime -End $CompletionTime -HighLevel NonZero -LowLevel Seconds
	$TimeDetails = New-Object PSObject
	Add-Member -InputObject $TimeDetails -MemberType NoteProperty -Name "StartTime" -Value $StartTime
	Add-Member -InputObject $TimeDetails -MemberType NoteProperty -Name "TimeAtPercent" -Value $TimeAtPercent
	Add-Member -InputObject $TimeDetails -MemberType NoteProperty -Name "CompletionTime" -Value $CompletionTime
	Add-Member -InputObject $TimeDetails -MemberType NoteProperty -Name "PercentComplete" -Value $PercentComplete
	Add-Member -InputObject $TimeDetails -MemberType NoteProperty -Name "TimeElapsed" -Value $TimeElapsed
	Add-Member -InputObject $TimeDetails -MemberType NoteProperty -Name "TimeElapsedCompletion" -Value $TimeElapsedCompletion
	$TimeDetails
}
# ---------------------------------------------------------------------------
# Function Join-Object starts here
Add-Type -TypeDefinition @'
	public enum JoinType {
		AllInLeft,
		OnlyIfInBoth,
		AllInBoth,
		AllInRight
	};
'@

Function AddItemProperties ($Item, $Properties, $Hash) {
	If ($Null -eq $Item) {
		Return
	}
	ForEach ($Property In $Properties) {
		$PropertyHash = $Property -as [HashTable]
		If ($Null -ne $PropertyHash) {
			$HashName = $PropertyHash["Name"] -as [String]
			If ($Null -eq $HashName) {
				Throw "There should be a string Name"
			}
			$Expression = $PropertyHash["Expression"] -as [ScriptBlock]
			If ($Null -eq $Expression) {
				Throw "There should be a ScriptBlock Expression"
			}
			$ExpressionValue = $Expression.Invoke($Item)
			$Hash[$HashName] = $ExpressionValue
		} Else {
			ForEach ($ItemProperty In $Item.PSObject.Properties) {
				If ($ItemProperty.Name -Like $Property) {
					$Hash[$ItemProperty.Name] = $ItemProperty.Value
				}
			}
		}
	}
}
Function WriteJoinObjectOutput($LeftItem, $RightItem, $LeftProperties, $RightProperties) {
	$Properties = @{}
	AddItemProperties $LeftItem $LeftProperties $Properties
	AddItemProperties $RightItem $RightProperties $Properties
	New-Object PSObject -Property $Properties
}
Function Join-Object {
	[CmdletBinding()]
	Param (
		# List to join with $Right
		[Parameter(Mandatory=$True)]
		[Object[]]
		$Left,

		# List to join with $Left
		[Parameter(Mandatory=$True)]
		[Object[]]
		$Right,

		# Must be a single property
		[Parameter(Mandatory = $True)]
		[String]
		$LeftJoinProperty,

		# Must be a single property
		[Parameter(Mandatory = $True)]
		[String]
		$RightJoinProperty,

		# Properties from $Left we want in the output.
		# Each property can:
		# - Be a plain property name like "Name"
		# - Contain wildcards like "*"
		# - Be a hashtable like @{Name="Product Name";Expression={$_.Name}}. Name is the output property name
		#   and Expression is the property value. The same syntax is available in select-object and it is
		#   important for join-object because joined lists could have a property with the same name
		[Parameter(Mandatory=$True)]
		[Object[]]
		$LeftProperties,

		# Properties from $Right we want in the output.
		# Like LeftProperties, each can be a plain name, wildcard or hashtable. See the LeftProperties comments.
		[Parameter(Mandatory=$True)]
		[Object[]]
		$RightProperties,

		# Type of join.
		# AllInLeft will have all elements from Left at least once in the output, and might appear more than once
		#     if the where clause is true for more than one element in right, Left elements with matches in Right are
		#     preceded by elements with no matches. This is equivalent to an outer left join (or simply left join)
		#     SQL statement.
		# AllInRight is similar to AllInLeft.
		# OnlyIfInBoth will cause all elements from Left to be placed in the output, only if there is at least one
		#     match in Right. This is equivalent to a SQL inner join (or simply join) statement.
		# AllInBoth will have all entries in right and left in the output. Specifically, it will have all entries
		#     in right with at least one match in left, followed by all entries in Right with no matches in left,
		#     followed by all entries in Left with no matches in Right.This is equivallent to a SQL full join.
		[Parameter(Mandatory=$False)]
		[JoinType]
		$Type = [JoinType]::OnlyIfInBoth
	)
	$LeftHash = New-Object System.Collections.Specialized.OrderedDictionary
	$RightHash = New-Object System.Collections.Specialized.OrderedDictionary
	# Hashtable keys can't be Null; we'll use any old object reference as a placeholder if needed.
	$NullKey = New-Object PSObject
	ForEach ($Item In $Left) {
		$Key = $Item.$LeftJoinProperty
		If ($Null -eq $Key) {
			$Key = $NullKey
		}
		$Bucket = $LeftHash[$Key]
		If ($Null -eq $Bucket) {
			$Bucket = New-Object System.Collections.ArrayList
			$LeftHash.Add($Key, $Bucket)
		}
		$Null = $Bucket.Add($Item)
	}
	ForEach ($Item In $Right) {
		$Key = $Item.$RightJoinProperty
		If ($Null -eq $Key) {
			$Key = $NullKey
		}
		$Bucket = $RightHash[$Key]
		If ($Null -eq $Bucket) {
			$Bucket = New-Object System.Collections.ArrayList
			$RightHash.Add($Key, $Bucket)
		}
		$Null = $Bucket.Add($Item)
	}
	ForEach ($Entry In $LeftHash.GetEnumerator()) {
		$Key = $Entry.Key
		$LeftBucket = $Entry.Value
		$RightBucket = $RightHash[$Key]
		If ($Null -eq $RightBucket) {
			If ($Type -eq [JoinType]::AllInLeft -or $Type -eq [JoinType]::AllInBoth) {
				ForEach ($LeftItem In $LeftBucket) {
					WriteJoinObjectOutput $LeftItem $Null $LeftProperties $RightProperties
				}
			}
		} Else {
			ForEach ($LeftItem In $LeftBucket) {
				ForEach ($RightItem In $RightBucket) {
					WriteJoinObjectOutput $LeftItem $RightItem $LeftProperties $RightProperties
				}
			}
		}
	}
	If ($Type -eq [JoinType]::AllInRight -or $Type -eq [JoinType]::AllInBoth) {
		ForEach ($Entry In $RightHash.GetEnumerator()) {
			$Key = $Entry.Key
			$RightBucket = $Entry.Value
			$LeftBucket = $LeftHash[$Key]
			If ($Null -eq $LeftBucket) {
				ForEach ($RightItem In $RightBucket) {
					WriteJoinObjectOutput $Null $RightItem $LeftProperties $RightProperties
				}
			}
		}
	}
}
# ---------------------------------------------------------------------------
Function ConvertTo-ScriptBlock  {
	# Function to Convert a String into a Script Block
	Param(
		[Parameter(
			Mandatory = $True,
			ParameterSetName = '',
			ValueFromPipeline = $True)]
			[String]$String
		)
	   $ScriptBlock = [ScriptBlock]::Create($String)
	   Return $ScriptBlock
}
# ---------------------------------------------------------------------------
Function RGBtoHex {
	# Convert color value from 3 Integers to RRR GGG BBB to Hex #RRGGBB
	[CmdletBinding()]
	Param (
		# RGB Red Integer
		[Parameter(Mandatory=$True)]
		[ValidateRange(0, 255)]
		[Int]$Red,

		# RGB Green Integer
		[Parameter(Mandatory=$True)]
		[ValidateRange(0, 255)]
		[Int]$Green,

		# RGB Blue Integer
		[Parameter(Mandatory = $True)]
		[ValidateRange(0, 255)]
		[Int]$Blue
	)
	$HexRed = ([System.Convert]::ToString($Red,16)).PadLeft(2,"0")
	$HexGreen = ([System.Convert]::ToString($Green,16)).PadLeft(2,"0")
	$HexBlue = ([System.Convert]::ToString($Blue,16)).PadLeft(2,"0")
	'#'+$HexRed+$HexGreen+$HexBlue
}
# ---------------------------------------------------------------------------
Function RGBtoBGR {
	# Convert color value from Hex #RRGGBB to Hex 0xBBGGRR
	Param ($TempColor)
	'0x'+$TempColor.SubString(5, 2)+$TempColor.SubString(3, 2)+$TempColor.SubString(1, 2)
}
# ---------------------------------------------------------------------------
Function BGRtoRGB {
	# Convert color value from Hex 0xBBGGRR to Hex #RRGGBB
	Param ($TempColor)
	$TempColor = ([System.Convert]::ToString($TempColor,16)).PadLeft(6,"0")
	'#'+$TempColor.SubString(4, 2)+$TempColor.SubString(2, 2)+$TempColor.SubString(0, 2)
}
# ---------------------------------------------------------------------------
Function IsNumeric {
	# Returns $True if $TempValue can be evaluated as a number even if quoted
	# Returns $False if $TempValue cannot be evaluated as a number
	Param ($TempValue)
	Add-Type -Assembly Microsoft.VisualBasic
	[Microsoft.VisualBasic.Information]::IsNumeric($TempValue)
}
# ---------------------------------------------------------------------------
Function Copy-File {
	Param (
		# Path: Specifies the path to the file(s) to copy.
		[Parameter()]
		[String[]]$Path,

		# Destination: Specifies the path to the new location. To rename a copied file, include the new name in the destination path.
		# Overwrites files of the same name in the destination
		[Parameter()]
		[String]$Destination
	)
	If ((Test-Path "$Path") -eq $True) {
		$SourceFiles = (Get-ChildItem -Path "$Path" | Select-Object FullName).FullName
		$Results = Copy-Item -Path "$Path" -Destination "$Destination" -Force -PassThru
		Start-Sleep -MilliSeconds 250
		ForEach ($Result In $Results) {
			If ((Test-Path -Path $Result.FullName) -eq $True) {
				Write-Host "Success"
				$Succeeded = $True
			} Else {
				Write-Host "Not Copied"
				$Result.FullName
				$Succeeded = $False
			}
		}
	}
}
# ---------------------------------------------------------------------------
Function Copy-Folder {
	Param (
		# Path: Specifies the path to the folder to copy.
		# Copies path recursively
		[Parameter()]
		[String]$Path,

		# Destination: Specifies the path to the new location. To rename a copied folder, include the new name in the destination path.
		[Parameter()]
		[String]$Destination
	)
	If ((Test-Path "$Path") -eq $True) {
		If ((Test-Path $Destination) -eq $True) {
			Get-ChildItem $Destination -Force | Remove-Item -Recurse -Force
			Remove-Item $Destination -Force
		}
		Copy-Item -Path "$Path" -Destination "$Destination" -Recurse -Force -Container -PassThru | Out-Null
		Start-Sleep -MilliSeconds 250
		$SourceFiles = (Get-ChildItem -Path $Path -Force -Recurse | Select-Object FullName).FullName -Replace([Regex]::Escape($Path), "") | Sort-Object
		$TargetFiles = (Get-ChildItem -Path $Destination -Force -Recurse | Select-Object FullName).FullName -Replace([Regex]::Escape($Destination), "") | Sort-Object
		$MissingFiles = $Null
		$MissingFiles = (Compare-Object -ReferenceObject $SourceFiles -DifferenceObject $TargetFiles -IncludeEqual | Where-Object {$_.SideIndicator -eq "<="}).InputObject
		If ($MissingFiles -eq $Null) {
			Write-Host "Success"
			$Succeeded = $True
		} Else {
			Write-Host "Not Copied"
			$MissingFiles
			$Succeeded = $False
		}
	}
}
# ---------------------------------------------------------------------------
Function Write-LogMessage {
<#
	Function to write activities to a Log file and / or the Host console

	Example 1: Writes an informational message to a log file and the host console using white text on dark gray
	Write-LogMessage -Path $LogFilePath -Message $MyMessage -ForegroundColor White -BackgroundColor DarkGray

	Example 2: Writes an error message to a log file and suppresses host console output
	Write-LogMessage -Path $LogFilePath -Message $MyMessage -IsError -Quiet

	Example 3: Writes an error message to a log file and the host console using red text (see below)
	Write-LogMessage -Path $LogFilePath -Message $MyMessage -IsSuccess -IsError -ForegroundColor Red

	NOTE
	Informational message is the default only when no other type is specified
	If more than one message type is included it will match the first one
	in the order: Custom Type / Error / Warning / Success
	rather than fail to write to the log
#>
	[CmdletBinding()]
	Param(
		# Message to display / log
		[Parameter(Mandatory=$True)]
		[String]$Message,

		# Path to log file
		[Parameter(Mandatory=$True)]
		[String]$Path,

		# Overwrite existing log, if it exists
		[Switch]$Overwrite,

		# Specify custom message type
		[String]$CustomType,

		# Display / log as ERROR
		[Switch]$IsError,

		# Display / log as WARNING
		[Switch]$IsWarning,

		# Display / log as SUCCESS
		[Switch]$IsSuccess,

		# Display using this ForegroundColor
		[String]$ForegroundColor = [Console]::ForegroundColor,

		# Display using this BackgroundColor
		[String]$BackgroundColor = [Console]::BackgroundColor,

		# Only send to log file, not host console
		[Switch]$Quiet
	)
	$DateTimeStamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
	$Message = ($Message -Replace "`r`n", " ").Trim()
	$LogEntry = $Null
	# Custom entry
	If ($CustomType -ne $Null) {
		$FixedType = Get-CenteredString $CustomType
		$LogEntry = ("[{0}] [{1}] {2}" -f $DateTimeStamp, $FixedType, $Message)
		If ($Quiet -eq $False) {
			Write-Host $LogEntry -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor
		}
	}
	# Informational entry (default)
	If ($IsWarning -eq $False -and $IsError -eq $False -and $IsSuccess -eq $False) {
		$LogEntry = ("[{0}] [INFORMATION] {1}" -f $DateTimeStamp, $Message)
		If ($Quiet -eq $False) {
			Write-Host $LogEntry -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor
		}
	}
	# IsError
	If ($IsError -eq $True) {
		$LogEntry = ("[{0}] [   ERROR   ] {1}" -f $DateTimeStamp, $Message)
		If ($Quiet -eq $False) {
			Write-Host $LogEntry -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor
		}
	}
	# IsWarning
	If ($IsWarning -eq $True) {
		$LogEntry = ("[{0}] [  WARNING  ] {1}" -f $DateTimeStamp, $Message)
		If ($Quiet -eq $False) {
			Write-Host $LogEntry -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor
		}
	}
	# IsSuccess
	If ($IsSuccess -eq $True) {
		$LogEntry = ("[{0}] [  SUCCESS  ] {1}" -f $DateTimeStamp, $Message)
		If ($Quiet -eq $False) {
			Write-Host $LogEntry -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor
		}
	}
	# Write to log file
	If ($Overwrite -eq $True) {
		Out-File -FilePath $Path -InputObject $LogEntry -Width 1024 -Encoding ASCII -Force
	} Else {
		Out-File -FilePath $Path -InputObject $LogEntry -Width 1024 -Encoding ASCII -Append -NoClobber -Force
	}
}
# ---------------------------------------------------------------------------
# Start of INI Functions - https://github.com/lipkau/PsIni
# Get-Command | Where-Object {$_.CommandType -eq "Function" -and $_.Name -like "*-Ini*" -and $_.Source -eq ""} | Format-Table Name -AutoSize
#    Add-IniComment
#    Convert-IniCommentToEntry
#    Convert-IniEntryToComment
#    Get-IniContent
#    Out-IniFile
#    Remove-IniComment
#    Remove-IniEntry
#    Set-IniContent
# ---------------------------------------------------------------------------
Function Add-IniComment {
	<#
	.Synopsis
		Comments out specified content of an INI file
	.Description
		Comments out specified keys in all sections or certain sections.
		The ini source can be specified by a file or piped in by the result of Get-IniContent.
		The modified content is returned as a ordered dictionary hashtable and can be piped to a file with Out-IniFile.
	.Notes
		Author		: Sean Seymour <seanjseymour@gmail.com> based on work by Oliver Lipkau <oliver@lipkau.net>
		Source		: https://github.com/lipkau/PsIni
					  http://gallery.technet.microsoft.com/scriptcenter/ea40c1ef-c856-434b-b8fb-ebd7a76e8d91
		Version		: 1.0.0 - 2016/08/18 - SS - Initial release
					: 1.0.1 - 2016/12/29 - SS - Removed need for delimiters by making Sections and Keys string arrays.
		#Requires -Version 2.0
	.Inputs
		System.String
		System.Collections.IDictionary
	.Outputs
		System.Collections.Specialized.OrderedDictionary
	.Example
		$ini = Add-IniComment -FilePath "C:\myinifile.ini" -Sections 'Printers' -Keys 'Headers','Footers'
		-----------
		Description
		Reads in the INI File c:\myinifile.ini, comments out any keys named 'Headers' or 'Footers' in the [Printers] section, and saves the modified ini to $ini.
	.Example
		Add-IniComment -FilePath "C:\myinifile.ini" -Sections 'Terminals','Monitors' -Keys 'Updated' | Out-IniFile "C:\myinifile.ini" -Force
		-----------
		Description
		Reads in the INI File c:\myinifile.ini and comments out any keys named 'Updated' in the [Terminals] and [Monitors] sections.
		The ini is then piped to Out-IniFile to write the INI File to c:\myinifile.ini. If the file is already present it will be overwritten.
	.Example
		Get-IniContent "C:\myinifile.ini" | Add-IniComment -Keys 'Headers' | Out-IniFile "C:\myinifile.ini" -Force
		-----------
		Description
		Reads in the INI File c:\myinifile.ini using Get-IniContent, which is then piped to Add-IniComment to comment out any 'Headers' keys in any
		section. The ini is then piped to Out-IniFile to write the INI File to c:\myinifile.ini. If the file is already present it will be overwritten.
	.Example
		Get-IniContent "C:\myinifile.ini" | Add-IniComment -Keys 'Updated' -Sections '_' | Out-IniFile "C:\myinifile.ini" -Force
		-----------
		Description
		Reads in the INI File c:\myinifile.ini using Get-IniContent, which is then piped to Add-IniComment to comment out any 'Updated' keys that
		are orphaned, i.e. not specifically in a section. The ini is then piped to Out-IniFile to write the INI File to c:\myinifile.ini.
	.Link
		Get-IniContent
		Out-IniFile
	#>
	[CmdletBinding(DefaultParameterSetName = "File")]
	[OutputType(
		[System.Collections.Specialized.OrderedDictionary]
	)]
	Param
	(
		# Specifies the path to the input file.
		[Parameter( Position = 0, Mandatory, ParameterSetName = "File" )]
		[ValidateNotNullOrEmpty()]
		[String]
		$FilePath,

		# Specifies the Hashtable to be modified. Enter a variable that contains the objects or type a command or expression that gets the objects.
		[Parameter( Mandatory, ValueFromPipeline, ParameterSetName = "Object" )]
		[ValidateNotNullOrEmpty()]
		[System.Collections.IDictionary]
		$InputObject,

		# String array of one or more keys to limit the changes to, separated by a comma. Optional.
		[Parameter( Mandatory )]
		[ValidateNotNullOrEmpty()]
		[String[]]
		$Keys,

		# Specify what character should be used to comment out entries.
		# Note: This parameter is a char array to maintain compatibility with the other functions.
		# However, only the first character is used to comment out entries.
		# Default: ";"
		[char[]]
		$CommentChar = @(";"),

		# String array of one or more sections to limit the changes to, separated by a comma.
		# Surrounding section names with square brackets is not necessary but is supported.
		# Ini keys that do not have a defined section can be modified by specifying '_' (underscore) for the section.
		[ValidateNotNullOrEmpty()]
		[String[]]
		$Sections
	)

	Begin {
		Write-Debug "PsBoundParameters:"
		$PSBoundParameters.GetEnumerator() | ForEach-Object { Write-Debug $_ }
		if ($PSBoundParameters['Debug']) {
			$DebugPreference = 'Continue'
		}
		Write-Debug "DebugPreference: $DebugPreference"

		Write-Verbose "$($MyInvocation.MyCommand.Name):: Function started"
	}

	Process {
		# Get the ini from either a file or object passed in.
		if ($PSCmdlet.ParameterSetName -eq 'File') { $content = Get-IniContent $FilePath }
		if ($PSCmdlet.ParameterSetName -eq 'Object') { $content = $InputObject }

		# Specific section(s) were requested.
		if ($Sections) {
			foreach ($section in $Sections) {
				# Get rid of whitespace and section brackets.
				$section = $section.Trim() -replace '[][]', ''

				Write-Debug ("Processing '{0}' section." -f $section)

				foreach ($key in $Keys) {
					Write-Debug ("Processing '{0}' key." -f $key)

					$key = $key.Trim()

					if ($content[$section]) {
						$currentValue = $content[$section][$key]
					}
					else {
						Write-Verbose ("$($MyInvocation.MyCommand.Name):: '{0}' section does not exist." -f $section)
						# Break out of the loop after this, because we don't want to check further keys for this non-existent section.
						break
					}

					if ($currentValue) {
						Convert-IniEntryToComment $content $key $section $CommentChar
					}
					else {
						Write-Verbose ("$($MyInvocation.MyCommand.Name):: '[{0}][{1}]' does not exist." -f $section, $key)
					}
				}
			}
		}
		else {
			# No section supplied, go through the entire ini since changes apply to all sections.
			foreach ($item in $content.GetEnumerator()) {
				$section = $item.key
				Write-Debug ("Processing '{0}' section." -f $section)

				foreach ($key in $Keys) {
					$key = $key.Trim()
					Write-Debug ("Processing '{0}' key." -f $key)

					if ($content[$section][$key]) {
						Convert-IniEntryToComment $content $key $section $CommentChar
					}
					else {
						Write-Verbose ("$($MyInvocation.MyCommand.Name):: '[{0}][{1}]' does not exist." -f $section, $key)
					}
				}
			}
		}

		Write-Output $content
	}
	End {
		Write-Verbose "$($MyInvocation.MyCommand.Name):: Function ended"
	}
}
# ---------------------------------------------------------------------------
Function Convert-IniCommentToEntry {
	<#
	.SYNOPSIS
		Internal module function to remove the old comment then insert a new key/value pair at the old location with the previous comment's value.
	#>
	param ($content, $key, $section, $commentChar)

	$index = 0
	$commentFound = $false

	$commentRegex = "^([$($commentChar -join '')]$key.*)$"
	Write-Debug ("commentRegex is {0}." -f $commentRegex)

	foreach ($entry in $content[$section].GetEnumerator()) {
		Write-Debug ("Uncomment looking at key '{0}' with value '{1}'." -f $entry.key, $entry.value)

		if ($entry.key.StartsWith('Comment') -and $entry.value -match $commentRegex) {
			Write-Verbose ("$($MyInvocation.MyCommand.Name):: Uncommenting '{0}' in {1} section." -f $entry.value, $section)
			$oldKey = $entry.key
			$split = $entry.value.Split("=")

			if ($split.Length -ge 2) {
				$newValue = $split[1].Trim()
			}
			else {
				# If the split did not result in 2+ items, it was not in the key=value form.
				# So just uncomment the key, as there is no value. It will result in a "key=" formatted output.
				$newValue = ''
			}

			# Break out once a match is found. If there are multiple commented out keys
			# with the same name, we can't add them anyway since it's a hash.
			$commentFound = $true
			break
		}
		$index++
	}

	if ($commentFound) {
		if ($content[$section][$key]) {
			Write-Verbose ("$($MyInvocation.MyCommand.Name):: Unable to uncomment '{0}' key in {1} section as there is already a key with that name." -f $key, $section)
		}
		else {
			Write-Debug ("Removing '{0}'." -f $oldKey)
			$content[$section].Remove($oldKey)
			Write-Debug ("Inserting [{0}][{1}] = {2} at index {3}." -f $section, $key, $newValue, $index)
			$content[$section].Insert($index, $key, $newValue)
		}
	}
	else {
		Write-Verbose ("$($MyInvocation.MyCommand.Name):: Did not find '{0}' key in {1} section to uncomment." -f $key, $section)
	}
}
# ---------------------------------------------------------------------------
Function Convert-IniEntryToComment {
	<#
	.SYNOPSIS
		Internal module function to remove the old key then insert a new one at the old location in the comment style used by Get-IniContent.
	#>
	param ($content, $key, $section, $commentChar)

	# Comments in Get-IniContent start with 1, not zero.
	$commentCount = 1

	foreach ($entry in $content[$section].GetEnumerator()) {
		if ($entry.key.StartsWith('Comment')) {
			$commentCount++
		}
	}

	Write-Debug ("commentCount is {0}." -f $commentCount)

	$desiredValue = $content[$section][$key]

	# Don't attempt to comment out non-existent keys.
	if ($desiredValue) {
		Write-Debug ("desiredValue is {0}." -f $desiredValue)

		$commentKey = 'Comment' + $commentCount
		Write-Debug ("commentKey is {0}." -f $commentKey)

		$commentValue = $commentChar[0] + $key + '=' + $desiredValue
		Write-Debug ("commentValue is {0}." -f $commentValue)

		# Thanks to http://stackoverflow.com/a/35731603/844937. However, that solution is case sensitive.
		# Tried $index = $($content[$section].keys).IndexOf($key, [StringComparison]"CurrentCultureIgnoreCase")
		# but it said there were no IndexOf overloads with two arguments. So if we get a -1 (not found),
		# use a variation on http://stackoverflow.com/a/34930231/844937 to search for a case-insensitive match.
		$sectionKeys = $($content[$section].keys)
		$index = $sectionKeys.IndexOf($key)
		Write-Debug ("Index of {0} is {1}." -f $key, $index)

		if ($index -eq -1) {
			$i = 0
			foreach ($sectionKey in $sectionKeys) {
				if ($sectionKey -match $key) {
					$index = $i
					Write-Debug ("Index updated to {0}." -f $index)
					break
				}
				else {
					$i++
				}
			}
		}

		if ($index -ge 0) {
			Write-Verbose ("$($MyInvocation.MyCommand.Name):: Commenting out {0} key in {1} section." -f $key, $section)
			$content[$section].Remove($key)
			$content[$section].Insert($index, $commentKey, $commentValue)
		}
		else {
			Write-Verbose ("$($MyInvocation.MyCommand.Name):: Could not find '{0}' key in {1} section to comment out." -f $key, $section)
		}
	}
}
# ---------------------------------------------------------------------------
Function Get-IniContent {
	<#
	.Synopsis
		Gets the content of an INI file
	.Description
		Gets the content of an INI file and returns it as a hashtable
	.Notes
		Author		: Oliver Lipkau <oliver@lipkau.net>
		Source		: https://github.com/lipkau/PsIni
					  http://gallery.technet.microsoft.com/scriptcenter/ea40c1ef-c856-434b-b8fb-ebd7a76e8d91
		Version		: 1.0.0 - 2010/03/12 - OL - Initial release
					  1.0.1 - 2014/12/11 - OL - Typo (Thx SLDR)
											  Typo (Thx Dave Stiff)
					  1.0.2 - 2015/06/06 - OL - Improvment to switch (Thx Tallandtree)
					  1.0.3 - 2015/06/18 - OL - Migrate to semantic versioning (GitHub issue#4)
					  1.0.4 - 2015/06/18 - OL - Remove check for .ini extension (GitHub Issue#6)
					  1.1.0 - 2015/07/14 - CB - Improve round-tripping and be a bit more liberal (GitHub Pull #7)
										   OL - Small Improvments and cleanup
					  1.1.1 - 2015/07/14 - CB - changed .outputs section to be OrderedDictionary
					  1.1.2 - 2016/08/18 - SS - Add some more verbose outputs as the ini is parsed,
												allow non-existent paths for new ini handling,
												test for variable existence using local scope,
												added additional debug output.
		#Requires -Version 2.0
	.Inputs
		System.String
	.Outputs
		System.Collections.Specialized.OrderedDictionary
	.Example
		$FileContent = Get-IniContent "C:\myinifile.ini"
		-----------
		Description
		Saves the content of the c:\myinifile.ini in a hashtable called $FileContent
	.Example
		$inifilepath | $FileContent = Get-IniContent
		-----------
		Description
		Gets the content of the ini file passed through the pipe into a hashtable called $FileContent
	.Example
		C:\PS>$FileContent = Get-IniContent "c:\settings.ini"
		C:\PS>$FileContent["Section"]["Key"]
		-----------
		Description
		Returns the key "Key" of the section "Section" from the C:\settings.ini file
	.Link
		Out-IniFile
	#>

	[CmdletBinding()]
	[OutputType(
		[System.Collections.Specialized.OrderedDictionary]
	)]
	Param(
		# Specifies the path to the input file.
		[ValidateNotNullOrEmpty()]
		[Parameter( Mandatory, ValueFromPipeline )]
		[string]
		$FilePath,

		# Specify what characters should be describe a comment.
		# Lines starting with the characters provided will be rendered as comments.
		# Default: ";"
		[char[]]
		$CommentChar = @(";"),

		# Remove lines determined to be comments from the resulting dictionary.
		[switch]
		$IgnoreComments
	)

	Begin {
		Write-Debug "PsBoundParameters:"
		$PSBoundParameters.GetEnumerator() | ForEach-Object { Write-Debug $_ }
		if ($PSBoundParameters['Debug']) {
			$DebugPreference = 'Continue'
		}
		Write-Debug "DebugPreference: $DebugPreference"

		Write-Verbose "$($MyInvocation.MyCommand.Name):: Function started"

		$commentRegex = "^([$($CommentChar -join '')].*)$"

		Write-Debug ("commentRegex is {0}." -f $commentRegex)
	}

	Process {
		Write-Verbose "$($MyInvocation.MyCommand.Name):: Processing file: $Filepath"

		$ini = New-Object System.Collections.Specialized.OrderedDictionary([System.StringComparer]::OrdinalIgnoreCase)

		if (!(Test-Path $Filepath)) {
			Write-Verbose ("Warning: `"{0}`" was not found." -f $Filepath)
			Write-Output $ini
		}

		$commentCount = 0
		switch -regex -file $FilePath {
			"^\s*\[(.+)\]\s*$" {
				# Section
				$section = $matches[1]
				Write-Verbose "$($MyInvocation.MyCommand.Name):: Adding section : $section"
				$ini[$section] = New-Object System.Collections.Specialized.OrderedDictionary([System.StringComparer]::OrdinalIgnoreCase)
				$CommentCount = 0
				continue
			}
			$commentRegex {
				# Comment
				if (!$IgnoreComments) {
					if (!(test-path "variable:local:section")) {
						$section = $script:NoSection
						$ini[$section] = New-Object System.Collections.Specialized.OrderedDictionary([System.StringComparer]::OrdinalIgnoreCase)
					}
					$value = $matches[1]
					$CommentCount++
					Write-Debug ("Incremented CommentCount is now {0}." -f $CommentCount)
					$name = "Comment" + $CommentCount
					Write-Verbose "$($MyInvocation.MyCommand.Name):: Adding $name with value: $value"
					$ini[$section][$name] = $value
				}
				else {
					Write-Debug ("Ignoring comment {0}." -f $matches[1])
				}

				continue
			}
			"(.+?)\s*=\s*(.*)" {
				# Key
				if (!(test-path "variable:local:section")) {
					$section = $script:NoSection
					$ini[$section] = New-Object System.Collections.Specialized.OrderedDictionary([System.StringComparer]::OrdinalIgnoreCase)
				}
				$name, $value = $matches[1..2]
				Write-Verbose "$($MyInvocation.MyCommand.Name):: Adding key $name with value: $value"
				$ini[$section][$name] = $value
				continue
			}
		}
		Write-Verbose "$($MyInvocation.MyCommand.Name):: Finished Processing file: $FilePath"
		Write-Output $ini
	}

	End {
		Write-Verbose "$($MyInvocation.MyCommand.Name):: Function ended"
	}
}
# ---------------------------------------------------------------------------
Function Out-IniFile {
	<#
	.Synopsis
		Write hash content to INI file
	.Description
		Write hash content to INI file
	.Notes
		Author      : Oliver Lipkau <oliver@lipkau.net>
		Blog        : http://oliver.lipkau.net/blog/
		Source      : https://github.com/lipkau/PsIni
					  http://gallery.technet.microsoft.com/scriptcenter/ea40c1ef-c856-434b-b8fb-ebd7a76e8d91
		Version     : 1.0.0 - 2010/03/12 - OL - Initial release
					  1.0.1 - 2012/04/19 - OL - Bugfix/Added example to help (Thx Ingmar Verheij)
					  1.0.2 - 2014/12/11 - OL - Improved handling for missing output file (Thx SLDR)
					  1.0.3 - 2014/01/06 - CB - removed extra \r\n at end of file
					  1.0.4 - 2015/06/06 - OL - Typo (Thx Dominik)
					  1.0.5 - 2015/06/18 - OL - Migrate to semantic versioning (GitHub issue#4)
					  1.0.6 - 2015/06/18 - OL - Remove check for .ini extension (GitHub Issue#6)
					  1.1.0 - 2015/07/14 - CB - Improve round-tripping and be a bit more liberal (GitHub Pull #7)
										   OL - Small Improvments and cleanup
					  1.1.2 - 2015/10/14 - OL - Fixed parameters in nested function
					  1.1.3 - 2016/08/18 - SS - Moved the get/create code for $FilePath to the Process block since it
												overwrites files piped in by other functions when it's in the Begin block,
												added additional debug output.
					  1.1.4 - 2016/12/29 - SS - Support output of a blank ini, e.g. if all sections got removed. This
												required removing [ValidateNotNullOrEmpty()] from InputObject
		#Requires -Version 2.0
	.Inputs
		System.String
		System.Collections.IDictionary
	.Outputs
		System.IO.FileSystemInfo
	 .Parameter Encoding
	 .Parameter Force
	 .Parameter PassThru
	 .Parameter Loose
	.Example
		Out-IniFile $IniVar "C:\myinifile.ini"
		-----------
		Description
		Saves the content of the $IniVar Hashtable to the INI File c:\myinifile.ini
	.Example
		$IniVar | Out-IniFile "C:\myinifile.ini" -Force
		-----------
		Description
		Saves the content of the $IniVar Hashtable to the INI File c:\myinifile.ini and overwrites the file if it is already present
	.Example
		$file = Out-IniFile $IniVar "C:\myinifile.ini" -PassThru
		-----------
		Description
		Saves the content of the $IniVar Hashtable to the INI File c:\myinifile.ini and saves the file into $file
	.Example
		$Category1 = @{�Key1�=�Value1�;�Key2�=�Value2�}
		$Category2 = @{�Key1�=�Value1�;�Key2�=�Value2�}
		$NewINIContent = @{�Category1�=$Category1;�Category2�=$Category2}
		Out-IniFile -InputObject $NewINIContent -FilePath "C:\MyNewFile.ini"
		-----------
		Description
		Creating a custom Hashtable and saving it to C:\MyNewFile.ini
	.Link
		Get-IniContent
	#>

	[CmdletBinding()]
	[OutputType(
		[System.IO.FileSystemInfo]
	)]
	Param(
		# Adds the output to the end of an existing file, instead of replacing the file contents.
		[switch]
		$Append,

		# Specifies the file encoding. The default is UTF8.
		#
		# Valid values are:
		# -- ASCII:  Uses the encoding for the ASCII (7-bit) character set.
		# -- BigEndianUnicode:  Encodes in UTF-16 format using the big-endian byte order.
		# -- Byte:   Encodes a set of characters into a sequence of bytes.
		# -- String:  Uses the encoding type for a string.
		# -- Unicode:  Encodes in UTF-16 format using the little-endian byte order.
		# -- UTF7:   Encodes in UTF-7 format.
		# -- UTF8:  Encodes in UTF-8 format.
		[ValidateSet("Unicode", "UTF7", "UTF8", "ASCII", "BigEndianUnicode", "Byte", "String")]
		[Parameter()]
		[string]
		$Encoding = "UTF8",

		# Specifies the path to the output file.
		[ValidateNotNullOrEmpty()]
		[ValidateScript( {Test-Path $_ -IsValid} )]
		[Parameter( Position = 0, Mandatory )]
		[string]
		$FilePath,

		# Allows the cmdlet to overwrite an existing read-only file. Even using the Force parameter, the cmdlet cannot override security restrictions.
		[switch]
		$Force,

		# Specifies the Hashtable to be written to the file. Enter a variable that contains the objects or type a command or expression that gets the objects.
		[Parameter( Mandatory, ValueFromPipeline )]
		[System.Collections.IDictionary]
		$InputObject,

		# Passes an object representing the location to the pipeline. By default, this cmdlet does not generate any output.
		[switch]
		$Passthru,

		# Adds spaces around the equal sign when writing the key = value
		[switch]
		$Loose
	)

	Begin {
		Write-Debug "PsBoundParameters:"
		$PSBoundParameters.GetEnumerator() | ForEach-Object { Write-Debug $_ }
		if ($PSBoundParameters['Debug']) {
			$DebugPreference = 'Continue'
		}
		Write-Debug "DebugPreference: $DebugPreference"

		Write-Verbose "$($MyInvocation.MyCommand.Name):: Function started"

		function Out-Keys {
			param(
				[ValidateNotNullOrEmpty()]
				[Parameter( Mandatory, ValueFromPipeline )]
				[System.Collections.IDictionary]
				$InputObject,

				[ValidateSet("Unicode", "UTF7", "UTF8", "ASCII", "BigEndianUnicode", "Byte", "String")]
				[Parameter( Mandatory )]
				[string]
				$Encoding = "UTF8",

				[ValidateNotNullOrEmpty()]
				[ValidateScript( {Test-Path $_ -IsValid})]
				[Parameter( Mandatory, ValueFromPipelineByPropertyName )]
				[string]
				$Path,

				[Parameter( Mandatory )]
				$Delimiter,

				[Parameter( Mandatory )]
				$MyInvocation
			)

			Process {
				if (!($InputObject.get_keys())) {
					Write-Warning ("No data found in '{0}'." -f $FilePath)
				}
				Foreach ($key in $InputObject.get_keys()) {
					if ($key -match "^Comment\d+") {
						Write-Verbose "$($MyInvocation.MyCommand.Name):: Writing comment: $key"
						Add-Content -Value "$($InputObject[$key])" -Encoding $Encoding -Path $Path
					}
					else {
						Write-Verbose "$($MyInvocation.MyCommand.Name):: Writing key: $key"
						Add-Content -Value "$key$delimiter$($InputObject[$key])" -Encoding $Encoding -Path $Path
					}
				}
			}
		}

		$delimiter = '='
		if ($Loose) {
			$delimiter = ' = '
		}

		# Splatting Parameters
		$parameters = @{
			Encoding = $Encoding;
			Path     = $FilePath
		}

	}

	Process {
		if ($Append) {
			Write-Debug ("Appending to '{0}'." -f $FilePath)
			$outfile = Get-Item $FilePath
		}
		else {
			Write-Debug ("Creating new file '{0}'." -f $FilePath)
			$outFile = New-Item -ItemType file -Path $Filepath -Force:$Force
		}

		if (!(Test-Path $outFile.FullName)) {Throw "Could not create File"}

		Write-Verbose "$($MyInvocation.MyCommand.Name):: Writing to file: $Filepath"
		foreach ($i in $InputObject.get_keys()) {
			if (!($InputObject[$i].GetType().GetInterface('IDictionary'))) {
				#Key value pair
				Write-Verbose "$($MyInvocation.MyCommand.Name):: Writing key: $i"
				Add-Content -Value "$i$delimiter$($InputObject[$i])" @parameters

			}
			elseif ($i -eq $script:NoSection) {
				#Key value pair of NoSection
				Out-Keys $InputObject[$i] `
					@parameters `
					-Delimiter $delimiter `
					-MyInvocation $MyInvocation
			}
			else {
				#Sections
				Write-Verbose "$($MyInvocation.MyCommand.Name):: Writing Section: [$i]"

				# Only write section, if it is not a dummy ($script:NoSection)
				if ($i -ne $script:NoSection) { Add-Content -Value "`n[$i]" @parameters }

				if ( $InputObject[$i].Count) {
					Out-Keys $InputObject[$i] `
						@parameters `
						-Delimiter $delimiter `
						-MyInvocation $MyInvocation
				}

			}
		}
		Write-Verbose "$($MyInvocation.MyCommand.Name):: Finished Writing to file: $FilePath"
	}

	End {
		if ($PassThru) {
			Write-Debug ("Returning file due to PassThru argument.")
			Write-Output (Get-Item $outFile)
		}
		Write-Verbose "$($MyInvocation.MyCommand.Name):: Function ended"
	}
}
# ---------------------------------------------------------------------------
Function Remove-IniComment {
	<#
	.Synopsis
		Uncomments out specified content of an INI file
	.Description
		Uncomments out specified keys in all sections or certain sections.
		The ini source can be specified by a file or piped in by the result of Get-IniContent.
		The modified content is returned as a ordered dictionary hashtable and can be piped to a file with Out-IniFile.
	.Notes
		Author		: Sean Seymour <seanjseymour@gmail.com> based on work by Oliver Lipkau <oliver@lipkau.net>
		Source		: https://github.com/lipkau/PsIni
					  http://gallery.technet.microsoft.com/scriptcenter/ea40c1ef-c856-434b-b8fb-ebd7a76e8d91
		Version		: 1.0.0 - 2016/08/18 - SS - Initial release
					: 1.0.1 - 2016/12/29 - SS - Removed need for delimiters by making Sections and Keys string arrays.
		#Requires -Version 2.0
	.Inputs
		System.String
		System.Collections.IDictionary
	.Outputs
		System.Collections.Specialized.OrderedDictionary
	.Example
		$ini = Remove-IniComment -FilePath "C:\myinifile.ini" -Sections 'Printers' -Keys 'Headers'
		-----------
		Description
		Reads in the INI File c:\myinifile.ini, uncomments out any keys named 'Headers' in the [Printers] section, and saves the modified ini to $ini.
	.Example
		Remove-IniComment -FilePath "C:\myinifile.ini" -Sections 'Terminals','Monitors' -Keys 'Updated' | Out-IniFile "C:\myinifile.ini" -Force
		-----------
		Description
		Reads in the INI File c:\myinifile.ini and uncomments out any keys named 'Updated' in the [Terminals] and [Monitors] sections.
		The ini is then piped to Out-IniFile to write the INI File to c:\myinifile.ini. If the file is already present it will be overwritten.
	.Example
		Get-IniContent "C:\myinifile.ini" | Remove-IniComment -Keys 'Headers' | Out-IniFile "C:\myinifile.ini" -Force
		-----------
		Description
		Reads in the INI File c:\myinifile.ini using Get-IniContent, which is then piped to Remove-IniComment to uncomment any 'Headers' keys in any
		section. The ini is then piped to Out-IniFile to write the INI File to c:\myinifile.ini. If the file is already present it will be overwritten.
	.Example
		Get-IniContent "C:\myinifile.ini" | Remove-IniComment -Keys 'Updated' -Sections '_' | Out-IniFile "C:\myinifile.ini" -Force
		-----------
		Description
		Reads in the INI File c:\myinifile.ini using Get-IniContent, which is then piped to Remove-IniComment to uncomment any 'Updated' keys that
		are orphaned, i.e. not specifically in a section. The ini is then piped to Out-IniFile to write the INI File to c:\myinifile.ini.
	.Link
		Get-IniContent
		Out-IniFile
	#>

	[CmdletBinding( DefaultParameterSetName = "File" )]
	[OutputType(
		[System.Collections.IDictionary]
	)]
	Param
	(
		# Specifies the path to the input file.
		[Parameter( Position = 0,  Mandatory, ParameterSetName = "File" )]
		[ValidateNotNullOrEmpty()]
		[String]
		$FilePath,

		# Specifies the Hashtable to be modified. Enter a variable that contains the objects or type a command or expression that gets the objects.
		[Parameter( Mandatory, ValueFromPipeline, ParameterSetName = "Object" )]
		[ValidateNotNullOrEmpty()]
		[System.Collections.IDictionary]
		$InputObject,

		# String array of one or more keys to limit the changes to, separated by a comma. Optional.
		[Parameter(Mandatory)]
		[ValidateNotNullOrEmpty()]
		[String[]]
		$Keys,

		# Specify what characters should be describe a comment.
		# Lines starting with the characters provided will be rendered as comments.
		# Default: ";"
		[char[]]
		$CommentChar = @(";"),

		# String array of one or more sections to limit the changes to, separated by a comma.
		# Surrounding section names with square brackets is not necessary but is supported.
		# Ini keys that do not have a defined section can be modified by specifying '_' (underscore) for the section.
		[ValidateNotNullOrEmpty()]
		[String[]]
		$Sections
	)

	Begin {
		Write-Debug "PsBoundParameters:"
		$PSBoundParameters.GetEnumerator() | ForEach-Object { Write-Debug $_ }
		if ($PSBoundParameters['Debug']) {
			$DebugPreference = 'Continue'
		}
		Write-Debug "DebugPreference: $DebugPreference"

		Write-Verbose "$($MyInvocation.MyCommand.Name):: Function started"
	}
	# Uncomment out the specified keys in the list, either in the specified section or in all sections.
	Process {
		# Get the ini from either a file or object passed in.
		if ($PSCmdlet.ParameterSetName -eq 'File') { $content = Get-IniContent $FilePath }
		if ($PSCmdlet.ParameterSetName -eq 'Object') { $content = $InputObject }

		# Specific section(s) were requested.
		if ($Sections) {
			foreach ($section in $Sections) {
				# Get rid of whitespace and section brackets.
				$section = $section.Trim() -replace '[][]', ''

				Write-Debug ("Processing '{0}' section." -f $section)

				foreach ($key in $Keys) {
					Write-Debug ("Processing '{0}' key." -f $key)

					$key = $key.Trim()

					if (!($content[$section])) {
						Write-Verbose ("$($MyInvocation.MyCommand.Name):: '{0}' section does not exist." -f $section)
						# Break out of the loop after this, because we don't want to check further keys for this non-existent section.
						break
					}
					# Since this is a comment, we need to search through all the CommentX keys in this section.
					# That's handled in the Convert-IniCommentToEntry function, so don't bother checking key existence here.
					Convert-IniCommentToEntry $content $key $section $CommentChar
				}
			}
		}
		else {
			# No section supplied, go through the entire ini since changes apply to all sections.
			foreach ($item in $content.GetEnumerator()) {
				$section = $item.key
				Write-Debug ("Processing '{0}' section." -f $section)

				foreach ($key in $Keys) {
					$key = $key.Trim()
					Write-Debug ("Processing '{0}' key." -f $key)
					Convert-IniCommentToEntry $content $key $section $CommentChar
				}
			}
		}

		Write-Output $content
	}
	End {
		Write-Verbose "$($MyInvocation.MyCommand.Name):: Function ended"
	}
}
# ---------------------------------------------------------------------------
Function Remove-IniEntry {
	<#
	.Synopsis
		Removes specified content from an INI file
	.Description
		Removes specified keys in all sections or certain sections.
		The ini source can be specified by a file or piped in by the result of Get-IniContent.
		The modified content is returned as a ordered dictionary hashtable and can be piped to a file with Out-IniFile.
	.Notes
		Author		: Sean Seymour <seanjseymour@gmail.com> based on work by Oliver Lipkau <oliver@lipkau.net>
		Source		: https://github.com/lipkau/PsIni
					  http://gallery.technet.microsoft.com/scriptcenter/ea40c1ef-c856-434b-b8fb-ebd7a76e8d91
		Version		: 1.0.0 - 2016/08/18 - SS - Initial release
					: 1.0.1 - 2016/12/29 - SS - Removed need for delimiters by making Sections and Keys string arrays.
		#Requires -Version 2.0
	.Inputs
		System.String
		System.Collections.IDictionary
	.Outputs
		System.Collections.Specialized.OrderedDictionary
	.Example
		$ini = Remove-IniEntry -FilePath "C:\myinifile.ini" -Sections 'Printers' -Keys 'Headers','Version'
		-----------
		Description
		Reads in the INI File c:\myinifile.ini, removes any keys named 'Headers' or 'Version' in the [Printers] section, and saves the modified ini to $ini.
	.Example
		Remove-IniEntry -FilePath "C:\myinifile.ini" -Sections 'Terminals','Monitors' -Keys 'Updated' | Out-IniFile "C:\myinifile.ini" -Force
		-----------
		Description
		Reads in the INI File c:\myinifile.ini and removes any keys named 'Updated' in the [Terminals] and [Monitors] sections.
		The ini is then piped to Out-IniFile to write the INI File to c:\myinifile.ini. If the file is already present it will be overwritten.
	.Example
		Get-IniContent "C:\myinifile.ini" | Remove-IniEntry -Keys 'Headers' | Out-IniFile "C:\myinifile.ini" -Force
		-----------
		Description
		Reads in the INI File c:\myinifile.ini using Get-IniContent, which is then piped to Remove-IniEntry to remove any 'Headers' keys in any
		section. The ini is then piped to Out-IniFile to write the INI File to c:\myinifile.ini. If the file is already present it will be overwritten.
	.Example
		Get-IniContent "C:\myinifile.ini" | Remove-IniEntry -Sections 'Terminals' | Out-IniFile "C:\myinifile.ini" -Force
		-----------
		Description
		Reads in the INI File c:\myinifile.ini using Get-IniContent, which is then piped to Remove-IniEntry to remove the 'Terminals' section.
		The ini is then piped to Out-IniFile to write the INI File to c:\myinifile.ini. If the file is already present it will be overwritten.
	.Example
		Get-IniContent "C:\myinifile.ini" | Remove-IniEntry -Keys 'Updated' -Sections '_' | Out-IniFile "C:\myinifile.ini" -Force
		-----------
		Description
		Reads in the INI File c:\myinifile.ini using Get-IniContent, which is then piped to Remove-IniEntry to remove any 'Updated' keys that
		are orphaned, i.e. not specifically in a section. The ini is then piped to Out-IniFile to write the INI File to c:\myinifile.ini.
	.Link
		Get-IniContent
		Out-IniFile
	#>

	[CmdletBinding(DefaultParameterSetName = "File")]
	[OutputType(
		[System.Collections.IDictionary]
	)]
	Param
	(
		# Specifies the path to the input file.
		[Parameter( Position = 0, Mandatory, ParameterSetName = "File")]
		[ValidateNotNullOrEmpty()]
		[String]
		$FilePath,

		# Specifies the Hashtable to be modified.
		# Enter a variable that contains the objects or type a command or expression that gets the objects.
		[Parameter( Mandatory, ValueFromPipeline, ParameterSetName = "Object" )]
		[System.Collections.IDictionary]
		$InputObject,

		# String array of one or more keys to limit the changes to, separated by a comma. Optional.
		[ValidateNotNullOrEmpty()]
		[String[]]
		$Keys,

		[ValidateNotNullOrEmpty()]
		[String[]]
		$Sections
	)

	Begin {
		Write-Debug "PsBoundParameters:"
		$PSBoundParameters.GetEnumerator() | ForEach-Object { Write-Debug $_ }
		if ($PSBoundParameters['Debug']) {
			$DebugPreference = 'Continue'
		}
		Write-Debug "DebugPreference: $DebugPreference"
		Write-Verbose "$($MyInvocation.MyCommand.Name):: Function started"
	}
	# Remove the specified keys in the list, either in the specified section or in all sections.
	Process {
		# Get the ini from either a file or object passed in.
		if ($PSCmdlet.ParameterSetName -eq 'File') { $content = Get-IniContent $FilePath }
		if ($PSCmdlet.ParameterSetName -eq 'Object') { $content = $InputObject }

		if (!$Keys -and !$Sections) {
			Write-Verbose ("No sections or keys provided, exiting.")
			Write-Output $content
		}

		# Specific section(s) were requested.
		if ($Sections) {
			foreach ($section in $Sections) {
				# Get rid of whitespace and section brackets.
				$section = $section.Trim() -replace '[][]', ''

				Write-Debug ("Processing '{0}' section." -f $section)

				# If the user wants to remove an entire section, there will be a section specified but no keys.
				if (!$Keys) {
					Write-Verbose ("Deleting entire section '{0}'." -f $section)
					$content.Remove($section)
				}
				else {
					foreach ($key in $Keys) {
						Write-Debug ("Processing '{0}' key." -f $key)

						$key = $key.Trim()

						if ($content[$section]) {
							$currentValue = $content[$section][$key]
						}
						else {
							Write-Verbose ("$($MyInvocation.MyCommand.Name):: '{0}' section does not exist." -f $section)
							# Break out of the loop after this, because we don't want to check further keys for this non-existent section.
							break
						}

						if ($currentValue) {
							Write-Verbose ("Removing {0} key from {1} section." -f $key, $section)
							$content[$section].Remove($key)
						}
						else {
							Write-Verbose ("$($MyInvocation.MyCommand.Name):: '{0}' key does not exist." -f $key)
						}
					}
				}
			}
		}
		else {
			# No section supplied, go through the entire ini since changes apply to all sections.
			foreach ($item in $content.GetEnumerator()) {
				$section = $item.key
				Write-Debug ("Processing '{0}' section." -f $section)

				foreach ($key in $Keys) {
					$key = $key.Trim()
					Write-Debug ("Processing '{0}' key." -f $key)

					if ($content[$section][$key]) {
						Write-Verbose ("Removing {0} key from {1} section." -f $key, $section)
						$content[$section].Remove($key)
					}
					else {
						Write-Verbose ("$($MyInvocation.MyCommand.Name):: '{0}' key does not exist in {1} section." -f $key, $section)
					}
				}
			}
		}

		Write-Output $content
	}
	End {
		Write-Verbose "$($MyInvocation.MyCommand.Name):: Function ended"
	}
}
# ---------------------------------------------------------------------------
Function Set-IniContent {
	<#
	.Synopsis
		Updates existing values or adds new key-value pairs to an INI file
	.Description
		Updates specified keys to new values in all sections or certain sections.
		Used to add new or change existing values. To comment, uncomment or remove keys use the related functions instead.
		The ini source can be specified by a file or piped in by the result of Get-IniContent.
		The modified content is returned as a ordered dictionary hashtable and can be piped to a file with Out-IniFile.
	.Notes
		Author		: Sean Seymour <seanjseymour@gmail.com> based on work by Oliver Lipkau <oliver@lipkau.net>
		Source		: https://github.com/lipkau/PsIni
					  http://gallery.technet.microsoft.com/scriptcenter/ea40c1ef-c856-434b-b8fb-ebd7a76e8d91
		Version		: 1.0.0 - 2016/08/18 - SS - Initial release
					: 1.0.1 - 2016/12/29 - SS - Removed need for delimiters by making Sections a string array
												and NameValuePairs a hashtable. Thanks Oliver!
		#Requires -Version 2.0
	.Inputs
		System.String
		System.Collections.IDictionary
	.Outputs
		System.Collections.Specialized.OrderedDictionary
	.Example
		$ini = Set-IniContent -FilePath "C:\myinifile.ini" -Sections 'Printers' -NameValuePairs @{'Name With Space' = 'Value1' ; 'AnotherName' = 'Value2'}
		-----------
		Description
		Reads in the INI File c:\myinifile.ini, adds or updates the 'Name With Space' and 'AnotherName' keys in the [Printers] section to the values specified,
		and saves the modified ini to $ini.
	.Example
		Set-IniContent -FilePath "C:\myinifile.ini" -Sections 'Terminals','Monitors' -NameValuePairs @{'Updated=FY17Q2'} | Out-IniFile "C:\myinifile.ini" -Force
		-----------
		Description
		Reads in the INI File c:\myinifile.ini and adds or updates the 'Updated' key in the [Terminals] and [Monitors] sections to the value specified.
		The ini is then piped to Out-IniFile to write the INI File to c:\myinifile.ini. If the file is already present it will be overwritten.
	.Example
		Get-IniContent "C:\myinifile.ini" | Set-IniContent -NameValuePairs @{'Headers' = 'True' ; 'Update' = 'False'} | Out-IniFile "C:\myinifile.ini" -Force
		-----------
		Description
		Reads in the INI File c:\myinifile.ini using Get-IniContent, which is then piped to Set-IniContent to add or update the 'Headers'  and 'Update' keys in all sections
		to the specified values. The ini is then piped to Out-IniFile to write the INI File to c:\myinifile.ini. If the file is already present it will be overwritten.
	.Example
		Get-IniContent "C:\myinifile.ini" | Set-IniContent -NameValuePairs @{'Updated'='FY17Q2'} -Sections '_' | Out-IniFile "C:\myinifile.ini" -Force
		-----------
		Description
		Reads in the INI File c:\myinifile.ini using Get-IniContent, which is then piped to Set-IniContent to add or update the 'Updated' key that
		is orphaned, i.e. not specifically in a section. The ini is then piped to Out-IniFile to write the INI File to c:\myinifile.ini.
	.Link
		Get-IniContent
		Out-IniFile
	#>

	[CmdletBinding(DefaultParameterSetName = "File")]
	[OutputType(
		[System.Collections.IDictionary]
	)]
	Param
	(
		# Specifies the path to the input file.
		[Parameter( Position = 0, Mandatory, ParameterSetName = "File" )]
		[ValidateNotNullOrEmpty()]
		[String]
		$FilePath,

		# Specifies the Hashtable to be modified.
		# Enter a variable that contains the objects or type a command or expression that gets the objects.
		[Parameter( Mandatory, ValueFromPipeline, ParameterSetName = "Object")]
		[ValidateNotNullOrEmpty()]
		[System.Collections.IDictionary]
		$InputObject,

		# Hashtable of one or more key names and values to modify. Required.
		[Parameter( Mandatory, ParameterSetName = "File")]
		[Parameter( Mandatory, ParameterSetName = "Object")]
		[ValidateNotNullOrEmpty()]
		[HashTable]
		$NameValuePairs,

		# String array of one or more sections to limit the changes to, separated by a comma.
		# Surrounding section names with square brackets is not necessary but is supported.
		# Ini keys that do not have a defined section can be modified by specifying '_' (underscore) for the section.
		[Parameter( ParameterSetName = "File" )]
		[Parameter( ParameterSetName = "Object" )]
		[ValidateNotNullOrEmpty()]
		[String[]]
		$Sections
	)

	Begin {
		Write-Debug "PsBoundParameters:"
		$PSBoundParameters.GetEnumerator() | ForEach-Object { Write-Debug $_ }
		if ($PSBoundParameters['Debug']) {
			$DebugPreference = 'Continue'
		}
		Write-Debug "DebugPreference: $DebugPreference"
		Write-Verbose "$($MyInvocation.MyCommand.Name):: Function started"

		# Update or add the name/value pairs to the section.
		Function Update-IniEntry {
			param ($content, $section)

			foreach ($pair in $NameValuePairs.GetEnumerator()) {
				if (!($content[$section])) {
					Write-Verbose ("$($MyInvocation.MyCommand.Name):: '{0}' section does not exist, creating it." -f $section)
					$content[$section] = New-Object System.Collections.Specialized.OrderedDictionary([System.StringComparer]::OrdinalIgnoreCase)
				}

				Write-Verbose ("$($MyInvocation.MyCommand.Name):: Setting '{0}' key in section {1} to '{2}'." -f $pair.key, $section, $pair.value)
				$content[$section][$pair.key] = $pair.value
			}
		}
	}
	# Update the specified keys in the list, either in the specified section or in all sections.
	Process {
		# Get the ini from either a file or object passed in.
		if ($PSCmdlet.ParameterSetName -eq 'File') { $content = Get-IniContent $FilePath }
		if ($PSCmdlet.ParameterSetName -eq 'Object') { $content = $InputObject }

		# Specific section(s) were requested.
		if ($Sections) {
			foreach ($section in $Sections) {
				# Get rid of whitespace and section brackets.
				$section = $section.Trim() -replace '[][]', ''

				Write-Debug ("Processing '{0}' section." -f $section)

				Update-IniEntry $content $section
			}
		}
		else {
			# No section supplied, go through the entire ini since changes apply to all sections.
			foreach ($item in $content.GetEnumerator()) {
				$section = $item.key

				Write-Debug ("Processing '{0}' section." -f $section)

				Update-IniEntry $content $section
			}
		}
		Write-Output $content
	}
	End {
		Write-Verbose "$($MyInvocation.MyCommand.Name):: Function ended"
	}
}
# ---------------------------------------------------------------------------
Set-Alias aic Add-IniComment
Set-Alias gic Get-IniContent
Set-Alias oif Out-IniFile
Set-Alias ric Remove-IniComment
Set-Alias rie Remove-IniEntry
Set-Alias sic Set-IniContent
# ---------------------------------------------------------------------------
# End of INI Functions - https://github.com/lipkau/PsIni
# ---------------------------------------------------------------------------
