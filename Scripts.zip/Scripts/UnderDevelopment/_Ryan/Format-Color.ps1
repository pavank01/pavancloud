﻿# ---------------------------------------------------------------------------
Function Format-Color {
<#
	.SYNOPSIS
		The Format-Color function takes a supplied object or string,
		and colors certain lines based on supplied criteria.

	.DESCRIPTION
		The Format-Color function takes a supplied object or string,
		and colors certain lines based on supplied criteria.

	.PARAMETER Object
		The object or string to process.

	.PARAMETER Colors
		A HashTable with search patterns and color sets in the following format:
		@{"SearchPattern1" = "ForegroundColor, BackgroundColor"; "SearchPattern2" = "ForegroundColor, BackgroundColor"}

		The Search pattern can be any basic text string or Regular Expression.
		The foreground and background colors are the standard 16 colors used by Write-Host.

			Black         DarkGray
			DarkBlue      Blue
			DarkGreen     Green
			DarkCyan      Cyan
			DarkRed       Red
			DarkMagenta   Magenta
			DarkYellow    Yellow
			Gray          White

	.PARAMETER SimpleMatch
		Use simple string and wildcard comparisons (*) instead of Regular Expressions.

	.OUTPUTS
		Writes to console host.

	.NOTES
		Originally written by Brad Greco (https://www.bgreco.net/powershell/format-color/)
		Expanded by Ryan Amsbury
#>
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $True, ValueFromPipeline = $True)]
		[PSObject]$Object,

		[Parameter(Mandatory = $True)]
		[HashTable]$Colors,

		[Parameter(Mandatory = $False)]
		[Switch] $SimpleMatch
	)
	$BlankCount = 0
	$ErrorAction = $ErrorActionPreference
	$DefaultFGColor = $Host.UI.RawUI.ForegroundColor
	$DefaultBGColor = $Host.UI.RawUI.BackgroundColor
	$Lines = (($Object | Out-String) -replace "`r", "") -Split "`n"
	ForEach ($Line In $Lines) {
		If ($Line.Trim() -eq $Null -or $Line.Trim() -eq "") {
			$BlankCount = $BlankCount + 1
		} Else {
			$BlankCount = 0
		}
		If ($BlankCount -lt 2) {
			$FGColor = ''
			$BGColor = ''
			$Colored = $False
			ForEach ($Pattern In $Colors.Keys) {
				If (!$SimpleMatch -and $Line -match $Pattern) {
					$CurrentColors = $Colors[$Pattern].Split(",")
					$ErrorActionPreference = "SilentlyContinue"
					$CurrentColors[0] = $CurrentColors[0].Trim()
					$CurrentColors[1] = $CurrentColors[1].Trim()
					$ErrorActionPreference = $ErrorAction
					If ($CurrentColors[0] -eq "" -or $CurrentColors[0] -eq $Null) {
						$FGColor = $DefaultFGColor
					} Else {
						$FGColor = $CurrentColors[0]
					}
					If ($CurrentColors[1] -eq "" -or $CurrentColors[1] -eq $Null) {
						$BGColor = $DefaultBGColor
					} Else {
						$BGColor = $CurrentColors[1]
					}
					$Colored = $True
				} ElseIf ($SimpleMatch -and $Line -like $Pattern) {
					$CurrentColors = $Colors[$Pattern].Split(",")
					$ErrorActionPreference = "SilentlyContinue"
					$CurrentColors[0] = $CurrentColors[0].Trim()
					$CurrentColors[1] = $CurrentColors[1].Trim()
					$ErrorActionPreference = $ErrorAction
					If ($CurrentColors[0] -eq "" -or $CurrentColors[0] -eq $Null) {
						$FGColor = $DefaultFGColor
					} Else {
						$FGColor = $CurrentColors[0]
					}
					If ($CurrentColors[1] -eq "" -or $CurrentColors[1] -eq $Null) {
						$BGColor = $DefaultBGColor
					} Else {
						$BGColor = $CurrentColors[1]
					}
					$Colored = $True
				}
			}
			If ($Colored -eq $True) {
				Write-Host $Line -ForegroundColor $FGColor -BackgroundColor $BGColor
			} Else {
				Write-Host $Line
			}
		}
	}
}
# ---------------------------------------------------------------------------