[CmdletBinding()]
Param ()
# ProcessFileVersions.ps1

# THINGS TO DO
#
# FileName parameter for output file of CompareFileVersions
# Path parameter for output file of CompareFileVersions
# Quiet

# FileName parameter for output file of GetFileVersions
# Path parameter for output file of GetFileVersions
# Recurse folders parameter of GetFileVersions
# Root folders parameter of GetFileVersions
# Exclude folders parameter of GetFileVersions
#
# ---------------------------------------------------------------------------
$Servers = "SNAPPCLSFAST011.fastts.firstam.net", "SNAPPCLSFAST012.fastts.firstam.net", "SNAPPCLSFAST013.fastts.firstam.net", "SNAPPCLSFAST014.fastts.firstam.net", "SNAPPCLSFAST015.fastts.firstam.net", "SNAPPCLSFAST016.fastts.firstam.net", "DFWPDCLSFAST011.fastts.firstam.net", "DFWPDCLSFAST012.fastts.firstam.net", "DFWPDCLSFAST013.fastts.firstam.net", "DFWPDCLSFAST014.fastts.firstam.net", "DFWPDCLSFAST015.fastts.firstam.net", "DFWPDCLSFAST016.fastts.firstam.net"

$MyPath = Split-Path -Path $Script:MyInvocation.MyCommand.Path # only works from a script, not from the commandline

$ScriptGetFileVersions = "GetFileVersions.ps1"
$ScriptCompareFileVersions = "CompareFileVersions.ps1"

Write-Host ("Running {0} On Servers" -f $ScriptGetFileVersions) -ForegroundColor DarkYellow
ForEach ($Server In $Servers) {
    If ((Test-Connection -ComputerName $Server -Quiet) -eq $True) {
		Write-Host
		Write-Host ("  {0}  " -f $Server) -ForegroundColor White -BackgroundColor DarkCyan
		Write-Host
		# Run GetFileVersions.ps1 on each remote server - C:\Windows normally takes under 3 minutes to complete
		Invoke-Command -ComputerName $Server -FilePath (Join-Path -Path $MyPath -ChildPath $ScriptGetFileVersions)
	} Else {
		Write-Host ("  {0}  " -f $Server) -ForegroundColor Yellow -BackgroundColor DarkRed
	}
	Write-Host
}

# Collect the resulting CSV files from the servers and copy locally
$FileList = @()
$TargetFolder = $MyPath
Write-Host "Collecting Result Files From Servers" -ForegroundColor DarkYellow
ForEach ($Server In $Servers) {
	$SourceFolder = ("\\{0}\c$\Scripts\FileVersions" -f $Server)
	# Select only CSV files created today
	$SourceFile = ("GetFileVersions_{0}_{1}_*.csv" -f ($Server -Replace('.fastts.firstam.net', '')), (Get-Date -Format "yyyy-MM-dd"))
    If ((Test-Connection -ComputerName $Server -Quiet) -eq $True) {
		Write-Host ("  {0}  " -f $Server) -ForegroundColor White -BackgroundColor DarkCyan
		If ([System.Management.Automation.WildcardPattern]::ContainsWildcardCharacters($SourceFile) -eq $True) {
		    # If using wildcard then pull the latest file that matches
		    $SourceFiles = (Get-ChildItem -Path (Join-Path -Path $SourceFolder -ChildPath $SourceFile) | Where-Object {$_.Name} | Sort-Object LastWriteTime | Select-Object FullName -Last 1 ).FullName
		} Else {
			$SourceFiles = Join-Path -Path $SourceFolder -ChildPath $SourceFile
		}
		ForEach ($File In $SourceFiles) {
			Write-Host
			Write-Host ("`tCopy    : {0}" -f $File) -ForegroundColor DarkGray
			Copy-Item -Path $File -Destination $TargetFolder -Force
		    If (Test-Path -Path (Join-Path -Path $TargetFolder -ChildPath ([System.IO.Path]::GetFileName($File)))) {
		    	Write-Host ("`tSuccess : {0}" -f (Join-Path -Path $TargetFolder -ChildPath ([System.IO.Path]::GetFileName($File)))) -ForegroundColor Green
				$FileList += (Join-Path -Path $TargetFolder -ChildPath ([System.IO.Path]::GetFileName($File)))
		    } Else {
		    	Write-Host ("`tFailed  : {0}" -f (Join-Path -Path $TargetFolder -ChildPath ([System.IO.Path]::GetFileName($File)))) -ForegroundColor Red
		    }
			Write-Host
		}
	} Else {
		Write-Host ("  {0}  " -f $Server) -ForegroundColor Yellow -BackgroundColor DarkRed
	}
	Write-Host
}

Write-Host ("Running {0} Against Result Files" -f $ScriptCompareFileVersions) -ForegroundColor DarkYellow
& (Join-Path -Path $MyPath -ChildPath $ScriptCompareFileVersions) -Files $FileList

