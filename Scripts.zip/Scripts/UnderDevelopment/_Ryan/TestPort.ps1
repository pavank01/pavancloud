Function Test-Port {
	<#
	.SYNOPSIS
		Tests if a port is open between source and target computers
	.DESCRIPTION
		Tests if a port is open between source and target computers
	.PARAMETER SourceComputerName
		Name of Source computer
		Defaults to the local computer
	.PARAMETER ComputerName
		Name of Target computer
	.PARAMETER Port
		Port number to test between 0 and 65535
	.PARAMETER Quiet
		If connection succeeds, returns $True. If connection fails, returns $False.
	.PARAMETER Interactive
		Displays colored output to the console with green for success and red for failure
		Does not pass an object to the pipeline
	.EXAMPLE
	.NOTES
		2018/04/06 - Initial Release [Ryan Amsbury]
	#>
	[CmdletBinding()]
	Param(
		[Parameter(Mandatory=$False)]
		[String]$SourceComputerName,

		[Parameter(Mandatory=$True)]
		[String]$ComputerName,

		[Parameter(Mandatory=$True)]
		[Int]$Port,

		[Parameter(Mandatory=$False)]
		[Switch]$PortDetails
	)
	# IANA.org has a full list of *officially assigned* ports that this script
	# can use. Download the CSV formatted list (service-names-port-numbers.csv)
	# from the URL below and put it in the script folder. When run the script
	# will read the CSV, clean up the data, then save as IANAPorts.csv.
	#
	# IANA.org CSV Port List
	# http://www.iana.org/assignments/service-names-port-numbers/service-names-port-numbers.csv
	#
	# Assigned System Ports and User Ports SHOULD NOT be used without or prior to IANA registration, as per [RFC6335]
	#
	# Ports 0-1023 are System Ports
	# System Ports are assigned by IETF process for standards-track protocols, as per [RFC6335]
	#
	# Ports 1024-49151 are User Ports
	# User Ports are assigned by IANA using the "IETF Review" process, the "IESG Approval" process, or the "Expert Review" process, as per [RFC6335]
	#
	# Ports 49152-65535 are Dynamic and/or Private
	# Dynamic and/or Private Ports are not assigned
	#
	# IANAPorts.csv will be used to display port details if it exists
	# If both files exist the script will update IANAPorts.csv if required
	# If neither file exists the script will run but not display port details
	$IANAPortsFile = ".\IANAPorts.csv"
	$IANAPortsSourceFile = ".\service-names-port-numbers.csv"
	Function ProcessPortsFile {
		$IANAPorts = @()
		Write-Host "Processing IANA.org Officially Assigned Ports List . . ." -ForegroundColor Yellow
		$IANAPortList = Import-CSV $IANAPortsSourceFile | Where-Object {$_."Port Number" -ne "" -and $_."Transport Protocol" -eq "tcp"} | Select-Object @{Name="Protocol";Expression={$_."Transport Protocol"}}, @{Name="Port";Expression={$_."Port Number"}}, @{Name="ServiceName";Expression={$_."Service Name"}}, Description
		ForEach ($IANAPort In $IANAPortList) {
			If ($IANAPort.Port -like "*-*") {
				$IANAPort.Port = $IANAPort.Port -Replace('-', '..')
				$PortRanges = Invoke-Expression -Command $IANAPort.Port
				ForEach ($PortRange In $PortRanges) {
				$PortSort = ([Int]$PortRange).ToString("00000")
					$PortTemp = New-Object PSObject
					Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "Protocol" -Value ([String]$IANAPort.Protocol)
					Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "Port" -Value ([Int]$PortRange)
					Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "PortSort" -Value ([String]$PortSort)
					Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "ServiceName" -Value ([String]$IANAPort.ServiceName)
					Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "Description" -Value ([String]$IANAPort.Description)
					If ($IANAPort.ServiceName -eq " " -or $IANAPort.ServiceName -eq "" -or $IANAPort.ServiceName -eq $Null) {
						$PortTemp.ServiceName = [String]$IANAPort.Description
					}
					If ($IANAPort.Description -eq " " -or $IANAPort.Description -eq "" -or $IANAPort.Description -eq $Null) {
						$PortTemp.Description = [String]$IANAPort.ServiceName
					}
					$IANAPorts += $PortTemp
				}
			} Else {
				$PortSort = ([Int]$IANAPort.Port).ToString("00000")
				$PortTemp = New-Object PSObject
				Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "Protocol" -Value ([String]$IANAPort.Protocol)
				Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "Port" -Value ([Int]$IANAPort.Port)
				Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "PortSort" -Value ([String]$PortSort)
				Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "ServiceName" -Value ([String]$IANAPort.ServiceName)
				Add-Member -InputObject $PortTemp -MemberType NoteProperty -Name "Description" -Value ([String]$IANAPort.Description)
				If ($IANAPort.ServiceName -eq " " -or $IANAPort.ServiceName -eq "" -or $IANAPort.ServiceName -eq $Null) {
					$PortTemp.ServiceName = [String]$IANAPort.Description
				}
				If ($IANAPort.Description -eq " " -or $IANAPort.Description -eq "" -or $IANAPort.Description -eq $Null) {
					$PortTemp.Description = [String]$IANAPort.ServiceName
				}
				$IANAPorts += $PortTemp
			}
		}
		$IANAPorts | Sort-Object PortSort, ServiceName | Export-Csv -Path $IANAPortsFile -Force -NoTypeInformation
	}
	# Does the $IANAPortsFile exist
	If ((Test-Path $IANAPortsFile) -eq $True -and ($PortDetails -eq $True)) {
		$IANAPortsExists = $True
		$IANAPortsModified = Get-Item $IANAPortsFile | ForEach {$_.LastWriteTime}
	} Else {
		$IANAPortsExists = $False
		$IANAPortsModified = $Null
	}
	# Does the $IANAPortsSourceFile exist
	If ((Test-Path $IANAPortsSourceFile) -eq $True -and ($PortDetails -eq $True)) {
		$IANAPortsSourceExists = $True
		$IANAPortsSourceModified = Get-Item $IANAPortsSourceFile | ForEach {$_.LastWriteTime}
	} Else {
		$IANAPortsSourceExists = $False
		$IANAPortsSourceModified = $Null
	}

	If (($IANAPortsExists -eq $False -and $IANAPortsSourceExists -eq $True) -and $IANAPorts -eq $Null) {
		ProcessPortsFile
		$IANAPortsExists = $True
		$IANAPortsModified = Get-Item $IANAPortsFile | ForEach {$_.LastWriteTime}
	}

	If ($IANAPortsSourceModified -gt $IANAPortsModified) {
		ProcessPortsFile
		$IANAPortsExists = $True
	}

	If ($IANAPortsExists -eq $True) {
		$IANAPorts = Import-CSV $IANAPortsFile
	}

	$ComputerName = ([Regex]::Match($ComputerName, '^[^\.]*').Value).ToUpper()+([Regex]::Match($ComputerName, '^*[\.](.*)$').Value).ToLower()

	If ((Test-Connection -ComputerName $ComputerName -Count 1 -Quiet) -eq $False) {
		Write-Host
		Write-Host ("Server {0} Is Not Responding - Testing Of Port TCP/{1} Is Not Possible" -f $ComputerName.ToUpper(), $Port) -ForegroundColor Red
		Write-Host
		Break
	}

	If ($SourceComputerName -eq $Null -or $SourceComputerName -eq "") {
		$SourceComputerName = (Get-ChildItem Env:ComputerName).Value
	}
	$WMIComputerSystem = Get-WmiObject -ComputerName $SourceComputerName -Class Win32_ComputerSystem -Property Name, PartOfDomain, Domain
	If ($WMIComputerSystem.PartOfDomain -eq $True) {
		$SourceComputerName = ($WMIComputerSystem.Name).ToUpper()+'.'+($WMIComputerSystem.Domain).ToLower()
	} Else {
		$SourceComputerName = ($WMIComputerSystem.Name).ToUpper()
	}

	If ([bool]($SourceComputerName -as [IPAddress])) {
		$SourceIPAddress = $SourceComputerName
		$ErrorAction = $ErrorActionPreference
		$ErrorActionPreference = "SilentlyContinue"
		$SourceComputerName = [System.Net.Dns]::GetHostbyAddress($SourceComputerName).HostName
		$ErrorActionPreference = $ErrorAction
	} Else {
		# Get first IPv4 addrress
		$SourceIPAddress = [System.Net.Dns]::GetHostAddresses($SourceComputerName) | Select-Object -ExpandProperty IPAddressToString | Where-Object {$_ -match "\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"} | Sort-Object | Select-Object -first 1
		$ErrorAction = $ErrorActionPreference
		$ErrorActionPreference = "SilentlyContinue"
		$SourceComputerName = [System.Net.Dns]::GetHostbyAddress($SourceIPAddress).HostName
		$ErrorActionPreference = $ErrorAction
	}

	If ([bool]($ComputerName -as [IPAddress])) {
		$IPAddress = $ComputerName
		$ErrorAction = $ErrorActionPreference
		$ErrorActionPreference = "SilentlyContinue"
		$ComputerName = [System.Net.Dns]::GetHostbyAddress($ComputerName).HostName
		$ErrorActionPreference = $ErrorAction
	} Else {
		# Get first IPv4 addrress
		$IPAddress = [System.Net.Dns]::GetHostAddresses($ComputerName) | Select-Object -ExpandProperty IPAddressToString | Where-Object {$_ -match "\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"} | Sort-Object | Select-Object -first 1
		$ErrorAction = $ErrorActionPreference
		$ErrorActionPreference = "SilentlyContinue"
		$ComputerName = [System.Net.Dns]::GetHostbyAddress($IPAddress).HostName
		$ErrorActionPreference = $ErrorAction
	}
	$SourceComputerName = ([Regex]::Match($SourceComputerName, '^[^\.]*').Value).ToUpper()+([Regex]::Match($SourceComputerName, '^*[\.](.*)$').Value).ToLower()
	$ComputerName = ([Regex]::Match($ComputerName, '^[^\.]*').Value).ToUpper()+([Regex]::Match($ComputerName, '^*[\.](.*)$').Value).ToLower()
	$PortTest = New-Object System.Net.Sockets.TcpClient
	Try {
		If ($IANAPorts -ne $Null) {
			$Result = $Null
			If ($Port -in 0..1023) {
				$Result = ("`nPort TCP/{0} - SYSTEM PORT - Assigned by Internet Engineering Task Force (IETF) [RFC6335]" -f $Port)
			}
			If ($Port -in 1024..49151) {
				$Result = ("`nPort TCP/{0} - USER PORT - Assigned by Internet Assigned Numbers Authority (IANA) [RFC6335]" -f $Port)
			}
			If ($Port -in 49152..65535) {
				$Result = ("`nPort TCP/{0} - DYNAMIC/PRIVATE PORT" -f $Port)
			}
			Write-Host $Result -ForegroundColor Blue
			$Result = $Null
			$IANAPorts | Where-Object {$_.Port -eq $Port} | ForEach {$Result = $Result+("Port {0}/{1} - {2} [{3}]`n" -f ($_.Protocol).ToUpper(), $_.Port, $_.Description, $_.ServiceName)}
			If ($Result -ne $Null) {
				Write-Host $Result -ForegroundColor Cyan
			}
		}
		$PortTest.Connect($ComputerName, $Port)
		Write-Host
		If ($ComputerName -eq $IPAddress) {
			Write-Host ("Connection From {0} To {1} On Port TCP/{2} Succeeded" -f $SourceComputerName, $ComputerName, $Port) -ForegroundColor Green
		} Else {
			Write-Host ("Connection From {0} ({1}) To {2} ({3}) On Port TCP/{4} Succeeded" -f $SourceComputerName, $SourceIPAddress, $ComputerName, $IPAddress, $Port) -ForegroundColor Green
		}
	}
	Catch {
		Write-Host
		If ($ComputerName -eq $IPAddress) {
			Write-Host ("Connection From {0} To {1} On Port TCP/{2} Failed" -f $SourceComputerName, $ComputerName, $Port) -ForegroundColor Red
		} Else {
			Write-Host ("Connection From {0} ({1}) To {2} ({3}) On Port TCP/{4} Failed" -f $SourceComputerName, $SourceIPAddress, $ComputerName, $IPAddress, $Port) -ForegroundColor Red
		}
	}
	Finally {
		$ErrorAction = $ErrorActionPreference
		$ErrorActionPreference = "SilentlyContinue"
		$PortTest.Dispose()
		$PortTest.Close()
		$ErrorActionPreference = $ErrorAction
		Write-Host
	}
}