# ------------------------------------------------------------------------
# NAME: GetSetExplorerSettings.ps1
# AUTHOR: ed wilson, Microsoft
# DATE: 1/5/2009
#
# KEYWORDS: Get-Itemproperty, Set-Itemproperty
# Registry, HSG
# COMMENTS: This script uses psh cmdlets to get
# and to set several values from the registry. The
# one interesting thing is the way it retrieves an entire
# registry key, stores it in a variable, and then uses
# the properties directly. This avoids multiple reg
# calls.
# HSG 1/6/2009
#
# ------------------------------------------------------------------------
Param([switch]$get,[switch]$set)
Function Get-ExplorerSettings()
{
 $RegExplorer =  Get-ItemProperty -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced
  	"AlwaysShowMenus              : $($RegExplorer.AlwaysShowMenus)"
	"AutoCheckSelect              : $($RegExplorer.AutoCheckSelect)"
	"DisablePreviewDesktop        : $($RegExplorer.DisablePreviewDesktop)"
	"DontPrettyPath               : $($RegExplorer.DontPrettyPath)"
	"Filter                       : $($RegExplorer.Filter)"
	"Hidden                       : $($RegExplorer.Hidden)"
	"HideDrivesWithNoMedia        : $($RegExplorer.HideDrivesWithNoMedia)"
	"HideFileExt                  : $($RegExplorer.HideFileExt)"
	"HideIcons                    : $($RegExplorer.HideIcons)"
	"HideMergeConflicts           : $($RegExplorer.HideMergeConflicts)"
	"IconsOnly                    : $($RegExplorer.IconsOnly)"
	"ListviewAlphaSelect          : $($RegExplorer.ListviewAlphaSelect)"
	"ListviewShadow               : $($RegExplorer.ListviewShadow)"
	"MapNetDrvBtn                 : $($RegExplorer.MapNetDrvBtn)"
	"NavPaneExpandToCurrentFolder : $($RegExplorer.NavPaneExpandToCurrentFolder)"
	"NavPaneShowFavorites         : $($RegExplorer.NavPaneShowFavorites)"
	"SeparateProcess              : $($RegExplorer.SeparateProcess)"
	"ServerAdminUI                : $($RegExplorer.ServerAdminUI)"
	"ShowCompColor                : $($RegExplorer.ShowCompColor)"
	"ShowInfoTip                  : $($RegExplorer.ShowInfoTip)"
	"ShowStatusBar                : $($RegExplorer.ShowStatusBar)"
	"ShowSuperHidden              : $($RegExplorer.ShowSuperHidden)"
	"ShowTypeOverlay              : $($RegExplorer.ShowTypeOverlay)"
	"StartMenuAdminTools          : $($RegExplorer.StartMenuAdminTools)"
	"StartMenuInit                : $($RegExplorer.StartMenuInit)"
	"Start_SearchFiles            : $($RegExplorer.Start_SearchFiles)"
	"TaskbarAnimations            : $($RegExplorer.TaskbarAnimations)"
	"TaskbarGlomLevel             : $($RegExplorer.TaskbarGlomLevel)"
	"TaskbarSizeMove              : $($RegExplorer.TaskbarSizeMove)"
	"TaskbarSmallIcons            : $($RegExplorer.TaskbarSmallIcons)"
	"WebView                      : $($RegExplorer.AlwaysShowMenus)"
} #end Get-ExplorerSettings

Function Set-ExplorerSettings()
{
 $RegValues = @{
	"AlwaysShowMenus" = 0;
	"AutoCheckSelect" = 0;
	"DisablePreviewDesktop" = 1;
	"DontPrettyPath" = 0;
	"Filter" = 0;
	"Hidden" = 1;
	"HideDrivesWithNoMedia" = 0;
	"HideFileExt" = 0;
	"HideIcons" = 0;
	"HideMergeConflicts" = 0;
	"IconsOnly" = 1;
	"ListviewAlphaSelect" = 0;
	"ListviewShadow" = 0;
	"MapNetDrvBtn" = 0;
	"NavPaneExpandToCurrentFolder" = 1;
	"NavPaneShowFavorites" = 0;
	"SeparateProcess" = 0;
	"ServerAdminUI" = 1;
	"ShowCompColor" = 1;
	"ShowInfoTip" = 1;
	"ShowStatusBar" = 1;
	"ShowSuperHidden" = 1;
	"ShowTypeOverlay" = 1;
	"StartMenuAdminTools" = 1;
	"StartMenuInit" = 5;
	"Start_SearchFiles" = 1;
	"TaskbarAnimations" = 0;
	"TaskbarGlomLevel" = 0;
	"TaskbarSizeMove" = 0;
	"TaskbarSmallIcons" = 0;
	"WebView" = 1
}

 $path = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
 ForEach ($key in $RegValues.Keys)
  {
    Set-ItemProperty -path $path -name $key -value $RegValues[$key]
   #"Setting $path $($key) to $($RegValues[$key])"
  }

}
Set-ExplorerSettings