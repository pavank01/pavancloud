<#
.SYNOPSIS
 A PowerShell script to manage current TLS settings

.DESCRIPTION
  A PowerShell script to manage current TLS settings by getting current settings, setting TLS to best practices or resetting all TLS back to server default.
  Disabled Protocols: Multi-Protocol Unified Hello, PCT 1.0, SSL 2.0, SSL 3.0, TLS 1.0
  Disabled Ciphers: NULL, DES 56/56, RC2 128/128, RC2 40/128, RC2 56/128, RC4 40/128, RC4 56/128, RC4 64/128, RC4 128/128, Triple DES 168/168
  Enabled Protocols: TLS 1.1, TLS 1.2
  Enabled Ciphers: AES 128/128, AES 256/256

.PARAMETER Show
  Shows outputs to screen the current TLS settings and

  .PARAMETER Enable_FAstandard
  Sets TLS to current best practices (First American Standard).
  - Enabled Protocols: TLS 1.1, TLS 1.2
  - Enabled Ciphers: AES 128/128, AES 256/256
  - Disables all others

.PARAMETER TLS10_Enable_Server
  ENABLES the TLS 1.0 protocol for server communications only
  Enabling TLS 1.0 server is not a First American Standard

.PARAMETER TLS10_Disable_Server
  DISABLES the TLS 1.0 protocol for server communications only

.PARAMETER TLS10_Enable_Client
  ENABLES the TLS 1.0 protocol for client communications only
  Enabling TLS 1.0 client is not a First American Standard

.PARAMETER TLS10_Disable_Client
  DISABLES the TLS 1.0 protocol for client communications only

.PARAMETER OsTlsDefault
  Removes all TLS settings putting server back to server defaults.
  ** This is VERY UNSECURE and the First American Standard should be applied after this option has been used.

.PARAMETER Force
  This switch will force the script to set TLS settings to run -Enable_FAstandard with no console outputs. Particularly useful for automation.

.EXAMPLE
  .\Set-TLSSecurity.ps1 -Show

  PS C:\>.\Set-TLSSecurity.ps1 -Enable_FAstandard

  PS C:\>.\Set-TLSSecurity.ps1 -TLS10_Enable_Server

  PS C:\>.\Set-TLSSecurity.ps1 -TLS10_Enable_Client
#>


[CmdletBinding(DefaultParameterSetName = 'TLSSecurity')]
Param (

    [Parameter(Mandatory = $False, ParameterSetName = 'TLSSecurity', ValueFromPipeline = $true)]
    [Switch]$Show,

    [Parameter(Mandatory = $False, ParameterSetName = 'TLSSecurity', ValueFromPipeline = $true)]
    [Switch]$Enable_FAstandard,

    [Parameter(Mandatory = $False, ParameterSetName = 'TLSSecurity', ValueFromPipeline = $true)]
    [Switch]$TLS10_Enable_Server,

    [Parameter(Mandatory = $False, ParameterSetName = 'TLSSecurity', ValueFromPipeline = $true)]
    [Switch]$TLS10_Disable_Server,

    [Parameter(Mandatory = $False, ParameterSetName = 'TLSSecurity', ValueFromPipeline = $true)]
    [Switch]$TLS10_Enable_Client,

    [Parameter(Mandatory = $False, ParameterSetName = 'TLSSecurity', ValueFromPipeline = $true)]
    [Switch]$TLS10_Disable_Client,

    [Parameter(Mandatory = $False, ParameterSetName = 'TLSSecurity', ValueFromPipeline = $true)]
    [Switch]$OsTlsDefault,

    [Parameter(Mandatory = $False, ParameterSetName = 'TLSSecurity', ValueFromPipeline = $true)]
    [Switch]$Force

)

# Get Windows version
$OSInfo = Get-WmiObject -Class Win32_OperatingSystem -ErrorAction SilentlyContinue | Select-Object @{L="OperatingSystem";E={($_.Caption -Replace('Microsoft',' ') -Replace('Server',' ') -Replace('[^\x20-\x7E]+', ' ') -Replace('\s+', ' ')).Trim()}}, @{L="OS";E={($_.Caption -Replace('Microsoft',' ') -Replace('Windows',' ') -Replace('Server',' ') -Replace('Standard',' ') -Replace('Enterprise',' ') -Replace('Datacenter',' ') -Replace('Essentials',' ') -Replace('Foundation',' ') -Replace('[^\x20-\x7E]+', ' ') -Replace('\s+', '')).Trim()}}
# ----------------------------------------------------------------------------
# Windows 2012 / 2012R2 / 2016 / *
If ($OSInfo.OS -ne "2008" -and $OSInfo.OS -ne "2008R2") {
	# Perform TLS Security changes
	If (!$Force) {
		Write-Host
		Write-Host "Performing CIS hardening on"$OSInfo.OperatingSystem -ForegroundColor Green
		Write-Host
	}
} Else {
	# Do not perform TLS Security changes
	Write-Host
	Write-Host "Not performing TLS Security changes" -ForegroundColor Yellow
	Write-Host "Please use Set-TLSSecurity-2008.ps1 for"$OSInfo.OperatingSystem -ForegroundColor Yellow
	Write-Host
	Break
}

If (1 -ne $Show.IsPresent `
        + $Enable_FAstandard.IsPresent `
        + $TLS10_Enable_Server.IsPresent `
        + $TLS10_Disable_Server.IsPresent `
        + $TLS10_Enable_Client.IsPresent `
        + $TLS10_Disable_Client.IsPresent `
        + $OsTlsDefault.IsPresent `
        + $Force.IsPresent) {

    Write-Host ""
    Write-Host " You must use only one switch at a time ..." -ForegroundColor Yellow
    Write-Host ""
    Write-Host 'SYNTAX' -ForegroundColor White
    Write-Host ' Set-TLSSecurity { -Show | -Enable_FAstandard | -TLS10_Enable_Server | -TLS10_Disable_Server | -TLS10_Enable_Client | -TLS10_Disable_Client | -OsTlsDefault | -Force }' -ForegroundColor White
    Write-Host ""
    Write-Host ""
    Write-host " See Get-Help cmdlet to display more information about this application: " -ForegroundColor White
    Write-Host ""
    Write-Host ' Get-Help .\Set-TLSSecurity_v3 ' -ForegroundColor White
    Write-Host ""

    exit 1

}

If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
            [Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host ""
    Write-Warning "The current Windows PowerShell session is not running as Administrator."
    Write-Warning "Start Windows PowerShell by using the Run as Administrator option, and then try running the script again."
    Write-Host ""
    Break
}


$sCmdLine = $PSBoundParameters.Keys
$DebugPreference = "SilentlyContinue"

[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")

$computerSystem = Get-CimInstance CIM_ComputerSystem
$computerOS     = Get-CimInstance CIM_OperatingSystem
$ReleaseId      = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").ReleaseId

If ($PSBoundParameters.verbose) {
    $sVebose = 1
}


$RegistryKeys = [ordered] @{}
$TLSstate = [ordered] @{}
$TLScolor = [ordered] @{}

$ServerName             = $computerSystem.Name
$LastBootUpTime         = $computerOS.LastBootUpTime
$Manufacturer           = $computerSystem.Manufacturer
$Model                  = $computerSystem.Model
$Caption                = $computerOS.Caption
$ServicePack            = $computerOS.ServicePackMajorVersion
$Version                = $computerOS.Version
$ReleaseId              = $ReleaseId
$InstallDate            = $computerOS.InstallDate

$ScriptVersion          = "Set-TLSSecurity v4.0"
$sLogDate               = Get-Date -Format yyyy-MM-dd
$sLogPath               = "C:\ProgramData\FirstAmerican\TLS"
$sLogName               = "TLSlog-$sLogDate.log"
$sFullPath              = Join-Path -Path $sLogPath -ChildPath $sLogName
$SMTPServer             = 'mail.firstam.com'
$MailFrom               = $ServerName + '@firstam.com'
$MailTo                 = "{0}@firstam.com" -f $(($Env:UserName).ToLower()-Replace("-a",""))
$MailSubject            = "$ScriptVersion [ $ServerName ] $([DateTime]::Now) "

$SysInfoArr = @()
$SysInfoArr += "Script              : $ScriptVersion"
$SysInfoArr += "Arg                 : -$sCmdLine"
$SysInfoArr += " "
$SysInfoArr += "User logged In      : $env:username"
$SysInfoArr += "Server Name         : $ServerName"
$SysInfoArr += "Last Reboot         : $LastBootUpTime"
$SysInfoArr += "Manufacturer        : $Manufacturer"
$SysInfoArr += "Model               : $Model"
$SysInfoArr += "Operating System    : $Caption"
$SysInfoArr += "Service Pack        : $ServicePack"
$SysInfoArr += "Version             : $Version "
$SysInfoArr += "ReleaseId           : $ReleaseId"
$SysInfoArr += "Install Date        : $InstallDate"

$SysInfo = $SysInfoArr | Format-Table | Out-String

If ( !(Test-Path -Path $sLogPath ) ) {
    New-Item -Path $sLogPath -ItemType Directory | Out-Null
}

Function Start-Log {
    Param (
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$LogPath,

        [Parameter(Mandatory = $true, Position = 1)]
        [string]$ScriptVersion,

        [Parameter(Mandatory = $true, Position = 2)]
        [string]$CmdLine,

        [Parameter(Mandatory = $false, Position = 3)]
        [switch]$ToScreen
    )

    Process {

        Add-Content -Path $LogPath -Value " "
        Add-Content -Path $LogPath -Value "==================================================================================================="
        Add-Content -Path $LogPath -Value " "
        Add-Content -Path $LogPath -Value " $ScriptVersion [ $CmdLine ] Started processing at: $([DateTime]::Now)"
        Add-Content -Path $LogPath -Value "---------------------------------------------------------------------------------------------------"
        Add-Content -Path $LogPath -Value "$SysInfo"
        Add-Content -Path $LogPath -Value ""
        Add-Content -Path $LogPath -Value ""

        If ( $ToScreen -eq $True ) {
            Write-Host " "
            Write-Host "==================================================================================================="
            Write-Host " "
            Write-Host " $ScriptVersion [ $CmdLine ] Started processing at: $([DateTime]::Now)"
            Write-Host "---------------------------------------------------------------------------------------------------"
            Write-Host "$SysInfo"
            Write-Host " "
            Write-Host ""
        }
    }
}

Function Write-LogInfo {
    Param (
        [Parameter(Mandatory = $true, Position = 0)]
        [string]$LogPath,

        [Parameter(Mandatory = $true, Position = 1)]
        [string]$Message,

        [Parameter(Mandatory = $false, Position = 2)]
        [switch]$TimeStamp,

        [Parameter(Mandatory = $false, Position = 3)]
        [switch]$ToScreen,

        [Parameter(Mandatory = $false, Position = 4)]
        [switch]$ToScreenNT,

        [Parameter(Mandatory = $false, Position = 5)]
        [string]$Color
    )


    Process {
        $nMessage = $Message
        If ( $TimeStamp -eq $True ) {

            $Message = "[$([DateTime]::Now)] $Message "

        }

        Add-Content -Path $LogPath -Value $Message


        If ($ToScreen) {
            #            Write-Host "[$([DateTime]::Now)]  " -NoNewline -ForegroundColor White
            Write-Host "$nMessage" -ForegroundColor $Color

        }

    }
}

Function Get-RegKeys() {
    $KeyList = Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders' -Recurse -ErrorAction SilentlyContinue | ForEach-Object {(Get-ItemProperty $_.PSPath).PSPath -Replace ([RegEx]::Escape('Microsoft.PowerShell.Core\Registry::HKEY_LOCAL_MACHINE'), 'HKLM:')}
    $KeyList = $KeyList | Where-Object {$_} | Sort-Object

    ForEach ($Key In $KeyList) {
        $RegValues = (Get-ItemProperty $Key -ErrorAction SilentlyContinue).PSObject.Properties | Where-Object {$_.Name -notlike "PS*"} | Select-Object Name, Value, @{N = "DataType"; E = {$_.TypeNameOfValue}}
        ForEach ($RegValue In $RegValues) {
            $Name = $Key + "\" + $RegValue.Name
            $Name = ($Name -Replace ("HKLM\:\\SYSTEM\\CurrentControlSet\\Control\\SecurityProviders\\SCHANNEL\\", "")).Trim()
            $Name = ($Name -Replace ("/", "\")).Trim()
            If ($Name -like "*Ciphers*" -or $Name -like "*Protocols*" -or $Name -like "*KeyExchangeAlgorithms*" -or $Name -like "*Hashes*") {
                Switch ($RegValue.DataType) {
                    "System.Byte[]" {
                        $Value = [Array]$RegValue.Value
                    }
                    "System.Int32" {
                        $Value = [Int32]$RegValue.Value
                    }
                    "System.UInt32" {
                        $Value = [UInt32]$RegValue.Value
                        $Value = '0x' + ([System.Convert]::ToString($RegValue.Value, 16)).PadLeft(8, "0")
                    }
                    "System.Int64" {
                        $Value = [Int64]$RegValue.Value
                    }
                    "System.UInt64" {
                        $Value = [UInt64]$RegValue.Value
                    }
                    "System.String" {
                        $Value = [String]$RegValue.Value
                    }
                    "System.String[]" {
                        $Value = [Array]$RegValue.Value
                    }
                    Default {
                        $Value = $RegValue.Value
                    }
                }
                $RegistryKeys.Add($Name, $Value)

            }
        }
    }

    # Multi-Protocol Unified Hello Server- DISABLED

    If (!$Force) {


        # Multi-Protocol Unified Hello Server- DISABLED

        If ($RegistryKeys.Contains("Protocols\Multi-Protocol Unified Hello\Server\DisabledByDefault") -eq $True -and $RegistryKeys.Contains("Protocols\Multi-Protocol Unified Hello\Server\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Protocols\Multi-Protocol Unified Hello\Server\DisabledByDefault") -eq "0xffffffff" -or 0 -and $RegistryKeys.Item("Protocols\Multi-Protocol Unified Hello\Server\Enabled") -eq 0) {
                $TLSstate.Mpuh_Server = "DISABLED      "
                $TLScolor.Mpuh_Server = "Green"
            } Else {
                $TLSstate.Mpuh_Server = "ENABLED       "
                $TLScolor.Mpuh_Server = "Red"
            }
        } Else {
            $TLSstate.Mpuh_Server = "Not Configured"
            $TLScolor.Mpuh_Server = "Yellow"
        }

        # Multi-Protocol Unified Hello Client- DISABLED

        If ($RegistryKeys.Contains("Protocols\Multi-Protocol Unified Hello\Client\DisabledByDefault") -eq $True -and $RegistryKeys.Contains("Protocols\Multi-Protocol Unified Hello\Client\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Protocols\Multi-Protocol Unified Hello\Client\DisabledByDefault") -eq "0xffffffff" -or 0 -and $RegistryKeys.Item("Protocols\Multi-Protocol Unified Hello\Client\Enabled") -eq 0) {
                $TLSstate.Mpuh_Client = "DISABLED      "
                $TLScolor.Mpuh_Client = "Green"
            } Else {
                $TLSstate.Mpuh_Client = "ENABLED       "
                $TLScolor.Mpuh_Client = "Red"
            }
        } Else {
            $TLSstate.Mpuh_Client = "Not Configured"
            $TLScolor.Mpuh_Client = "Yellow"
        }

        # PCT 1.0  Server- DISABLED

        If ($RegistryKeys.Contains("Protocols\PCT 1.0\Server\DisabledByDefault") -eq $True -and $RegistryKeys.Contains("Protocols\PCT 1.0\Server\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Protocols\PCT 1.0\Server\DisabledByDefault") -eq "0xffffffff" -or 0 -and $RegistryKeys.Item("Protocols\PCT 1.0\Server\Enabled") -eq 0) {
                $TLSstate.Pct_Server = "DISABLED      "
                $TLScolor.Pct_Server = "Green"
            } Else {
                $TLSstate.Pct_Server = "ENABLED       "
                $TLScolor.Pct_Server = "Red"
            }
        } Else {
            $TLSstate.Pct_Server = "Not Configured"
            $TLScolor.Pct_Server = "Yellow"
        }

        # PCT 1.0  Client- DISABLED

        If ($RegistryKeys.Contains("Protocols\PCT 1.0\Client\DisabledByDefault") -eq $True -and $RegistryKeys.Contains("Protocols\PCT 1.0\Client\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Protocols\PCT 1.0\Client\DisabledByDefault") -eq "0xffffffff" -or 0 -and $RegistryKeys.Item("Protocols\PCT 1.0\Client\Enabled") -eq 0) {
                $TLSstate.Pct_Client = "DISABLED      "
                $TLScolor.Pct_Client = "Green"
            } Else {
                $TLSstate.Pct_Client = "ENABLED       "
                $TLScolor.Pct_Client = "Red"
            }
        } Else {
            $TLSstate.Pct_Client = "Not Configured"
            $TLScolor.Pct_Client = "Yellow"
        }

        # SSL 2.0 Server - DISABLED

        If ($RegistryKeys.Contains("Protocols\SSL 2.0\Server\DisabledByDefault") -eq $True -and $RegistryKeys.Contains("Protocols\SSL 2.0\Server\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Protocols\SSL 2.0\Server\DisabledByDefault") -eq "0xffffffff" -and $RegistryKeys.Item("Protocols\SSL 2.0\Server\Enabled") -eq 0) {
                $TLSstate.SSLv2_Server = "DISABLED      "
                $TLScolor.SSLv2_Server = "Green"
            } Else {
                $TLSstate.SSLv2_Server = "ENABLED       "
                $TLScolor.SSLv2_Server = "Red"
            }
        } Else {
            $TLSstate.SSLv2_Server = "Not Configured"
            $TLScolor.SSLv2_Server = "Yellow"
        }

        # SSL 2.0 Client - DISABLED

        If ($RegistryKeys.Contains("Protocols\SSL 2.0\Client\DisabledByDefault") -eq $True -and $RegistryKeys.Contains("Protocols\SSL 2.0\Client\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Protocols\SSL 2.0\Client\DisabledByDefault") -eq "0xffffffff" -and $RegistryKeys.Item("Protocols\SSL 2.0\Client\Enabled") -eq 0) {
                $TLSstate.SSLv2_Client = "DISABLED      "
                $TLScolor.SSLv2_Client = "Green"
            } Else {
                $TLSstate.SSLv2_Client = "ENABLED       "
                $TLScolor.SSLv2_Client = "Red"
            }
        } Else {
            $TLSstate.SSLv2_Client = "Not Configured"
            $TLScolor.SSLv2_Client = "Yellow"
        }

        # SSL 3.0 Server - DISABLED

        If ($RegistryKeys.Contains("Protocols\SSL 3.0\Server\DisabledByDefault") -eq $True -and $RegistryKeys.Contains("Protocols\SSL 3.0\Server\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Protocols\SSL 3.0\Server\DisabledByDefault") -eq "0xffffffff" -and $RegistryKeys.Item("Protocols\SSL 3.0\Server\Enabled") -eq 0) {
                $TLSstate.SSLv3_Server = "DISABLED      "
                $TLScolor.SSLv3_Server = "Green"
            } Else {
                $TLSstate.SSLv3_Server = "ENABLED       "
                $TLScolor.SSLv3_Server = "Red"
            }
        } Else {
            $TLSstate.SSLv3_Server = "Not Configured"
            $TLScolor.SSLv3_Server = "Yellow"
        }

        # SSL 3.0 Client - DISABLED

        If ($RegistryKeys.Contains("Protocols\SSL 3.0\Client\DisabledByDefault") -eq $True -and $RegistryKeys.Contains("Protocols\SSL 3.0\Client\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Protocols\SSL 3.0\Client\DisabledByDefault") -eq "0xffffffff" -and $RegistryKeys.Item("Protocols\SSL 3.0\Client\Enabled") -eq 0) {
                $TLSstate.SSLv3_Client = "DISABLED      "
                $TLScolor.SSLv3_Client = "Green"
            } Else {
                $TLSstate.SSLv3_Client = "ENABLED       "
                $TLScolor.SSLv3_Client = "Red"
            }
        } Else {
            $TLSstate.SSLv3_Client = "Not Configured"
            $TLScolor.SSLv3_Client = "Yellow"
        }

        # TLS 1.0 Server - DISABLED

        If ($RegistryKeys.Contains("Protocols\TLS 1.0\Server\DisabledByDefault") -eq $True -and $RegistryKeys.Contains("Protocols\TLS 1.0\Server\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Protocols\TLS 1.0\Server\DisabledByDefault") -eq "0xffffffff" -and $RegistryKeys.Item("Protocols\TLS 1.0\Server\Enabled") -eq 0) {
                $TLSstate.TLSv1_0_Server = "DISABLED      "
                $TLScolor.TLSv1_0_Server = "Green"
            } Else {
                $TLSstate.TLSv1_0_Server = "ENABLED       "
                $TLScolor.TLSv1_0_Server = "Red"
            }
        } Else {
            $TLSstate.TLSv1_0_Server = "Not Configured"
            $TLScolor.TLSv1_0_Server = "Yellow"
        }

        # TLS 1.0 Client - DISABLED

        If ($RegistryKeys.Contains("Protocols\TLS 1.0\Client\DisabledByDefault") -eq $True -and $RegistryKeys.Contains("Protocols\TLS 1.0\Client\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Protocols\TLS 1.0\Client\DisabledByDefault") -eq "0xffffffff" -and $RegistryKeys.Item("Protocols\TLS 1.0\Client\Enabled") -eq 0) {
                $TLSstate.TLSv1_0_Client = "DISABLED      "
                $TLScolor.TLSv1_0_Client = "Green"
            } Else {
                $TLSstate.TLSv1_0_Client = "ENABLED       "
                $TLScolor.TLSv1_0_Client = "Red"
            }
        } Else {
            $TLSstate.TLSv1_0_Client = "Not Configured"
            $TLScolor.TLSv1_0_Client = "Yellow"
        }

        # TLS 1.1 Server - ENABLED

        If ($RegistryKeys.Contains("Protocols\TLS 1.1\Server\DisabledByDefault") -eq $True -and $RegistryKeys.Contains("Protocols\TLS 1.1\Server\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Protocols\TLS 1.1\Server\DisabledByDefault") -eq 0 -and $RegistryKeys.Item("Protocols\TLS 1.1\Server\Enabled") -eq "0xffffffff") {
                $TLSstate.TLSv1_1_Server = "ENABLED       "
                $TLScolor.TLSv1_1_Server = "Green"
            } Else {
                $TLSstate.TLSv1_1_Server = "DISABLED      "
                $TLScolor.TLSv1_1_Server = "Red"
            }
        } Else {
            $TLSstate.TLSv1_1_Server = "Not Configured"
            $TLScolor.TLSv1_1_Server = "Yellow"
        }

        # TLS 1.1 Client - ENABLED

        If ($RegistryKeys.Contains("Protocols\TLS 1.1\Client\DisabledByDefault") -eq $True -and $RegistryKeys.Contains("Protocols\TLS 1.1\Client\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Protocols\TLS 1.1\Client\DisabledByDefault") -eq 0 -and $RegistryKeys.Item("Protocols\TLS 1.1\Client\Enabled") -eq "0xffffffff") {
                $TLSstate.TLSv1_1_Client = "ENABLED       "
                $TLScolor.TLSv1_1_Client = "Green"
            } Else {
                $TLSstate.TLSv1_1_Client = "DISABLED      "
                $TLScolor.TLSv1_1_Client = "Red"
            }
        } Else {
            $TLSstate.TLSv1_1_Client = "Not Configured"
            $TLScolor.TLSv1_1_Client = "Yellow"
        }

        # TLS 1.2 Server - ENABLED

        If ($RegistryKeys.Contains("Protocols\TLS 1.2\Server\DisabledByDefault") -eq $True -and $RegistryKeys.Contains("Protocols\TLS 1.2\Server\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Protocols\TLS 1.2\Server\DisabledByDefault") -eq 0 -and $RegistryKeys.Item("Protocols\TLS 1.2\Server\Enabled") -eq "0xffffffff") {
                $TLSstate.TLSv1_2_Server = "ENABLED       "
                $TLScolor.TLSv1_2_Server = "Green"
            } Else {
                $TLSstate.TLSv1_2_Server = "DISABLED      "
                $TLScolor.TLSv1_2_Server = "Red"
            }
        } Else {
            $TLSstate.TLSv1_2_Server = "Not Configured"
            $TLScolor.TLSv1_2_Server = "Yellow"
        }

        # TLS 1.2 Client - ENABLED

        If ($RegistryKeys.Contains("Protocols\TLS 1.2\Client\DisabledByDefault") -eq $True -and $RegistryKeys.Contains("Protocols\TLS 1.2\Client\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Protocols\TLS 1.2\Client\DisabledByDefault") -eq 0 -and $RegistryKeys.Item("Protocols\TLS 1.2\Client\Enabled") -eq "0xffffffff") {
                $TLSstate.TLSv1_2_Client = "ENABLED       "
                $TLScolor.TLSv1_2_Client = "Green"
            } Else {
                $TLSstate.TLSv1_2_Client = "DISABLED      "
                $TLScolor.TLSv1_2_Client = "Red"
            }
        } Else {
            $TLSstate.TLSv1_2_Client = "Not Configured"
            $TLScolor.TLSv1_2_Client = "Yellow"
        }

        # Cipher NULL - DISABLED

        If ($RegistryKeys.Contains("Ciphers\NULL\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Ciphers\NULL\Enabled") -eq 0) {
                $TLSstate.CipherNULL = "DISABLED      "
                $TLScolor.CipherNULL = "Green"
            } Else {
                $TLSstate.CipherNULL = "ENABLED       "
                $TLScolor.CipherNULL = "Red"
            }
        } Else {
            $TLSstate.CipherNULL = "Not Configured"
            $TLScolor.CipherNULL = "Yellow"
        }

        # Cipher DES 56\56 - DISABLED

        If ($RegistryKeys.Contains("Ciphers\DES 56\56\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Ciphers\DES 56\56\Enabled") -eq 0) {
                $TLSstate.CipherDES_5656 = "DISABLED      "
                $TLScolor.CipherDES_5656 = "Green"
            } Else {
                $TLSstate.CipherDES_5656 = "ENABLED       "
                $TLScolor.CipherDES_5656 = "Red"
            }
        } Else {
            $TLSstate.CipherDES_5656 = "Not Configured"
            $TLScolor.CipherDES_5656 = "Yellow"
        }

        # Cipher RC2 40\128 - DISABLED

        If ($RegistryKeys.Contains("Ciphers\RC2 40\128\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Ciphers\RC2 40\128\Enabled") -eq 0) {
                $TLSstate.CipherRC2_40128 = "DISABLED      "
                $TLScolor.CipherRC2_40128 = "Green"
            } Else {
                $TLSstate.CipherRC2_40128 = "ENABLED       "
                $TLScolor.CipherRC2_40128 = "Red"
            }
        } Else {
            $TLSstate.CipherRC2_40128 = "Not Configured"
            $TLScolor.CipherRC2_40128 = "Yellow"
        }

        # Cipher RC2 56\128 - DISABLED

        If ($RegistryKeys.Contains("Ciphers\RC2 56\128\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Ciphers\RC2 56\128\Enabled") -eq 0) {
                $TLSstate.CipherRC2_56128 = "DISABLED      "
                $TLScolor.CipherRC2_56128 = "Green"
            } Else {
                $TLSstate.CipherRC2_56128 = "ENABLED       "
                $TLScolor.CipherRC2_56128 = "Red"
            }
        } Else {
            $TLSstate.CipherRC2_56128 = "Not Configured"
            $TLScolor.CipherRC2_56128 = "Yellow"
        }

        # Cipher RC2 128\128 - DISABLED

        If ($RegistryKeys.Contains("Ciphers\RC2 128\128\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Ciphers\RC2 128\128\Enabled") -eq 0) {
                $TLSstate.CipherRC2_128128 = "DISABLED      "
                $TLScolor.CipherRC2_128128 = "Green"
            } Else {
                $TLSstate.CipherRC2_128128 = "ENABLED       "
                $TLScolor.CipherRC2_128128 = "Red"
            }
        } Else {
            $TLSstate.CipherRC2_128128 = "Not Configured"
            $TLScolor.CipherRC2_128128 = "Yellow"
        }

        # Cipher RC4 40\128 - DISABLED

        If ($RegistryKeys.Contains("Ciphers\RC4 40\128\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Ciphers\RC4 40\128\Enabled") -eq 0) {
                $TLSstate.CipherRC4_40128 = "DISABLED      "
                $TLScolor.CipherRC4_40128 = "Green"
            } Else {
                $TLSstate.CipherRC4_40128 = "ENABLED       "
                $TLScolor.CipherRC4_40128 = "Red"
            }
        } Else {
            $TLSstate.CipherRC4_40128 = "Not Configured"
            $TLScolor.CipherRC4_40128 = "Yellow"
        }

        # Cipher RC4 56\128 - DISABLED

        If ($RegistryKeys.Contains("Ciphers\RC4 56\128\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Ciphers\RC4 56\128\Enabled") -eq 0) {
                $TLSstate.CipherRC4_56128 = "DISABLED      "
                $TLScolor.CipherRC4_56128 = "Green"
            } Else {
                $TLSstate.CipherRC4_56128 = "ENABLED       "
                $TLScolor.CipherRC4_56128 = "Red"
            }
        } Else {
            $TLSstate.CipherRC4_56128 = "Not Configured"
            $TLScolor.CipherRC4_56128 = "Yellow"
        }

        # Cipher RC4 64\128 - DISABLED

        If ($RegistryKeys.Contains("Ciphers\RC4 64\128\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Ciphers\RC4 64\128\Enabled") -eq 0) {
                $TLSstate.CipherRC4_64128 = "DISABLED      "
                $TLScolor.CipherRC4_64128 = "Green"
            } Else {
                $TLSstate.CipherRC4_64128 = "ENABLED       "
                $TLScolor.CipherRC4_64128 = "Red"
            }
        } Else {
            $TLSstate.CipherRC4_64128 = "Not Configured"
            $TLScolor.CipherRC4_64128 = "Yellow"
        }

        # Cipher RC4 128\128 - DISABLED

        If ($RegistryKeys.Contains("Ciphers\RC4 128\128\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Ciphers\RC4 128\128\Enabled") -eq 0) {
                $TLSstate.CipherRC4_128128 = "DISABLED      "
                $TLScolor.CipherRC4_128128 = "Green"
            } Else {
                $TLSstate.CipherRC4_128128 = "ENABLED       "
                $TLScolor.CipherRC4_128128 = "Red"
            }
        } Else {
            $TLSstate.CipherRC4_128128 = "Not Configured"
            $TLScolor.CipherRC4_128128 = "Yellow"
        }

        # Cipher Triple DES 168 - DISABLED

        If ($RegistryKeys.Contains("Ciphers\Triple DES 168\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Ciphers\Triple DES 168\Enabled") -eq 0) {
                $TLSstate.CipherTriple_DES168 = "DISABLED      "
                $TLScolor.CipherTriple_DES168 = "Green"
            } Else {
                $TLSstate.CipherTriple_DES168 = "ENABLED       "
                $TLScolor.CipherTriple_DES168 = "Red"
            }
        } Else {
            $TLSstate.CipherTriple_DES168 = "Not Configured"
            $TLScolor.CipherTriple_DES168 = "Yellow"
        }

        # Cipher AES 128\128 - ENABLED

        If ($RegistryKeys.Contains("Ciphers\AES 128\128\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Ciphers\AES 128\128\Enabled") -eq "0xffffffff") {
                $TLSstate.CipherAES_128128 = "ENABLED       "
                $TLScolor.CipherAES_128128 = "Green"
            } Else {
                $TLSstate.CipherAES_128128 = "DISABLED      "
                $TLScolor.CipherAES_128128 = "Red"
            }
        } Else {
            $TLSstate.CipherAES_128128 = "Not Configured"
            $TLScolor.CipherAES_128128 = "Yellow"
        }

        # Cipher AES 256\256 - ENABLED

        If ($RegistryKeys.Contains("Ciphers\AES 256\256\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Ciphers\AES 256\256\Enabled") -eq "0xffffffff") {
                $TLSstate.CipherAES_256256 = "ENABLED       "
                $TLScolor.CipherAES_256256 = "Green"
            } Else {
                $TLSstate.CipherAES_256256 = "DISABLED      "
                $TLScolor.CipherAES_256256 = "Red"
            }
        } Else {
            $TLSstate.CipherAES_256256 = "Not Configured"
            $TLScolor.CipherAES_256256 = "Yellow"
        }

        # Hash MD5 - DISABLED

        If ($RegistryKeys.Contains("Hashes\MD5\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Hashes\MD5\Enabled") -eq 0) {
                $TLSstate.HashMD5 = "DISABLED      "
                $TLScolor.HashMD5 = "Green"
            } Else {
                $TLSstate.HashMD5 = "ENABLED       "
                $TLScolor.HashMD5 = "Red"
            }
        } Else {
            $TLSstate.HashMD5 = "Not Configured"
            $TLScolor.HashMD5 = "Yellow"
        }

        # Hash SHA - ENABLED

        If ($RegistryKeys.Contains("Hashes\SHA\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Hashes\SHA\Enabled") -eq "0xffffffff") {
                $TLSstate.HashSHA = "ENABLED       "
                $TLScolor.HashSHA = "Green"
            } Else {
                $TLSstate.HashSHA = "DISABLED      "
                $TLScolor.HashSHA = "Red"
            }
        } Else {
            $TLSstate.HashSHA = "Not Configured"
            $TLScolor.HashSHA = "Yellow"
        }

        # Hash SHA256 - ENABLED

        If ($RegistryKeys.Contains("Hashes\SHA256\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Hashes\SHA256\Enabled") -eq "0xffffffff") {
                $TLSstate.HashSHA256 = "ENABLED       "
                $TLScolor.HashSHA256 = "Green"
            } Else {
                $TLSstate.HashSHA256 = "DISABLED      "
                $TLScolor.HashSHA256 = "Red"
            }
        } Else {
            $TLSstate.HashSHA256 = "Not Configured"
            $TLScolor.HashSHA256 = "Yellow"
        }

        # Hash SHA384 - ENABLED

        If ($RegistryKeys.Contains("Hashes\SHA384\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Hashes\SHA384\Enabled") -eq "0xffffffff") {
                $TLSstate.HashSHA384 = "ENABLED       "
                $TLScolor.HashSHA384 = "Green"
            } Else {
                $TLSstate.HashSHA384 = "DISABLED      "
                $TLScolor.CipherAES_256256 = "Red"
            }
        } Else {
            $TLSstate.HashSHA384 = "Not Configured"
            $TLScolor.HashSHA384 = "Yellow"
        }

        # Hash SHA512 - ENABLED

        If ($RegistryKeys.Contains("Hashes\SHA512\Enabled") -eq $True) {
            If ($RegistryKeys.Item("Hashes\SHA512\Enabled") -eq "0xffffffff") {
                $TLSstate.HashSHA512 = "ENABLED       "
                $TLScolor.HashSHA512 = "Green"
            } Else {
                $TLSstate.HashSHA512 = "DISABLED      "
                $TLScolor.HashSHA512 = "Red"
            }
        } Else {
            $TLSstate.HashSHA512 = "Not Configured"
            $TLScolor.HashSHA512 = "Yellow"
        }

        # KeyExchangeAlgorithm Diffie-Hellman - ENABLED

        If ($RegistryKeys.Contains("KeyExchangeAlgorithms\Diffie-Hellman\Enabled") -eq $True) {
            If ($RegistryKeys.Item("KeyExchangeAlgorithms\Diffie-Hellman\Enabled") -eq "0xffffffff") {
                $TLSstate.KEA_Diffie = "ENABLED       "
                $TLScolor.KEA_Diffie = "Green"
            } Else {
                $TLSstate.KEA_Diffie = "DISABLED      "
                $TLScolor.KEA_Diffie = "Red"
            }
        } Else {
            $TLSstate.KEA_Diffie = "Not Configured"
            $TLScolor.KEA_Diffie = "Yellow"
        }

        # KeyExchangeAlgorithm ECDH - ENABLED

        If ($RegistryKeys.Contains("KeyExchangeAlgorithms\ECDH\Enabled") -eq $True) {
            If ($RegistryKeys.Item("KeyExchangeAlgorithms\ECDH\Enabled") -eq "0xffffffff") {
                $TLSstate.KEA_ECDH = "ENABLED       "
                $TLScolor.KEA_ECDH = "Green"
            } Else {
                $TLSstate.KEA_ECDH = "DISABLED      "
                $TLScolor.KEA_ECDH = "Red"
            }
        } Else {
            $TLSstate.KEA_ECDH = "Not Configured"
            $TLScolor.KEA_ECDH = "Yellow"
        }

        # KeyExchangeAlgorithm PKCS - ENABLED

        If ($RegistryKeys.Contains("KeyExchangeAlgorithms\PKCS\Enabled") -eq $True) {
            If ($RegistryKeys.Item("KeyExchangeAlgorithms\PKCS\Enabled") -eq "0xffffffff") {
                $TLSstate.KEA_PKCS = "ENABLED       "
                $TLScolor.KEA_PKCS = "Green"
            } Else {
                $TLSstate.KEA_PKCS = "DISABLED      "
                $TLScolor.KEA_PKCS = "Red"
            }
        } Else {
            $TLSstate.KEA_PKCS = "Not Configured"
            $TLScolor.KEA_PKCS = "Yellow"
        }

        # cipher suites order as secure as possible (Enables Perfect Forward Secrecy)

        $os = Get-WmiObject -class Win32_OperatingSystem
        if ([System.Version]$os.Version -lt [System.Version]'10.0') {

            $ExpectedCipherSuitesOrder = @(
                'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P521',
                'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P384',
                'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P256',
                'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P521',
                'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P384',
                'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P256',
                'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P521',
                'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P384',
                'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P256',
                'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P521',
                'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P384',
                'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P256',
                'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384_P521',
                'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384_P384',
                'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P521',
                'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P384',
                'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P256',
                'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384_P521',
                'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384_P384',
                'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P521',
                'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P384',
                'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P256',
                'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P521',
                'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P384',
                'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P256',
                'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P521',
                'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P384',
                'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P256',
                'TLS_RSA_WITH_AES_256_GCM_SHA384',
                'TLS_RSA_WITH_AES_128_GCM_SHA256',
                'TLS_RSA_WITH_AES_256_CBC_SHA256',
                'TLS_RSA_WITH_AES_128_CBC_SHA256',
                'TLS_RSA_WITH_AES_256_CBC_SHA',
                'TLS_RSA_WITH_AES_128_CBC_SHA'
            )
        } else {

            $ExpectedCipherSuitesOrder = @(
                'TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384',
                'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256',
                'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384',
                'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256',
                'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA',
                'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA',
                'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384',
                'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256',
                'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384',
                'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256',
                'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA',
                'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA',
                'TLS_RSA_WITH_AES_256_GCM_SHA384',
                'TLS_RSA_WITH_AES_128_GCM_SHA256',
                'TLS_RSA_WITH_AES_256_CBC_SHA256',
                'TLS_RSA_WITH_AES_128_CBC_SHA256',
                'TLS_RSA_WITH_AES_256_CBC_SHA',
                'TLS_RSA_WITH_AES_128_CBC_SHA'
            )
        }

        $CurrentCipherSuitesOrder = @(((Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002').PSObject.Properties | Where-Object {$_.Name -notlike "ps*"} | Select-Object Value).Value -Split ",")

        If ($CurrentCipherSuitesOrder -ne $Null) {
            $CipherSuitesEqual = @(Compare-Object $ExpectedCipherSuitesOrder $CurrentCipherSuitesOrder -SyncWindow 0).Length -eq 0
            If ($CipherSuitesEqual -eq $True) {
                $TLSstate.CipherOrder = "Correct Order "
                $TLScolor.CipherOrder = "Green"
            } Else {
                $TLSstate.CipherOrder = "Incorrect Order"
                $TLScolor.CipherOrder = "Red"
            }
        } Else {
            $TLSstate.CipherOrder = "Not Configured"
            $TLScolor.CipherOrder = "Yellow"
        }


        If ($sVebose) {
            $RegistryKeys.GetEnumerator() | Format-Table -Auto
        }

    }
}

Function Show-TLSsettings() {


    Write-Host ""

    Write-host "             Protocols             " -NoNewline -ForegroundColor White -BackgroundColor Blue
    Write-Host "  " -NoNewline
    Write-host "              Ciphers              " -NoNewline -ForegroundColor White -BackgroundColor Blue
    Write-Host "  " -NoNewline
    Write-host "       Hashes and Algorithms       " -ForegroundColor White -BackgroundColor Blue
    Write-Host " "

    Write-Host "Multi-Protocol Unified Hello       " -NoNewline -ForegroundColor White
    Write-Host "  " -NoNewline
    Write-Host "Insecure \ Weak Ciphers            " -NoNewline -ForegroundColor White
    Write-Host "  " -NoNewline
    Write-Host "Hashes                             " -ForegroundColor White

    Write-Host "    Server         :" $TLSstate.Mpuh_Server -NoNewline -ForegroundColor $TLScolor.Mpuh_Server
    Write-Host "  " -NoNewline
    Write-Host "    Null           :" $TLSstate.CipherNULL -NoNewline -ForegroundColor $TLScolor.CipherNULL
    Write-Host "  " -NoNewline
    Write-Host "    MD5            :" $TLSstate.HashMD5 -ForegroundColor $TLScolor.HashMD5

    Write-Host "    Client         :" $TLSstate.Mpuh_Client -NoNewline -ForegroundColor $TLScolor.Mpuh_Client
    Write-Host "  " -NoNewline
    Write-Host "    DES 56\56      :" $TLSstate.CipherDES_5656 -NoNewline -ForegroundColor $TLScolor.CipherDES_5656
    Write-Host "  " -NoNewline
    Write-Host "    SHA            :" $TLSstate.HashSHA -ForegroundColor $TLScolor.HashSHA

    Write-Host "PCT v1.0                           " -NoNewline -ForegroundColor White
    Write-Host "  " -NoNewline
    Write-Host "    RC2 40\128     :" $TLSstate.CipherRC2_40128 -NoNewline -ForegroundColor $TLScolor.CipherRC2_40128
    Write-Host "  " -NoNewline
    Write-Host "    SHA256         :" $TLSstate.HashSHA256 -ForegroundColor $TLScolor.HashSHA256

    Write-Host "    Server         :" $TLSstate.Pct_Server -NoNewline -ForegroundColor $TLScolor.Pct_Server
    Write-Host "  " -NoNewline
    Write-Host "    RC2 56\128     :" $TLSstate.CipherRC2_56128 -NoNewline -ForegroundColor $TLScolor.CipherRC2_56128
    Write-Host "  " -NoNewline
    Write-Host "    SHA384         :" $TLSstate.HashSHA384 -ForegroundColor $TLScolor.HashSHA384

    Write-Host "    Client         :" $TLSstate.Pct_Client -NoNewline -ForegroundColor $TLScolor.Pct_Client
    Write-Host "  " -NoNewline
    Write-Host "    RC2 128\128    :" $TLSstate.CipherRC2_128128 -NoNewline -ForegroundColor $TLScolor.CipherRC2_128128
    Write-Host "  " -NoNewline
    Write-Host "    SHA512         :" $TLSstate.HashSHA512 -ForegroundColor $TLScolor.HashSHA512

    Write-Host "SSL v2.0                           " -NoNewline -ForegroundColor White
    Write-Host "  " -NoNewline
    Write-Host "    RC4 40\128     :" $TLSstate.CipherRC4_40128 -NoNewline -ForegroundColor $TLScolor.CipherRC4_40128
    Write-Host "  " -NoNewline
    Write-Host "Key Exchange Algorithms            " -ForegroundColor White

    Write-Host "    Server         :" $TLSstate.SSLv2_Server -NoNewline -ForegroundColor $TLScolor.SSLv2_Server
    Write-Host "  " -NoNewline
    Write-Host "    RC4 56\128     :" $TLSstate.CipherRC4_56128 -NoNewline -ForegroundColor $TLScolor.CipherRC4_56128
    Write-Host "  " -NoNewline
    Write-Host "    Diffie-Hellman :" $TLSstate.KEA_Diffie -ForegroundColor $TLScolor.KEA_Diffie

    Write-Host "    Client         :" $TLSstate.SSLv2_Client -NoNewline -ForegroundColor $TLScolor.SSLv2_Client
    Write-Host "  " -NoNewline
    Write-Host "    RC4 64\128     :" $TLSstate.CipherRC4_64128 -NoNewline -ForegroundColor $TLScolor.CipherRC4_64128
    Write-Host "  " -NoNewline
    Write-Host "    ECDH           :" $TLSstate.KEA_ECDH -ForegroundColor $TLScolor.KEA_ECDH

    Write-Host "SSL v3.0                           " -NoNewline -ForegroundColor White
    Write-Host "  " -NoNewline
    Write-Host "    RC4 128\128    :" $TLSstate.CipherRC4_128128 -NoNewline -ForegroundColor $TLScolor.CipherRC4_128128
    Write-Host "  " -NoNewline
    Write-Host "    PKCS           :" $TLSstate.KEA_PKCS -ForegroundColor $TLScolor.KEA_PKCS

    Write-Host "    Server         :" $TLSstate.SSLv3_Server -NoNewline -ForegroundColor $TLScolor.SSLv3_Server
    Write-Host "  " -NoNewline
    Write-Host "    Triple DES 168 :" $TLSstate.CipherTriple_DES168 -ForegroundColor $TLScolor.CipherTriple_DES168

    Write-Host "    Client         :" $TLSstate.SSLv3_Client -NoNewline -ForegroundColor $TLScolor.SSLv3_Client
    Write-Host "  " -NoNewline
    Write-Host "Secure \ Strong Ciphers            " -ForegroundColor White

    Write-Host "TLS v1.0                           " -NoNewline -ForegroundColor White
    Write-Host "  " -NoNewline
    Write-Host "    AES 128\128    :" $TLSstate.CipherAES_128128 -ForegroundColor $TLScolor.CipherAES_128128

    Write-Host "    Server         :" $TLSstate.TLSv1_0_Server -NoNewline -ForegroundColor $TLScolor.TLSv1_0_Server
    Write-Host "  " -NoNewline
    Write-Host "    AES 256\256    :" $TLSstate.CipherAES_256256 -ForegroundColor $TLScolor.CipherAES_256256

    Write-Host "    Client         :" $TLSstate.TLSv1_0_Client -NoNewline -ForegroundColor $TLScolor.TLSv1_0_Client
    Write-Host "  " -NoNewline
    Write-Host "Cipher Suites Order                " -ForegroundColor White

    Write-Host "TLS v1.1                           " -NoNewline -ForegroundColor White
    Write-Host "  " -NoNewline
    Write-Host "    Cipher Order   :" $TLSstate.CipherOrder -ForegroundColor $TLScolor.CipherOrder

    Write-Host "    Server         :" $TLSstate.TLSv1_1_Server  -ForegroundColor $TLScolor.TLSv1_1_Server

    Write-Host "    Client         :" $TLSstate.TLSv1_1_Client -ForegroundColor $TLScolor.TLSv1_1_Client

    Write-Host "TLS v1.2                           " -ForegroundColor White

    Write-Host "    Server         :" $TLSstate.TLSv1_2_Server -ForegroundColor $TLScolor.TLSv1_2_Server

    Write-Host "    Client         :" $TLSstate.TLSv1_2_Client -ForegroundColor $TLScolor.TLSv1_2_Client

    Write-Host "  "
    Write-Host "  "

}

Function Set-Enable_FAstandard {

    If ($Force) {
        Write-LogInfo -LogPath $sFullPath -Message '---------------------------------------------------------------------------------------------------'
        Write-LogInfo -LogPath $sFullPath -Message '           Configuring TLS Protocols, Ciphers, Hashes & Algorithms to Best Prcatice...'
        Write-LogInfo -LogPath $sFullPath -Message '---------------------------------------------------------------------------------------------------'
    } Else {
        Write-Host ''
        Write-LogInfo -LogPath $sFullPath -ToScreen -Color "White" -Message '---------------------------------------------------------------------------------------------------'
        Write-LogInfo -LogPath $sFullPath -ToScreen -Color "Green" -Message '           Configuring TLS Protocols, Ciphers, Hashes & Algorithms to Best Prcatice...'
        Write-LogInfo -LogPath $sFullPath -ToScreen -Color "White" -Message '---------------------------------------------------------------------------------------------------'
    }

    # Disable Multi-Protocol Unified Hello
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

    If ($Force) {
        Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "Multi-Protocol Unified Hello Server has been disabled."
    } Else {
        Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "Multi-Protocol Unified Hello Server has been disabled."
    }

    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Client' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Client' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Client' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

    If ($Force) {
        Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "Multi-Protocol Unified Hello Client has been disabled."
    } Else {
        Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "Multi-Protocol Unified Hello Client has been disabled."
    }

    # Disable PCT 1.0
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

    If ($Force) {
        Write-LogInfo -LogPath $sFullPath  -TimeStamp -Message "PCT 1.0 Server has been disabled."
    } Else {
        Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "PCT 1.0 Server has been disabled."
    }

    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Client' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Client' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Client' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

    If ($Force) {
        Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "PCT 1.0 Client has been disabled."
    } Else {
        Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "PCT 1.0 Client has been disabled."
    }

    # Disable SSL 2.0 (PCI Compliance)
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

    If ($Force) {
        Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "SSL 2.0 Server has been disabled."
    } Else {
        Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "SSL 2.0 Server has been disabled."
    }

    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

    If ($Force) {
        Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "SSL 2.0 Client has been disabled."
    } Else {
        Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "SSL 2.0 Client has been disabled."
    }

    # Disable SSL 3.0 (PCI Compliance) and enable "Poodle" protection
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

    If ($Force) {
        Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "SSL 3.0 Server has been disabled."
    } Else {
        Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "SSL 3.0 Server has been disabled."
    }

    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Client' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

    If ($Force) {
        Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "SSL 3.0 Server has been disabled."
    } Else {
        Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "SSL 3.0 Server has been disabled."
    }

    # Add and Enable TLS 1.0 for client and server SCHANNEL communications
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -name 'Enabled' -value 0 -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

    If ($Force) {
        Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "TLS 1.0 Server has been disabled."
    } Else {
        Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "TLS 1.0 Server has been disabled."
    }


    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -name 'Enabled' -value 0 -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

    If ($Force) {
        Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "TLS 1.0 Client has been disabled."
    } Else {
        Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "TLS 1.0 Client has been disabled."
    }

    # Add and Enable TLS 1.1 for client and server SCHANNEL communications
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null

    If ($Force) {
        Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "TLS 1.1 Server has been enabled."
    } Else {
        Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "TLS 1.1 Server has been enabled."
    }

    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null

    If ($Force) {
        Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "TLS 1.1 Client has been enabled."
    } Else {
        Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "TLS 1.1 Client has been enabled."
    }

    # Add and Enable TLS 1.2 for client and server SCHANNEL communications
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null

    If ($Force) {
        Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "TLS 1.2 Server has been enabled."
    } Else {
        Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "TLS 1.2 Server has been enabled."
    }

    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null

    If ($Force) {
        Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "TLS 1.2 Client has been enabled."
    } Else {
        Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "TLS 1.2 Client has been enabled."
    }

    # Re-create the ciphers key.
    New-Item 'HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers' -Force | Out-Null

    # Disable insecure/weak ciphers.
    $insecureCiphers = @(
        'NULL',
        'DES 56/56',
        'RC2 128/128',
        'RC2 40/128',
        'RC2 56/128',
        'RC4 40/128',
        'RC4 56/128',
        'RC4 64/128',
        'RC4 128/128',
        'Triple DES 168'
    )
    Foreach ($insecureCipher in $insecureCiphers) {
        $key = (Get-Item HKLM:\).OpenSubKey('SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers', $true).CreateSubKey($insecureCipher)
        $key.SetValue('Enabled', 0, 'DWord')
        $key.close()

        If ($Force) {
            Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "Weak cipher $insecureCipher has been disabled."
        } Else {
            Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "Weak cipher $insecureCipher has been disabled."
        }
    }

    # Enable new secure ciphers.

    $secureCiphers = @(
        'AES 128/128',
        'AES 256/256'
    )
    Foreach ($secureCipher in $secureCiphers) {
        $key = (Get-Item HKLM:\).OpenSubKey('SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers', $true).CreateSubKey($secureCipher)
        New-ItemProperty -path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\$secureCipher" -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
        $key.close()

        If ($Force) {
            Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "Strong cipher $secureCipher has been enabled."
        } Else {
            Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "Strong cipher $secureCipher has been enabled."
        }
    }

    # Set hashes configuration.
    New-Item 'HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes' -Force | Out-Null
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\MD5' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\MD5' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null

    If ($Force) {
        Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "Hash MD5 has been disabled."
    } Else {
        Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "Hash MD5 has been disabled."
    }

    $secureHashes = @(
        'SHA',
        'SHA256',
        'SHA384',
        'SHA512'
    )
    Foreach ($secureHash in $secureHashes) {
        $key = (Get-Item HKLM:\).OpenSubKey('SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes', $true).CreateSubKey($secureHash)
        New-ItemProperty -path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\$secureHash" -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
        $key.close()

        If ($Force) {
            Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "Hash $secureHash has been enabled."
        } Else {
            Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "Hash $secureHash has been enabled."
        }
    }

    # Set KeyExchangeAlgorithms configuration.
    New-Item 'HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms' -Force | Out-Null
    $secureKeyExchangeAlgorithms = @(
        'Diffie-Hellman',
        'ECDH',
        'PKCS'
    )
    Foreach ($secureKeyExchangeAlgorithm in $secureKeyExchangeAlgorithms) {
        $key = (Get-Item HKLM:\).OpenSubKey('SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms', $true).CreateSubKey($secureKeyExchangeAlgorithm)
        New-ItemProperty -path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\$secureKeyExchangeAlgorithm" -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
        $key.close()

        If ($Force) {
            Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "KeyExchangeAlgorithm $secureKeyExchangeAlgorithm has been enabled."
        } Else {
            Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "KeyExchangeAlgorithm $secureKeyExchangeAlgorithm has been enabled."
        }
    }

    # Set cipher suites order as secure as possible (Enables Perfect Forward Secrecy).
    $os = Get-WmiObject -class Win32_OperatingSystem
    if ([System.Version]$os.Version -lt [System.Version]'10.0') {

        If ($Force) {
            Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "Use cipher suites order for Windows 2008/2008R2/2012/2012R2."
        } Else {
            Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "Use cipher suites order for Windows 2008/2008R2/2012/2012R2."
        }
        $cipherSuitesOrder = @(
            'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P521',
            'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P384',
            'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P256',
            'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P521',
            'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P384',
            'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P256',
            'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P521',
            'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P384',
            'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P256',
            'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P521',
            'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P384',
            'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P256',
            'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384_P521',
            'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384_P384',
            'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P521',
            'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P384',
            'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P256',
            'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384_P521',
            'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384_P384',
            'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P521',
            'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P384',
            'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P256',
            'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P521',
            'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P384',
            'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P256',
            'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P521',
            'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P384',
            'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P256',
            'TLS_RSA_WITH_AES_256_GCM_SHA384',
            'TLS_RSA_WITH_AES_128_GCM_SHA256',
            'TLS_RSA_WITH_AES_256_CBC_SHA256',
            'TLS_RSA_WITH_AES_128_CBC_SHA256',
            'TLS_RSA_WITH_AES_256_CBC_SHA',
            'TLS_RSA_WITH_AES_128_CBC_SHA'
        )
    } else {

        If ($Force) {
            Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "Using cipher suites order for Windows 2016 and later."

        } Else {
            Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Green" -Message "Using cipher suites order for Windows 2016 and later."

        }
        $cipherSuitesOrder = @(
            'TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384',
            'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256',
            'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384',
            'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256',
            'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA',
            'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA',
            'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384',
            'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256',
            'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384',
            'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256',
            'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA',
            'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA',
            'TLS_RSA_WITH_AES_256_GCM_SHA384',
            'TLS_RSA_WITH_AES_128_GCM_SHA256',
            'TLS_RSA_WITH_AES_256_CBC_SHA256',
            'TLS_RSA_WITH_AES_128_CBC_SHA256',
            'TLS_RSA_WITH_AES_256_CBC_SHA',
            'TLS_RSA_WITH_AES_128_CBC_SHA'
        )
    }

    $cipherSuitesAsString = [string]::join(',', $cipherSuitesOrder)
    # One user reported this key does not exists on Windows 2012R2. Cannot repro myself on a brand new Windows 2012R2 core machine. Adding this just to be save.
    New-Item 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' -ErrorAction SilentlyContinue
    New-ItemProperty -path 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' -name 'Functions' -value $cipherSuitesAsString -PropertyType 'String' -Force | Out-Null

}

Function Set-Enable_tls10_server {

    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null

    Write-Host ''
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "DarkGray" -Message '---------------------------------------------------------------------------------------------------'
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "Red" -Message '                       TLS 1.0 Protocal for Server has been Enabled....'
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "DarkGray" -Message '---------------------------------------------------------------------------------------------------'

}

Function Set-Enable_tls10_client {

    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null

    Write-Host ''
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "White" -Message '---------------------------------------------------------------------------------------------------'
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "Red" -Message '                       TLS 1.0 Protocal for Client has been Enabled....'
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "White" -Message '---------------------------------------------------------------------------------------------------'

}

Function Set-Disable_tls10_server {

    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -name 'Enabled' -value 0 -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

    Write-Host ''
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "White" -Message '---------------------------------------------------------------------------------------------------'
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "Green" -Message '                       TLS 1.0 Protocal for Server has been Disabled....'
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "White" -Message '---------------------------------------------------------------------------------------------------'

}

Function Set-Disable_tls10_client {

    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -name 'Enabled' -value 0 -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Client' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
    Write-Host ''
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "White" -Message '---------------------------------------------------------------------------------------------------'
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "Green" -Message '                       TLS 1.0 Protocal for Client has been Disabled....'
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "White" -Message '---------------------------------------------------------------------------------------------------'

}

Function OsTlsDefault {

    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "White" -Message "--------------------------------------------------------------------------------------"
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "Red" -Message "              ** Resetting TLS to WEAK and INSECURE Defaults **"
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "White" -Message "--------------------------------------------------------------------------------------"

    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers' -Force > $null
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\CipherSuites' -Force > $null
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes' -Force > $null
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms' -Force > $null
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols' -Force > $null

    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client' -Force > $null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Client' -name DisabledByDefault -value 1 -PropertyType 'DWord' > $null

    New-Item 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' -Force > $null

    Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Red" -Message "All Ciphers Cleared"
    Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Red" -Message "All CipherSuites Cleared"
    Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Red" -Message "All Hashes Cleared"
    Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Red" -Message "All KeyExchangeAlgorithms Cleared"
    Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Red" -Message "All Protocols Cleared"
    Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Red" -Message "Deafult SSLv2 Enabled"
    Write-LogInfo -LogPath $sFullPath -ToScreen -TimeStamp -Color "Red" -Message "CipherSuite Order Cleared"

    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "White" -Message "--------------------------------------------------------------------------------------"
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "Red" -Message "        ** TLS Security Settings have been set to WEAK and INSECURE Defaults **"
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "White" -Message "--------------------------------------------------------------------------------------"



}

Function Show-RebootMessage {

    If (!$Force) {

  #      Write-Host ''
        Write-Host '-------------------------------------------------------------------------------------------------------------' -ForegroundColor White
        Write-Host ''
        Write-Host '                   NOTE: The below settings will be applied after you reboot the server' -ForegroundColor Yellow
        Write-Host ''
        Write-Host '-------------------------------------------------------------------------------------------------------------' -ForegroundColor White
        Write-Host ''

    }

}


Start-Log -LogPath $sFullPath -ScriptVersion $ScriptVersion -CmdLine $sCmdLine


If ($Show) {

    Write-LogInfo -LogPath $sFullPath -TimeStamp -Message ' '
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "White" -Message '-------------------------------------------------------------------------------------------------------------'
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "Cyan" -Message '                       Current Server TLS Protocols, Ciphers, Hashes & Algorithms...'
    Write-LogInfo -LogPath $sFullPath -ToScreen -Color "White" -Message '-------------------------------------------------------------------------------------------------------------'

    Get-RegKeys
    Show-TLSsettings

    $CurrentKeys = $RegistryKeys.GetEnumerator() | Format-Table -Auto | Out-String
    Write-LogInfo -LogPath $sFullPath -Message $CurrentKeys

}

If ($Enable_FAstandard) {
    Set-Enable_FAstandard

    Show-RebootMessage
    Get-RegKeys
    Show-TLSsettings

    Write-LogInfo -LogPath $sFullPath -Message "  "
    Write-LogInfo -LogPath $sFullPath -Message "Current Registry Settings..."

    $CurrentKeys = $RegistryKeys.GetEnumerator() | Format-Table -Auto | Out-String
    Write-LogInfo -LogPath $sFullPath -Message $CurrentKeys


}

If ($TLS10_Enable_Server) {

    Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "TLS1.0 Server Settings Enabled"

    Set-Enable_tls10_server

    Show-RebootMessage
    Get-RegKeys
    Show-TLSsettings

    $CurrentKeys = $RegistryKeys.GetEnumerator() | Format-Table -Auto | Out-String
    Write-LogInfo -LogPath $sFullPath -Message $CurrentKeys

}

If ($TLS10_Enable_Client) {

    Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "TLS1.0 Client Settings Enabled"

    Set-Enable_tls10_client

    Show-RebootMessage
    Get-RegKeys
    Show-TLSsettings


    $CurrentKeys = $RegistryKeys.GetEnumerator() | Format-Table -Auto | Out-String
    Write-LogInfo -LogPath $sFullPath -Message $CurrentKeys
}

If ($TLS10_Disable_Server) {

    Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "TLS1.0 Server Settings Disabled"

    Set-Disable_tls10_server

    Show-RebootMessage
    Get-RegKeys
    Show-TLSsettings

    $CurrentKeys = $RegistryKeys.GetEnumerator() | Format-Table -Auto | Out-String
    Write-LogInfo -LogPath $sFullPath -Message $CurrentKeys
}

If ($TLS10_Disable_Client) {

    Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "TLS1.0 Client Settings Disabled"

    Set-Disable_tls10_client

    Show-RebootMessage
    Get-RegKeys
    Show-TLSsettings

    $CurrentKeys = $RegistryKeys.GetEnumerator() | Format-Table -Auto | Out-String
    Write-LogInfo -LogPath $sFullPath -Message $CurrentKeys
}

If ($OsTlsDefault) {

	# Disabled some of this code that displays a pop up message requiring user input
	# This was done to allow full automation

    #$oResponse = [System.Windows.Forms.MessageBox]::Show("Are you sure you want to reset TLS to weak and insecure defaults?" , "TLS weak and insecure defaults..." , 4 , "Error", "button2")
    #if ($oResponse -eq "YES" ) {

        Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "Server TLS settings have been Default, Server is in UNSECURE state"
        OsTlsDefault

        Show-RebootMessage
        Get-RegKeys
        Show-TLSsettings

        $CurrentKeys = $RegistryKeys.GetEnumerator() | Format-Table -Auto | Out-String
        Write-LogInfo -LogPath $sFullPath -Message $CurrentKeys

    #} else {
    #    Break
    #}

}

If ($Force) {

    Write-LogInfo -LogPath $sFullPath -TimeStamp -Message "TLS settings configured via -Force switch to FA Standard"

    Set-Enable_FAstandard
    Get-RegKeys
    $CurrentKeys = $RegistryKeys.GetEnumerator() | Format-Table -Auto | Out-String
    Write-LogInfo -LogPath $sFullPath -Message $CurrentKeys
}


Write-LogInfo -LogPath $sFullPath -Message " Finished processing at: $([DateTime]::Now)"
Write-LogInfo -LogPath $sFullPath -Message " "
Write-LogInfo -LogPath $sFullPath -Message "==================================================================================================="

Start-Sleep -Seconds 2
Send-MailMessage -From $MailFrom -To $MailTo -Subject $MailSubject -SmtpServer $SMTPServer -Body $SysInfo -Attachments $sFullPath -ErrorAction SilentlyContinue

$RegistryKeys = $null
$TLSstate = $null
$TLScolor = $null
