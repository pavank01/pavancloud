Function Set-PSAffinity {
<#
	.SYNOPSIS
		Set the processor affinity of the specified Process
	.PARAMETER ProcessID
		The Process ID of the Process to set processor affinity
	.PARAMETER ProcessName
		The Process Name of the Process to set processor affinity
	.PARAMETER Core
		The core thread that is allowed to run this process. Separate each core with a comma.
		Core thread can be 1 to max core threads.
	.PARAMETER All
		If specified, all cores are allowed.
	.EXAMPLE
		Set-PSAffinity -Core 2
	.EXAMPLE
		Set-PSAffinity -Core 1,3,5
	.EXAMPLE
		Set-PSAffinity -All
#>
	Param (
		[Parameter()]
		[String]$ProcessID = $PID,

		[Parameter()]
		[String]$ProcessName = $Null,

		[Parameter()]
		[ValidateRange(1,512)]
		[Int[]]$Core,

		[Parameter()]
		[Switch]$All
	)
	[Int]$LogicalProcessors = 0
	Get-WMIObject -Class Win32_Processor | ForEach-Object {$LogicalProcessors += $_.NumberOfLogicalProcessors}
	$MaxAffinity = ([Math]::Pow(2, $LogicalProcessors) - 1)
	If ($Core) {
		$Core | Select-Object -Unique | ForEach-Object {$Affinity = 0} {$Affinity += [Math]::Pow(2, $_ -1) }
	}
	If ($All) {
		$Affinity = $MaxAffinity
	}
	If (($Affinity -gt $MaxAffinity) -or ($Affinity -lt 1)) {
		$Affinity = $MaxAffinity
	}
	If ($ProcessName -eq $Null -or $ProcessName -eq "") {
		(Get-Process -ID $ProcessID).ProcessorAffinity = [Int]$Affinity
	} Else {
		(Get-Process -Name $ProcessName).ID | ForEach-Object {(Get-Process -ID $_).ProcessorAffinity = [Int]$Affinity}
	}
}

