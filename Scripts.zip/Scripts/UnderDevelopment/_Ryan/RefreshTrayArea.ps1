Add-Type -AssemblyName System.Windows.Forms
Add-Type @"
using System;
using System.Runtime.InteropServices;
public struct RECT {
    public int left;
    public int top;
    public int right;
    public int bottom;
}
public class pInvoke {
    [DllImport("user32.dll")]
    public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
    [DllImport("user32.dll")]
    public static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpszClass, string lpszWindow);
    [DllImport("user32.dll")]
    public static extern bool GetClientRect(IntPtr hWnd, out RECT lpRect);
    [DllImport("user32.dll")]
    public static extern IntPtr SendMessage(IntPtr hWnd, uint msg, int wParam, int lParam);

    public static void RefreshTrayArea() {
        IntPtr systemTrayContainerHandle = FindWindow("Shell_TrayWnd", null);
        IntPtr systemTrayHandle = FindWindowEx(systemTrayContainerHandle, IntPtr.Zero, "TrayNotifyWnd", null);
        IntPtr sysPagerHandle = FindWindowEx(systemTrayHandle, IntPtr.Zero, "SysPager", null);
        IntPtr notificationAreaHandle = FindWindowEx(sysPagerHandle, IntPtr.Zero, "ToolbarWindow32", "Notification Area");
        if (notificationAreaHandle == IntPtr.Zero) {
            notificationAreaHandle = FindWindowEx(sysPagerHandle, IntPtr.Zero, "ToolbarWindow32", "User Promoted Notification Area");
            IntPtr notifyIconOverflowWindowHandle = FindWindow("NotifyIconOverflowWindow", null);
            IntPtr overflowNotificationAreaHandle = FindWindowEx(notifyIconOverflowWindowHandle, IntPtr.Zero, "ToolbarWindow32", "Overflow Notification Area");
            RefreshTrayArea(overflowNotificationAreaHandle);
        }
        RefreshTrayArea(notificationAreaHandle);
    }
    private static void RefreshTrayArea(IntPtr windowHandle) {
        const uint wmMousemove = 0x0200;
        RECT rect;
        GetClientRect(windowHandle, out rect);
        for (var x = 0; x < rect.right; x += 5)
        for (var y = 0; y < rect.bottom; y += 5)
        SendMessage(windowHandle, wmMousemove, 0, (y << 16) + x);
    }
}
"@

[pInvoke]::RefreshTrayArea()
