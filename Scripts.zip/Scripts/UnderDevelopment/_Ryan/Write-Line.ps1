﻿Function Write-Line {
	# Examples:
	# Write-Line "-" -Length 25 -BackgroundColor White -ForegroundColor Black
	# Write-Line "-=" -Length 25
	# Write-Line "_" -Length 40 -ForegroundColor White -BackgroundColor Blue
	# Write-Line "#" -BackgroundColor White -ForegroundColor Blue -Length 80
	# Write-Line -Text "-+-" -Length 100 -BackgroundColor DarkRed -ForegroundColor White
	[CmdletBinding()]
    Param(
    	[Parameter(Mandatory=$False,Position=0)][string]$Text = "_",
		[Parameter(Mandatory=$False)][Int]$Length = ([Console]::WindowWidth - 1),
        [Parameter(Mandatory=$False)][string]$ForegroundColor = [Console]::ForegroundColor,
        [Parameter(Mandatory=$False)][string]$BackgroundColor = [Console]::BackgroundColor
        )
    Begin {}
    Process {
		If ($Length -le $Text.Length) {
			Write-Host $Text -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor
		} Else {
			$CurrentLength = 0
			$NewText = ""
			Do {
				$NewText = $NewText.ToString() + $Text.ToString()
				$CurrentLength = $CurrentLength + 1
			} Until ($CurrentLength -ge $Length)
			$NewText = $NewText.SubString(0, $Length)
		    Write-Host $NewText -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor
		}
	}
	End {}
}
