﻿Param (
	[CmdletBinding()]

	[Parameter()]
	[String]$UserName = "",

	[Parameter()]
	[String]$GroupName = "",

	[Parameter()]
	[ValidateSet("corp.firstam.com", "fastts.firstam.net", "intl.corp.firstam.com", "datatree.local", "corp", "fastts", "intl", "datatree")]
	[String]$Domain = "corp.firstam.com",

	[Parameter()]
	[Switch]$Photo = $False
)


# Need to add options for FirstName and LastName and wildcards (RegEx?)


# ---------------------------------------------------------------------------
Function Get-Matches($String, $RegEx) {
	If ($String -match $RegEx) {
		$Matches[1..($Matches.Count - 1)]
	} Else {
		@()
	}
}
# ---------------------------------------------------------------------------
Function Write-Line {
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $False, Position = 0)]
		[string]$Text = "_",
		[Parameter(Mandatory = $False)]
		[Int]$Length = ([Console]::WindowWidth - 10),
		[Parameter(Mandatory = $False)]
		[string]$ForegroundColor = [Console]::ForegroundColor,
		[Parameter(Mandatory = $False)]
		[string]$BackgroundColor = [Console]::BackgroundColor
	)
	Begin { }
	Process {
		If ($Length -le $Text.Length) {
			Write-Host $Text -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor
		} Else {
			$CurrentLength = 0
			$NewText = ""
			Do {
				$NewText = $NewText.ToString() + $Text.ToString()
				$CurrentLength = $CurrentLength + 1
			} Until ($CurrentLength -ge $Length)
			$NewText = $NewText.SubString(0, $Length)
			Write-Host $NewText -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor
		}
	}
	End { }
}
# ---------------------------------------------------------------------------
Function Get-ElapsedTime {
<#
	.SYNOPSIS
		The Get-ElapsedTime function takes a date/time range and converts it to years,
		weeks, days, hours, minutes, seconds, and milliseconds

	.DESCRIPTION
		The Get-ElapsedTime function takes a date/time range and converts it to years,
		weeks, days, hours, minutes, seconds, and milliseconds

	.PARAMETER Start
		The starting date/time of the range to calculate

	.PARAMETER End
		The ending date/time of the range to calculate
		Current date/time (Default)

	.PARAMETER HighLevel
		Highest level of date/time to return

		NonZero (Default)
		Years
		Weeks
		Days
		Hours
		Seconds
		Milliseconds

	.PARAMETER LowLevel
		Lowest level of date/time to return

		Years
		Weeks
		Days
		Hours
		Seconds (Default)
		Milliseconds

	.PARAMETER LevelText
		Text to use for each level of date/time
		There must always be 7 elements

		" years / weeks / days / hours / minutes / seconds / milliseconds" (Default)
		"y /w /d /h /m /s /m"
		" yr, / wk, / dy, / hr, / mn, / sc, / ms"
		"y:/w:/d:/h:/m:/s:/m:/t"
		" year(s) / week(s) / day(s) / hour(s) / minute(s) / second(s) / millisecond(s)"

	.PARAMETER Delimiter
		Delimiter used to split LevelText
		Values will not be trimmed so spaces and other punctuation can be used
		"/" (Default)

	.PARAMETER NoText
		Do not show time span text after time values

		True:  4 13 34 56
		False: 4 days 13 hours 34 minutes 56 seconds (Default)

	.PARAMETER LeadingZero
		Make all time values 2 digits by adding a LeadingZero if required
		Milliseconds will be converted to 3 digits if required

		True:  04 days, 13 hours, 05 minutes, 09 seconds, 068 milliseconds
		False: 4 days, 13 hours, 5 minutes, 9 seconds, 68 milliseconds (Default)

	.PARAMETER Object
		Return an Object instead of the default String

	.OUTPUTS
		String (Default)
		Object

	.NOTES
		Written by Ryan Amsbury
		v0.5 - Alpha Testing
#>
	[CmdletBinding()]
	Param
	(
		[Parameter(Mandatory = $True,
				   ValueFromPipeline = $True,
				   Position = 0)]
		[DateTime]$Start,

		[Parameter(Mandatory = $False,
				   ValueFromPipeline = $True,
				   Position = 1)]
		[DateTime]$End = (Get-Date),

		[Parameter(Mandatory = $False)]
		[ValidateSet('NonZero', 'Years', 'Weeks', 'Days', 'Hours', 'Minutes', 'Seconds', 'Milliseconds', IgnoreCase = $True)]
		[string]$HighLevel = 'NonZero',

		[Parameter(Mandatory = $False)]
		[ValidateSet('Milliseconds', 'Seconds', 'Minutes', 'Hours', 'Days', 'Weeks', 'Years', IgnoreCase = $True)]
		[string]$LowLevel = 'Seconds',

		[Parameter(Mandatory = $False)]
		[String]$LevelText = ' years / weeks / days / hours / minutes / seconds / milliseconds',

		[Parameter(Mandatory = $False)]
		[String]$Delimiter = '/',

		[Parameter(Mandatory = $False)]
		[Switch]$NoText = $False,

		[Parameter(Mandatory = $False)]
		[Switch]$LeadingZero = $False,

		[Parameter(Mandatory = $False)]
		[Switch]$Object = $False
	)
	Begin {
		$LevelHash = @{
			'NonZero' = 8;
			'Years' = 7;
			'Weeks' = 6;
			'Days' = 5;
			'Hours' = 4;
			'Minutes' = 3;
			'Seconds' = 2;
			'Milliseconds' = 1;
		}
	} # Begin
	Process {
		If ($LevelHash.$HighLevel -lt $LevelHash.$LowLevel) {
			$HighLevel = 'NonZero'
		}
		$IncludeZero = $False
		$LevelTextArray = $LevelText -Split $Delimiter, 7, [StringSplitOptions]::"SimpleMatch"
		$TimeSpan = New-TimeSpan -Start $Start -End $End
		$Years = 0
		$Weeks = 0
		$Days = $TimeSpan.Days
		$Hours = $TimeSpan.Hours
		$Minutes = $TimeSpan.Minutes
		$Seconds = $TimeSpan.Seconds
		$Milliseconds = $TimeSpan.Milliseconds
		# Calculate years
		If ($LevelHash.$HighLevel -ge $LevelHash.Years) {
			If ($Days -gt 365) {
				# more than 1 year
				$Years = [Math]::Floor($Days / 365)
				If (($Days / 365) -gt $Years) {
					# there are extra days
					$Days = ($Days % 365) # returns the remainder of days
				} ElseIf (($Days / 365) -eq $Years) {
					# no more days
					$Days = 0
				}
			} ElseIf ($Days -lt -365) {
				# more than 1 year
				$Years = 0 - [Math]::Floor($Days / -365)
				If (($Days / -365) -gt $Years) {
					# there are extra days
					$Days = ($Days % -365) # returns the remainder of days
				} ElseIf (($Days / -365) -eq $Years) {
					# no more days
					$Days = 0
				}
			}
			If ($Days -eq 365) {
				# exactly 1 year
				$Years = 1
				$Days = 0
			}
			If ($Days -eq -365) {
				$Years = -1
				$Days = 0
			}
		}
		# Calculate weeks
		If ($LevelHash.$HighLevel -ge $LevelHash.Weeks) {
			If ($Days -gt 0) {
				# days left to process
				$Weeks = [Math]::Floor($Days / 7)
				If (($Days / 7) -gt $Weeks) {
					# there are extra days
					$Days = ($Days % 7) # returns the remainder of days
				} ElseIf (($Days / 7) -eq $Weeks) {
					# no more days
					$Days = 0
				}
			} ElseIf ($Days -lt 0) {
				# days left to process
				$Weeks = 0 - [Math]::Floor($Days / -7)
				If (($Days / -7) -gt $Weeks) {
					# there are extra days
					$Days = ($Days % -7) # returns the remainder of days
				} ElseIf (($Days / -7) -eq $Weeks) {
					# no more days
					$Days = 0
				}
			}
			If ($Days -eq 7) {
				# exactly 1 week
				$Weeks = 1
				$Days = 0
			}
			If ($Days -eq -7) {
				# exactly 1 week
				$Weeks = -1
				$Days = 0
			}
		}
		If ($LeadingZero -eq $True) {
			$Years = "{0:D2}" -f [int]$Years
			$Weeks = "{0:D2}" -f [int]$Weeks
			$Days = "{0:D2}" -f [int]$Days
			$Hours = "{0:D2}" -f [int]$Hours
			$Minutes = "{0:D2}" -f [int]$Minutes
			$Seconds = "{0:D2}" -f [int]$Seconds
			$Milliseconds = "{0:D3}" -f [int]$Milliseconds
		}

		$ElapsedTime = @()
		$TempElapsed = New-Object System.Object
		$TempElapsed | Add-Member -Type NoteProperty -Name Years -Value ([String]$Years)
		$TempElapsed | Add-Member -Type NoteProperty -Name YearsText -Value ([String]$LevelTextArray[0])
		$TempElapsed | Add-Member -Type NoteProperty -Name Weeks -Value ([String]$Weeks)
		$TempElapsed | Add-Member -Type NoteProperty -Name WeeksText -Value ([String]$LevelTextArray[1])
		$TempElapsed | Add-Member -Type NoteProperty -Name Days -Value ([String]$Days)
		$TempElapsed | Add-Member -Type NoteProperty -Name DaysText -Value ([String]$LevelTextArray[2])
		$TempElapsed | Add-Member -Type NoteProperty -Name Hours -Value ([String]$Hours)
		$TempElapsed | Add-Member -Type NoteProperty -Name HoursText -Value ([String]$LevelTextArray[3])
		$TempElapsed | Add-Member -Type NoteProperty -Name Minutes -Value ([String]$Minutes)
		$TempElapsed | Add-Member -Type NoteProperty -Name MinutesText -Value ([String]$LevelTextArray[4])
		$TempElapsed | Add-Member -Type NoteProperty -Name Seconds -Value ([String]$Seconds)
		$TempElapsed | Add-Member -Type NoteProperty -Name SecondsText -Value ([String]$LevelTextArray[5])
		$TempElapsed | Add-Member -Type NoteProperty -Name Milliseconds -Value ([String]$Milliseconds)
		$TempElapsed | Add-Member -Type NoteProperty -Name MillisecondsText -Value ([String]$LevelTextArray[6])
		$ElapsedTime += $TempElapsed

		$Years = $Null
		$Weeks = $Null
		$Days = $Null
		$Hours = $Null
		$Minutes = $Null
		$Seconds = $Null
		$Milliseconds = $Null

		Switch ($ElapsedTime) {
			{ (([Int]$_.Years -gt 0) -or ($LevelHash.$HighLevel -eq 7)) -and (($LevelHash.$HighLevel -ge 7) -and ($LevelHash.$LowLevel -le 7)) }
				{
					If ($NoText -eq $True) {
						$Years = $_.Years + ' '
					} Else {
						$Years = $_.Years + $_.YearsText
					}
					$IncludeZero = $True
				}

			{ ((([Int]$_.Weeks -gt 0) -or ($LevelHash.$HighLevel -eq 6) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 6) -and ($LevelHash.$LowLevel -le 6))) }
				{
					If ($NoText -eq $True) {
						$Weeks = $_.Weeks + ' '
					} Else {
						$Weeks = $_.Weeks + $_.WeeksText
					}
					$IncludeZero = $True
				}

			{ ((([Int]$_.Days -gt 0) -or ($LevelHash.$HighLevel -eq 5) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 5) -and ($LevelHash.$LowLevel -le 5))) }
				{
					If ($NoText -eq $True) {
						$Days = $_.Days + ' '
					} Else {
						$Days = $_.Days + $_.DaysText
					}
					$IncludeZero = $True
				}

			{ ((([Int]$_.Hours -gt 0) -or ($LevelHash.$HighLevel -eq 4) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 4) -and ($LevelHash.$LowLevel -le 4))) }
				{
					If ($NoText -eq $True) {
						$Hours = $_.Hours + ' '
					} Else {
						$Hours = $_.Hours + $_.HoursText
					}
					$IncludeZero = $True
				}

			{ ((([Int]$_.Minutes -gt 0) -or ($LevelHash.$HighLevel -eq 3) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 3) -and ($LevelHash.$LowLevel -le 3))) }
				{
					If ($NoText -eq $True) {
						$Minutes = $_.Minutes + ' '
					} Else {
						$Minutes = $_.Minutes + $_.MinutesText
					}
					$IncludeZero = $True
				}

			{ ((([Int]$_.Seconds -gt 0) -or ($LevelHash.$HighLevel -eq 2) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 2) -and ($LevelHash.$LowLevel -le 2))) }
				{
					If ($NoText -eq $True) {
						$Seconds = $_.Seconds + ' '
					} Else {
						$Seconds = $_.Seconds + $_.SecondsText
					}
				}

			{ ((([Int]$_.Milliseconds -gt 0) -or ($LevelHash.$HighLevel -eq 1) -or ($IncludeZero -eq $True)) -and (($LevelHash.$HighLevel -ge 1) -and ($LevelHash.$LowLevel -le 1))) }
				{
					If ($NoText -eq $True) {
						$Milliseconds = $_.Milliseconds + ' '
					} Else {
						$Milliseconds = $_.Milliseconds + $_.MillisecondsText
					}
					$IncludeZero = $True
				}
		}
		If ($Object -eq $True) {
			Return $ElapsedTime
		} Else {
			Return "$Years$Weeks$Days$Hours$Minutes$Seconds$Milliseconds".Trim()
		}
	} # Process
	End {
	} # End
}
# ---------------------------------------------------------------------------
Function Format-Color {
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $True, ValueFromPipeline = $True)]
		[String]$InputData,

		[Parameter(Mandatory = $True)]
		[HashTable]$Colors,

		[Parameter(Mandatory = $False)]
		[Switch] $SimpleMatch
	)
	$BlankCount = 0
	$ErrorAction = $ErrorActionPreference
	$DefaultFGColor = $Host.UI.RawUI.ForegroundColor
	$DefaultBGColor = $Host.UI.RawUI.BackgroundColor
	$Lines = (($InputData | Out-String) -replace "`r", "") -Split "`n"
	ForEach ($Line In $Lines) {
		If ($Line.Trim() -eq $Null -or $Line.Trim() -eq "") {
			$BlankCount = $BlankCount + 1
		} Else {
			$BlankCount = 0
		}
		If ($BlankCount -lt 2) {
			$FGColor = ''
			$BGColor = ''
			$Colored = $False
			ForEach ($Pattern In $Colors.Keys) {
				If (!$SimpleMatch -and $Line -match $Pattern) {
					$CurrentColors = $Colors[$Pattern].Split(",")
					$ErrorActionPreference = "SilentlyContinue"
					$CurrentColors[0] = $CurrentColors[0].Trim()
					$CurrentColors[1] = $CurrentColors[1].Trim()
					$ErrorActionPreference = $ErrorAction
					If ($CurrentColors[0] -eq "" -or $CurrentColors[0] -eq $Null) {
						$FGColor = $DefaultFGColor
					} Else {
						$FGColor = $CurrentColors[0]
					}
					If ($CurrentColors[1] -eq "" -or $CurrentColors[1] -eq $Null) {
						$BGColor = $DefaultBGColor
					} Else {
						$BGColor = $CurrentColors[1]
					}
					$Colored = $True
				}
				ElseIf ($SimpleMatch -and $Line -like $Pattern) {
					$CurrentColors = $Colors[$Pattern].Split(",")
					$ErrorActionPreference = "SilentlyContinue"
					$CurrentColors[0] = $CurrentColors[0].Trim()
					$CurrentColors[1] = $CurrentColors[1].Trim()
					$ErrorActionPreference = $ErrorAction
					If ($CurrentColors[0] -eq "" -or $CurrentColors[0] -eq $Null) {
						$FGColor = $DefaultFGColor
					} Else {
						$FGColor = $CurrentColors[0]
					}
					If ($CurrentColors[1] -eq "" -or $CurrentColors[1] -eq $Null) {
						$BGColor = $DefaultBGColor
					} Else {
						$BGColor = $CurrentColors[1]
					}
					$Colored = $True
				}
			}
			If ($Colored -eq $True) {
				Write-Host $Line -ForegroundColor $FGColor -BackgroundColor $BGColor
			} Else {
				Write-Host $Line
			}
		}
	}
}
# ---------------------------------------------------------------------------

Import-Module ActiveDirectory

# ---------------------------------------------------------------------------

#$ErrorAction = $ErrorActionPreference

If ($UserName -eq "" -and $GroupName -eq "") {
	Write-Host
	Write-Host "A UserName or GroupName is required" -ForegroundColor Yellow -BackgroundColor Red
	Break
}
If ($UserName -like "*\*") {
	$Domain = ($UserName.Split("\\"))[0].ToUpper()
	$UserName = ($UserName.Split("\\"))[1].ToUpper()
}
If ($GroupName -like "*\*") {
	$Domain = ($GroupName.Split("\\"))[0].ToUpper()
	$GroupName = ($GroupName.Split("\\"))[1].ToUpper()
}
If ($UserName -ne "") {
	$IsUser = $True
	$UserName = $UserName.ToUpper()
} Else {
	$IsUser = $False
	$GroupName = $GroupName.ToUpper()
}
If ($Domain -eq "" -or $Domain -eq $Null) {
	$Domain = ((Get-ADDomainController -Discover -Service "PrimaryDC").Domain).ToLower()
}
If ($IsUser -eq $True) {
	# User account
	If (([regex]::Matches($UserName, " ")).count -gt 0) {
		$FName = $UserName.Split(" ")[0]
		$LName = $UserName.Split(" ")[1]
		[String]$ADFilter = "GivenName -like '$($FName)' -and SN -like '$($LName)'"
	} Else {
		$ADFilter = "SamAccountName -like '$($UserName)'"
	}
} Else {
	# Group Account
	$ADFilter = "SamAccountName -like '$($GroupName)'"
}

$ErrorActionPreference = "SilentlyContinue"
$PrimaryDC = (Get-ADDomainController -Discover -Domain $Domain -Service "PrimaryDC").Name
$Domain = ((Get-ADDomainController -Discover -Domain $Domain -Service "PrimaryDC").Domain).ToLower()

If ($IsUser -eq $True) {
	# ---------------------------------------------------------------------------
	# User search
	# ---------------------------------------------------------------------------
	Write-Host
	Write-Host "Looking up user $UserName in $Domain"
	Write-Host
	$ADUsers = Get-ADUser -Filter $ADFilter -Server $PrimaryDC -Properties *
	If ($ADUsers -ne $Null) {
		# Get domain account policy for later use
		$AccountPolicy = Get-ADDefaultDomainPasswordPolicy -Server $Domain
		ForEach ($ADUser In ($ADUsers | Sort-Object SamAccountName)) {
			$UserName = $ADUser.SamAccountName
			If ($ADUser.Enabled -eq $True) {
				$ForegroundColor = "Green"
			} Else {
				$ForegroundColor = "Red"
			}
			# is the account expired
			$Expires = $ADUser.AccountExpires
			If ($Expires -ne 0 -and $Expires -ne 9223372036854775807) {
				$ExpirationDate = [DateTime]::FromFileTime($Expires).ToString('g')
				If ((Get-Date) -gt $ExpirationDate) {
					$Expired = $True
					$ForegroundColor = "Red"
				} Else {
					$Expired = $False
				}
			} Else {
				$Expired = $False
			}
			$PhotoPath = "$Env:Temp\" + $UserName + ".jpg"
			If ((Test-Path $PhotoPath) -eq $True) {
				Remove-Item $PhotoPath -Force
			}
			$BaseDomain = ($Domain.Split("."))[0]
			$DomUser = ($BaseDomain + '\' + $UserName).ToUpper()
			$ADUserFullName = ("$($ADUser.GivenName) $($ADUser.SurName)").Trim()
			$ADUserFN = "$($ADUser.GivenName)"
			$ADUserLN = "$($ADUser.SurName)"
			If ((Test-Path .\Figlet\ReadFigletFont.ps1) -eq $True) {
				.\Figlet\ReadFigletFont.ps1 $ADUserFullName -FigFont .\Figlet\Fonts\colossal.flf -Tracking 1 -ForegroundColor $ForegroundColor
				#Write-Host
				#.\Figlet\ReadFigletFont.ps1 $DomUser.ToLower() -FigFont .\Figlet\Fonts\colossal.flf -Tracking 1 -ForegroundColor $ForegroundColor
			}
			Write-Line "_" -ForegroundColor DarkGray
			Write-Host
			Write-Host "Details for User $ADUserFullName ($DomUser):" -ForegroundColor $ForegroundColor
			$ADUserDetails = $ADUser | Format-List | Out-String
			Format-Color -InputData $ADUserDetails -Colors @{"^AccountExpirationDate\s+: [\w]" = "Black,DarkYellow"; "^BadLogonCount\s+: [^0]" = ",DarkRed"; "^AccountLockoutTime\s+: [\w]" = "Black,DarkYellow"; "^LastBadPasswordAttempt\s+: [\w]" = "Black,DarkYellow"; "^PasswordNeverExpires\s+: True" = "Black,DarkYellow"; "^PasswordNotRequired\s+: True" = "Black,DarkYellow"; "^CannotChangePassword\s+: True" = "Black,DarkYellow"; "^Enabled\s+: False" = ",DarkRed "; "^Enabled\s+: True" = ",DarkGreen"; "LockedOut\s+: True" = ",DarkRed "; "LockedOut\s+: False" = ",DarkGreen"; "PasswordExpired\s+: True" = ",DarkRed "; "PasswordExpired\s+: False" = ",DarkGreen"; "Manager\s+: [\w]" = "Black,DarkCyan"; "EmployeeID\s+: [\w]" = "Black,DarkCyan"; "Title\s+: [\w]" = "Black,DarkCyan"; "^EmployeeType\s+: Service Account" = "Black,DarkYellow"; "^EmployeeType\s+: [\w]" = "Black,DarkCyan"}
			$ADGroups = $ADUser | Select-Object -ExpandProperty MemberOf | Get-ADGroup -Server $Domain -Property Name, GroupScope, GroupCategory
			Write-Line "_" -ForegroundColor DarkGray
			Write-Host
			Write-Host "$ADUserFullName ($DomUser) is a Member of the Following Groups:" -ForegroundColor $ForegroundColor
			#$ADGroups | Sort-Object Name | Select-Object Name, @{Label='Type';Expression={"$($_.GroupScope) $($_.GroupCategory) Group"}} | Sort-Object Type, Name | Format-Table Name -GroupBy Type -AutoSize
			$ADGroups | Sort-Object Name | Select-Object Name, @{ Label = 'Type'; Expression = { "$($_.GroupScope) $($_.GroupCategory) Group" } } | Sort-Object Type, Name | Format-Table Name -GroupBy Type -AutoSize | Out-String | Format-Color -Colors @{"Type: " = "Black,DarkGray"; "Domain Admins" = ",DarkMagenta"}

			If ($ADUser.DirectReports -ne $Null) {
				$DirectReports = $ADUser | Select-Object -ExpandProperty DirectReports | ForEach { Get-ADUser -Identity $_ -Server $Domain -Property Enabled, GivenName, SurName, SamAccountName, Title } | Sort-Object SamAccountName
				Write-Line "_" -ForegroundColor DarkGray
				Write-Host
				Write-Host "$ADUserFullName ($DomUser) Manages the Following Users:" -ForegroundColor $ForegroundColor
				#$DirectReports | Select-Object Enabled, @{Label='Name';Expression={"$($_.GivenName) $($_.SurName)"}}, SamAccountName, Title | Sort-Object Enabled, Name | Format-Table Name, SamAccountName, Title -GroupBy Enabled -AutoSize
				$DirectReports | Select-Object Enabled, @{ Label = 'Name'; Expression = { ("$($_.GivenName) $($_.SurName)").Trim() } }, SamAccountName, Title | Sort-Object Enabled, Name | Format-Table Name, SamAccountName, Title -GroupBy Enabled -AutoSize | Out-String | Format-Color -Colors @{"Enabled: True" = ",DarkGreen"; "Enabled: False" = ",DarkRed"}
			}
			Write-Line "_" -ForegroundColor DarkGray
			Write-Host
			If ($Photo -eq $True -and $ADUser.ThumbnailPhoto -ne $Null) {
				[System.Io.File]::WriteAllBytes($PhotoPath, $ADUser.ThumbnailPhoto)
				If ((Test-Path $PhotoPath) -eq $True) {
					#Invoke-Item $PhotoPath
					.\Write-ASCIIArt.ps1 -Path $PhotoPath -Ratio 2 -MaxWidth 100 -Palette Shade -ForegroundColor White -backgroundColor Black
					Write-Host
					Write-Line "_" -ForegroundColor DarkGray
					Write-Host
				}
			}
			If ($ADUser.Enabled -eq $True -and $Expired -eq $False) {
				Write-Host "$ADUserFullName ($DomUser) is ENABLED" -ForegroundColor $ForegroundColor
			}
			If ($ADUser.Enabled -eq $True -and $Expired -eq $True) {
				Write-Host "$ADUserFullName ($DomUser) is ENABLED and EXPIRED" -ForegroundColor $ForegroundColor
			}
			If ($ADUser.Enabled -eq $False -and $Expired -eq $False) {
				Write-Host "$ADUserFullName ($DomUser) is DISABLED" -ForegroundColor $ForegroundColor
			}
			If ($ADUser.Enabled -eq $False -and $Expired -eq $True) {
				Write-Host "$ADUserFullName ($DomUser) is DISABLED and EXPIRED" -ForegroundColor $ForegroundColor
			}
			$LogonsPerDay = (Get-ElapsedTime -Start $ADUser.Created -HighLevel Days -LowLevel Days -NoText)
			If ($LogonsPerDay.Length -lt 1) {
				$LogonsPerDay = $ADUser.LogonCount
			} Else {
				$LogonsPerDay = [Int]($ADUser.LogonCount / $LogonsPerDay)
			}
			$AccountAge = (Get-ElapsedTime -Start $ADUser.Created -LowLevel Hours -LevelText "y /w /d /h /m /s /m")
			If ($AccountAge.Length -lt 2) {
				$AccountAge = (Get-ElapsedTime -Start $ADUser.Created -LowLevel Minutes -LevelText "y /w /d /h /m /s /m")
			}
			$ModifyAge = (Get-ElapsedTime -Start $ADUser.Modified -LowLevel Hours -LevelText "y /w /d /h /m /s /m")
			If ($ModifyAge.Length -lt 2) {
				$ModifyAge = (Get-ElapsedTime -Start $ADUser.Modified -LowLevel Minutes -LevelText "y /w /d /h /m /s /m")
			}
			$PasswordAge = (Get-ElapsedTime -Start $ADUser.PasswordLastSet -LowLevel Hours -LevelText "y /w /d /h /m /s /m")
			If ($PasswordAge.Length -lt 2) {
				$PasswordAge = (Get-ElapsedTime -Start $ADUser.PasswordLastSet -LowLevel Minutes -LevelText "y /w /d /h /m /s /m")
			}
			Write-Host ("Created on {0} ({1})" -f $ADUser.Created, $AccountAge) -ForegroundColor $ForegroundColor
			Write-Host ("Modified on {0} ({1})" -f $ADUser.Modified, $ModifyAge) -ForegroundColor $ForegroundColor
			Write-Host ("{0} total logons ({1} per day)" -f $ADUser.LogonCount, $LogonsPerDay) -ForegroundColor $ForegroundColor
			Write-Host ("Password last changed on {0} ({1})" -f $ADUser.PasswordLastSet, $PasswordAge) -ForegroundColor $ForegroundColor
			# Does the account expire
			# $ADUser.AccountExpires = 9223372036854775807 means account never had an expiration date set
			# $ADUser.AccountExpires = 0 means account had an expiration date but it was cleared
			$Expires = $ADUser.AccountExpires
			If ($Expires -ne 0 -and $Expires -ne 9223372036854775807) {
				$ExpirationDate = [DateTime]::FromFileTime($Expires).ToString('g')
				If ((Get-Date) -gt $ExpirationDate) {
					Write-Host ("Account expired on {0}" -f $ExpirationDate) -ForegroundColor Red
				} Else {
					$Expirationleft = (Get-ElapsedTime -Start (Get-Date) -End $ExpirationDate -LowLevel Hours -LevelText "y /w /d /h /m /s /m")
					If ($Expirationleft.Length -lt 2) {
						$Expirationleft = (Get-ElapsedTime -Start (Get-Date) -End $ExpirationDate -LowLevel Minutes -LevelText "y /w /d /h /m /s /m")
					}
					Write-Host ("Account expires on {0} ({1})" -f $ExpirationDate, $Expirationleft) -ForegroundColor Yellow
				}
			}
			# Is service account
			If ($ADUser.EmployeeType -eq "Service Account") {
				Write-Host "This is a Service Account" -ForegroundColor Yellow
			}
			# Can password be changed
			If ($ADUser.CannotChangePassword -eq $True) {
				Write-Host "Password cannot be changed by the user" -ForegroundColor Yellow
			}
			# Does the password expire
			If ($ADUser.PasswordNeverExpires -eq $True) {
				Write-Host "Password does not expire" -ForegroundColor Yellow
			} Else {
				$Temp = $AccountPolicy.MaxPasswordAge -Split "[\.\:]"
				If ($Temp[0] -ne 0) {
					$PWAgeDays = $Temp[0]
				} Else {
					$PWAgeDays = 0
				}
				If ($Temp[1] -ne 0) {
					$PWAgeHours = $Temp[1]
				} Else {
					$PWAgeHours = 0
				}
				If ($Temp[2] -ne 0) {
					$PWAgeMinutes = $Temp[2]
				} Else {
					$PWAgeMinutes = 0
				}
				If ($Temp[3] -ne 0) {
					$PWAgeSeconds = $Temp[3]
				} Else {
					$PWAgeSeconds = 0
				}
				$PasswordLastSet = [DateTime]$ADUser.PasswordLastSet
				$NextPWChange = $PasswordLastSet.AddDays($PWAgeDays).AddHours($PWAgeHours).AddMinutes($PWAgeMinutes).AddSeconds($PWAgeSeconds)
				$PWChangeLeft = (Get-ElapsedTime -Start (Get-Date) -End $NextPWChange -LowLevel Hours -LevelText "y /w /d /h /m /s /m")
				If ($PWChangeLeft.Length -lt 2) {
					$PWChangeLeft = (Get-ElapsedTime -Start (Get-Date) -End $NextPWChange -LowLevel Minutes -LevelText "y /w /d /h /m /s /m")
				}
				If ($ADUser.PasswordExpired -eq $True) {
					Write-Host ("Password was not changed on {0} (EXPIRED)" -f $NextPWChange) -ForegroundColor Red
				} Else {
					Write-Host ("Password must be changed on {0} ({1})" -f $NextPWChange, $PWChangeLeft) -ForegroundColor $ForegroundColor
				}
			}
			# is account locked out
			If ($ADUser.LockedOut -eq $True) {
				$Temp = $AccountPolicy.LockoutDuration -Split "[:]"
				If ($Temp[0] -ne 0) {
					$LockoutHours = $Temp[0]
				} Else {
					$LockoutHours = 0
				}
				If ($Temp[1] -ne 0) {
					$LockoutMinutes = $Temp[1]
				} Else {
					$LockoutMinutes = 0
				}
				If ($Temp[2] -ne 0) {
					$LockoutSeconds = $Temp[2]
				} Else {
					$LockoutSeconds = 0
				}
				$TimeLocked = [DateTime]$ADUser.AccountLockoutTime
				$LockedOutUntil = $TimeLocked.AddHours($LockoutHours).AddMinutes($LockoutMinutes).AddSeconds($LockoutSeconds)
				$LockoutTimeleft = (Get-ElapsedTime -Start (Get-Date) -End $LockedOutUntil -HighLevel Minutes -LowLevel Seconds -Object)
				Write-Host
				Write-Host ("This account was locked out at {0} and will automatically unlock at {1} ({2} minutes and {3} seconds)" -f $TimeLocked, $LockedOutUntil, $LockoutTimeleft.Minutes, $LockoutTimeleft.Seconds) -ForegroundColor Yellow -BackgroundColor DarkRed
			}
			Write-Host
			Write-Line "#" -ForegroundColor DarkGray
			Write-Host
		}
	} Else {
		Write-Host
		Write-Host ("The user '{0}' was not found in {1}" -f $UserName, $Domain) -ForegroundColor Yellow -BackgroundColor Red
	}
} Else {
	# ---------------------------------------------------------------------------
	# Group search
	# ---------------------------------------------------------------------------
	Write-Host
	Write-Host "Looking up group $GroupName in $Domain"
	Write-Host
	$ADGroups = Get-ADGroup -Filter $ADFilter -Server $PrimaryDC -Properties *
	$ADGroupMembers = $ADGroups | Select-Object -ExpandProperty Members | ForEach {$DistinguishedName = $_; If ($DistinguishedName -match '(?<=(DC=))\w*(?=(,))') {$AccountDomain = ($Matches[0]).ToUpper()} Else {$AccountDomain = $Domain.ToUpper()}; Get-ADObject -Filter {DistinguishedName -eq $DistinguishedName} -Server $AccountDomain -Property ObjectClass, SamAccountName, DistinguishedName} | Select-Object ObjectClass, @{L="Domain";E={$AccountDomain}}, SamAccountName, DistinguishedName | Sort-Object ObjectClass, Domain, SamAccountName
	$ADGroupMembersGroups = $ADGroupMembers | Where-Object {$_.ObjectClass -eq "group"} | ForEach {$AccountDomain = $_.Domain; Get-ADGroup -Identity $_.SamAccountName -Server $_.Domain -Property SamAccountName, Description, CanonicalName} | Select-Object SamAccountName, Description, CanonicalName, @{L="Domain";E={$AccountDomain}} | Sort-Object SamAccountName
	$ADGroupMembersUsers = $ADGroupMembers | Where-Object {$_.ObjectClass -eq "user"} | ForEach {$AccountDomain = $_.Domain; Get-ADUser -Identity $_.SamAccountName -Server $_.Domain -Property Enabled, GivenName, SurName, SamAccountName, Title, Description, CanonicalName} | Select-Object Enabled, @{L='GivenName';E={($_.GivenName -Replace('-a', '') -Replace('- a', '')).Trim()}}, @{L='SurName';E={($_.SurName -Replace('-a', '') -Replace('- a', '')).Trim()}}, SamAccountName, Title, Description, CanonicalName, @{L="Domain";E={$AccountDomain}} | Sort-Object SamAccountName

	If ($ADGroup -ne $Null) {
		ForEach ($ADGroup In ($ADGroups | Sort-Object SamAccountName)) {
			$GroupName = $ADGroup.SamAccountName
			$ForegroundColor = "Green"
			$BaseDomain = ($Domain.Split("."))[0]
			$DomGroup = ($BaseDomain + '\' + $GroupName).ToUpper()
			If ((Test-Path .\Figlet\ReadFigletFont.ps1) -eq $True) {
				.\Figlet\ReadFigletFont.ps1 $GroupName -FigFont .\Figlet\Fonts\colossal.flf -Tracking 1 -ForegroundColor $ForegroundColor
				#Write-Host
				#.\Figlet\ReadFigletFont.ps1 $DomGroup.ToLower() -FigFont .\Figlet\Fonts\colossal.flf -Tracking 1 -ForegroundColor $ForegroundColor
			}
			Write-Line "_" -ForegroundColor DarkGray
			Write-Host
			Write-Host "Details for Group $GroupName ($DomGroup):" -ForegroundColor $ForegroundColor
			$ADGroupDetails = $ADGroup | Format-List | Out-String
			Format-Color -InputData $ADGroupDetails -Colors @{"ManagedBy\s+: [\w]" = "Black,DarkCyan"; "Description\s+: [\w]" = "Black,DarkCyan"; "DisplayName\s+: [\w]" = "Black,DarkCyan"; "^GroupCategory\s+: Distribution" = "Black,DarkYellow"; "^GroupCategory\s+: [\w]" = "Black,DarkCyan"}
			Write-Line "_" -ForegroundColor DarkGray
			Write-Host

			If ($ADGroupMembersGroups -ne $Null) {
				Write-Host "$GroupName ($DomGroup) has the Following Member Groups:" -ForegroundColor $ForegroundColor
				$ADGroupMembersGroups | Sort-Object SamAccountName | Select-Object SamAccountName, Description, CanonicalName, @{ Label = 'Type'; Expression = {"$($_.GroupScope) $($_.GroupCategory) Group"}}, Domain | Sort-Object Type, SamAccountName, Domain | Format-Table SamAccountName, Domain, Description, CanonicalName -GroupBy Type -AutoSize | Out-String | Format-Color -Colors @{"Type: " = "Black,DarkGray"; "Domain Admins" = ",DarkMagenta"}
				Write-Host
			} Else {
				Write-Host "$GroupName ($DomGroup) has no Member Groups" -ForegroundColor Yellow
				Write-Host
			}
			If ($ADGroupMembersUsers -ne $Null) {
				Write-Host "$GroupName ($DomGroup) has the Following Member Users:" -ForegroundColor $ForegroundColor
				$ADGroupMembersUsers  | Select-Object Domain, Enabled, @{L='Name';E={If (($_.SurName -eq $Null -or $_.SurName -eq "" -or $_.GivenName -eq $Null -or $_.GivenName -eq "") -or ($_.SurName -eq $_.GivenName)) {$_.SamAccountName} Else {("$($_.GivenName) $($_.SurName)").Trim()}}}, SamAccountName, Title, Description | Sort-Object Enabled, Name, Domain, SamAccountName | Format-Table Name, Domain, SamAccountName, Title, Description -GroupBy Enabled -AutoSize | Out-String | Format-Color -Colors @{"Enabled: True" = ",DarkGreen"; "Enabled: False" = ",DarkRed"}
				Write-Host
			} Else {
				Write-Host "$GroupName ($DomGroup) has no Member Users" -ForegroundColor Yellow
				Write-Host
			}

			Write-Line "_" -ForegroundColor DarkGray
			Write-Host
			Write-Host "$GroupName ($DomGroup)" -ForegroundColor $ForegroundColor
			$AccountAge = (Get-ElapsedTime -Start $ADGroup.Created -LowLevel Hours -LevelText "y /w /d /h /m /s /m")
			If ($AccountAge.Length -lt 2) {
				$AccountAge = (Get-ElapsedTime -Start $ADGroup.Created -LowLevel Minutes -LevelText "y /w /d /h /m /s /m")
			}
			$ModifyAge = (Get-ElapsedTime -Start $ADGroup.Modified -LowLevel Hours -LevelText "y /w /d /h /m /s /m")
			If ($ModifyAge.Length -lt 2) {
				$ModifyAge = (Get-ElapsedTime -Start $ADGroup.Modified -LowLevel Minutes -LevelText "y /w /d /h /m /s /m")
			}
			Write-Host ("Created on {0} ({1})" -f $ADGroup.Created, $AccountAge) -ForegroundColor $ForegroundColor
			Write-Host ("Modified on {0} ({1})" -f $ADGroup.Modified, $ModifyAge) -ForegroundColor $ForegroundColor
			# Is service account
			If ($ADGroup.GroupCategory -eq "Security") {
				Write-Host "This is a Security Group" -ForegroundColor $ForegroundColor
			}
			If ($ADGroup.GroupCategory -eq "Distribution") {
				Write-Host "This is a Distribution Group" -ForegroundColor Yellow
			}
			Write-Host
			Write-Line "#" -ForegroundColor DarkGray
			Write-Host
		}
	} Else {
		Write-Host
		Write-Host ("The group '{0}' was not found in {1}" -f $GroupName, $Domain) -ForegroundColor Yellow -BackgroundColor Red
	}
}
$ErrorActionPreference = $ErrorAction

#.\GetUserDetails.ps1 -GroupName FAHQ-GU-CCDBA
