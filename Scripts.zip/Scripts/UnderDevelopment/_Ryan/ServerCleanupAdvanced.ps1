[CmdletBinding()]
Param (
	[Parameter(Mandatory = $False)]
	[ValidateSet("Conservative", "Moderate", "Aggressive")]
	[String]$Level = "Conservative",
	# Conservative, Moderate, Aggressive

	[Parameter(Mandatory = $False)]
	[ValidateSet("Idle", "BelowNormal", "Normal", "AboveNormal", "High", "RealTime")]
	[String]$Priority = "BelowNormal",

	[Parameter(Mandatory = $False)]
	[Switch]$Silent
)
# ---------------------------------------------------------------------------
Function Get-ScriptDirectory {
	# Only works from script not from the command line
	Split-Path $Script:MyInvocation.MyCommand.Path
}
# ---------------------------------------------------------------------------
Function Get-Round {
	# This performs the standard rounding we are used to instead of the PowerShell default
	# PowerShell default is Round Half to Even
	#     Rounds to the nearest even whole number
	#         23.5 = 24, 24.5 = 24; while -23.5 = -24, 24.5 = -24
	# Round Half Away from Zero
	#     Rounds to the nearest whole number
	#         23.5 = 24, 24.5 = 25; while -23.5 = -24, -24.5 = -25
	Param(
		[Parameter(Mandatory=$True, Position = 0)]
		[Decimal]$Number,
		[Parameter(Mandatory=$False, Position = 1)]
		[Int]$Digits = 0
	)
	[Math]::Round($Number, $Digits, "AwayFromZero")
}
# ---------------------------------------------------------------------------

$ScriptName = "ServerCleanupAdvanced"
$ScriptVersion = 0.8
$ScriptDisplayName = ("{0} (v{1})" -f $ScriptName, $ScriptVersion)
$ScriptStartTime = Get-Date

If ($Silent -eq $False) {
	Clear-Host
	1..10 | ForEach {Write-Host}
}

If ($Silent -eq $False) {
	Write-Host
	Write-Host "Starting $ScriptDisplayName at"$(Get-Date $ScriptStartTime -Format "yyyy-MM-dd hh:mm:ss tt") -ForegroundColor Cyan
}

Get-Process -ProcessName "PowerShell" | ForEach {$_.PriorityClass = $Priority}

$ScriptFolder = Get-ScriptDirectory
# Import the CSV and add the numeric clean level field set to 0
$FoldersList = Import-CSV -Path (Join-Path -Path (Get-ScriptDirectory) -ChildPath 'ServerCleanupAdvanced.csv') | Select-Object @{N="CleanNumber";E={0}}, CleanLevel, FolderPath, FileSpec, FileExclusion, FileAge, Recursive, DateAdded, AddedBy, Notes | Sort-Object FolderPath, FileSpec

# Determine the numeric clean level to use and correct capitalization for display
If ($Level -eq 'Conservative' -or $Level -eq 'C') {
	$Level = 'Conservative'
	[Int]$ProcessLevel = 3
}
If ($Level -eq 'Moderate' -or $Level -eq 'M') {
	$Level = 'Moderate'
	[Int]$ProcessLevel = 2
}
If ($Level -eq 'Aggressive' -or $Level -eq 'A') {
	$Level = 'Aggressive'
	[Int]$ProcessLevel = 1
}

# Alter the numeric clean level with the correct number
ForEach ($Folder In $FoldersList) {
	If ($Folder.CleanLevel -eq 'Conservative') {
		$Folder.CleanNumber = [Int]3
	}
	If ($Folder.CleanLevel -eq 'Moderate') {
		$Folder.CleanNumber = [Int]2
	}
	If ($Folder.CleanLevel -eq 'Aggressive') {
		$Folder.CleanNumber = [Int]1
	}
}

# Determine the numeric clean level to use and correct capitalization for display
If ($Level -eq 'Conservative') {
	$Level = 'Conservative'
	[Int]$ProcessLevel = 3
}
If ($Level -eq 'Moderate') {
	$Level = 'Moderate'
	[Int]$ProcessLevel = 2
}
If ($Level -eq 'Aggressive') {
	$Level = 'Aggressive'
	[Int]$ProcessLevel = 1
}

$Services = Get-WmiObject Win32_Service | Where-Object {$_.Name -eq "wuauserv" -or $_.PathName -like "*dagent.exe*"} | Select-Object Name, DisplayName | Sort-Object DisplayName
ForEach ($Service In $Services) {
	$Counter = 0
	If ($Silent -eq $False) {
		Write-Host
		Write-Host ("Temporarily stopping the {0} Service " -f $Service.DisplayName) -ForegroundColor Yellow -NoNewLine
	}
	$MyServiceJob = Start-Job -ArgumentList $Service.Name -ScriptBlock {Param ($Name) Stop-Service -Name $Name -Force}
	While ((Get-Service -Name $Service.Name).Status -ne 'Stopped') {
		$Counter = $Counter + 1
		If ($Silent -eq $False) {
			Write-Host "." -ForegroundColor DarkGray -NoNewLine
		}
		Start-Sleep -Seconds 1
		If ($Counter -ge 30) {
			# Break out of loop if over 30 seconds
			Break
		}
	}
	If ((Get-Service -Name $Service.Name).Status -eq 'Stopped') {
		If ($Silent -eq $False) {
			Write-Host " DONE" -ForegroundColor Green
		}
	} Else {
		If ($Silent -eq $False) {
			Write-Host " Cannot Stop Service After 30 Seconds - Aborting" -ForegroundColor Red
		}
	}
	$MyServiceJob | Get-Job | ForEach {Remove-Job -ID $_.ID -Force}
}
$Counter = $Null
(schtasks /end /tn "\Microsoft\Windows\Wininet\CacheTask") 2>&1 | Out-Null
(fsutil behavior set disabledeletenotify 0) 2>&1 | Out-Null
If ($Silent -eq $False) {
	Write-Host
}
$Services = $Null
$Service = $Null
$MyServiceJob = $Null
[System.GC]::Collect()

# Create the list to process based on the the numeric clean level
$ProcessList = $FoldersList | Where-Object {$_.CleanNumber -ge $ProcessLevel} | Sort-Object FolderPath, FileSpec, CleanNumber
$FoldersList = $Null
[System.GC]::Collect()

# Remove lower clean levels for the same folders / file specs so we do not process multiple times
$TempList = @()
$Last = ""
ForEach ($List In $ProcessList) {
	If ($Last -ne (Join-Path -Path $List.FolderPath -ChildPath $List.FileSpec))	{
		$TempList += $List
		$Last = (Join-Path -Path $List.FolderPath -ChildPath $List.FileSpec)
	}
}
$ProcessList = $TempList
$TempList = $Null
$Last = $Null
$TotalFolders = $ProcessList.Count + 1
$CurrentFolder = 0
[System.GC]::Collect()

$AllFolders = $Null
$AllFolders = New-Object System.Collections.ArrayList

$Drive = Get-WmiObject Win32_LogicalDisk | Where-Object {$_.DeviceID -eq "C:"} | Select-Object Size, FreeSpace
$Size = ($Drive.Size / 1MB)
$FreeBefore = ($Drive.FreeSpace / 1MB)
$Drive = $Null
[System.GC]::Collect()

ForEach ($List In $ProcessList) {
	$ErrorActionPreference = "SilentlyContinue"
	$AllFiles = $Null
	[System.GC]::Collect()
	$AllFiles = New-Object System.Collections.ArrayList
	$TotalFiles = 0
	$CurrentFile = 0
	$CurrentFolder ++
	$MainStatus = ("{0} - Folder {1} of {2} - Older Than {3} ({4} days) - {5} - {6}" -f $Level, $CurrentFolder, $TotalFolders, (Get-Date -Date (Get-Date).AddDays(-$List.FileAge) -Format "MM/dd/yyyy"), $List.FileAge, (Join-Path -Path $List.FolderPath -ChildPath $List.FileSpec), $List.Notes)
	$MainPct = [Math]::Round((100/$TotalFolders) * $CurrentFolder, 2)
	If ($Silent -eq $False) {
		Write-Progress -ID 1 -Activity $MainStatus -Status ("Progress: {0:N2} %" -f $MainPct) -PercentComplete $MainPct
	}
	$FullData = $Null
	[System.GC]::Collect()
	If ((Test-Path $List.FolderPath) -eq $True) {
		If ($List.Recursive -eq $True) {
			If ($List.FileSpec -eq "*.*") {
				If ($List.FileExclusion -eq "") {
					$FullData = (Get-ChildItem -Path $List.FolderPath -Force -Recurse -ErrorAction SilentlyContinue | Where-Object {$_.PSIsContainer -eq $False -and [DateTime](Get-Date -Date $_.LastWriteTime -Format "MM/dd/yyyy") -le [DateTime](Get-Date -Date (Get-Date).AddDays(-$List.FileAge) -Format "MM/dd/yyyy")} | Select-Object FullName, LastWriteTime, PSIsContainer)
				} Else {
					$FullData = (Get-ChildItem -Path $List.FolderPath -Exclude $List.FileExclusion -Force -Recurse -ErrorAction SilentlyContinue | Where-Object {$_.PSIsContainer -eq $False -and [DateTime](Get-Date -Date $_.LastWriteTime -Format "MM/dd/yyyy") -le [DateTime](Get-Date -Date (Get-Date).AddDays(-$List.FileAge) -Format "MM/dd/yyyy")} | Select-Object FullName, LastWriteTime, PSIsContainer)
				}
			} Else {
				If ($List.FileExclusion -eq "") {
					$FullData = (Get-ChildItem -Path $List.FolderPath -Include $List.FileSpec -Force -Recurse -ErrorAction SilentlyContinue | Where-Object {$_.PSIsContainer -eq $False -and [DateTime](Get-Date -Date $_.LastWriteTime -Format "MM/dd/yyyy") -le [DateTime](Get-Date -Date (Get-Date).AddDays(-$List.FileAge) -Format "MM/dd/yyyy")} | Select-Object FullName, LastWriteTime, PSIsContainer)
				} Else {
					$FullData = (Get-ChildItem -Path $List.FolderPath -Include $List.FileSpec -Exclude $List.FileExclusion -Force -Recurse -ErrorAction SilentlyContinue | Where-Object {$_.PSIsContainer -eq $False -and [DateTime](Get-Date -Date $_.LastWriteTime -Format "MM/dd/yyyy") -le [DateTime](Get-Date -Date (Get-Date).AddDays(-$List.FileAge) -Format "MM/dd/yyyy")} | Select-Object FullName, LastWriteTime, PSIsContainer)
				}
			}
		} Else {
			If ($List.FileSpec -eq "*.*") {
				If ($List.FileExclusion -eq "") {
					$FullData = (Get-ChildItem -Path $List.FolderPath -Force -ErrorAction SilentlyContinue | Where-Object {$_.PSIsContainer -eq $False -and [DateTime](Get-Date -Date $_.LastWriteTime -Format "MM/dd/yyyy") -le [DateTime](Get-Date -Date (Get-Date).AddDays(-$List.FileAge) -Format "MM/dd/yyyy")} | Select-Object FullName, LastWriteTime, PSIsContainer)
				} Else {
					$FullData = (Get-ChildItem -Path $List.FolderPath -Exclude $List.FileExclusion -Force -ErrorAction SilentlyContinue | Where-Object {$_.PSIsContainer -eq $False -and [DateTime](Get-Date -Date $_.LastWriteTime -Format "MM/dd/yyyy") -le [DateTime](Get-Date -Date (Get-Date).AddDays(-$List.FileAge) -Format "MM/dd/yyyy")} | Select-Object FullName, LastWriteTime, PSIsContainer)
				}
			} Else {
				If ($List.FileExclusion -eq "") {
					$FullData = (Get-ChildItem -Path $List.FolderPath -Include $List.FileSpec -Force -ErrorAction SilentlyContinue | Where-Object {$_.PSIsContainer -eq $False -and [DateTime](Get-Date -Date $_.LastWriteTime -Format "MM/dd/yyyy") -le [DateTime](Get-Date -Date (Get-Date).AddDays(-$List.FileAge) -Format "MM/dd/yyyy")} | Select-Object FullName, LastWriteTime, PSIsContainer)
				} Else {
					$FullData = (Get-ChildItem -Path $List.FolderPath -Include $List.FileSpec -Exclude $List.FileExclusion -Force -ErrorAction SilentlyContinue | Where-Object {$_.PSIsContainer -eq $False -and [DateTime](Get-Date -Date $_.LastWriteTime -Format "MM/dd/yyyy") -le [DateTime](Get-Date -Date (Get-Date).AddDays(-$List.FileAge) -Format "MM/dd/yyyy")} | Select-Object FullName, LastWriteTime, PSIsContainer)
				}
			}
		}
		$FullData | Select-Object FullName | Sort-Object FullName | ForEach {$AllFiles.Add($_.FullName)} | Out-Null
		#$FullData | Where-Object {$_.PSIsContainer -eq $False -and [DateTime](Get-Date -Date $_.LastWriteTime -Format "MM/dd/yyyy") -le [DateTime](Get-Date -Date (Get-Date).AddDays(-$List.FileAge) -Format "MM/dd/yyyy")} | Select-Object FullName | Sort-Object FullName | ForEach {$AllFiles.Add($_.FullName)} | Out-Null

		#$FullData | Where-Object {$_.PSIsContainer -eq $True -and [DateTime](Get-Date -Date $_.LastWriteTime -Format "MM/dd/yyyy") -le [DateTime](Get-Date -Date (Get-Date).AddDays(-$List.FileAge) -Format "MM/dd/yyyy")} | Select-Object FullName | Sort-Object FullName | Sort-Object LastWriteTime -Descending | Format-Table LastWriteTime, FullName -Auto -Wrap
		#$FullData | Where-Object {$_.PSIsContainer -eq $True -and [DateTime](Get-Date -Date $_.LastWriteTime -Format "MM/dd/yyyy") -le [DateTime](Get-Date -Date (Get-Date).AddDays(-$List.FileAge) -Format "MM/dd/yyyy")} | Select-Object FullName | Sort-Object FullName | ForEach {$AllFolders.Add($_.FullName)} | Out-Null
		$TotalFiles = $AllFiles.Count
		$StartTime = Get-Date -Format "yyyy/MM/dd HH:mm:ss"
		If ($TotalFiles -gt 0) {
			# Preseed the LastStatusUpdate to be 1 second ago
			# This forces the secondary Write-Progress to display at least 1 time
			$LastStatusUpdate = (Get-Date).AddSeconds(-1)
			ForEach ($File In $AllFiles) {
				$TimeNow = Get-Date
				$CurrentFile ++
				If ($Silent -eq $False -and ([Math]::Floor((New-TimeSpan -Start (Get-Date -Date $LastStatusUpdate) -End (Get-Date -Date $TimeNow)).TotalMilliseconds)) -gt 250) {
					$SecondaryPct = [Math]::Round((100/$TotalFiles) * $CurrentFile, 2)
					$ElapsedSec = (New-TimeSpan -Start $StartTime -End (Get-Date -Date $TimeNow)).TotalSeconds
					$RemainSec = ($ElapsedSec / $SecondaryPct) * (100 - $SecondaryPct)
					$EstimatedEndTime = (Get-Date -Date $TimeNow).AddSeconds($RemainSec)
					$MinutesToGo = [Math]::Floor((New-TimeSpan -Start (Get-Date -Date $TimeNow) -End $EstimatedEndTime).TotalMinutes)
					$SecondsToGo = ([Math]::Floor((New-TimeSpan -Start (Get-Date -Date $TimeNow) -End $EstimatedEndTime).TotalSeconds)) - ($MinutesToGo * 60) + 1
					If ($SecondsToGo -eq 60) {
						$MinutesToGo = $MinutesToGo + 1
						$SecondsToGo = $SecondsToGo = 0
					}
					$SecondaryStatus = ("File {0} of {1} - {2}" -f $CurrentFile, $TotalFiles, $File)
					Write-Progress -ID 2 -ParentId 1 -Activity $SecondaryStatus -Status ("Progress: {0:N2} % - Time Remaining: {1:0}:{2:00}" -f $SecondaryPct, $MinutesToGo, $SecondsToGo) -PercentComplete $SecondaryPct
					$LastStatusUpdate = Get-Date
				}
				Remove-Item $File -Force

			}
			$SecondaryStatus = ("File {0} of {1} Completed" -f $TotalFiles, $TotalFiles)
			$SecondaryPct = [Math]::Round((100/$TotalFiles) * $CurrentFile, 2)
			If ($Silent -eq $False) {
				Write-Progress -ID 2 -ParentId 1 -Activity $SecondaryStatus -Status "Progress: 100 %" -PercentComplete 100
				Write-Progress -ID 2 -ParentId 1 -Activity $SecondaryStatus -Status "Progress: 100 %" -Completed
			}
			[System.GC]::Collect()
		}
	}
	$ErrorActionPreference = "Continue"
	[System.GC]::Collect()
}

# Clean up the Recycle.Bin on all drives
$Drives = Get-WmiObject -Class Win32_Volume | Where-Object {$_.DriveType -eq 3 -and $_.Label -ne "System Reserved"} | Select-Object @{L = "Letter"; E = {$_.DriveLetter}} | Sort-Object Letter
ForEach ($Drive In $Drives) {
	$ErrorActionPreference = "SilentlyContinue"
	$Path = ("{0}\{1}\*" -f $Drive.Letter, '$Recycle.Bin')
	$MainStatus = ("{0} - Folder {1} of {2} - {3}" -f $Level, $CurrentFolder, $TotalFolders, $Path)
	$MainPct = [Math]::Round((100/$TotalFolders) * $CurrentFolder, 2)
	If ($Silent -eq $False) {
		Write-Progress -ID 1 -Activity $MainStatus -Status ("Progress: {0:N2} %" -f $MainPct) -PercentComplete $MainPct
	}
	Remove-Item $Path -Recurse -Force
	$ErrorActionPreference = "Continue"
}

$MainStatus = ("{0} - Folder {1} of {2} Completed" -f $Level, $TotalFolders, $TotalFolders)
If ($Silent -eq $False) {
	Write-Progress -ID 1 -Activity $MainStatus -Status "Progress: 100 %" -PercentComplete 100
}

$Drive = Get-WmiObject Win32_LogicalDisk -ErrorAction SilentlyContinue | Where-Object {$_.DeviceID -eq "C:" -and $_.DriveType -eq 3} | Select-Object FreeSpace
$FreeAfter = ($Drive.FreeSpace /  1MB)
$Difference = $FreeBefore - $FreeAfter
$BeforePct = [math]::Abs((Get-Round -Number ((100 / $Size) * $FreeBefore) -Digits 1))
$AfterPct = [math]::Abs((Get-Round -Number ((100 / $Size) * $FreeAfter) -Digits 1))
$DifferencePct = [math]::Abs((Get-Round -Number ((100 / $Size) * $Difference) -Digits 1))

If ($Silent -eq $False) {
	Write-Progress -ID 1 -Activity $MainStatus -Status "Progress: 100 %" -Completed
}

$Services = Get-WmiObject Win32_Service | Where-Object {$_.Name -eq "wuauserv" -or $_.PathName -like "*dagent.exe*"} | Select-Object Name, DisplayName | Sort-Object DisplayName
ForEach ($Service In $Services) {
	$Counter = 0
	If ($Silent -eq $False) {
		Write-Host
		Write-Host ("Restarting the {0} Service " -f $Service.DisplayName) -ForegroundColor Yellow -NoNewLine
	}
	$MyServiceJob = Start-Job -ArgumentList $Service.Name -ScriptBlock {Param ($Name) Start-Service -Name $Name}
	While ((Get-Service -Name $Service.Name).Status -ne 'Running') {
		$Counter = $Counter + 1
		If ($Silent -eq $False) {
			Write-Host "." -ForegroundColor DarkGray -NoNewLine
		}
		Start-Sleep -Seconds 1
		If ($Counter -ge 30) {
			# Break out of loop if over 30 seconds
			Break
		}
	}
	If ((Get-Service -Name $Service.Name).Status -eq 'Running') {
		If ($Silent -eq $False) {
			Write-Host " DONE" -ForegroundColor Green
		}
	} Else {
		If ($Silent -eq $False) {
			Write-Host " Cannot Start Service After 30 Seconds - Aborting" -ForegroundColor Red
		}
	}
	$MyServiceJob | Get-Job | ForEach {Remove-Job -ID $_.ID -Force}
}
$Counter = $Null
(schtasks /run /tn "\Microsoft\Windows\Wininet\CacheTask") 2>&1 | Out-Null
$Services = $Null
$Service = $Null
$MyServiceJob = $Null
[System.GC]::Collect()

$ScriptEndTime = Get-Date
If ($Silent -eq $False) {
	Write-Host
	Write-Host ("Drive C: Total Size  : {0,10:N1} MB   {1,5:N1}%" -f $Size, 100)
	Write-Host ("Drive C: Free Before : {0,10:N1} MB   {1,5:N1}%" -f $FreeBefore, $BeforePct)
	If ([Math]::Round($FreeAfter,1) -lt 10) {
		Write-Host ("Drive C: Free After  : {0,10:N1} MB   {1,5:N1}%" -f $FreeAfter, $AfterPct) -ForegroundColor Yellow
	} Else {
		Write-Host ("Drive C: Free After  : {0,10:N1} MB   {1,5:N1}%" -f $FreeAfter, $AfterPct) -ForegroundColor Green
	}
	Write-Host "----------------------------------------------"
	If ([Math]::Round($Difference,1) -lt 0.0) {
		Write-Host ("Drive C: Difference  : {0,10:N1} MB - {1,5:N1}%" -f [math]::abs($Difference), $DifferencePct) -ForegroundColor Green
	} ElseIf ([Math]::Round($Difference,1) -gt 0.0) {
		Write-Host ("Drive C: Difference  : {0,10:N1} MB + {1,5:N1}%" -f $Difference, $DifferencePct) -ForegroundColor Yellow
	} Else {
		Write-Host "Drive C: Difference  :        0.0 MB     0.0%"
	}
	Write-Host
	Write-Host "Stopping $ScriptDisplayName at"$(Get-Date $ScriptEndTime -Format "yyyy-MM-dd hh:mm:ss tt") -ForegroundColor Cyan
}

$Win32_OperatingSystem = Get-WmiObject -Class Win32_OperatingSystem | Select-Object @{N="ComputerName";E={$Null}}, @{N="Domain";E={$Null}}, Version, @{L="PS";E={"{0}.{1}" -f $PSVersionTable.PSVersion.Major, $PSVersionTable.PSVersion.Minor}}, @{L="OperatingSystem";E={($_.Caption -Replace('Microsoft',' ') -Replace('Server',' ') -Replace('[^\x20-\x7E]+', ' ') -Replace('\s+', ' ')).Trim()}}, @{L="SP";E={$_.ServicePackMajorVersion}}, @{L="OSBit";E={$_.OSArchitecture}}, @{N="MemoryGB";E={[Math]::Round($_.TotalVisibleMemorySize/1MB, 1, "AwayFromZero")}}, @{N="Cores";E={$Null}}, @{N="HardwareModel";E={$Null}}, @{L="Type";E={$Null}}, @{N="LastBoot";E={Get-Date ($_.ConvertToDateTime($_.LastBootUpTime)) -Format "yyyy-MM-dd hh:mm:ss tt"}}
$Win32_ComputerSystem = Get-WmiObject -Class Win32_ComputerSystem | Select-Object @{N="ComputerName";E={($_.Name).ToUpper()}}, @{N="Domain";E={($_.Domain).ToLower()}}, @{N="HardwareModel";E={(($_.Manufacturer -Replace('\, Inc\.', ''))+" "+$_.Model) -Replace('\b(\w+)\s+\1\b', '$1')}}, Model, NumberOfLogicalProcessors
$Win32_OperatingSystem.ComputerName = $Win32_ComputerSystem.ComputerName
$Win32_OperatingSystem.Domain = $Win32_ComputerSystem.Domain
$Win32_OperatingSystem.HardwareModel = $Win32_ComputerSystem.HardwareModel
$Win32_OperatingSystem.Cores = $Win32_ComputerSystem.NumberOfLogicalProcessors
If ($Win32_ComputerSystem -like "*virtual*") {
	$Win32_OperatingSystem.Type = "Virtual"
} Else {
	$Win32_OperatingSystem.Type = "Physical"
}
$ReleaseNumber = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").ReleaseId
If ($ReleaseNumber -ne $Null) {
	$Win32_OperatingSystem.Version = ("{0} (Release {1})" -f $Win32_OperatingSystem.Version, $ReleaseNumber)
}

$SysInfoArr = @()
$SysInfoArr += "Script Name          : "+$ScriptDisplayName
$SysInfoArr += "Script Started       : "+$(Get-Date $ScriptStartTime -Format "yyyy-MM-dd hh:mm:ss tt")
$SysInfoArr += "Script Ended         : "+$(Get-Date $ScriptEndTime -Format "yyyy-MM-dd hh:mm:ss tt")
$SysInfoArr += " "
$SysInfoArr += "User Running Script  : "+([System.Security.Principal.WindowsIdentity]::GetCurrent().Name).ToLower()
$SysInfoArr += "Computer Name        : "+$Win32_OperatingSystem.ComputerName
$SysInfoArr += "Domain Name          : "+$Win32_OperatingSystem.Domain
$SysInfoArr += "Operating System     : "+$Win32_OperatingSystem.OperatingSystem
$SysInfoArr += "Service Pack         : "+$Win32_OperatingSystem.SP
$SysInfoArr += "OS Version           : "+$Win32_OperatingSystem.Version
$SysInfoArr += "OS Architecture      : "+$Win32_OperatingSystem.OSBit
$SysInfoArr += "Memory GB            : "+$Win32_OperatingSystem.MemoryGB
$SysInfoArr += "CPU Cores            : "+$Win32_OperatingSystem.Cores
$SysInfoArr += "Hardware Model       : "+$Win32_OperatingSystem.HardwareModel
$SysInfoArr += "Type                 : "+$Win32_OperatingSystem.Type
$SysInfoArr += "Last Reboot          : "+$Win32_OperatingSystem.LastBoot
$SysInfoArr += "PowerShell Version   : "+$Win32_OperatingSystem.PS
$SysInfoArr += " "
$SysInfoArr += "Script Parameters"
$ParameterList = (Get-Command -Name $MyInvocation.InvocationName).Parameters
ForEach ($Key In $ParameterList.Keys) {
	$Var = Get-Variable -Name $Key -ErrorAction SilentlyContinue
	If ($Var) {
		$SysInfoArr += ("{0,-20} : {1}" -f $Var.Name, $Var.Value)
	}
}
$SysInfoArr += " "
$SysInfoArr += "Script Results"
$SysInfoArr += ("Drive C: Total Size  : {0,10:N1} MB   {1,5:N1}%" -f $Size, 100)
$SysInfoArr += ("Drive C: Free Before : {0,10:N1} MB   {1,5:N1}%" -f $FreeBefore, $BeforePct)
$SysInfoArr += ("Drive C: Free After  : {0,10:N1} MB   {1,5:N1}%" -f $FreeAfter, $AfterPct)
If ([Math]::Round($Difference,1) -lt 0.0) {
	$SysInfoArr += ("Drive C: Difference  : {0,10:N1} MB - {1,5:N1}%" -f [math]::abs($Difference), $DifferencePct)
} ElseIf ([Math]::Round($Difference,1) -gt 0.0) {
	$SysInfoArr += ("Drive C: Difference  : {0,10:N1} MB + {1,5:N1}%" -f $Difference, $DifferencePct)
} Else {
	$SysInfoArr += "Drive C: Difference  :        0.0 MB     0.0%"
}

If ($Env:UserDNSDomain -eq $Null) {
	$UserName = ($Env:UserName).ToLower() -Replace("-a","")
} Else {
	$UserName = ($Env:UserName).ToLower()-Replace("-a","")
}
$MailTo = ("{0}@firstam.com" -f $UserName)
$MailFrom = ("{0}@firstam.com" -f $Win32_OperatingSystem.ComputerName)
$MailSubject = ("{0} on {1}" -f $ScriptDisplayName, $(Get-Date $ScriptEndTime -Format "yyyy-MM-dd hh:mm tt"))
$SMTPServer = 'mail.firstam.com'

$SysInfo = $SysInfoArr | Out-String
Send-MailMessage -From $MailFrom -To $MailTo -Subject $MailSubject -SmtpServer $SMTPServer -Body $SysInfo -ErrorAction SilentlyContinue

$SysInfoArr = $Null
Get-Process -ProcessName "PowerShell" | ForEach {$_.PriorityClass = "Normal"}
[System.GC]::Collect()
