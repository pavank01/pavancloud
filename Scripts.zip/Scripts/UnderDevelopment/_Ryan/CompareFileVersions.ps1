[CmdletBinding()]
Param (
	[Parameter()]
	[String[]]$Files,

	[Parameter()]
	[String]$Location = (Get-Location).Path
)
# ---------------------------------------------------------------------------
Function Format-FileNameWithDate {
	Param (
		[String]$Prefix,
		[String]$Suffix,
		[String]$DateFormat
	)
	If ($DateFormat -eq $Null -or $DateFormat -eq "") {
		$DateFormat = "yyyy-MM-dd"
	}
	$TextDate = Get-Date -Format $DateFormat
	Return $Prefix+$TextDate+$Suffix
}
# ---------------------------------------------------------------------------
#If ($Files -eq $Null) {
#    $Files = @($Input)
#}
If ($Files.Count -lt 2) {
	Write-Host "Error - At least 2 files are required for a comparison" -ForegroundColor Red
	Break
}

# Is it using wildcards?
#$IsWP = [System.Management.Automation.WildcardPattern]::ContainsWildcardCharacters($Files)
#if($IsWP) {
#	# Convert wildcards to full names
#    $files = Get-ChildItem $files | % { $_.Name }
#}



# layout of the hash table
#$CompareFiles = @{
#	"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"     = "TAMSBURY-L1�6.3.9600.16406|SNAPPCLSFAST016�6.3.9600.17415 (6.3.9600.17396)|DFWPDCLSFAST016�6.3.9600.17415 (6.3.9600.17396)";
#	"C:\Windows\System32\WindowsPowerShell\v1.0\powershell_ise.exe" = "TAMSBURY-L1�6.3.9600.16406|SNAPPCLSFAST016�6.3.9600.17399|DFWPDCLSFAST016�6.3.9600.17399";
#}

# Create blank Hash Tables and Arrays
$CompareFiles = @{}
$FileDetails = @{}
$AllServers = @()

# my temp file list to be replace with parameters
#$Files = "GetFileVersions_DFWPDCLSFAST011_2016-11-02_1102.csv", "GetFileVersions_DFWPDCLSFAST012_2016-11-02_1105.csv", "GetFileVersions_DFWPDCLSFAST013_2016-11-02_1108.csv", "GetFileVersions_DFWPDCLSFAST014_2016-11-02_1111.csv", "GetFileVersions_DFWPDCLSFAST015_2016-11-02_1113.csv", "GetFileVersions_DFWPDCLSFAST016_2016-11-02_1115.csv", "GetFileVersions_SNAPPCLSFAST011_2016-11-02_1118.csv", "GetFileVersions_SNAPPCLSFAST012_2016-11-02_1121.csv", "GetFileVersions_SNAPPCLSFAST013_2016-11-02_1124.csv", "GetFileVersions_SNAPPCLSFAST014_2016-11-02_1127.csv", "GetFileVersions_SNAPPCLSFAST015_2016-11-02_1129.csv", "GetFileVersions_SNAPPCLSFAST016_2016-11-02_1132.csv"

Write-Host ("{0} - Start" -f (Get-Date))

Write-Host ("{0} - Importing {1:N0} Server Files" -f (Get-Date), $Files.Count)

$Total = $Files.Count
$Counter = 0
$PctLast = 0
$PctCurrent = 0
Write-Host ("{0}% " -f $PctCurrent) -ForegroundColor Green -NoNewLine
ForEach ($File In ($Files | Sort-Object)) {
	# Read in each CSV file one at a time
	$ImportFile = Import-CSV -Path $File
	ForEach ($Line In $ImportFile) {
		$ServerName = $Line.ServerName
		# check for the existence of the key
		If ($CompareFiles.Contains($Line.FullName) -eq $True) {
			# key found
			# save existing value
			$TempValue = $CompareFiles.Get_Item($Line.FullName)
			# combine new value to existing value and save to key
			$CompareFiles.Set_Item($Line.FullName, $($TempValue+'|'+$Line.ServerName+'�'+$Line.CombinedVersion))
		} Else {
			# key not found
			# create new key and value in hash table
			$CompareFiles.Add($Line.FullName, $($Line.ServerName+'�'+$Line.CombinedVersion))
		}
		If ($FileDetails.Contains($Line.FullName) -eq $False) {
			$FileDetails.Add($Line.FullName, $Line.FullFileDescription)
		}

	}
	# add server name from CSV to server list array
	$AllServers += $ServerName
	$Counter += 1
	$PctCurrent = [Math]::Abs([Math]::Round((100/$Total) * $Counter))
	If ($PctCurrent -ge ($PctLast + 5)) {
		Write-Host ("{0}% " -f $PctCurrent) -ForegroundColor Green -NoNewLine
		$PctLast = $PctCurrent
	}
}
Write-Host
$MainObject = @()
$Total = $CompareFiles.Count
$Counter = 0
$PctLast = 0
$PctCurrent = 0
Write-Host ("{0} - Comparing {1:N0} Files From {2:N0} Servers" -f (Get-Date), $CompareFiles.Count, $Files.Count)
Write-Host ("{0}% " -f $PctCurrent) -ForegroundColor Green -NoNewLine
ForEach ($CompareFile In ($CompareFiles.GetEnumerator() | Sort-Object Name)) {
	$FullFileName = $CompareFile.Name
	$FileVersion = $CompareFile.Value
	$FileDescription = $FileDetails.Get_Item($CompareFile.Name)
	$TempObject = New-Object PSObject
	$IsSame = $True
	$CompareVersion = $Null
	Add-Member -InputObject $TempObject -MemberType NoteProperty -Name "FullName" -Value ([String]$FullFileName)
	Add-Member -InputObject $TempObject -MemberType NoteProperty -Name "FileDescription" -Value ([String]$FileDescription)
	Add-Member -InputObject $TempObject -MemberType NoteProperty -Name "IsSame" -Value $IsSame
	ForEach ($ServerName In ($AllServers | Sort-Object)) {
		# add properties for each server in $AllServers with a $Null value
		Add-Member -InputObject $TempObject -MemberType NoteProperty -Name $ServerName -Value $Null
	}
	# for each key split the value into array of ServerName�CombinedVersion pairs
	ForEach ($ServerPair In ($CompareFile.Value -Split('\|'))) {
		# ServerName�CombinedVersion pair split into array of ServerName and CombinedVersion
		# $Server[0] is ServerName and $Server[1] is CombinedVersion
		$Server = $ServerPair -Split('\�')
		# change the value of property $Server[0] (ServerName) to the CombinedVersion ($Server[1])
		$TempObject.($Server[0]) = $Server[1]
		If ($CompareVersion -ne $Null) {
			# WHAT TO DO ABOUT MISSING FILES? Should they be compared or ignored?
			If ($CompareVersion -eq $Server[1] -and $IsSame -eq $True) {
				$TempObject.IsSame = $True
			} Else {
				$IsSame = $False
				$TempObject.IsSame = $False
			}
		} Else {
			$CompareVersion = $Server[1]
		}
	}
	$MainObject += $TempObject
	$TempObject = $Null
	$Counter += 1
	$PctCurrent = [Math]::Abs([Math]::Round((100/$Total) * $Counter))
	If ($PctCurrent -ge ($PctLast + 5)) {
		Write-Host ("{0}% " -f $PctCurrent) -ForegroundColor Green -NoNewLine
		$PctLast = $PctCurrent
	}
}
Write-Host
$Path = Split-Path -Path $Script:MyInvocation.MyCommand.Path # only works from a script, not at the console
$FileName = [io.path]::GetFileNameWithoutExtension((Split-Path -Path $Script:MyInvocation.MyCommand.Path -Leaf))
$NewFileName = Join-Path -Path $Path -ChildPath ($FileName+"_")
$ExportFileName = Format-FileNameWithDate -Prefix $NewFileName -Suffix ".csv" -DateFormat "yyyy-MM-dd_HHmm"
Write-Host ("{0} - Saving Server File Comparison To {1}" -f (Get-Date), $ExportFileName)
$MainObject | Sort-Object FullName | Export-CSV  $ExportFileName -NoTypeInformation
Write-Host ("{0} - End" -f (Get-Date))
