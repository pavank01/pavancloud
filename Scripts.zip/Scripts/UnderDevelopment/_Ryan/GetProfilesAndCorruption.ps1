[CmdletBinding()]
Param (
	[Parameter()]
	[Switch]$DeleteCorrupted = $False
)
# ---------------------------------------------------------------------------
Function Format-Color ([HashTable] $Colors = @{}, [switch] $SimpleMatch) {
	$ErrorAction = $ErrorActionPreference
	$DefaultFGColor = $Host.UI.RawUI.ForegroundColor
	$DefaultBGColor = $Host.UI.RawUI.BackgroundColor
	$Lines = ($Input | Out-String) -replace "`r", "" -Split "`n"
	ForEach ($Line In $Lines) {
		$FGColor = ''
		$BGColor = ''
		$Colored = $False
		ForEach ($Pattern In $Colors.Keys) {
			If (!$SimpleMatch -and $Line -match $Pattern) {
				$CurrentColors = $Colors[$Pattern].Split(",")
				$ErrorActionPreference = "SilentlyContinue"
				$CurrentColors[0] = $CurrentColors[0].Trim()
				$CurrentColors[1] = $CurrentColors[1].Trim()
				$ErrorActionPreference = $ErrorAction
				If ($CurrentColors[0] -eq "" -or $CurrentColors[0] -eq $Null) {
					$FGColor = $DefaultFGColor
				} Else {
					$FGColor = $CurrentColors[0]
				}
				If ($CurrentColors[1] -eq "" -or $CurrentColors[1] -eq $Null) {
					$BGColor = $DefaultBGColor
				} Else {
					$BGColor = $CurrentColors[1]
				}
				$Colored = $True
			}
			ElseIf ($SimpleMatch -and $Line -like $Pattern) {
				$CurrentColors = $Colors[$Pattern].Split(",")
				$ErrorActionPreference = "SilentlyContinue"
				$CurrentColors[0] = $CurrentColors[0].Trim()
				$CurrentColors[1] = $CurrentColors[1].Trim()
				$ErrorActionPreference = $ErrorAction
				If ($CurrentColors[0] -eq "" -or $CurrentColors[0] -eq $Null) {
					$FGColor = $DefaultFGColor
				} Else {
					$FGColor = $CurrentColors[0]
				}
				If ($CurrentColors[1] -eq "" -or $CurrentColors[1] -eq $Null) {
					$BGColor = $DefaultBGColor
				} Else {
					$BGColor = $CurrentColors[1]
				}
				$Colored = $True
			}
		}
		If ($Colored -eq $True) {
			Write-Host -ForegroundColor $FGColor -BackgroundColor $BGColor $Line
		} Else {
			Write-Host $Line
		}
	}
}
# ---------------------------------------------------------------------------
$StatusType = @{
	0 = "Standard";
	1 = "Temporary";
	2 = "Roaming";
	4 = "Mandatory";
	8 = "Corrupted"
}

$Background = $Host.UI.RawUI.BackgroundColor
New-PSDrive HKU Registry HKEY_USERS -ErrorAction SilentlyContinue | Out-Null

#$UserProfiles = Get-WmiObject Win32_UserProfile | Where-Object {$_.LocalPath -ne "C:\Users\Test" -and $_.LocalPath -ne "C:\Users\Test2"} | Select-Object SID, LocalPath, Status, Loaded, @{Label="LastUseTime";Expression={$_.ConvertToDateTime($_.LastUseTime)}}
$UserProfiles = Get-WmiObject Win32_UserProfile | Select-Object SID, LocalPath, Status, Loaded, @{Label="LastUseTime";Expression={$_.ConvertToDateTime($_.LastUseTime)}} | Sort-Object LocalPath
Write-Host
Write-Host ("Found {0} User Profiles - Collecting Details Now ..." -f $UserProfiles.Count)

$Profiles = @()
ForEach ($User In $UserProfiles) {
	$TempUser = $Null
	$TempUser = ((($User.LocalPath).Split("\"))[-1]).ToUpper()
	$TempUser = ((($TempUser).Split("@"))[0]).ToUpper()
	If ($TempUser -eq "LOCALSERVICE") {
		$TempUser = "LOCAL SERVICE"
	}
	If ($TempUser -eq "NETWORKSERVICE") {
		$TempUser = "NETWORK SERVICE"
	}
	If ($TempUser -eq "SYSTEMPROFILE") {
		$TempUser = "SYSTEM"
	}

# Gets the name of the local admin account even if renamed
# (Get-WmiObject -Class Win32_UserAccount -Filter "LocalAccount = 'True' AND SID LIKE 'S-1-5-21-%-500'").Name

	$RegUserName = $Null
	$RegAccountName = $Null
	$RegUserProfile = $Null


	Try {
		$UserSID = New-Object System.Security.Principal.SecurityIdentifier($User.SID)
		$UserAccount = (($UserSID.Translate([System.Security.Principal.NTAccount])).Value).ToUpper()
	}
	Catch {
		$TempSID = $User.SID
		If ((Test-Path "HKU:\$TempSID") -eq $True) {
			If ((Test-Path "HKU:\$TempSID\Volatile Environment") -eq $True) {
				$RegUserName = ((Get-ItemProperty "HKU:\$TempSID\Volatile Environment").UserName).ToUpper()
				$RegAccountName = ((Get-ItemProperty "HKU:\$TempSID\Volatile Environment").UserDomain+"\"+$RegUserName).ToUpper()
				$RegUserProfile = (Get-Culture).TextInfo.ToTitleCase(((Get-ItemProperty "HKU:\$TempSID\Volatile Environment").UserProfile).ToLower())
			}
		}
		$TempSID = $Null
		If ($RegAccountName -ne $Null -or $RegAccountName -ne "") {
			$UserAccount = $RegAccountName
		} Else {
			$UserAccount = $TempUser
		}
	}

	$DefaultProfileFolder = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList").ProfilesDirectory
	$ProfileFolders = Get-ChildItem $DefaultProfileFolder"\*" | Where-Object {$_.Name -notmatch "(\b[\w]+-[\w]+-[\w]+\b|[\s]+)"} | Select-Object FullName | Sort-Object FullName
	$ProfileAge = @()
	ForEach ($ProfileFolder In $ProfileFolders) {
		Write-Host "Searching "$ProfileFolder.FullName -ForegroundColor Cyan
		$ErrorActionPreference = "SilentlyContinue"
		$ProfileAge += ((Get-ChildItem $ProfileFolder.FullName -ErrorAction SilentlyContinue -Force -Recurse -Exclude ntuser*.* | Where-Object {$_.PSIsContainer -eq $False}) | Sort-Object LastWriteTime | Select-Object -Last 1 @{L="ProfileFolder";E={$ProfileFolder.FullName}}, LastWriteTime, @{L="LatestFile";E={$_.FullName}})
		$ErrorActionPreference = "Continue"
	}
	$ProfileAge | Sort LastWriteTime | Format-Table -Auto


# DTRESNA09SCTX03.datatree.local


#
#$DriveName = "Testing"
#$Hive = "HKLM\$DriveName"
#$Path = "C:\Users\TEMP\NTUSER.DAT"
#Reg Load  $Hive $Path
#New-PSDrive -Name $DriveName -PSProvider Registry -Root $Hive -Scope Global
#
#
#
#
#Remove-PSDrive -Name $DriveName
#Reg Unload "HKLM\$DriveName"
#[GC]::Collect()
#
#




	$ProfilesTemp = New-Object PSObject

	Add-Member -InputObject $ProfilesTemp -MemberType NoteProperty -Name "ProfilePath" -Value $User.LocalPath
	If ($RegAccountName -ne $Null) {
		Add-Member -InputObject $ProfilesTemp -MemberType NoteProperty -Name "Account" -Value $RegAccountName
	} Else {
		Add-Member -InputObject $ProfilesTemp -MemberType NoteProperty -Name "Account" -Value $UserAccount
	}
	$TempStatus = $Null
	$TempStatus = $StatusType.Get_Item([int]$user.Status)
	Add-Member -InputObject $ProfilesTemp -MemberType NoteProperty -Name "Status" -Value $TempStatus
	Add-Member -InputObject $ProfilesTemp -MemberType NoteProperty -Name "ProfileLoaded" -Value $User.Loaded
	Add-Member -InputObject $ProfilesTemp -MemberType NoteProperty -Name "LastUsed" -Value $User.LastUseTime
	Add-Member -InputObject $ProfilesTemp -MemberType NoteProperty -Name "SID" -Value $User.SID
	$Profiles += $ProfilesTemp
}

Write-Host
Write-Host "  All Profiles                                                      " -ForegroundColor Black -BackgroundColor DarkGray
$Profiles | Sort-Object ProfilePath | Format-Table -Auto | Out-String | Format-Color @{"Temporary" = "Yellow,"; "Roaming" = "Cyan,"; "Mandatory" = "Magenta,"; "Corrupted" = "Yellow,"}

If (($Profiles | Where-Object {$_.ProfileLoaded -eq $True}) -ne $Null) {
	Write-Host "  Currently Loaded Profiles                                         " -ForegroundColor White -BackgroundColor DarkCyan
	$Profiles | Where-Object {$_.ProfileLoaded -eq $True} | Sort-Object ProfilePath | Format-Table -Auto | Out-String | Format-Color @{"Temporary" = "Yellow,"; "Roaming" = "Cyan,"; "Mandatory" = "Magenta,"; "Corrupted" = "Yellow,"}
}
If (($Profiles | Where-Object {$_.Status -eq "Roaming" -or $_.Status -eq "Mandatory"}) -ne $Null) {
	Write-Host "  Roaming and Mandatory Profiles                                    " -ForegroundColor White -BackgroundColor DarkMagenta
	$Profiles | Where-Object {$_.Status -eq "Roaming" -or $_.Status -eq "Mandatory"} | Sort-Object ProfilePath | Format-Table -Auto | Out-String | Format-Color @{"Temporary" = "Yellow,"; "Roaming" = "Cyan,"; "Mandatory" = "Magenta,"; "Corrupted" = "Yellow,"}
}
If (($Profiles | Where-Object {$_.Status -eq "Temporary" -or $_.Status -eq "Corrupted"}) -ne $Null) {
	Write-Host "  Temporary and Corrupted Profiles                                  " -ForegroundColor Yellow -BackgroundColor DarkRed
	Write-Host
	Write-Host "NOTE: Only remove corrupted profiles when they are not currently loaded" -ForegroundColor Yellow -NoNewLine
	Write-Host
	Write-Host "Delete the corrupted profile folder from " -ForegroundColor Gray -NoNewline
	Write-Host "C:\Users\" -ForegroundColor Cyan -NoNewline
	Write-Host "AccountName" -ForegroundColor DarkCyan
	Write-Host "And delete the corrupted profile from " -ForegroundColor Gray -NoNewLine
	Write-Host "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\" -ForegroundColor Cyan -NoNewLine
	Write-Host "ProfileSID" -ForegroundColor DarkCyan
	$Profiles | Where-Object {$_.Status -eq "Temporary" -or $_.Status -eq "Corrupted"} | Sort-Object ProfilePath | Format-Table -Auto | Out-String | Format-Color @{"Temporary" = "Yellow,"; "Roaming" = "Cyan,"; "Mandatory" = "Magenta,"; "Corrupted" = "Yellow,"}
}
Write-Host

If ($DeleteCorrupted -eq $True -and ($Profiles | Where-Object {$_.Status -eq "Temporary" -or $_.Status -eq "Corrupted"}) -ne $Null) {
	$Accounts = $Profiles | Where-Object {$_.Status -eq "Temporary" -or $_.Status -eq "Corrupted"} | Select-Object @{N="UserID";E={(Get-Culture).TextInfo.ToTitleCase(($_.ProfilePath -Replace("C:\\Users\\","")).ToLower())}} | Sort-Object UserID
	$Counter = $Accounts.Count
	ForEach ($Account In $Accounts) {
		$FindAccount = $Account.UserID
		$Profile = Get-WmiObject -Class Win32_UserProfile | Where-Object {$_.Special -eq $False -and $_.LocalPath -eq ("C:\Users\{0}" -f $FindAccount)}
		If ($Profile -ne $Null) {
			$ProfileName = (Get-Culture).TextInfo.ToTitleCase((($Profile.LocalPath.Split("\"))[2]).ToLower())
			Write-Host ("{0,5} Local User Profile {1} Has Been Found" -f $Counter, $ProfileName) -ForegroundColor Cyan
			If ($Profile.Loaded -eq $True) {
				$SessionID = ((QUser | Where-Object {$_ -like "*$FindProfile*"}) -Split ' +')[2]
				If ($SessionID -ne $Null) {
					Logoff $SessionID
					Write-Host ("{0,5} User {1} Has Been Logged Off" -f '', $ProfileName) -ForegroundColor Yellow
				}
			}
			$Profile.Delete()
			Write-Host ("{0,5} Local User Profile {1} Has Been Deleted" -f '', $ProfileName) -ForegroundColor Green
		} Else {
			Write-Host ("{0,5} Local User Profile {1} Not Found Or Ignored" -f '', $FindAccount) -ForegroundColor DarkCyan
		}
		Write-Host
		$Counter = $Counter - 1
	}
}











#Get-WmiObject -Class Win32_UserProfile | Where-Object {$_.LocalPath.Split('\')[-1] -eq 'WOnes'} | ForEach {$_.Delete()}





#requires
#-version 3.0
#Remove-UserProfile.ps1
#[cmdletbinding(SupportsShouldProcess)]
#Param(
#	[Parameter(Position=0)]
#	[ValidateNotNullorEmpty()]
#	[int]$Days=30
#)
#Start-Transcript -Path C:\ProfileCleanup.txt -Append
#Write-Warning "Filtering for user profiles older than $Days days"
#Get-CimInstance win32_userprofile -Verbose |
#	Where {$_.LastUseTime -lt $(Get-Date).Date.AddDays(-$days)} |
#	Remove-CimInstance -Verbose
#Stop-Transcript



#
## Look into remove options
## Remove-CimInstance
#
## HealthStatus is for the Roaming / Remote Profile
#$HealthStatusHash = @{
#	"Unhealthy"      = 1
#	"Caution"        = 2
#	"Not Applicable" = 4
#}
#
## Status is for the Local Profile
#$StatusHash = @{
#	"Temporary" = 1
#	"Roaming"   = 2
#	"Mandatory" = 4
#	"Corrupted" = 8
#}
#Write-Host "Loading Profile Information" -ForegroundColor Magenta
#$Profiles = Get-CimInstance Win32_UserProfile | Select-Object @{L="UserName";E={$Null}}, LocalPath, SID, LastUseTime, Loaded, Special, @{L="Type";E={$Null}}, Status, @{L="LocalStatus";E={$Null}}, HealthStatus, @{L="RoamingStatus";E={$Null}} | Where-Object {$_.LocalPath -ne "C:\Users\Test" -and $_.LocalPath -ne "C:\Users\Test2"} | Sort-Object LocalPath
#$NetworkProfiles = Get-WmiObject Win32_NetworkLoginProfile | Select-Object Caption, Name, @{Label="LastLogon";Expression={$_.ConvertToDateTime($_.LastLogon)}}
#
#
#ForEach ($Profile In $Profiles) {
#	$Roaming = $False
#	$TempUser = ((($Profile.LocalPath).Split("\"))[-1]).ToUpper()
#	#Write-Host "Getting User Name For "$Profile.LocalPath -ForegroundColor Magenta
#	#$Profile.UserName = (Get-WmiObject Win32_UserAccount -Filter "SID = '$SID'").Caption
#
#	If ($Profile.Type.Length -lt 1 -and $Profile.LocalPath -like "*-a" -or $Profile.LocalPath -like "*-a@*") {
#		$Profile.Type = "SupportAdmin"
#	}
#	If ($Profile.Type.Length -lt 1 -and $Profile.LocalPath -like "*-SA-*") {
#		# What about -RA- accounts?
#		$Profile.Type = "ServiceAccount"
#	}
#	If (($Profile.Type.Length -lt 1) -and ($Profile.LocalPath -like "*$*" -or $Profile.LocalPath -like "*SQL*" -or $Profile.LocalPath -like "*SSISTELEMETRY*" -or $Profile.LocalPath -like "*MsDtsServer*")) {
#		$Profile.Type = "SQLService"
#	}
#	If (($Profile.Type.Length -lt 1) -and ($Profile.Special -eq $True -or $Profile.LocalPath -like "*FAAdmin*" -or $Profile.LocalPath -like "*Administrator*" -or $Profile.LocalPath -like "*FAAdmin*" -or $Profile.LocalPath -like "*DMZAdmin*" -or $Profile.LocalPath -like "*.NET*")) {
#		$Profile.Type = "SystemAccount"
#	}
#	If ($Profile.Type.Length -lt 1) {
#		$Profile.Type = "UserAccount"
#	}
#
#	If ($Profile.Status -ne 0) {
#		ForEach ($Bit In ($StatusHash.GetEnumerator() | Sort-Object -Property Value )){
#			If (($Profile.Status -band $Bit.Value) -ne 0) {
#				If (($Profile.Status -band $Bit.Value) -eq 2) {
#					$Roaming = $True
#				}
#				If ($Profile.LocalStatus.Length -gt 1) {
#					$Profile.LocalStatus += ' | '+$Bit.Key
#				} Else {
#					$Profile.LocalStatus = $Bit.Key
#				}
#			}
#		}
#	} Else {
#		$Profile.LocalStatus = "Healthy"
#	}
#	If ($Roaming -eq $True) {
#		If ($Profile.HealthStatus -ne 0) {
#			ForEach ($Bit In ($HealthStatusHash.GetEnumerator() | Sort-Object -Property Value )){
#				If (($Profile.HealthStatus -band $Bit.Value) -ne 0) {
#					If ($Profile.RoamingStatus.Length -gt 1) {
#						$Profile.RoamingStatus += ' | '+$Bit.Key
#					} Else {
#						$Profile.RoamingStatus = $Bit.Key
#					}
#				}
#			}
#		} Else {
#			$Profile.RoamingStatus = "Healthy"
#		}
#	} Else {
#		$Profile.RoamingStatus = "N/A"
#	}
#}
#Write-Host
#Write-Host "ALL PROFILES" -ForegroundColor White
#$Profiles | Sort-Object Type, LocalPath | Format-Table Type, UserName, LocalPath, LastUseTime, Loaded, LocalStatus, RoamingStatus, SID -Auto | Out-String | Format-Color @{"LocalPath" = "Gray,"; "Healthy" = "Green,"; "Temporary" = "Yellow,"; "Roaming" = "Cyan,"; "Mandatory" = "Magenta,"; "Corrupted" = "Red,"; "Unhealthy" = "Red,"; "Caution" = "Yellow,"}
#Write-Host
#Write-Host "PROFILES LOADED" -ForegroundColor White
#$Profiles | Where-Object {$_.Loaded -eq $True} | Sort-Object Type, UserName, LocalPath | Format-Table Type, LocalPath, LastUseTime, Loaded, LocalStatus, RoamingStatus -Auto | Out-String | Format-Color @{"LocalPath" = "Gray,"; "Healthy" = "Green,"; "Temporary" = "Yellow,"; "Roaming" = "Cyan,"; "Mandatory" = "Magenta,"; "Corrupted" = "Red,"; "Unhealthy" = "Red,"; "Caution" =  "Yellow,"}
#Write-Host
#Write-Host "PROFILES NOT LOADED" -ForegroundColor White
#$Profiles | Where-Object {$_.Loaded -eq $False} | Sort-Object Type, UserName, LocalPath | Format-Table Type, LocalPath, LastUseTime, Loaded, LocalStatus, RoamingStatus -Auto | Out-String | Format-Color @{"LocalPath" = "Gray,"; "Healthy" = "Green,"; "Temporary" = "Yellow,"; "Roaming" = "Cyan,"; "Mandatory" = "Magenta,"; "Corrupted" = "Red,"; "Unhealthy" = "Red,"; "Caution" =  "Yellow,"}
#
#
#
##$Profiles | Where-Object {$_.Loaded -eq $False -and $_.Type -eq "UserAccount"} | Get-CimInstance Win32_UserProfile -Filter @{SID=$_.SID}


