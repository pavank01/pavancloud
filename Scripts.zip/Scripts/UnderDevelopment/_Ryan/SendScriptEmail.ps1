Function Send-ScriptEmail {
<#
	.SYNOPSIS
		Send email about the usage of a script - NOT COMPLETE

	.DESCRIPTION
		Send email about the usage of a script - NOT COMPLETE

	.PARAMETER ParameterName1

	.PARAMETER ParameterName2

	.EXAMPLE

	.NOTES
		-Initial Release
#>
	[CmdletBinding()]
	Param (
		# Param1 very short help description
		[Parameter(Mandatory = $False, ValueFromPipeline = $True)]
		[PSObject[]]$ParameterName1,

		# Param2 very short help description
		[Parameter(Mandatory = $False, ValueFromPipeline = $True)]
		[PSObject[]]$ParameterName2
	)
	# --------------------------------------------------------------------------------
	$PSVersion = $PSVersionTable.PSVersion.Major

	If ($PSVersion -lt 3) {
		# Older PowerShell
		$ComputerSystem = Get-WmiObject -Class Win32_ComputerSystem
		$OperatingSystem = Get-WmiObject -Class Win32_OperatingSystem

		$WMIOperatingSystem = Get-WmiObject -Class Win32_OperatingSystem | Select-Object @{L="ComputerName";E={If ($_.PSComputerName) {$_.PSComputerName} Else {$_.CSName}}}, @{L="Domain";E={$Null}}, @{L="OperatingSystem";E={($_.Caption -Replace('Microsoft',' ') -Replace('Server',' ') -Replace('[^\x20-\x7E]+', ' ') -Replace('\s+', ' ')).Trim()}}, @{L="SP";E={If ($_.ServicePackMinorVersion -gt 0) {"{0}.{1}" -f $_.ServicePackMajorVersion, $_.ServicePackMinorVersion} Else {$_.ServicePackMajorVersion}}}, Version, @{L="Release";E={$Null}}, OSArchitecture, @{L="Type";E={$Null}}, @{L="PSVersion";E={"{0}.{1}" -f $PSVersionTable.PSVersion.Major, $PSVersionTable.PSVersion.Minor}}
		$Type = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").InstallationType
		If ($Type -eq "Client") {
			$WMIOperatingSystem.Type = "Workstation"
		} Else {
			$WMIOperatingSystem.Type = $Type
		}
		$ReleaseID = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").ReleaseID
		If ($ReleaseID -gt 0) {
			$WMIOperatingSystem.Release = $ReleaseID
		} Else {
			$WMIOperatingSystem.Release = 0
		}
		$WMIComputerSystem = Get-WmiObject Win32_ComputerSystem -Property PartOfDomain, Domain, Workgroup
		If ($WMIComputerSystem.PartOfDomain -eq $True) {
			$WMIOperatingSystem.Domain = ($WMIComputerSystem.Domain).ToLower()
		} Else {
			$WMIOperatingSystem.Domain = ($WMIComputerSystem.Workgroup).ToUpper()
		}
	} Else {
		# Newer PowerShell
		$ComputerSystem = Get-CimInstance -Class CIM_ComputerSystem
		$OperatingSystem = Get-CimInstance -Class CIM_OperatingSystem
	}


	Get-WmiObject -Class Win32_OperatingSystem | Select-Object @{L="OperatingSystem";E={($_.Caption -Replace('Microsoft',' ') -Replace('[^\x20-\x7E]+', ' ') -Replace('\s+', ' ')).Trim()}}, @{L="SP";E={$_.ServicePackMajorVersion}}, @{L="OSArchitecture";E={$_.OSArchitecture -Replace('\-bit', '')}}, @{L="PSVersion";E={"{0}.{1}" -f $PSversionTable.psversion.major, $PSversionTable.psversion.minor}}


	$ReleaseId = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").ReleaseId

	$ServerName = $ComputerSystem.Name
	$LastBootUpTime = $OperatingSystem.LastBootUpTime
	$Manufacturer = $ComputerSystem.Manufacturer
	$Model = $ComputerSystem.Model
	$Caption = $OperatingSystem.Caption
	$ServicePack = $OperatingSystem.ServicePackMajorVersion
	$Version = $OperatingSystem.Version
	$ReleaseId = $ReleaseId
	$InstallDate = $OperatingSystem.InstallDate

	$ScriptName = [io.path]::GetFileNameWithoutExtension($MyInvocation.MyCommand.Definition)
	$ScriptVersion = 1.0
	$sLogDate = Get-Date -Format yyyy-MM-dd
	$SMTPServer = 'mail.firstam.com'
	$MailFrom = $ServerName + '@firstam.com'
	$MailTo = ($Env:UserName -Replace('-a','')) + '@firstam.com'
	$MailSubject = "$ScriptVersion [ $ServerName ] $([DateTime]::Now) "

	$SysInfoArr = @()
	$SysInfoArr += ("Script              : {0} v{1}" -f $ScriptName, $ScriptVersion)
	$SysInfoArr += "Arg                 : -$sCmdLine"
	$SysInfoArr += " "
	$SysInfoArr += "User Logged In      : $Env:UserName"
	$SysInfoArr += "Server Name         : $ServerName"
	$SysInfoArr += "Last Reboot         : $LastBootUpTime"
	$SysInfoArr += "Manufacturer        : $Manufacturer"
	$SysInfoArr += "Model               : $Model"
	$SysInfoArr += "Operating System    : $Caption"
	$SysInfoArr += "Service Pack        : $ServicePack"
	$SysInfoArr += "Version             : $Version "
	$SysInfoArr += "ReleaseId           : $ReleaseId"
	$SysInfoArr += "Install Date        : $InstallDate"

	$SysInfo = $SysInfoArr | Format-Table | Out-String


	If ((Test-Path -Path $sLogPath) -eq $False) {
		New-Item -Path $sLogPath -ItemType Directory | Out-Null
	}

	Send-MailMessage -From $MailFrom -To $MailTo -Subject $MailSubject -SmtpServer $SMTPServer -Body $SysInfo -Attachments $sFullPath
}
