# -----------------------------------------------------------------------------
$Policies = Get-ExecutionPolicy -List
ForEach ($Policy in $Policies) {
	If ($Policy.Scope -eq "CurrentUser") {
		If ($Policy.ExecutionPolicy -ne "Unrestricted") {
			Write-Host "Changing the Current User Execution Policy to Unrestricted" -ForegroundColor Yellow
			Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Force -Scope CurrentUser
		} Else {
			Write-Host "Current User Execution Policy is Unrestricted" -ForegroundColor Green
		}
	}
	If ($Policy.Scope -eq "LocalMachine") {
		If ($Policy.ExecutionPolicy -ne "Unrestricted") {
			Write-Host "Changing the Local Machine Execution Policy to Unrestricted" -ForegroundColor Yellow
			Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Force -Scope LocalMachine
		} Else {
			Write-Host "Local Machine Execution Policy is Unrestricted" -ForegroundColor Green
		}
	}
}
Try {
	$ExecutionPolicy = Invoke-Command -ComputerName LocalHost {Get-ExecutionPolicy} -ErrorAction Stop
	Write-Host "PSRemoting is Enabled" -ForegroundColor Green
} Catch {
	Write-Host "Enabling PSRemoting" -ForegroundColor Yellow
	Enable-PSRemoting -Force
}
winrm set winrm/config/winrs '@{MaxShellsPerUser="25"}'
# -----------------------------------------------------------------------------