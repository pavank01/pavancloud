Function Uninstall-Hotfix {
<#
	.SYNOPSIS
		Uninstalls Microsoft Hotfixes / Patches
	.DESCRIPTION
		Uninstalls Microsoft Hotfixes / Patches. Always uninstalls them in date order from the most recent to the oldest.
	.PARAMETER HotfixID
		The Hotfix ID or array of IDs to uninstall
	.PARAMETER Path
		Path to a file with the Hotfix ID or IDs to uninstall, one per line
	.EXAMPLE
		Uninstall-Hotfix -HotfixID KB3185279, KB3185331, KB3192404
	.EXAMPLE
		Uninstall-Hotfix -HotfixID KB3185279
	.EXAMPLE
		$Hotfixes = "KB3185279", "KB3185331", "KB3192404"
		C:\PS>Uninstall-Hotfix -HotfixID $Hotfixes
	.EXAMPLE
		Uninstall-Hotfix -Path C:\Temp\HotfixList.txt

		HotfixList.txt
		    KB3185279
		    KB3185331
		    KB3192404
#>
	[CmdletBinding()]
	Param (
		[String[]]$HotfixID,
		[String[]]$Path = $Null
	)
	If ($Path -ne $Null) {
		$HoxfixID = Get-Content -Path $Path
	}
	$InstalledHotfixes = Get-WmiObject -Class Win32_QuickFixEngineering | Select-Object HotfixID | Sort-Object HotfixID -Descending
	Write-Host
	Write-Host ("{0} Hotfixes Installed - Uninstalling {1} Hotfixes" -f $InstalledHotfixes.Count, $HotfixID.Count) -ForegroundColor White
	Write-Host
	ForEach ($Hotfix In ($HotFixID | Sort-Object -Descending)) {
		If ($InstalledHotfixes -match $Hotfix) {
			$Hotfix = $Hotfix.Replace("KB","")
			Write-Host ("Uninstalling Hotfix KB{0} ... " -f $Hotfix) -NoNewLine -ForegroundColor Cyan
			Start-Process "C:\Windows\System32\cmd.exe" -ArgumentList "/c wusa.exe /uninstall /kb:$Hotfix /quiet /norestart" -Wait -WindowStyle Hidden
			Write-Host ("Completed" -f $Hotfix) -ForegroundColor Green
		} Else {
			Write-Host ("Hotfix {0} Not Installed" -f $Hotfix) -ForegroundColor Yellow
		}
	}
	Write-Host
}


