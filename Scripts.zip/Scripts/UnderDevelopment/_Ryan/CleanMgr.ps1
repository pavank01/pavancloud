#$ErrorAction = $ErrorActionPreference
#$ErrorActionPreference = "SilentlyContinue"
$Bit = Get-WmiObject -Class Win32_OperatingSystem | Select-Object -Expand OSArchitecture
$Windows = Get-WmiObject -Class Win32_OperatingSystem | Select-Object @{N="OperatingSystem";E={($_.Caption -Replace('Microsoft',' ') -Replace('Server',' ') -Replace('[^\x20-\x7E]+', ' ') -Replace('\s+', ' ')).Trim()}} | Select-Object -Expand OperatingSystem
Write-Host $Bit -ForegroundColor Magenta
If ($Bit -eq "64-bit") {
	# x64
	Write-host ("{0} ({1})" -f $Windows, $Bit) -ForegroundColor Cyan
	$CleanMgr = Get-ChildItem -Path "C:\Windows\WinSxS\amd64_microsoft-windows-cleanmgr*\*" -Filter "cleanmgr.exe*" -Recurse -ErrorAction SilentlyContinue | Where-Object {$_.PSPath -like "*amd64_microsoft-windows-cleanmgr*"} | Sort-Object PSPath -Descending
	$CleanMgr | ForEach {Write-Host $_ -ForegroundColor DarkGray}
	$CMEXE = ($CleanMgr | Where-Object {$_.PSPath -like "*amd64_microsoft-windows-cleanmgr_*"} | Select-Object -First 1).PSPath
	$CMEXE = $CMEXE.SubString(38, $CMEXE.Length-38)
	$CMMUI = ($CleanMgr | Where-Object {$_.PSPath -like "*amd64_microsoft-windows-cleanmgr.resources_*"} | Select-Object -First 1).PSPath
	$CMMUI = $CMMUI.SubString(38, $CMMUI.Length-38)
} Else {
	# x32
	Write-host ("{0} ({1})" -f $Windows, $Bit) -ForegroundColor Cyan
	$CleanMgr = Get-ChildItem -Path "C:\Windows\WinSxS\x86_microsoft-windows-cleanmgr*\*" -Filter "cleanmgr.exe*" -Recurse -ErrorAction SilentlyContinue | Where-Object {$_.PSPath -like "*x86_microsoft-windows-cleanmgr*"} | Sort-Object PSPath -Descending
	Write-Host $CleanMgr -ForegroundColor DarkGray
	$CMEXE = ($CleanMgr | Where-Object {$_.PSPath -like "*x86_microsoft-windows-cleanmgr_*"} | Select-Object -First 1).PSPath
	$CMEXE = $CMEXE.SubString(38, $CMEXE.Length-38)
	$CMMUI = ($CleanMgr | Where-Object {$_.PSPath -like "*x86_microsoft-windows-cleanmgr.resources_*"} | Select-Object -First 1).PSPath
	$CMMUI = $CMMUI.SubString(38, $CMMUI.Length-38)
}
$Success = $False
# Copy cleanmgr.exe
$Source = $CMEXE
$Target = "C:\Windows\System32\cleanmgr.exe"
If (Test-Path -Path $Target) {
	Write-Host ("CleanMgr.exe ({0}) already installed" -f $Bit) -ForegroundColor Green
	$Success = $True
} Else {
	Copy-Item -Path $Source -Destination $Target -Force
	If (Test-Path -Path $Target) {
		Write-Host "Successfully copied" $Target -ForegroundColor Green
		$Success = $True
	} Else {
		Write-Host "Copy failed" $Target -ForegroundColor Red
		$Success = $False
	}
}
# Copy cleanmgr.exe.mui
$Source = $CMMUI
$Target = "C:\Windows\System32\en-US\cleanmgr.exe.mui"
If (Test-Path -Path $Target) {
	Write-Host ("CleanMgr.exe.mui ({0}) already installed" -f $Bit) -ForegroundColor Green
	$Success = $True
} Else {
	Copy-Item -Path $Source -Destination $Target -Force
	If (Test-Path -Path $Target) {
		Write-Host "Successfully copied" $Target -ForegroundColor Green
		$Success = $True
	} Else {
		Write-Host "Copy failed" $Target -ForegroundColor Red
		$Success = $False
	}
}
If ($Success = $True) {
	Write-Host ("CleanMgr.exe ({0}) is available to be used" -f $Bit) -ForegroundColor Cyan
	$CleanMgr = "C:\Windows\System32\CleanMgr.exe"
	$Arguments = @("/SageSet", "/SageRun", "/VeryLowDisk")
	$Arguments | ForEach-Object {Start-Process -FilePath $CleanMgr -ArgumentList $_ -Wait}
} Else {
	Write-Host ("CleanMgr.exe ({0}) is not available to be used" -f $Bit) -ForegroundColor Yellow
}


#$ErrorActionPreference = $ErrorAction



<#
$Bit = (Get-ItemProperty -Path Registry::"HKLM\HARDWARE\DESCRIPTION\System\CentralProcessor\0").Identifier
If ($Bit -eq $Null -or $Bit -eq "") {
	$Bit = "Intel64"
}
Write-Host $Bit -ForegroundColor Magenta
If ($Bit.StartsWith("Intel64")) {
	# x64
	Write-host "Windows 64-bit" -ForegroundColor Cyan
	$Bit = "x64"
	$CleanMgr = Get-ChildItem -Path "C:\Windows\WinSxS\amd64_microsoft-windows-cleanmgr*\*" -Filter "cleanmgr.exe*" -Recurse -ErrorAction SilentlyContinue | Where-Object {$_.FullName -like "*amd64_microsoft-windows-cleanmgr*"} | Sort-Object FullName -Descending | Select-Object -ExpandProperty FullName
	$CleanMgr | ForEach {Write-Host $_ -ForegroundColor Magenta}
	ForEach ($CM In $CleanMgr) {
		$Temp = $CM -Split("_")

	}

	$CMEXE = ($CleanMgr | Where-Object {$_.PSPath -like "*amd64_microsoft-windows-cleanmgr_*"} | Select-Object -First 1).PSPath
	$CMEXE = $CMEXE.SubString(38, $CMEXE.Length-38)
	$CMMUI = ($CleanMgr | Where-Object {$_.PSPath -like "*amd64_microsoft-windows-cleanmgr.resources_*"} | Select-Object -First 1).PSPath
	$CMMUI = $CMMUI.SubString(38, $CMMUI.Length-38)
} Else {
	# x32
	Write-host "Windows 32-bit" -ForegroundColor Cyan
	$Bit = "x32"
	$CleanMgr = Get-ChildItem -Path "C:\Windows\WinSxS\x86_microsoft-windows-cleanmgr*\*" -Filter "cleanmgr.exe*" -Recurse -ErrorAction SilentlyContinue | Where-Object {$_.PSPath -like "*x86_microsoft-windows-cleanmgr*"} | Sort-Object PSPath -Descending
	Write-Host $CleanMgr -ForegroundColor Magenta
	$CMEXE = ($CleanMgr | Where-Object {$_.PSPath -like "*x86_microsoft-windows-cleanmgr_*"} | Select-Object -First 1).PSPath
	$CMEXE = $CMEXE.SubString(38, $CMEXE.Length-38)
	$CMMUI = ($CleanMgr | Where-Object {$_.PSPath -like "*x86_microsoft-windows-cleanmgr.resources_*"} | Select-Object -First 1).PSPath
	$CMMUI = $CMMUI.SubString(38, $CMMUI.Length-38)
}
#>


# Options
# /sageset:nn
# /sagerun:nn
# /tuneup:nn
# /lowdisk
# /verylowdisk
#
# CleanMgr.exe /sageset:1 - Sets defaults to delete for set 1
# CleanMgr.exe /sagerun:1 - Runs delete for default set 1


