If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
   [Security.Principal.WindowsBuiltInRole] "Administrator"))

   {
        Write-Warning "You do not have Administrator rights to run this script!`nPlease re-run this script as an Administrator!"
        Exit
   }

   
# Variables
$DCSNameST = "DiskPerf"
$SourceTemplatesFolder = '.\'

# File containing server list to run commands against
$Servers = Get-Content ".\servers.txt"


# Iterate through each server in $Servers and run commands below
ForEach ($Server in $Servers)
{
    #Building the command execution
    $templatePathST   = Join-Path -Path $SourceTemplatesFolder -ChildPath "DiskPerf.xml"
    $templatePathTask = Join-Path -Path $SourceTemplatesFolder -ChildPath "DiskPerfSchedTask.xml"

    Write-Verbose ("Running command logman import -s $Server -xml $templatePathST -name $DCSNameST") -v
    logman import -s $Server -xml $templatePathST -name $DCSNameST
    
    switch($LASTEXITCODE)
    {
	    -2147467259 {Write-Host "Path or file not found. The Collector Set was not created. The script and the template should be in the same folder" -ForegroundColor Red}
	    -2144337737 {Write-host "Collector Set already exists on $Server and can not be imported" -ForegroundColor Red}
	    0 			{Write-Host "Collector Set imported and created" -ForegroundColor Green}
    }

    logman start -s $Server -name $DCSNameST
    
    if($LASTEXITCODE -eq 0)
    {
	    Write-Host "Starting Collector Set on $Server"
	    sleep -Milliseconds 5000
        schtasks /CREATE /S $Server /TN "DiskPerf\DiskPerfRestartOnBoot" /RU "SYSTEM" /XML $templatePathTask /F

    }
    else
    {
        Write-Error ("Error stating Collector Set on $Server : $LASTEXITCODE")
        Continue
    }
    
    sleep -Milliseconds 2000
    logman query -s $Server
}