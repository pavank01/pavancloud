If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(`
   [Security.Principal.WindowsBuiltInRole] "Administrator"))

   {
        Write-Warning "You do not have Administrator rights to run this script!`nPlease re-run this script as an Administrator!"
        Exit
   }

#Set location to source files
#Set-location \\corp.firstam.com\restricted\ServerOps-Admin\Scripts\UnderDevelopment\_Kimber\Perfmon
   
# Variables
$DCSNameST = "HealthCheck (ST)"
$DCSNameLT = "HealthCheck (LT)"
$SourceTemplatesFolder = '.\'

# File containing server list to run commands against
$Servers = Get-Content ".\servers.txt"


# Iterate through each server in $Servers and run commands below
ForEach ($Server in $Servers)
{
    #Building the command execution
    $templatePathST   = Join-Path -Path $SourceTemplatesFolder -ChildPath "CoreOS.ST.xml"
    $templatePathLT   = Join-Path -Path $SourceTemplatesFolder -ChildPath "CoreOS.LT.xml"
    $templatePathTask = Join-Path -Path $SourceTemplatesFolder -ChildPath "CoreOsStSchedTask.xml"

    Write-Verbose ("Running command logman import -s $Server -xml $templatePathST -name $DCSNameST") -v
    logman import -s $Server -xml $templatePathST -name $DCSNameST
    
    Write-Verbose ("Running command logman import -s $Server -xml $templatePathLT -name $DCSNameLT") -v
    logman import -s $Server -xml $templatePathLT -name $DCSNameLT      
    
    switch($LASTEXITCODE)
    {
	    -2147467259 {Write-Host "Path or file not found. The Collector Set was not created. The script and the template should be in the same folder" -ForegroundColor Red}
	    -2144337737 {Write-host "Collector Set already exists on $Server and can not be imported" -ForegroundColor Red}
	    0 			{Write-Host "Collector Set imported and created" -ForegroundColor Green}
    }

    logman start -s $Server -name $DCSNameST
    logman start -s $Server -name $DCSNameLT

    if($LASTEXITCODE -eq 0)
    {
	    Write-Host "Starting Collector Set on $Server"
	    sleep -Milliseconds 5000
        schtasks /CREATE /S $Server /TN "HealthCheck\HealthCheckRestartOnBoot" /RU "SYSTEM" /XML $templatePathTask /F

    }
    else
    {
        Write-Error ("Error stating Collector Set on $Server : $LASTEXITCODE")
        Continue
    }
    
    sleep -Milliseconds 2000
    logman query -s $Server
}