﻿param(

    [Parameter(Mandatory=$true)]
    [PSCredential]$AzureCredential,
    [Parameter(Mandatory=$true)]
    [PSCredential]$WindowsCredential,
    [Parameter(Mandatory=$false)]
    $ServiceNamePattern = 'SO-1-1-FINT-CS-*',
    [Parameter(Mandatory=$false)]
    $DomainSuffix = 'fastts.firstam.net'

)

function Check-ServiceHealth {

    param(
        [Parameter(Mandatory=$true)]
        [string]$ServiceName,
        [Parameter(Mandatory=$false)]
        $DomainSuffix
    )

    $vmList = Get-AzureVM -ServiceName $fintService.ServiceName

    foreach ($vm in $vmList) {

        Check-VMHealth -VM $vm -DomainSuffix $DomainSuffix

    }

}

function Check-VMHealth {

    param(
        [Parameter(Mandatory=$true)]
        $VM,
        [Parameter(Mandatory=$false)]
        $DomainSuffix
    )

    if ($DomainSuffix) {
        $ComputerName = "$($VM.Name).$DomainSuffix"
    } else {
        $ComputerName = $VM.Name
    }

    if ($vm.PowerState -eq 'Started') {

        try {

            $result = Invoke-Command -ComputerName $ComputerName -Credential $WindowsCredential -ScriptBlock { $env:COMPUTERNAME } -ErrorAction Stop

        } catch {

            $result = 'FAILED'

        }

    } else {

        $result = 'n/a'

    }

    $output = [PSCustomObject]@{ 
        ServiceName = $VM.ServiceName
        InstanceName = $VM.InstanceName
        PowerState = $VM.PowerState
        IPAddress = $VM.IpAddress
        HostName = $ComputerName
        Check = $result
    }

    Write-Verbose $output

    $output

}



Write-Verbose 'Logging into Azure...'
Add-AzureAccount -Credential $AzureCredential | Out-Null

Write-Verbose 'Selecting subscription...'
Select-AzureSubscription -SubscriptionName 'SO-1-AzureSub-1' | Out-Null

Write-Verbose 'Retrieving list of services...'
$fintServices = Get-AzureService | ? { $_.ServiceName -like $ServiceNamePattern }

foreach ($fintService in $fintServices) {

    Write-Verbose "Checking $($fintService.ServiceName)..."
    Check-ServiceHealth -ServiceName $fintService.ServiceName -DomainSuffix $DomainSuffix

}
