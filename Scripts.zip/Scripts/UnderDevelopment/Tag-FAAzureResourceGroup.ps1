<#
.SYNOPSIS
Tag an Azure Resource group with ApplicationName and EnvironmentName

.DESCRIPTION
A PowerShell script to create tag an Azure Resource gorup with the required tags for ApplicationName and EnvironmentName.  This 
will replace any and all tags that currently exist on the resource group.

.PARAMETER ResourceGroupName
The name of the resource group to tag.

.PARAMETER ApplicationName,
The application name to tag the resource with.  This should be the same as the Application Name in the CMDB.

.PARAMETER EnvironmentName
The environment name to tag the resource with.  This should be the same as the Environment Name in the CMDB.

.INPUTS
None.  You cannot pipe input to Tag-FAAzureResourceGroup.ps1.

.OUTPUTS
None.  Tag-FAAzureResourceGroup.ps1 does not generate any output.

.EXAMPLE
.\Tag-FAAzureResourceGroup.ps1 -ResourceGroupName 'SO-1-1-AZUR-RG-1' -ApplicationName 'Microsoft Azure' -EnvironmentName 'Prod'

Tag the resource group 'SO-1-1-AZUR-RG-1' as being part of the Production instance of the Microsoft Azure application.

#>

#------------------------------------------------------------------------------
#region - Parameters
#------------------------------------------------------------------------------
Param(

    [Parameter(Mandatory=$TRUE)]
    [string]$ResourceGroupName,
    
    [Parameter(Mandatory=$TRUE)]
    [string]$ApplicationName,
    
    [Parameter(Mandatory=$TRUE)]
    [string]$EnvironmentName
    
)

$tags = @{ApplicationName=$ApplicationName;EnvironmentName=$EnvironmentName}
    
Set-AzureRMResourceGroup -Name $ResourceGroupName -Tag $tags     
