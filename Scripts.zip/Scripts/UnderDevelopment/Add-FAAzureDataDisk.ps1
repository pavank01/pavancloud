﻿<#
.DESCRIPTION
Add-FAAzureDataDisk.ps1 will add multiple data disk dsrive 
to an Azure VM based on the DiskCount parameter.

.PARAMETER ServiceName
The cloud service where the target VM resides.

.PARAMETER VmName
The target VM.

.PARAMETER StorageAccount
The storage account where the disks will reside.

.PARAMETER DiskCount
The number of data disks to add.

.PARAMETER DiskSize
The size of the new disk, in GB.

.PARAMETER HostCaching
The host level caching settings of the disk. Acceptable values
are "None", "ReadOnly", and "ReadWrite". The default is "None".

.EXAMPLE
.\Add-FAAzureDataDisk.ps1 -ServiceName SO-1-1-AZUR-CS-1 -VmName azuvnappazur052 -StorageAccount soa1s1azursa1 -DiskCount 2 -DiskSizeGB 50
#>

[CmdletBinding()]
    param (
        [Parameter(Mandatory=$True)]
        [string]$ServiceName,

        [Parameter(Mandatory=$True)]
        [string]$VmName,

        [Parameter(Mandatory=$True)]
        [string]$StorageAccount,

        [Parameter(Mandatory=$True)]
        [int]$DiskCount,
        
        [Parameter(Mandatory=$True)]
        [int]$DiskSizeGB,

        [Parameter(Mandatory=$False)]
        [ValidateSet("None","ReadOnly","ReadWrite")]
        [string]$HostCaching = 'None'

    )

# Change VM name to uppercase

$VmName = $VmName.ToUpper()

for ($Counter=0;$Counter -lt $DiskCount;$Counter++) {

    # Gather data disk information from VM

    Write-Verbose "Gathering data disk info from $VmName."

    $DiskInfo = Get-AzureVM -ServiceName $ServiceName -Name $VmName |
        Get-AzureDataDisk

    # Calculate the next available LUN number

    $LUN = ($DiskInfo.Count -1) + 1


    # Add the disk

    Write-Verbose "Adding LUN $LUN to $VmName."

    Get-AzureVM -ServiceName $ServiceName -name $VmName |
	    Add-AzureDataDisk -CreateNew -DiskSizeInGB $DiskSizeGB -DiskLabel "$VmName-Data$LUN" -HostCaching $HostCaching -LUN $LUN `
            -MediaLocation "https://$StorageAccount.blob.core.windows.net/vhds/$VmName-Data$LUN.vhd" |

    Update-AzureVM

}