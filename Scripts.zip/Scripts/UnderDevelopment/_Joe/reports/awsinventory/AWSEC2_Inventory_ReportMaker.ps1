#################################################################################
#   AWS EC2 Inventory Report
#   V.1.0 - Joe O'Brien 20JAN2022
#
#   - Run on AWS CLI/Powershell enabled JMP Server: awsvpjmpceng001.
#   - Update AWSAccountList.CSV from: 
#     http://test.cloudmanagement.firstam.net/AWSAccountList.html, prior to run.
#
#################################################################################

#Imports Powershell Module
Write-Host "Importing AWSPowershell Module... Please wait." -ForegroundColor Green
Import-Module AWSPowershell -ErrorAction Stop

#Configure Report Input/Output
$reportpath = "$env:USERPROFILE\Desktop\AWSEC2InventoryReport.csv"
$SourceFolder = "C:\publish\scripts"
$AwsAccountListSourceFile = "AWSAccountsList.csv"
$awsAccountlistSourcePath = $SourceFolder + "\" + $AwsAccountListSourceFile
$AwsAccountListSourceHeadersDirty = Get-Content -Path $awsAccountlistSourcePath -First 2 | ConvertFrom-Csv
$AwsaccountListSourceHeadersCleaned = $AwsAccountListSourceHeadersDirty.PSObject.Properties.Name.Trim(' ') -Replace '\s',''
$listofawsaccounts = Import-CSV -Path $awsAccountlistSourcePath -Header $AwsaccountListSourceHeadersCleaned | Select-Object -Skip 1

#Produce List of AWS PROD Accounts from Environment Codes in CSV
$prodawsaccounts = $listofawsaccounts | Where-Object {
    ($_.Environment -eq "P") -and ($_.Environment -notlike "")
}
#Produce List of AWS NONPROD Accounts from Environment Codes in CSV
$nonprodawsaccounts = $listofawsaccounts | Where-Object {
    ($_.Environment -eq "N") -and ($_.Environment -notlike "")
}
#Produce List of AWS SANDBOX Accounts from Environment Codes in CSV
$sandboxawsaccounts = $listofawsaccounts | Where-Object {
    ($_.Environment -eq "S") -and ($_.Environment -notlike "")
}
#Produce List of AWS Unknown Accounts from Environment Codes in CSV. 
#Unknown meaning does not have an environment code.
$unknownawsaccounts = $listofawsaccounts | where-object Environment -eq ""

#RecordsCounter Display
$i = 0
foreach ($awsaccount in $sandboxawsaccounts) {
    $i++   
}
$sandboxaccountscount = $i
Write-host = "There are $i Sandbox Accounts in the CSV." -ForegroundColor Green

$i = 0
foreach ($awsaccount in $nonprodawsaccounts) {
    $i++   
}
$nonprodawsaccountscount = $i
Write-host = "There are $i Non-Production Accounts in the CSV." -ForegroundColor Green

$i = 0
foreach ($awsaccount in $prodawsaccounts) {
    $i++   
}
$prodawsaccountscount = $i
Write-host = "There are $i Production Accounts in the CSV." -ForegroundColor Green

$i = 0
foreach ($awsaccount in $unknownawsaccounts) {
    $i++   
}

$unknownawsaccountscount = $i

#Gives status of unkonwn accounts, this is helpful to let the teams know that the site might not have accounts fully onboarded yet.
Write-host ""
Write-host = "There are $i Accounts WITHOUT an Environment Code (P/N/S) in the CSV. Skipping." -ForegroundColor Red
Write-Host "    SOURCE: AWSAccountList.csv in the CloudEnginnering Repository." -ForegroundColor Yellow  
Write-Host "    INFO: This file is created from http://test.cloudmanagement.firstam.net/AWSAccountList.html" -ForegroundColor Yellow    
Write-host "    NOTE: The following Accounts will not be processed." -ForegroundColor Yellow
foreach ($awsaccount in $unknownawsaccounts) {
    $excludedaccountid = $awsaccount.id
    $excludedaccountname = $awsaccount.AccountName
    Write-Host "---------------------------------------"
    Write-Host "ID:               $excludedaccountid"    
    Write-Host "AccountName:      $excludedaccountname"
}
$unknownawsaccountscount = $i
Write-host "---------------------------------------"

#Begins Processing Sandbox Servers (Environment = S).
Write-Host ""
Write-Host "Starting Sandbox Servers" -ForegroundColor Green
Write-Host ""
aws-azure-login --profile xacc-s-0

$count = 1  #this is a check to confirm total account numbers
ForEach ($awsaccount in $sandboxawsaccounts){
    
    $awsID = $awsaccount.ID
    $awsEnv = $awsaccount.Environment
    $awsAccountname = $awsaccount.AccountName
    $awsPortalAppName = $awsaccount.PortalApp
    $listofawsregions = (Get-EC2Region).RegionName
    
    Write-Host ""
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    Write-Host "Processing Account: $count of $sandboxaccountscount" -ForegroundColor Green
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    Write-Host "AWS AccountName = $awsAccountname"
    Write-Host "AWS AccountID = $awsID"
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    $arn = "arn:aws:iam::$awsID" + ":role/FirstAm_super-pds"
    $assume_role = aws sts assume-role --role-arn $arn --role-session-name test-tagDetails --profile xacc-s-0 --no-verify-ssl 
    $a = $assume_role  | ConvertFrom-Json 
    $count++     
  
    ForEach ($x in $a){
        $env:AWS_Access_Key_ID = $x.Credentials.AccessKeyId
        $env:AWS_SECRET_Access_Key = $x.Credentials.SecretAccessKey
        $env:AWS_SESSION_TOKEN = $x.Credentials.SessionToken
    }

    ForEach ($awsRegion in $listofawsregions) {
        Write-Host "$awsRegion Region --------------------"
        $instancequery = Get-Ec2Instance -region $awsRegion
        $data = $instancequery.instances
        $report = @()
        ForEach ($inst In $data) {
            $instanceName = ( $inst.Tags | Where-Object {$_.Key.Trim() -eq "Name"} ).Value
            $instanceState = $inst.state.name
            $instPlatformName = $inst.Platform
            $ApplicationName = ( $inst.Tags | Where-Object {$_.Key.Trim() -eq "ApplicationName"} ).Value
            $ASNumber = ( $inst.Tags | Where-Object {$_.Key.Trim() -eq "ApplicationServiceNumber"} ).Value
            $BANumber = ( $inst.Tags | Where-Object {$_.Key.Trim() -eq "BusinessApplicationNumber"} ).Value
            $LegacyAppID = ( $inst.Tags | Where-Object {$_.Key.Trim() -eq "ApplicationID"} ).Value
            $EC2AddressInstID = $inst.Instanceid
            $EC2AddressGet = (Get-EC2Address -Filter @{Name="instance-id";Values=$EC2AddressInstID})
            $PublicIPNicName = ( $EC2AddressGet.Tags | Where-Object {$_.Key.Trim() -eq "Name"} ).Value
    
            #SETS Blank Values
            if ($instPlatformName -like "*window*") {
                $instPlatformName = "Windows"
            }
            else {
              $instPlatformName = "Other"  
            }
            
            ###CSV Row Creation###
            $report += [PSCustomObject][Ordered]@{
                InstName                    = $instanceName
                InstID                      = $inst.Instanceid
                InstType                    = $inst.InstanceType
                InstState                   = $instanceState
                InstPlatform                = $instPlatformName
                InstPrivateIP               = $inst.privateipaddress
                InstPublicIP                = $inst.publicipaddress
                AWSRegion                   = $awsregion
                AWSAccountId                = $awsID
                AWSAccountName              = $awsAccountname
                AWSPortalApp                = $awsPortalAppName
                EnvironmentCode             = $awsEnv
                ApplicationNameTag          = $ApplicationName
                ASNumberTag                 = $ASNumber
                BANumberTag                 = $BANumber
                AppIDTag                    = $LegacyAppID
                PipNICName                  = $PublicIPNicName
                EniNameid                   = $EC2AddressGet.NetworkInterfaceId
                Ec2AddPrivIP                = $EC2AddressGet.PrivateIpAddress
                Ec2AddPubvIP                = $EC2AddressGet.PublicIp
            }
        }
        $report | Export-CSV $reportpath -noTypeInfo -Append
        $awsRegion = $null
    }
    $listofawsregions = $null
}
Write-Host "END-----------------------------------------------------------" -ForegroundColor Green
#Ends Processing Sandbox Servers (Environment = S).

#Begins Processing Non-PROD Servers (Environment = N).
Write-Host ""
Write-Host "Starting Non-Production Servers" -ForegroundColor Green
Write-Host ""
aws-azure-login --profile xacc-n-0

$count = 1  #this is a check to confirm total account numbers
ForEach ($awsaccount in $nonprodawsaccounts){
    
    $awsID = $awsaccount.ID
    $awsEnv = $awsaccount.Environment
    $awsAccountname = $awsaccount.AccountName
    $awsPortalAppName = $awsaccount.PortalApp
    $listofawsregions = (Get-EC2Region).RegionName
    
    Write-Host ""
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    Write-Host "Processing Account: $count of $nonprodawsaccountscount" -ForegroundColor Green
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    Write-Host "AWS AccountName = $awsAccountname"
    Write-Host "AWS AccountID = $awsID"
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    $arn = "arn:aws:iam::$awsID" + ":role/FirstAm_super-pds"
    $assume_role = aws sts assume-role --role-arn $arn --role-session-name test-tagDetails --profile xacc-n-0 --no-verify-ssl 
    $a = $assume_role  | ConvertFrom-Json 
    $count++     
  
    ForEach ($x in $a){
        $env:AWS_Access_Key_ID = $x.Credentials.AccessKeyId
        $env:AWS_SECRET_Access_Key = $x.Credentials.SecretAccessKey
        $env:AWS_SESSION_TOKEN = $x.Credentials.SessionToken
    }

    ForEach ($awsRegion in $listofawsregions) {
        Write-Host "$awsRegion Region --------------------"
        $instancequery = Get-Ec2Instance -region $awsRegion
        $data = $instancequery.instances
        $report = @()
        ForEach ($inst In $data) {
            $instanceName = ( $inst.Tags | Where-Object {$_.Key.Trim() -eq "Name"} ).Value
            $instanceState = $inst.state.name
            $instPlatformName = $inst.Platform
            $ApplicationName = ( $inst.Tags | Where-Object {$_.Key.Trim() -eq "ApplicationName"} ).Value
            $ASNumber = ( $inst.Tags | Where-Object {$_.Key.Trim() -eq "ApplicationServiceNumber"} ).Value
            $BANumber = ( $inst.Tags | Where-Object {$_.Key.Trim() -eq "BusinessApplicationNumber"} ).Value
            $LegacyAppID = ( $inst.Tags | Where-Object {$_.Key.Trim() -eq "ApplicationID"} ).Value
            $EC2AddressInstID = $inst.Instanceid
            $EC2AddressGet = (Get-EC2Address -Filter @{Name="instance-id";Values=$EC2AddressInstID})
            $PublicIPNicName = ( $EC2AddressGet.Tags | Where-Object {$_.Key.Trim() -eq "Name"} ).Value
    
            #SETS Blank Values
            if ($instPlatformName -like "*window*") {
                $instPlatformName = "Windows"
            }
            else {
              $instPlatformName = "Other"  
            }
            
            ###CSV Row Creation###
            $report += [PSCustomObject][Ordered]@{
                InstName                    = $instanceName
                InstID                      = $inst.Instanceid
                InstType                    = $inst.InstanceType
                InstState                   = $instanceState
                InstPlatform                = $instPlatformName
                InstPrivateIP               = $inst.privateipaddress
                InstPublicIP                = $inst.publicipaddress
                AWSRegion                   = $awsregion
                AWSAccountId                = $awsID
                AWSAccountName              = $awsAccountname
                AWSPortalApp                = $awsPortalAppName
                EnvironmentCode             = $awsEnv
                ApplicationNameTag          = $ApplicationName
                ASNumberTag                 = $ASNumber
                BANumberTag                 = $BANumber
                AppIDTag                    = $LegacyAppID
                PipNICName                  = $PublicIPNicName
                EniNameid                   = $EC2AddressGet.NetworkInterfaceId
                Ec2AddPrivIP                = $EC2AddressGet.PrivateIpAddress
                Ec2AddPubvIP                = $EC2AddressGet.PublicIp
            }
        }
        $report | Export-CSV $reportpath -noTypeInfo -Append
        $awsRegion = $null
    }
    $listofawsregions = $null
}
Write-Host "END-----------------------------------------------------------" -ForegroundColor Green
#Ends Processing Non-Prod Servers (Environment = N).

#Begins Processing PROD Servers (Environment = P).
Write-Host ""
Write-Host "Starting Production Servers" -ForegroundColor Green
Write-Host ""
aws-azure-login --profile xacc-p-0
$count = 1  #this is a check to confirm total account numbers
ForEach ($awsaccount in $prodawsaccounts){
    
    $awsID = $awsaccount.ID
    $awsEnv = $awsaccount.Environment
    $awsAccountname = $awsaccount.AccountName
    $awsPortalAppName = $awsaccount.PortalApp
    $listofawsregions = (Get-EC2Region).RegionName
    Write-Host ""
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    Write-Host "Processing Account: $count of $prodawsaccountscount" -ForegroundColor Green
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    Write-Host "AWS AccountName = $awsAccountname"
    Write-Host "AWS AccountID = $awsID"
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    $arn = "arn:aws:iam::$awsID" + ":role/FirstAm_super-pds"
    $assume_role = aws sts assume-role --role-arn $arn --role-session-name test-tagDetails --profile xacc-p-0 --no-verify-ssl 
    $a = $assume_role  | ConvertFrom-Json 
    $count++     
  
    ForEach ($x in $a){
        $env:AWS_Access_Key_ID = $x.Credentials.AccessKeyId
        $env:AWS_SECRET_Access_Key = $x.Credentials.SecretAccessKey
        $env:AWS_SESSION_TOKEN = $x.Credentials.SessionToken
    }

    ForEach ($awsRegion in $listofawsregions) {
        Write-Host "$awsRegion Region --------------------"
        $instancequery = Get-Ec2Instance -region $awsRegion
        $data = $instancequery.instances
        $report = @()
        ForEach ($inst In $data) {
            $instanceName = ( $inst.Tags | Where-Object {$_.Key.Trim() -eq "Name"} ).Value
            $instanceState = $inst.state.name
            $instPlatformName = $inst.Platform
            $ApplicationName = ( $inst.Tags | Where-Object {$_.Key.Trim() -eq "ApplicationName"} ).Value
            $ASNumber = ( $inst.Tags | Where-Object {$_.Key.Trim() -eq "ApplicationServiceNumber"} ).Value
            $BANumber = ( $inst.Tags | Where-Object {$_.Key.Trim() -eq "BusinessApplicationNumber"} ).Value
            $LegacyAppID = ( $inst.Tags | Where-Object {$_.Key.Trim() -eq "ApplicationID"} ).Value
            $EC2AddressInstID = $inst.Instanceid
            $EC2AddressGet = (Get-EC2Address -Filter @{Name="instance-id";Values=$EC2AddressInstID})
            $PublicIPNicName = ( $EC2AddressGet.Tags | Where-Object {$_.Key.Trim() -eq "Name"} ).Value
    
            #SETS Blank Values
            if ($instPlatformName -like "*window*") {
                $instPlatformName = "Windows"
            }
            else {
              $instPlatformName = "Other"  
            }
            
            ###CSV Row Creation###
            $report += [PSCustomObject][Ordered]@{
                InstName                    = $instanceName
                InstID                      = $inst.Instanceid
                InstType                    = $inst.InstanceType
                InstState                   = $instanceState
                InstPlatform                = $instPlatformName
                InstPrivateIP               = $inst.privateipaddress
                InstPublicIP                = $inst.publicipaddress
                AWSRegion                   = $awsregion
                AWSAccountId                = $awsID
                AWSAccountName              = $awsAccountname
                AWSPortalApp                = $awsPortalAppName
                EnvironmentCode             = $awsEnv
                ApplicationNameTag          = $ApplicationName
                ASNumberTag                 = $ASNumber
                BANumberTag                 = $BANumber
                AppIDTag                    = $LegacyAppID
                PipNICName                  = $PublicIPNicName
                EniNameid                   = $EC2AddressGet.NetworkInterfaceId
                Ec2AddPrivIP                = $EC2AddressGet.PrivateIpAddress
                Ec2AddPubvIP                = $EC2AddressGet.PublicIp
            }
        }
        $report | Export-CSV $reportpath -noTypeInfo -Append
        $awsRegion = $null
    }
    $listofawsregions = $null
}
Write-Host "END-----------------------------------------------------------" -ForegroundColor Green
#Ends Processing PROD Servers (Environment = P).
Write-Host "Count:  $count" #confirms total aws account numbers

#After this script is completed, the CSV file with all results will becreated in the report destination configured at beginning of this script.