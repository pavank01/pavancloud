############################################################################
# First American Decommission Script
#   v3.4
#
# - Removed AzureRM module references and replaced it with AZ Modules.
#   10/13/2021
#   
#   By Joe O'Brien 04/06/2021
############################################################################
#Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

Function promptYesNo {
    while("yes","no" -notcontains $answer)
    {
        $answer = Read-Host "Would you like to continue? (Yes/No)"
    }
        If ($answer -eq "no") {
            Write-Host "Exiting..." -ForeGroundColor Red
        exit
    }
}

Function promptYesNo_Vmware {
    while("yes","no" -notcontains $answer)
    {
        $answer = Read-Host "Would you like to continue? (Yes/No)"
    }
        If ($answer -eq "no") {
            Write-Host "Exiting..." -ForeGroundColor Red
            Disconnect-VIServer -Server * -Force -Confirm:$false
        exit
    }
}

Function ConfirmationValidation {
    ##Validation-Start####################################################
    $null | set-clipboard
    Write-Host "Validation" -ForegroundColor Green
    Write-Host ""
    Write-Host "Please INPUT the following details from Decommission TASK:" -ForegroundColor Yellow
    $TaskIDValidationInput = Read-Host "TASK Number (ID) "
    $TaskIDValidation = $TaskIDValidationInput.Trim()
    $VMValidationInput = Read-Host "Server Name (VM) "
    $VMValidation = $VMValidationInput.Trim()
    if ($TaskID -eq $TaskIDValidation -and $VM -eq $VMValidation) {
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        Write-Host "Validation Passed!" -ForegroundColor Green
        Write-Host ""
        Write-Host "$TaskID = $TaskIDValidation" -ForegroundColor Green 
        Write-Host "$VM = $VMValidation" -ForegroundColor Green 
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    }
    else {
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Red
        Write-Host "Validation Failed!" -ForegroundColor Red
        Write-Host ""
        Write-Host "$TaskID = $TaskIDValidation" -ForegroundColor Yellow 
        Write-Host "$VM = $VMValidation" -ForegroundColor Yellow
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Red
        exit
    }
}
    ##Validation-End######################################################

Function ConfirmationValidation_VMware {
    ##Validation-Start####################################################
    $null | set-clipboard
    Write-Host "Validation" -ForegroundColor Green
    Write-Host ""
    Write-Host "Please INPUT the following details from Decommission TASK:" -ForegroundColor Yellow
    $TaskIDValidationInput = Read-Host "TASK Number (ID) "
    $TaskIDValidation = $TaskIDValidationInput.Trim()
    $VMValidationInput = Read-Host "Server Name (VM) "
    $VMValidation = $VMValidationInput.Trim()
    if ($TaskID -eq $TaskIDValidation -and $VM -eq $VMValidation) {
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        Write-Host "Validation Passed!" -ForegroundColor Green
        Write-Host ""
        Write-Host "$TaskID = $TaskIDValidation" -ForegroundColor Green 
        Write-Host "$VM = $VMValidation" -ForegroundColor Green 
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    }
    else {
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Red
        Write-Host "Validation Failed!" -ForegroundColor Red
        Write-Host ""
        Write-Host "$TaskID = $TaskIDValidation" -ForegroundColor Yellow 
        Write-Host "$VM = $VMValidation" -ForegroundColor Yellow
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Red
        Disconnect-VIServer -Server * -Force -Confirm:$false
        exit
    }
    ##Validation-End######################################################
}

Function menuPrompt {
    while("Azure","AWS","Physical","VMware","OCI","Exit" -notcontains $answer)
    {
        $answer = $null
        Write-Host ""
        $answer = Read-Host "Please select the platform: (AWS, Azure, VMware, OCI, Physical) or Type Exit to exit"
    }
    
    If ($answer -eq "Azure") {
        Write-Host "Loading: Azure Code Block..." -ForeGroundColor Green
        $psexecLogFilePath = "$env:USERPROFILE\Desktop\last_decom_azure_psexec-output.log"

        #AzureBlock-Start###########################################################################################################################################################

        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        Write-Host "Please enter the following details: "
        $TASKIDinput = Read-Host -Prompt "SF Task Number"
        $TASKID = $TASKIDInput.Trim()
        $VMinput = Read-Host -Prompt "VM Name"
        $VM = $VMInput.Trim()
        $SubscriptionNameInput = Read-Host -Prompt "Azure Subscription Name"
        $SubscriptionName = $SubscriptionNameInput.Trim()
        $ResourceGroupNameInput = Read-Host -Prompt "Azure Resource Group Name"
        $ResourceGroupName = $ResourceGroupNameInput.Trim()
        $PingTestResult = Test-Connection -ComputerName $VM -Count 1 -Quiet
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        Write-Host "Logging into Subscription..." -ForegroundColor Green
        Set-AzContext -SubscriptionName $SubscriptionName 
        Write-Host "Server Decommission Overview:" -ForegroundColor Green
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        $azureVMDetails = Get-AzVM -ResourceGroupName $ResourceGroupName -Name $VM
        $azureVMos = $azureVmdetails.storageprofile.osDisk.osType
        $azureVMstatus = ((Get-AzVM -ResourceGroupName $ResourceGroupName -Name $VM -Status).Statuses[1]).code
        Write-Host ""
        Write-Host "SF TaskID:          $TaskID"
        Write-Host "Azure VM Name:      $VM"
        Write-Host "Operating System    $azureVMos"
        Write-Host "Status:             $AzureVMStatus"
        Write-Host "Resource Group:     $ResourceGroupName"
        Write-Host "Subscription:       $SubscriptionName"
        Write-Host ""
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        promptYesNo
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        if ($azureVMos -like "*linux*") {
            Write-Host "IMPORTANT: CET only performs decommissions on Windows Servers. Linux or Unix servers are handled by the Unix Services SF Assignment Group." -ForeGroundColor Red
            Write-Host "Action: Please reassign this ticket to Unix Services" -ForeGroundColor Yellow
            exit
        }
        ConfirmationValidation
        Write-Host "Checking VM Eligibility and Next Steps..." -ForegroundColor Green
        Write-Host ""
        if ($azureVMos -like "*window*") {
            if ($AzureVMStatus -like "*running") {
                Write-Host "Azure VM Name:      $VM"
                Write-Host "Status:             $AzureVMStatus" -ForeGroundColor Yellow
                Write-Host ""
                Write-Host "Next Steps: PSEXEC, VM Powerdown." -ForeGroundColor Green
                Write-Host "PowerState = On, Starting: PSEXEC.------------------------" -ForeGroundColor Green
                Write-Host "IMPORTANT: Selecting YES will start running PSEXEC with the following options: ipconfig /all & net localgroup administrators & wmic bios get serialnumber" -ForeGroundColor Yellow
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                promptYesNo
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                C:\SysinternalsSuite\psexec -accepteula \\$VM -e cmd /c "ipconfig /all & net localgroup administrators & wmic bios get serialnumber" > $psexecLogFilePath
                Get-Content $psexecLogFilePath
                Get-Content $psexecLogFilePath | Set-Clipboard
                Write-Host ""
                Write-Host "IMPORTANT: Please copy and paste the SUCCESSFUL PSEXEC Output to the SF TASK Notes. If unsuccessful, troubleshooting may be required. If all attempts to retrieve this information fails, please update the ticket accordingly." -ForeGroundColor yellow
                Write-Host ""
                Write-Host "INFORMATION: Errors requiring manual intervention include:"-ForeGroundColor yellow
                Write-Host "Error: 'The Handle is invalid' or 'Couldn't access $VM' - Server may be off the domain. "-ForeGroundColor yellow
                Write-Host ""
                Write-Host "Finished: PSEXEC.------------------------" -ForeGroundColor Green
                Write-Host "PowerState = On, Starting: Powerdown------------------------" -ForeGroundColor Green
                Write-Host ""
                Write-Host "IMPORTANT: Selecting YES confirms that the server is safe to be shut down and to begin the Decommission process." -ForeGroundColor Yellow
                Write-Host "NOTE: The Stop/Deallocation process may take approximately 5 minutes or so. Please be patient." -ForeGroundColor Yellow
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                promptYesNo
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                Stop-AzVM -ResourceGroupName $ResourceGroupName -Name $VM -Confirm:$true
                Write-Host "Finished: Powerdown------------------------" -ForeGroundColor Green
                $timestamp = Get-Date -Format "dddd, MM/dd/yyyy HH:mm K"
                Write-Host ""
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                Write-Host "$VM was POWERED DOWN on $timestamp UTC." -ForeGroundColor Green
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                exit 
            }
            if ($AzureVMStatus -like "*deallocated" -or $AzureVMStatus -like "*stopped") {
                Write-Host "Azure VM Name:      $VM" -ForeGroundColor Green
                Write-Host "Status:             $AzureVMStatus" -ForeGroundColor Green
                Write-Host ""
                Write-Host "PowerState = Off, Starting: VM Delete------------------------" -ForeGroundColor Green
                Write-Host ""
                Write-Host "IMPORTANT: Choose YES to confirms that the VM has been powered off for a minimum of 24 hours." -ForeGroundColor Yellow
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                promptYesNo
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                Remove-FAAzureRMVM -ResourceGroupName $ResourceGroupName -VMName $VM -Confirm:$false -Verbose
                Write-Host "Finished: VM Delete------------------------" -ForeGroundColor Green
                $timestamp = Get-Date -Format "dddd, MM/dd/yyyy HH:mm K"
                Write-Host ""
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                Write-Host "$VM was RETIRED on $timestamp UTC." -ForeGroundColor Green 
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                exit
            }
        }   
        $answer = $null
        menuPrompt
    
    }
    If ($answer -eq "AWS") {
        Write-Host "Loading: AWS Code Block..." -ForeGroundColor Green
        $psexecLogFilePath = "$env:USERPROFILE\Desktop\last_decom_aws_psexec-output.log"

        #AwsBlock-Start###########################################################################################################################################################

        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        Write-Host "Please enter the following details: "
        $TASKIDinput = Read-Host -Prompt "SF Task Number"
        $TASKID = $TASKIDInput.Trim()
        $VMinput = Read-Host -Prompt "VM Name"
        $VM = $VMInput.Trim()
        $awsAccountIDInput = Read-Host -Prompt "AWS Account ID"
        $awsAccountID = $awsAccountIDInput.Trim()
        $awsAccountProfileInput = Read-Host -Prompt "Profile Name (xacc-p-0 or xacc-n-0)"
        $awsAccountProfile = $awsAccountProfileInput.Trim()
        $PingTestResult = Test-Connection -ComputerName $VM -Count 1 -Quiet
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        Write-Host "Logging into AWS Account..." -ForegroundColor Green
        Write-Host ""
        Write-Host "Please make sure that you've activated AWS-XACC-P-0 and AWS-XACC-N-0 in the Azure Portal." -ForegroundColor yellow
        Write-Host "Once completed, select Yes below to continue." -ForegroundColor yellow
        Write-Host ""
        promptYesNo
        Write-Host ""
        $awsAzureLoginProfile = $awsAccountProfile
        aws-azure-login --profile $awsAzureLoginProfile

        $role_arn = "arn:aws:iam::" + $awsAccountID + ":role/FirstAm_super-pds"
        $arn = "arn:aws:iam::$awsAccountID" + ":role/FirstAm_super-pds"
        $roleSessionName = "DecomScript"

        $assume_role = aws sts assume-role --role-arn $role_arn --role-session-name $roleSessionName --profile $awsAzureLoginProfile --no-verify-ssl
        $assume_role_vars = $assume_role  | ConvertFrom-Json 

        ForEach ($x in $assume_role_vars){
            $env:AWS_Access_Key_ID = $x.Credentials.AccessKeyId
            $env:AWS_SECRET_Access_Key = $x.Credentials.SecretAccessKey
            $env:AWS_SESSION_TOKEN = $x.Credentials.SessionToken
        }
        Write-Host ""
        Write-Host "Were you logged in without Errors? Select Yes to continue, No to Exit." -ForegroundColor yellow
        Write-Host ""
        promptYesNo
        Write-Host ""
        Write-Host "Server Decommission Overview:" -ForegroundColor Green
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        $awserverslist = (Get-Ec2Instance).Instances | select @{Name="Servername";Expression={$_.tags | where key -eq "Name" | select Value -expand Value}}, InstanceId
        $awserverslistcapture = $awserverslist | where Servername -eq "$vm"
        $awsserverinstanceid = $awserverslistcapture.InstanceId
        $ec2Info = aws ec2 describe-instances --instance-ids $awsserverinstanceid --no-verify-ssl
        $ec2InfoFormatted = $ec2Info | ConvertFrom-JSon
        $ec2state = $ec2InfoFormatted.Reservations.Instances.State.Name
        $ec2OSname = $ec2InfoFormatted.Reservations.Instances.Platform

        if ($ec2OSname -like "*window*") {
            $ec20sName = "Windows"
        }
        else {
          $ec2OSName = "Other"  
        }

        Write-Host ""
        Write-Host "SF TaskID:          $TaskID"
        Write-Host "AWS Account ID:     $awsAccountID"
        Write-Host "VM Name:            $VM"
        Write-Host "Instance ID:        $awsserverinstanceid"
        Write-Host "Operating System:   $ec2OSname"
        Write-Host "Status:             $ec2state "
        Write-Host ""
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        promptYesNo
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        if ($ec2OSname -like "Other") {
            Write-Host "IMPORTANT: CET only performs decommissions on Windows Servers!" -ForeGroundColor Red
            Write-Host "If this is a Linux/Unix server, please assign the Task $TaskID to the Unix Services Assignment Group!" -ForegroundColor yellow
            exit
        }
        ConfirmationValidation
        Write-Host "Checking VM Eligibility and Next Steps..." -ForegroundColor Green
        Write-Host ""
        if ($ec2OSname -like "*window*") {
            if ($ec2state -like "*running") {
                Write-Host "VM Name:            $VM"
                Write-Host "Status:             $ec2state" -ForeGroundColor Yellow
                Write-Host ""
                Write-Host "Next Steps: PSEXEC, VM Powerdown." -ForeGroundColor Green
                Write-Host "PowerState = On, Starting: PSEXEC.------------------------" -ForeGroundColor Green
                Write-Host "IMPORTANT: Selecting YES will start running PSEXEC with the following options: ipconfig /all & net localgroup administrators & wmic bios get serialnumber" -ForeGroundColor Yellow
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                promptYesNo
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                C:\SysinternalsSuite\psexec -accepteula \\$VM -e cmd /c "ipconfig /all & net localgroup administrators & wmic bios get serialnumber" > $psexecLogFilePath
                Get-Content $psexecLogFilePath
                Get-Content $psexecLogFilePath | Set-Clipboard
                Write-Host ""
                Write-Host "IMPORTANT: Please copy and paste the SUCCESSFUL PSEXEC Output to the SF TASK Notes. If unsuccessful, troubleshooting may be required. If all attempts to retrieve this information fails, please update the ticket accordingly." -ForeGroundColor yellow
                Write-Host ""
                Write-Host "INFORMATION: Errors requiring manual intervention include:"-ForeGroundColor yellow
                Write-Host "Error: 'The Handle is invalid' or 'Couldn't access $VM' - Server may be off the domain. "-ForeGroundColor yellow
                Write-Host ""
                Write-Host "Finished: PSEXEC.------------------------" -ForeGroundColor Green
                Write-Host "PowerState = On, Starting: Powerdown------------------------" -ForeGroundColor Green
                Write-Host ""
                Write-Host "IMPORTANT: Selecting YES confirms that the server is safe to be shut down and to begin the Decommission process." -ForeGroundColor Yellow
                Write-Host "NOTE: The Stop/Deallocation process may take approximately 5 minutes or so. Please be patient." -ForeGroundColor Yellow
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                promptYesNo
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                #Stop-AzVM -ResourceGroupName $ResourceGroupName -Name $VM -Confirm:$true
                Stop-EC2Instance -InstanceId $awsserverinstanceid
                Write-Host "Finished: Powerdown------------------------" -ForeGroundColor Green
                $timestamp = Get-Date -Format "dddd, MM/dd/yyyy HH:mm K"
                Write-Host ""
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                Write-Host "$VM EC2Instance was STOPPED on $timestamp UTC." -ForeGroundColor Green
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                exit 
            }
            if ($ec2state -like "*stopped" -or $ec2state -like "*stopped") {
                Write-Host "VM Name:            $VM" -ForeGroundColor Green
                Write-Host "Status:             $ec2state" -ForeGroundColor Green
                Write-Host ""
                Write-Host "PowerState = Off, Starting: VM Delete------------------------" -ForeGroundColor Green
                Write-Host ""
                Write-Host "IMPORTANT: Choose YES to confirms that the VM has been powered off for a minimum of 24 hours." -ForeGroundColor Yellow
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                promptYesNo
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                #Remove-FAAzureRMVM -ResourceGroupName $ResourceGroupName -VMName $VM -Confirm:$false -Verbose
                Remove-EC2Instance -InstanceId $awsserverinstanceid
                Write-Host "Finished: VM Delete------------------------" -ForeGroundColor Green
                $timestamp = Get-Date -Format "dddd, MM/dd/yyyy HH:mm K"
                Write-Host ""
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                Write-Host "$VM EC2Instance was TERMINATED on $timestamp UTC." -ForeGroundColor Green 
                Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                exit
            }
        $answer = $null
        menuPrompt
        }
    }
    If ($answer -eq "OCI") {
        Write-Host "OCI... In Development..." -ForeGroundColor Red

        $answer = $null
        menuPrompt
    }
    If ($answer -eq "VMware") {
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        Write-Host "Loading: VMware Code Block" -ForeGroundColor Green

        #VMwareBlock-Start#########################################################################################################################################################
        Import-Module VMware.VimAutomation.Core
        Import-Module VMware.VimAutomation.Vds     
        $psexecLogFilePath = "$env:USERPROFILE\Desktop\last_decom_vmware_psexec-output.log"
        #$vmwareserverlogpath = "$env:USERPROFILE\Desktop\VMware_Servers_Decom.log"

            Write-Host ""
            Write-Host "Please enter the following details: "
            $TASKIDinput = Read-Host -Prompt 'SF Task Number (ID) '
            $TASKID = $TASKIDInput.Trim()
            $VMinput = Read-Host -Prompt 'Server Name (VM) '
            $VM = $VMinput.Trim()
            $Vcentreinput = Read-Host -Prompt 'vCenter Servername '
            $Vcentre = $Vcentreinput.Trim()
            Write-Host ""
            Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
            Write-Host "Connecting to vCenter Server $Vcentre..." -ForegroundColor Green
            Write-Host ""
            Connect-VIServer $Vcentre
            Write-host ""
            Write-Host "Status: Connected" -ForegroundColor Green
            Write-host ""
            Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
            Write-Host "Building Script Variables from $VM..."-ForegroundColor Green
            Write-Host ""
            Write-Host "Please wait...This may take 10-15 seconds..." -ForegroundColor Green
            Write-Host ""
            $VMResult = Get-VM $VM
            $VMHost = $VMResult.VMHost
            $VMCluster = $VMHost.Parent
            $VMDataCenter = $VMHost.Parent | Get-DataCenter
            $FolderName = Get-Folder -Location $VMDataCenter | Where-Object {
                ($_.Name -Like "VMs_To_Be_Deleted*") -or ($_.Name -Like "_Decommissioned")
            }
            $OutputObj = @()
            $VMDetails = Get-VM $VM 
            $VMHardDisk = Get-HardDisk -VM $VM -DiskType "rawVirtual","rawPhysical" | Select-Object Name,ScsiCanonicalName
            $Vmcluster = Get-Cluster -VM $VM
            $VMGuestOS = $VMDetails.ExtensionData.Config.GuestFullname
            $VMPowerResult = $VMResult.Powerstate
            $VMdatastoreName = (get-vm $vm | get-Datastore).name
            $numberrdm = Get-VM $VM | Get-HardDisk -DiskType "RawPhysical","RawVirtual" | measure
            #$numberrdm.Count
            $VMdatastoreName = (get-vm $vm | get-Datastore).name
            Write-Host "Status: Completed" -ForegroundColor Green
            Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
            Write-Host "Server Decommission Overview:" -ForegroundColor Green
            Write-Host ""
            Write-Host "SF TaskID:          $TaskID"
            Write-Host "VMware VM Name:     $VM"
            Write-Host "Guest OS:           $VMGuestOS"
            Write-Host "Power Status:       $VMPowerResult"
            Write-Host "vCenter Server:     $Vcentre"
            
            if ($VMDatastoreName -like "SRM*") {
                $numberSRM = "TRUE"
                Write-Host "SRM Enabled:        $numberSRM" -ForegroundColor Yellow
                Write-Host "SRM Storage Group:  $VMdatastoreName" -ForegroundColor Yellow
            }
            else {
                $numberSRM = "FALSE"
                Write-Host "SRM Enabled:        $numberSRM"
            }
            if ($numberrdm.Count -eq "0") {
                Write-Host "RDM:               "$numberrdm.Count""
            }
            else {
                Write-Host "RDM:               "$numberrdm.Count"" -ForegroundColor Yellow
            }
            Write-Host ""

            Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
            promptYesNo_Vmware
            Write-Host "-----------------------------------------------------------------" -ForegroundColor Green

            if ($VMGuestOS -like "*linux*") {
                Write-Host "IMPORTANT: CET only performs decommissions on Windows Servers. Linux or Unix servers are handled by the Unix Services SF Assignment Group." -ForeGroundColor Red
                Write-Host "Action: Please reassign this ticket to Unix Services" -ForeGroundColor Yellow
                Disconnect-VIServer -Server * -Force -Confirm:$false
                exit
            }
            ConfirmationValidation_VMware
            Write-Host "Checking VM Eligibility and Next Steps...Please wait..." -ForegroundColor Green
            Write-Host ""
            if ($VMGuestOS -like "*windows*") {
                if ($VMPowerResult -eq "PoweredOn") {
                    Write-Host "VM Name:        $VM"
                    Write-Host "Status:         $VMPowerResult" -ForeGroundColor Yellow
                    Write-Host ""
                    Write-Host "Next Steps: PSEXEC, VM Powerdown." -ForeGroundColor Green
                    Write-Host "PowerState = On, Starting: PSEXEC.------------------------" -ForeGroundColor Green
                    Write-Host "IMPORTANT: Selecting YES will start running PSEXEC with the following options: ipconfig /all & net localgroup administrators & wmic bios get serialnumber" -ForeGroundColor Yellow
                    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                    promptYesNo_Vmware
                    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                    C:\SysinternalsSuite\psexec -accepteula \\$VM -e cmd /c "ipconfig /all & net localgroup administrators & wmic bios get serialnumber" > $psexecLogFilePath
                    Get-Content $psexecLogFilePath
                    Get-Content $psexecLogFilePath | Set-Clipboard
                    Write-Host ""
                    Write-Host "IMPORTANT: Please copy and paste the SUCCESSFUL PSEXEC Output to the SF TASK Notes. If unsuccessful, troubleshooting may be required. If all attempts to retrieve this information fails, please update the ticket accordingly." -ForeGroundColor yellow
                    Write-Host ""
                    Write-Host "INFORMATION: Errors requiring manual intervention include:"-ForeGroundColor yellow
                    Write-Host "Error: 'The Handle is invalid' or 'Couldn't access $VM' - Server may be off the domain. "-ForeGroundColor yellow
                    Write-Host ""
                    Write-Host "Finished: PSEXEC.------------------------" -ForeGroundColor Green
                    Write-Host "PowerState = On, Starting: Powerdown------------------------" -ForeGroundColor Green
                    Write-Host "IMPORTANT: Selecting YES confirms that the server is safe to be shut down and to begin the Decommission process." -ForeGroundColor Yellow
                    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                    promptYesNo_Vmware
                    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                    Stop-VM $VM -Confirm:$true 
                    $timestamp = Get-Date -Format "dddd, MM/dd/yyyy HH:mm K"
                    Write-Host "Finished: Powerdown------------------------" -ForeGroundColor Green
                    Write-Host ""
                    $powerdowntext = "$VM was POWERED DOWN on $timestamp UTC."
                    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                    Write-Host "$powerdowntext" -ForeGroundColor Green 
                    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green

                    $null | set-clipboard
                    $powerdowntext > $psexecLogFilePath
                    Get-Content $psexecLogFilePath | Set-Clipboard

                    Disconnect-VIServer -Server * -Force -Confirm:$false
                    exit
                }
                if ($VMPowerResult -eq "PoweredOff") {

                    $VmwarePowerDownEventRaw = (Get-VIEvent $VM | select-object  CreatedTime,FullformattedMessage | where-object -property FullFormattedMessage -like "*is powered off*").createdTime
                    $vmwarepowerdownevent = $VmwarePowerDownEventRaw | select-object -first 1
                    $VMwareVMPowerDownTime = $vmwarepowerdownevent | Get-Date -Format "dddd, MM/dd/yyyy HH:mm K"

                    $timestamp = Get-Date -Format "dddd, MM/dd/yyyy HH:mm K"

                    $TimeDiff = (New-TimeSpan -Start $VMwareVMPowerDownTime -End $timestamp).TotalHours
                    $ShutdownHoursThreshold = "24"
                
                    Write-Host "VM Name:            $VM" -ForeGroundColor Green
                    Write-Host "Status:             $VMPowerResult" -ForeGroundColor Green
                    If ($TimeDiff -lt $ShutdownHoursThreshold) {
                        Write-Host "Shutdown Timer:     $TimeDiff hours " -ForegroundColor Yellow
                        Write-Host "Overall:            FAIL" -ForegroundColor Red
                        Write-host ""
                        Write-Host "REASON: The VM has been powered off for shorter than $ShutdownHoursThreshold hours! Exiting..." -ForegroundColor Yellow
                        Disconnect-VIServer -Server * -Force -Confirm:$false
                        exit
                    }
                    else {
                        Write-Host "Shutdown Timer:     $TimeDiff hours " -ForegroundColor Green
                        Write-Host "Overall:            PASS" -ForegroundColor Green
                        Write-host ""
                        Write-Host "REASON: The VM has been powered off for longer than $ShutdownHoursThreshold hours! Continuing..." -ForegroundColor Green
                        Write-Host ""
                        Write-Host "PowerState = Off, Starting: VM Delete------------------------" -ForeGroundColor Green
                    }
                    Write-Host ""
                    Write-Host "IMPORTANT: Selecting YES below begins the VM Delete Process!" -ForeGroundColor yellow
                    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                    promptYesNo_Vmware
                    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                    Get-Folder -ID $FolderName.ID | Move-VM -VM $VM
                    Remove-VM -VM $VM -DeletePermanently -RunAsync -Confirm:$True
                    Write-Host ""
                    Write-Host "Finished: VM Delete------------------------" -ForeGroundColor Green
                    $timestamp = Get-Date -Format "dddd, MM/dd/yyyy HH:mm K"
                    $vmdeletetext = "$VM was RETIRED on $timestamp UTC."
                    Write-Host ""
                    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                    Write-Host "$vmdeletetext" -ForeGroundColor Green 
                    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
                    Write-Host ""

                    $null | set-clipboard
                    $vmdeletetext > $psexecLogFilePath
                    Get-Content $psexecLogFilePath | Set-Clipboard

                    Disconnect-VIServer -Server * -Force -Confirm:$false
                }
            }   

            ############DO NOT TOUCH BELOW FOR VMWARE############
            Write-Host  "Starting: Post Script Process-----------------------------------"  -ForeGroundColor Green
            $OutputObj += New-Object PSObject -Property  @{
            "Name" = $VM
            "WWN's"= ($VMHardDisk.ScsiCanonicalName) -join ","
            "Cluster"=$Vmcluster.Name
            "Deleted By"=$env:USERNAME
            }
            
            $LogDirectory       = Get-Date -Format yyyy-MM
            $LogPath            = "\\corp.firstam.com\Restricted\ServerOps-Admin\Scripts\Reports\Remove-VM"
            
            If ( !(Test-Path -Path $LogPath\$LogDirectory -PathType Container) ) {
                    New-Item -Path $LogPath\$LogDirectory -ItemType Directory | Out-Null
                }
            
            
            $csvName = "$LogPath\$LogDirectory\" + "VM's removed from $Vcentre"+"_"+  "Info.csv" 
            
            $OutputObj |Export-CSV $csvName -NoTypeInfo -Append
            
            $Header = @"
            <style>
            TABLE {border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;}
            TH {border-width: 1px; padding: 3px; border-style: solid; border-color: black; background-color: #6495ED;}
            TD {border-width: 1px; padding: 3px; border-style: solid; border-color: black;}
            </style>
"@
            $Output= $OutputObj | ConvertTo-Html -Head $Header
            
            $mailFrom = 'SNAVPUTLVMWR001@firstam.com'
            $mailTo = @("SOMHyperVisorSystems@firstam.com")
            $subject = "LUN details of Deleted server by script"
            $body = @"
            
            Below are the Server and LUN details :
            
            $Output
"@
        
            Send-MailMessage -BodyAsHtml $body -From $mailFrom -To $mailTo -Subject $subject -SmtpServer mail.firstam.com -Attachments $csvName
            
            $Servernotfound
            Write-host ""
            Write-Host "Completed: Post Script Process--------------------------------"  -ForeGroundColor Green
            Write-host ""
            #VMwareBlock-End###################################################################################################################################################################
            exit
            
        $answer = $null
        menuPrompt
    }
    If ($answer -eq "Physical") {
        Write-Host "Loading: Physical Code Block..." -ForeGroundColor Green
        $psexecLogFilePath = "$env:USERPROFILE\Desktop\last_decom_physical_psexec-output.log"

        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        Write-Host "Please enter the following details: "
        $TASKIDinput = Read-Host -Prompt "SF Task Number"
        $TASKID = $TASKIDInput.Trim()
        $VMNameinput = Read-Host -Prompt "Server Name"
        $VM = $VMNameinput.Trim()
        $PingQuiet = Test-Connection -ComputerName $VM -Count 1 -Quiet
        $Ping = Test-Connection -ComputerName $VM -Count 1
        $PingIPAddress = $Ping.IPV4Address
        $PingResponseTime = $Ping.ResponseTime

        Write-Host "Server Decommission Overview:" -ForegroundColor Green
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        Write-Host ""
        Write-Host "SF TaskID:          $TaskID"
        Write-Host "Server Name:        $VM"
        Write-Host "IPAddress:          $pingIPAddress"
        Write-Host "Ping Response:      $pingquiet"
        Write-Host "Response Time:      $PingResponseTime ms"
        Write-Host ""
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        promptYesNo
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        ConfirmationValidation
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        Write-Host "Checking Server Eligibility and Next Steps..." -ForegroundColor Green
        Write-Host ""
        Write-Host "Server Name:        $VM"
        if ($pingquiet -like "*False*"){
            Write-Host "Ping Response:      $pingquiet" -ForegroundColor Yellow
            Write-Host ""
            Write-Host "Unable to receive a response from the host via PING, exiting..." -ForegroundColor Red
            exit
        }
        else {
            Write-Host "Ping Response:      $pingquiet"
        }
        Write-Host "IPAddress:          $pingIPAddress"
        Write-Host ""
        Write-Host "Next Steps: PSEXEC, Server Powerdown." -ForeGroundColor Green
        Write-Host "PowerState = On, Starting: PSEXEC.------------------------" -ForeGroundColor Green
        Write-Host "IMPORTANT: Selecting YES will start running PSEXEC with the following options: ipconfig /all & net localgroup administrators & wmic bios get serialnumber" -ForeGroundColor Yellow
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        promptYesNo
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        C:\SysinternalsSuite\psexec -accepteula \\$VM -e cmd /c "ipconfig /all & net localgroup administrators & wmic bios get serialnumber" > $psexecLogFilePath
        Get-Content $psexecLogFilePath
        Get-Content $psexecLogFilePath | Set-Clipboard
        Write-Host ""
        Write-Host "IMPORTANT: Please copy and paste the SUCCESSFUL PSEXEC Output to the SF TASK Notes. If unsuccessful, troubleshooting may be required. If all attempts to retrieve this information fails, please update the ticket accordingly." -ForeGroundColor yellow
        Write-Host ""
        Write-Host "INFORMATION: Errors requiring manual intervention include:"-ForeGroundColor yellow
        Write-Host "Error: 'The Handle is invalid' or 'Couldn't access $VM' - Server may be off the domain. "-ForeGroundColor yellow
        Write-Host ""
        Write-Host "Finished: PSEXEC.------------------------" -ForeGroundColor Green
        Write-Host "PowerState = On, Starting: Powerdown------------------------" -ForeGroundColor Green
        Write-Host ""
        Write-Host "IMPORTANT: ***Selecting YES confirms that the server is safe to be shut down***. YOU WILL NOT RECEIVE A CONFIRMATION AFTER THIS STEP!" -ForeGroundColor Yellow
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        promptYesNo
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        Write-Host ""
        Write-Host "INFORMATION: Powering down $VM NOW!" -ForeGroundColor Green
        shutdown /s /m \\$VM /t 0 /c "Decommission"
        Write-Host ""
        Write-Host "Finished: Powerdown------------------------" -ForeGroundColor Green
        $timestamp = Get-Date -Format "dddd, MM/dd/yyyy HH:mm K"
        Write-Host ""
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        Write-Host "$VM was POWERED DOWN on $timestamp UTC." -ForeGroundColor Green
        Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
        Write-Host ""
        ping $VM
        exit 

        $answer = $null
        menuPrompt######################################################################################################################################
    }
    If ($answer -eq "Exit","Cancel") {
        Write-Host "Exiting..." -ForeGroundColor Red
        exit
    }
}
menuPrompt