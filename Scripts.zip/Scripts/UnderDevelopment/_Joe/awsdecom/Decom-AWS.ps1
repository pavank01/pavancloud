$awsAccountID = "720125431026"
$vm = "AWSVPTSTCENG999"
$ec2instanceid = "i-01fa80ec9f508cf1c"

write-host = "-----------------------------------------------"
write-host = "Servername:       $vm"
write-host = "AWSAccountID:     $awsAccountID"
write-host = "-----------------------------------------------"


$awsAzureLoginProfile = "xacc-p-0"
aws-azure-login --profile $awsAzureLoginProfile

$role_arn = "arn:aws:iam::" + $awsAccountID + ":role/FirstAm_super-pds"
$arn = "arn:aws:iam::$awsAccountID" + ":role/FirstAm_super-pds"
$roleSessionName = "DecomScript"

$assume_role = aws sts assume-role --role-arn $role_arn --role-session-name $roleSessionName --profile $awsAzureLoginProfile --no-verify-ssl
$assume_role_vars = $assume_role  | ConvertFrom-Json 

ForEach ($x in $assume_role_vars){
    $env:AWS_Access_Key_ID = $x.Credentials.AccessKeyId
    $env:AWS_SECRET_Access_Key = $x.Credentials.SecretAccessKey
    $env:AWS_SESSION_TOKEN = $x.Credentials.SessionToken
}

#$env:AWS_Access_Key_ID 
#$env:AWS_SECRET_Access_Key
#$env:AWS_SESSION_TOKEN

$awserverslist = (Get-Ec2Instance).Instances | select @{Name="Servername";Expression={$_.tags | where key -eq "Name" | select Value -expand Value}}, InstanceId

$awserverslistcapture = $awserverslist | where Servername -eq "$vm"
#$awserverslistcapture
$awsserverinstanceid = $awserverslistcapture.InstanceId

$ec2Info = aws ec2 describe-instances --instance-ids $awsserverinstanceid --no-verify-ssl
$ec2InfoFormatted = $ec2Info | ConvertFrom-JSon
$ec2state = $ec2InfoFormatted.Reservations.Instances.State.Name


write-host = ""
write-host = "-----------------------------------------------"
write-host = "The InstanceID for $vm is $awsserverinstanceid"
write-host = "Status: $ec2state"
write-host = "-----------------------------------------------"
write-host = ""
write-host = "-----------------------------------------------"
write-host = "All EC2 Instances on AWSAccountID:$awsAccountID"
write-host = "-----------------------------------------------"
$awserverslist

########################
#Notes
#npm install -g aws-azure-login
#aws-azure-login --confirgure --profile ceng1
#Update ENV Variables for node_modules folder (Default in profile) - Terminal Server only?
#Update Config file from repo (to be done soon)
#Activate Roles VIA Azure PIM
#run aws-azure-login --profile xacc-p-0
#run aws-azure-login --profile xacc-n-0
#assume-role
#aws sts assume-role --role-arn "arn:aws:iam::720125431026:role/FirstAm_super-pds" --role-session-name Session1 --profile xacc-p-0 --no-verify-ssl
#Get the JSON output Update these
#Populate these vars from the output of JSON above
#$env:AWS_Access_Key_ID = "ASIA2PKWSBTZHWG6C5XV"
#$env:AWS_SECRET_Access_Key = "wl9WOXja97XKJ5Ys8BNP7RsRiV5iL3JtP4UmU4Dm"
#$env:AWS_SESSION_TOKEN= "FwoGZXIvYXdzEAsaDN0iG+cHym9L+uKqXSKsAZfkitiwVf536SvPhlkHXTBY4+fgp5ys2JLsprtz3NSM0OTv5qjfm//j1povV6qyeKEESf3qFb6v6PJPJ85eVPEP8Ko9OBc5VnAmUq+sXiSczutnEHuzBLRX/BujTMM/2CiCAHAw3evEKTKYlbeRX1elqL93jSLwYDxOlrqjMaJWUZYdlSQxjOPKna2QgnVc45EfGV95wLRrq4R415y0xBv8LYVOu1uPLC8ghHco453miwYyLSoEIQJxSrQGjRKgIr4lc5U4wCc2qkevgvexOvfJI4oDYzooHcPbOOchCF3CLA=="
#Test by running: aws sts get-caller-identity --profile xacc-p-0
#PS C:\Windows\system32> aws sts get-caller-identity
#{
#    "UserId": "AROA2PKWSBTZELVGXLVMG:Session1",
#    "Account": "720125431026",
#    "Arn": "arn:aws:sts::720125431026:assumed-role/FirstAm_super-pds/Session1"
#commands work now
#Use AWS 