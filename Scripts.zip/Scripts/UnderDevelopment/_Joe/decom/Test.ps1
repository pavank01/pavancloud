function Remove-FAAzureRMVM { 
    
    [CmdletBinding(SupportsShouldProcess = $true, DefaultParameterSetName = 'Delete')]
    param (              

        [parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $True)]
        [ValidatePattern("^([A-Z]{2,4})-([0-9NP]+)-([0-9]+)-(\w{4})-([A-Z]{2})-([0-9]+)$")]
        [String]$ResourceGroupName, 

        [parameter(Mandatory = $true, ValueFromPipelineByPropertyName = $True)]
        [String]$VMName,

        [parameter(Mandatory = $false, ParameterSetName = 'SafeDelete', ValueFromPipelineByPropertyName = $True)]
        [switch]$PreserveDataDisk,

        [parameter(Mandatory = $false, ParameterSetName = 'ForceDelete', ValueFromPipelineByPropertyName = $True)]
        [switch]$Force
                         
    )

    Begin {

        Write-Verbose "Executing Script: 'Remove-FAAzureRMVM'."

    }

    Process {

        try {

            #Initialize log file path
            if ($ResourceGroupName) {

                $logFilePath = Create-LogFilePath -ResourceGroupName $ResourceGroupName -FileName $VMName

            } else {
        
                $logFilePath = Create-LogFilePath -FileName $VMName
            }

            Write-FAMessageLog -Message  "Executing Script: 'Remove-FAAzureRMVM'." -LogFilePath $logFilePath -Status Starting

            # Check if Resource Group exists

            Write-Verbose "Executing command: 'Get-AzureRmResourceGroup'. Checking if specified Resource Group: '$ResourceGroupName' exists."
            Write-FAMessageLog -Message  "Executing command: 'Get-AzureRmResourceGroup'. Checking if specified Resource Group: '$ResourceGroupName' exists." -LogFilePath $logFilePath
            $resourceGroup = Get-AzureRmResourceGroup -Name $ResourceGroupName -ErrorAction Stop -WarningAction Ignore

            if ( $resourceGroup ) {

                Write-Verbose "Provided Resource Group: '$ResourceGroupName' exists."
                Write-FAMessageLog -Message  "Provided Resource Group: '$ResourceGroupName' exists." -LogFilePath $logFilePath
            
                # Check if specified VM exists     

                Write-Verbose "Executing command: 'Get-AzureRmVM'. Checking if specified VM exists."
                Write-FAMessageLog -Message  "Executing command: 'Get-AzureRmVM'. Checking if specified VM exists." -LogFilePath $logFilePath
                $vm = Get-AzureRmVM -ResourceGroupName $ResourceGroupName -Name $VMName -ErrorAction Stop -WarningAction Ignore

                if ( $vm ) {

                    Write-Verbose "Specified VM '$VMName' exists"
                    Write-FAMessageLog -Message  "Specified VM '$VMName' exists" -LogFilePath $logFilePath

                    Write-Host "---------Details of the VM and its associated resources-------"
                    Write-Host "VM Name : "$vm.Name
                    Write-Host "ResourceGroup name: "$vm.ResourceGroupName
                    Write-Host "Associated NICs:"
                    foreach ($config in $vm.NetworkProfile.NetworkInterfaces) {
                        
                        Write-Host "NIC Id: "$config.ID.ToString()
                    }

                    $DiskInfo = Get-FAAzureDiskInfo -Vm $vm

                    # Delete the target VM

                    if ($PSCmdlet.ShouldProcess($VMName)) {

                        Write-Host "Deleting VM.."
                        Write-Verbose "Executing command: 'Remove-AzureRmVM'. Deleting VM: '$VMName' in Resource group: '$ResourceGroupName'."
                        Write-FAMessageLog -Message  "Executing command: 'Remove-AzureRmVM'. Deleting VM: '$VMName' in Resource group: '$ResourceGroupName'." -LogFilePath $logFilePath
                        $removeVM = Remove-AzureRmVM -Name $VMName -ResourceGroupName $ResourceGroupName -Force -ErrorAction Stop -WarningAction Ignore
                    
                        if ( $removeVM ) {

                            Write-Host "VM deleted successfully!"
                            Write-Verbose "VM: '$VMName' Deleted."
                            Write-FAMessageLog -Message  "VM: '$VMName' Deleted." -LogFilePath $logFilePath

                            Write-Host " Deleting Resources associated to VM...."

                            # Remove the OS disk

                            # Added logic for managed and unmanaged disk - if ($vm.StorageProfile.OSDisk.ManagedDisk) {} else {}
                            
                            foreach ($disk in $DiskInfo) {
                                if ((-not $PreserveDataDisk) -or $Force){

                                    Write-Verbose -Message 'Removing $($disk.Type) disks of Type $($disk.AzureDiskType)...'
                                    Write-FAMessageLog -Message 'Removing $($disk.Type) disks Type $($disk.AzureDiskType)...' -LogFilePath $logFilePath

                                    if ($disk.AzureDiskType -eq "Managed"){
                                        #managed code 
                                        Remove-AzureRmDisk -DiskName $disk.DiskName -ResourceGroupName $vm.ResourceGroupName -verbose -Force
                                    }
                                    else {

                                        #unmanaged code
                                        $DiskStorageAcct = Get-AzureRmStorageAccount -ResourceGroupName $vm.ResourceGroupName -Name $disk.StorageAccount -ErrorAction Stop

                                        if ( $DiskStorageAcct ) {                                                                                    

                                            $DiskStorageAcct | Remove-AzureStorageBlob -Container $disk.Containername -Blob $disk.DiskName -Force -ErrorAction SilentlyContinue -WarningAction Ignore -ErrorVariable ActionError
                                            $ActionError | Process-Error -DisplayError -LogError -LogFilePath $logFilePath
                                            
                                            
                                            if ($disk.Type -eq "OS") {
                                                #remove snapshot only when OS disk
                                                $DiskStorageAcct | Get-AzureStorageBlob -Container $disk.Containername -Blob "$($vm.Name)*.status" | Remove-AzureStorageBlob -Force -ErrorAction SilentlyContinue -WarningAction Ignore -ErrorVariable ActionError
                                                $ActionError | Process-Error -DisplayError -LogError -LogFilePath $logFilePath
                                
                                                Write-Verbose "OS disk status blob removed."
                                                Write-FAMessageLog -Message  "OS disk status blob removed." -LogFilePath $logFilePath
                                            }
                                            
                                        } 
                                    }
                    
                                }
                                elseif ($PreserveDataDisk) {
                                    
                                    #delete only osdisk and .status files
                                    if ($disk.AzureDiskType -eq "Managed" -and $disk.Type -eq "OS"){
                                        #managed code 
                                        Remove-AzureRmDisk -DiskName $disk.DiskName -ResourceGroupName $vm.ResourceGroupName -verbose -Force
                                    }
                                    elseif ($disk.AzureDiskType -eq "UnManaged" -and $disk.Type -eq "OS")
                                    {
                                        $DiskStorageAcct = Get-AzureRmStorageAccount -ResourceGroupName $vm.ResourceGroupName -Name $disk.StorageAccount -ErrorAction Stop

                                        $DiskStorageAcct | Remove-AzureStorageBlob -Container $disk.Containername -Blob $disk.DiskName -Force -ErrorAction SilentlyContinue -WarningAction Ignore -ErrorVariable ActionError
                                        $ActionError | Process-Error -DisplayError -LogError -LogFilePath $logFilePath
                                        
                                        #remove snapshot only when OS disk
                                        if ($disk.Type -eq "OS") {

                                            $DiskStorageAcct | Get-AzureStorageBlob -Container $disk.Containername -Blob "$($vm.Name)*.status" | Remove-AzureStorageBlob -Force -ErrorAction SilentlyContinue -WarningAction Ignore -ErrorVariable ActionError
                                            $ActionError | Process-Error -DisplayError -LogError -LogFilePath $logFilePath
                            
                                            Write-Verbose "OS disk status blob removed."
                                            Write-FAMessageLog -Message  "OS disk status blob removed." -LogFilePath $logFilePath
                                        }

                                    }

                                }
                            }
                            # Remove the nic

                            $pipIds = New-Object System.Collections.ArrayList                             

                            Write-Verbose "Removing NIC..."
                            Write-FAMessageLog -Message  "Removing NIC..." -LogFilePath $logFilePath
                            $nics = $vm.NetworkProfile.NetworkInterfaces

                            if ($nics.Count -gt 0) {  
                                                        
                                foreach ($nic in $nics) { 

                                    $tempNic = Get-AzureRmResource -ResourceId $nic.ID -ErrorAction SilentlyContinue -WarningAction Ignore -ErrorVariable ActionError 
                                    $ActionError | Process-Error -DisplayError -LogError -LogFilePath $logFilePath
                                        
                                    $nicName = $tempNic.Name
                                
                                    $completeNic = Get-AzureRmNetworkInterface -Name $nicName -ResourceGroupName $ResourceGroupName -ErrorAction SilentlyContinue -WarningAction Ignore -ErrorVariable ActionError 
                                    $ActionError | Process-Error -DisplayError -LogError -LogFilePath $logFilePath
                                
                                    $pipId = $completeNic.IpConfigurations[0].PublicIpAddress.Id
                                    if ($pipId) {
                                        [void] $pipIds.Add($pipId)
                                    }
                                                                                            
                                    Write-Verbose "Excuting command: 'Remove-AzureRmNetworkInterface'. Deleting NIC: '$nicName'." 
                                    Write-FAMessageLog -Message  "Excuting command: 'Remove-AzureRmNetworkInterface'. Deleting NIC: '$nicName'." -LogFilePath $logFilePath
                                    Remove-AzureRmNetworkInterface -Name $nicName -ResourceGroupName $ResourceGroupName -Force -ErrorAction SilentlyContinue -WarningAction Ignore -ErrorVariable ActionError 

                                    $ActionError | Process-Error -DisplayError -LogError -LogFilePath $logFilePath
                                    Write-Verbose "NIC: '$nicName' Deleted."
                                    Write-FAMessageLog -Message  "NIC: '$nicName' Deleted." -LogFilePath $logFilePath

                                }

                            }
                                    
                            # Remove PIP
                        
                            Write-Verbose "Removing PIP..."
                            Write-FAMessageLog -Message  "Removing PIP..." -LogFilePath $logFilePath

                            if ($pipIds.Count -gt 0) {  

                                foreach ($pipId in $pipIds) { 

                                    $tempPIP = Get-AzureRmResource -ResourceId $pipId -ErrorAction SilentlyContinue -WarningAction Ignore -ErrorVariable ActionError 
                                    $ActionError | Process-Error -DisplayError -LogError -LogFilePath $logFilePath
                                    $pipName = $tempPIP.Name

                                    Write-Verbose "Excuting command: 'Remove-AzureRmPublicIpAddress'. Deleting PIP: '$pipName'." 
                                    Write-FAMessageLog -Message  "Excuting command: 'Remove-AzureRmPublicIpAddress'. Deleting PIP: '$pipName'." -LogFilePath $logFilePath
                                    Remove-AzureRmPublicIpAddress -Name $pipName -ResourceGroupName $ResourceGroupName -Force -ErrorAction SilentlyContinue -WarningAction Ignore -ErrorVariable ActionError 
                                    $ActionError | Process-Error -DisplayError -LogError -LogFilePath $logFilePath
                                    Write-Verbose "PIP: '$pipName' Deleted."
                                    Write-FAMessageLog -Message  "PIP: '$pipName' Deleted." -LogFilePath $logFilePath

                                }

                            } else {
                        
                                Write-Verbose "No PIP Associated with VM: '$VMName'."
                                Write-FAMessageLog -Message  "No PIP Associated with VM: '$VMName'." -LogFilePath $logFilePath

                            }

                            write-host " Associated Resources Deleted!"
                    
                        } Else {

                            Write-Verbose "VM: '$VMName' could not be deleted." 
                            Write-FAMessageLog -Message  "VM: '$VMName' could not be deleted." -LogFilePath $logFilePath
                            Write-Host "VM could not be deleted."                   

                        }

                    } else {
                    
                        #Case: WhatIf Delete
                    
                        Write-Host -ForegroundColor Red "WhatIf: The associated Resources- OS disc, NICs, PIPs associated to NICs and Status blob from the Storage Account will be deleted along with the VM deletion."
                    
                        if (!$PreserveDataDisk) {
                        
                            Write-Host -ForegroundColor Red "WhatIf: Without switch parameter 'PreserveDataDisk', the attached Data Discs, if any, will be deleted from the storage account."
                        } 
                    
                    }
                    
                } Else {

                    Write-Verbose "VM: '$VMName' does not exist."
                    throw [Exception] "VM: '$VMName' does not exist."
                }
            } Else {   
                
                Write-Verbose "Resource Group: '$ResourceGroupName' does not exist."
                throw [Exception] "Resource Group: '$ResourceGroupName' does not exist."
            }    
        } catch {

            # Handle Errors/Exceptions occurred.
            $Global:Error[0] | Process-Error -ThrowAndStop -DisplayError -LogError -LogFilePath $logFilePath
        }
        Write-FAMessageLog -Message  "VM deleted successfully." -LogFilePath $logFilePath -Status "Completed"
    }

    End {

        Write-Verbose "Executed script: 'Remove-FAAzureRMVM'."
        Write-FAMessageLog -Message  "Executed script: 'Remove-FAAzureRMVM'." -LogFilePath $logFilePath -Status "Completed"
    } 

}