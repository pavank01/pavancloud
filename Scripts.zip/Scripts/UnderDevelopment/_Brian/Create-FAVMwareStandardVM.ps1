﻿<#
.SYNOPSIS
Create a VMware VM.

.DESCRIPTION
A PowerShell script to create a VMware VM with the specified parameters for the selected operating system, CPU and memory amount,
target vSphere environment, build VLAN, and domain options. The script will use a dynamic OS Custom Specification file based
on the parameters passed to it. If the DomainJoin option is chosen the script will create the computer AD object in the specified
OU.

.PARAMETER VmName
The name of the virtual machine to create.

.PARAMETER CpuCount,
The number of CPUs to assign to the VM.

.PARAMETER MemoryGB
The amount of memory to assign to the VM in GB.

.PARAMETER Cluster
The name of the cluster to build the VM in. Options are the primary cluster for each
vSphere server as chosen by the Cloud team based on capacity.

.PARAMETER DatastoreCluster
The name of the datastore cluster to build the VM in. Options are the primary datastore cluster
for each vSphere server as chosen by the Cloud team based on capacity.

.PARAMETER Folder
The name of the vSphere folder to build the VM in.

.PARAMETER PortGroup
The VLAN to build the VM on. Options are: SNA-Build-VLAN (best option for Non-Prod), SNA-Build-VLAN1 (best option for Prod), and DAL-Build-VLAN.

.PARAMETER Template
The template used for your operating system choice. Options will be a standard build for each version of OS.

.PARAMETER DomainJoin
The fully qualified name of a domain to be joined.  These parameters are ignored if the selected opreating system is Linux.  This parameter is optional.

.PARAMETER DomainOU
The OU to be used for the domain join.  This parameter is optional unless domainJoin is specified.

.PARAMETER DomainCredential
The AD credential object to be used for the domain join. The format for user name must follow the following pattern: user-a@fully qualified domain name.
This parameter is optional unless domainJoin is specified

.PARAMETER Force
This switch will force the script to skip user prompts for CPU and Memory validation, and the AD Object check. Use this when automating builds.

.INPUTS
None.  You cannot pipe input to Create-FAVMwareStandardVM.ps1.

.OUTPUTS
None.  Create-FAVMwareStandardVM.ps1 does not generate any output.

.EXAMPLE
.\Create-FAVMwareStandardVM.ps1 -VmName 'snavnmsbvmwr001' -CpuCount 2 -MemoryGB 4 -Cluster SNA09_1-Test-Shared -DatastoreCluster SNA09_1-Test-Shared_SDRS01 -Folder 'Z_Testing' -PortGroup SNA-Build-VLAN -Template FASTD2008R2 -adminPassword 'pa$$Word' -domainJoin 'corp.firstam.com' -domainOU 'OU=Azure,OU=Environments,OU=Servers,OU=Datacenter,DC=corp,DC=firstam,DC=com' -DomainCredential $(Get-Credential)

Creates a VM in an AD domain.

.EXAMPLE
.\Create-FAVMwareStandardVM.ps1 -VmName 'snavnmsbvmwr001' -CpuCount 2 -MemoryGB 4 -Cluster SNA09_1-Test-Shared -DatastoreCluster SNA09_1-Test-Shared_SDRS01 -Folder 'Z_Testing' -PortGroup SNA-Build-VLAN -Template FASTD2008R2 -adminPassword 'pa$$Word'

Creates a standalone VM.

.EXAMPLE
.\Create-FAVMwareStandardVM.ps1 -VmName 'snavnmsbvmwr001' -CpuCount 2 -MemoryGB 4 -Cluster SNA09_1-Test-Shared -DatastoreCluster SNA09_1-Test-Shared_SDRS01 -Folder 'Z_Testing' -PortGroup SNA-Build-VLAN -Template FASTD2008R2 -adminPassword 'pa$$Word' -domainJoin 'corp.firstam.com' -domainOU 'OU=Azure,OU=Environments,OU=Servers,OU=Datacenter,DC=corp,DC=firstam,DC=com' -DomainCredential $(Get-Credential) -Force

Creates a VM and skips any prompts for existing AD object or over capacity settings.

#>

#------------------------------------------------------------------------------
#region - Parameters
#------------------------------------------------------------------------------
[CmdletBinding(DefaultParameterSetName='NoDomain')]
Param(

    [Parameter(Mandatory=$True)]
    [string]$VmName,

    [Parameter(Mandatory=$True)]
    [int]$CpuCount,

    [Parameter(Mandatory=$True)]
    [int]$MemoryGB,
	
    [Parameter(Mandatory=$True)]
    [ValidateSet("SNA09_7-Prod-Shared","SNA09_8-Prod-Shared","DFW-DR-07","SNA09_5-Test-Shared")]
    [string]$Cluster,

    [Parameter(Mandatory=$True)]
    [ValidateSet("SNA09_7-Prod-Shared_SDRS01","SNA09_8-Prod-Shared_SDRS01","DFW-DR-07_SDRS01","SNA09_5-Test-Shared-sDRS01")]
    [string]$DatastoreCluster,

    [Parameter(Mandatory=$True)]
    [string]$Folder,

    [Parameter(Mandatory=$True)]
    [ValidateSet("SNA-Build-VLAN1","DAL-Build-VLAN")]
    [string]$PortGroup,

    [Parameter(Mandatory=$True)]
    [ValidateSet("FAStandard2008R2","FAStandard2012","FAStandard2012R2")]
    [string]$Template,

    [Parameter(Mandatory=$True)]
    [string]$AdminPassword,

    [Parameter(ParameterSetName='Domain',Mandatory=$True)]
    [string]$DomainJoin,
   
    [Parameter(ParameterSetName='Domain',Mandatory=$True)]
    [string]$DomainOU,

    [Parameter(ParameterSetName='Domain',Mandatory=$True)]
    [PSCredential]$DomainCredential,

    [Parameter(Mandatory=$False)]
    [switch]$Force

    )
#------------------------------------------------------------------------------
#endregion - Parameters
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Constants
#------------------------------------------------------------------------------

$VmName             = $VmName.ToUpper()
$SoftwareStaging    = 'C:\Software'
$ScriptPath         = '\\corp.firstam.com\Restricted\ServerOps-Admin\Scripts\'
$ScriptName         = 'Configure-FAVMwareStandardVM.ps1'
$SoftwareSource     = '\\corp.firstam.com\Restricted\ServerOps-Admin\Software\PKG\'
$FullVmName         = $VmName + '.' + $DomainJoin
$OUTarget           = $DomainOU.Split(",")[0]
$OUName             = $OUTarget.Split("=")[1]
$LogName            = "$VmName.log"
$LogDirectory       = Get-Date -Format yyyy-MM
$LogPath            = "\\corp.firstam.com\Restricted\ServerOps-Admin\Scripts\Logs"
$FullLogPath        = $LogPath + "\" + $LogDirectory + "\" + $LogName
$SpecApproval       =''
$VMApproval         =''
$CpuCountMaxSetting = '4'
$MemoryGBMaxSetting = '8'
$MailFrom           = $($global:DefaultViServer.Name) + '@firstam.com'
$MailTo             = 'FAHQ-DL-SOMCloudTeam@firstam.com'
$MailSubject        = 'VM Build Alert'
$MailBody           = "$VmName was created on $($global:DefaultViServer.Name) with $CpuCount CPUs and $MemoryGB GB of memory by $($global:DefaultViServer.User)"
$SMTPServer         = 'mail.firstam.com'


# Check the log file directory, create it if it does not exist

If ( !(Test-Path -Path $LogPath\$LogDirectory -PathType Container) ) {
	
	    New-Item -Path $LogPath\$LogDirectory -ItemType Directory | Out-Null

	}


#------------------------------------------------------------------------------
#endregion - Constants
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Functions
#------------------------------------------------------------------------------

Function Log-Message {
    Param(

        [string]$Message,

        [switch]$Warning

    )

    $dateTimeStamp = Get-Date -Format "[yyyy-MM-dd hh:mm:ss]"

    $LogEntry = "<![LOG[$Message]LOG]!><time=`"$(Get-Date -Format HH:mm:ss.ffff)`" " +`
                "date=`"$(Get-Date -Format MM-dd-yyyy)`">"
	
    Add-Content -Path $FullLogPath -Value $LogEntry

    if ($Warning) {

        Write-Host "$dateTimeStamp`t$message" -foregroundcolor "yellow"

    } else {

        Write-Output "$dateTimeStamp`t$message"

    }

}

#------------------------------------------------------------------------------
#endregion - Functions
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Validate parameters
#------------------------------------------------------------------------------

# Check to see if you are logged into a ViServer

if (!$global:DefaultViServer) {

    Log-Message "You are not logged into a vSphere server. Please login prior to running the script" -Warning

    Log-Message "Exiting build script" -Warning

    Exit 0

}

Log-Message "Beginning build of $VmName on $($global:DefaultViServer.Name) by $($global:DefaultViServer.User)"

Log-Message "Logfile located at $FullLogPath"

if ($DomainCredential.UserName -notmatch "(\w+)-a@(\w+)") {

    Log-Message "DomainCredential is not in the proper format" -Warning

    Log-Message "Use the following: username-a@FQDN" -Warning

    Log-Message "Exiting build script." -Warning

    Exit 0

}


# If logged into SNAPPVSPVMWR010, change the PortGroup variable to SNA-Build-VLAN1
# This is a temporary method until we fix the underlying network issue

if ($global:DefaultViServer.Name -eq 'snappvspvmwr010') {

    $PortGroup = 'SNA-Build-VLAN1'

}


# Check to see if the VM guest name is in use on the vSphere server

Log-Message "Validating vSphere guest"

$VMExists = Get-VM $VmName -ErrorAction SilentlyContinue

if ($VMExists) {

    Log-Message "$VmName guest already exists in vSphere server." -Warning
    
    Log-Message "Exiting build script." -Warning

    Exit 0

}


# Check to see if the folder exists on the vSphere server

Log-Message "Validating vSphere Folder"

$Location = Get-Folder -Name $Folder -ErrorAction SilentlyContinue

if (!$Location) {

    Log-Message "$Folder does not exist on vSphere server" -Warning

    Log-Message "Exiting build script" -Warning

    Exit 0

}


# If the DomainJoin parameter was used, check to see if the AD OU exists

if ($DomainJoin) {

    Log-Message "Validating DomainOU"

    Try {

        $ADOU = Get-ADOrganizationalUnit -Identity $DomainOU -Server $DomainJoin

    } Catch {

        Log-Message "$DomainOU does not exist." -Warning

        Log-Message "Exiting build script." -Warning

        Exit 0

    }

}


# If the DomainJoin parameter was used, check to see if the Computer AD object exists
# Using the Force switch will skip this step

if ($DomainJoin) {

    if (!$Force) {

        Log-Message "Validating VMName AD object status"

        Try {

            $ADObject = Get-ADComputer -Identity $VmName -Server $DomainJoin -Credential $DomainCredential

    
        } Catch {}


        if ($ADObject) {

            $ADObjectExists = 'True'

            Log-Message "$VmName already exists in Active Directory" -Warning

            Log-Message "$($ADObject.DistinguishedName)" -Warning

            $VMApproval = Read-Host "`tContinue build? (Y/N)"

            if ($VMApproval.ToUpper() -eq 'Y') {

                Log-Message "Continuing build at user's request"

            } else {

                Log-Message "Stopping build at user request" -Warning
    
                Exit 0

            }

        }

    } else {

        Log-Message "The -Force parameter was used, no AD object validation called" -Warning

    }

}


# Check the CPU and MemoryGB values and alert if it's over the specified values
# Using the Force switch will skip this step

if (!$Force) {

    Log-Message "Validating CPU and MemoryGB"

    if ($CpuCount -gt $CpuCountMaxSetting -or $MemoryGB -gt $MemoryGBMaxSetting) {

        Log-Message "The number of CPUs and/or total memory settings are above the capacity guidelines" -Warning
        Log-Message "Please consult with the Cloud Team before continuing" -Warning

        $SpecApproval = Read-Host "`tContinue build? (Y/N)"

        if ($SpecApproval.ToUpper() -eq 'Y') {

            Log-Message "Continuing build at user's request"

            Send-MailMessage -From $MailFrom -To $MailTo -Subject $MailSubject -SmtpServer $SMTPServer -Body $MailBody
        
        } else {
    
            Log-Message "Stopping build at user's request"
    
            Exit 0

        }
    }

} else {

    Log-Message "The -Force parameter was used, no CPU or Memory validation called" -Warning

}

#------------------------------------------------------------------------------
#endregion - Validate Paramters
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Main
#------------------------------------------------------------------------------

# Create the computer AD object if the DomainJoin parameters where used.

if ($DomainJoin -and $(!$ADObject)) {

    Log-Message "Creating computer AD object for $VmName"

    Try { 
        
        New-ADComputer -Name $VmName -Server $DomainJoin -Path $DomainOU -Credential $DomainCredential

    } Catch {
    
    $ErrorMessage = $_.Exception.Message
    
    Log-Message "$ErrorMessage" -Warning
    
    }

}

# Gather some needed objects

# vSphere 5.5
# $Datastore = (Get-DatastoreCluster -Name $DatastoreCluster | Get-Datastore | sort -Property "FreeSpaceGB" -Descending)[0].name

# vSphere 5.1
$Datastore = (Get-Datastore -RelatedObject $DataStoreCluster | sort -Property "FreeSpaceGB" -Descending)[0].Name

$AvailableClusters = Get-Cluster $Cluster

$VmHost = $AvailableClusters | Get-VMhost | Where-Object { $_.ConnectionState -eq "Connected" } | Get-Random

$TargetPortGroup = Get-VirtualPortGroup -VMHost $VmHost -Name $PortGroup


# Create the OS Customization Specification.

if($DomainJoin) {

    $OSCustSpec = New-OSCustomizationSpec -FullName 'First American Title' `
                    -OrgName 'First American Title' `
                    -OSType Windows `
                    -NamingScheme fixed `
                    -NamingPrefix $VmName `
                    -ChangeSid `
                    -Domain $DomainJoin `
                    -DomainCredentials $DomainCredential `
                    -TimeZone Pacific `
                    -AdminPassword $adminPassword `
                    -Type NonPersistent

} Else {
        
    $OSCustSpec = New-OSCustomizationSpec -FullName 'First American Title' `
                    -OrgName 'First American Title' `
                    -OSType Windows `
                    -NamingScheme fixed `
                    -NamingPrefix $VmName `
                    -ChangeSid `
                    -WorkGroup 'WORKGROUP' `
                    -TimeZone Pacific `
                    -AdminPassword $adminPassword `
                    -Type NonPersistent

}


# Create the VM

Log-Message "Creating shell VM $VmName"
    
$NewVm = New-VM -VMHost $VmHost -Name $VmName -Location $Location -Datastore $Datastore -DiskStorageFormat Thick -OSCustomizationSpec $OSCustSpec -Template $Template


# Configure CPU and memory settings

Log-Message "Setting CPU and Memory options"

$NewVm | Set-VM -NumCPu $CpuCount -MemoryGB $MemoryGB -Confirm:$False | Out-Null


# Configure the network card portgroup

Log-Message "Setting portgroup to $TargetPortGroup"

$NewVm | Get-NetworkAdapter | Set-NetworkAdapter -Portgroup $TargetPortGroup -Confirm:$false | Out-Null


# Start the VM

Log-Message "Starting $VmName."

# Start-VM -VM $VmName -Confirm:$False

$NewVm | Start-VM | Get-NetworkAdapter | Set-NetworkAdapter -StartConnected:$true -Connected:$true -Confirm:$False | Out-Null


# Wait for the sysprep and OS customization to occur

Log-Message "Starting sysprep and OS customization."

Log-Message "Start-Sleep -Seconds 240"

Start-Sleep -Seconds 240

$MaxTimeSpent = New-TimeSpan -Minutes 20

$StartTime = Get-Date

Do {
    
    $Event = Get-VM -Name $VmName | Get-VIEvent | Where-Object { $_ -is "VMware.Vim.CustomizationSucceeded" }

    Log-Message "Waiting for sysprep and OS customization to complete."

    Start-Sleep -Seconds 60

    if ( (Get-Date) - $StartTime -ge $MaxTimeSpent) {
        
            Write-Warning "There was a problem with the sysprep and OS customization. Check the logs"

            Exit 0

        }
    
} Until (

    $Event

)

Log-Message "Sysprep and OS customization are complete."


if (!$DomainJoin) {

    Log-Message "Computer build complete."

    Exit 0

}

Log-Message "Start-Sleep -Seconds 180"

Start-Sleep -Seconds 180

# test for DNS connectivity
# 2016-03-03 - mblackman - modified the Do/Until loop to include Quiet and removed the hard Exit
#    Added if ($TimeOut) check
# 2016-03-09 - mblackman - changed name test to host only and removed $FullVmName references 
<#
$MaxTimeSpent = New-TimeSpan -Minutes 10

$StartTime = Get-Date

$TimeOut = ''

Do {

	
	$Event = Test-Connection $VmName -Quiet

    Log-Message "Testing name resolution"
    
    Start-Sleep -Seconds 60

    if ( (Get-Date) - $StartTime -ge $MaxTimeSpent) {
        
        $TimeOut = 'true'

    }
    
} Until (

    ($Event -eq 'true' -or $TimeOut -eq 'true')
    
)

if ($TimeOut -eq 'true') {

    Log-Message "Name resolution for $VmName is taking too long" -Warning

    Log-Message "The configuration script will need to be run manually" -Warning

    Log-Message "Continuing with script"

}
#>
#------------------------------------------------------------------------------
#endregion - Main
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Post build process
#------------------------------------------------------------------------------


$FullSource = Join-Path $ScriptPath -ChildPath $ScriptName
$FullTarget = Join-Path $SoftwareStaging -ChildPath $ScriptName


# Build the parameters for the scheduled task

$taskParameters = @('/Create', 
                    '/SC ONSTART', 
                    '/TN "\Microsoft\Windows\Desired State Configuration\FAConfiguration"', 
                    '/RU System', 
                    '/F', 
                    '/RL HIGHEST',
                    '/DELAY 0005:00',
                    "/TR ""PowerShell.exe -ExecutionPolicy Unrestricted -File $FullTarget"" " )



# Copy scripts and intall files needed for installation.
# Check the local directory and create it if it does not exist
# 2016-03-03 - mblackman - changed method from invoke-command to invoke-vmscript

Log-Message "Preparing for local file copies"
    

$ScriptText = "If ( !(Test-Path -Path $SoftwareStaging -PathType Container) ) { New-Item -Path $SoftwareStaging -ItemType Directory }"

Invoke-VMScript -VM $VmName -GuestCredential $DomainCredential -ScriptText $ScriptText | Out-Null


# Invoke-Command -ComputerName $VmName -Credential $DomainCredential -ScriptBlock { If ( !(Test-Path -Path $args[0] -PathType Container) ) { New-Item -Path $args[0] -ItemType Directory } } -ArgumentList $SoftwareStaging | Out-Null


# Copy the configuration script local

Log-Message "Copying $ScriptName to $SoftwareStaging"

Invoke-VMScript -ScriptText "Copy-Item -Path $FullSource -Destination $SoftwareStaging -Force" -VM $VmName -GuestCredential $DomainCredential | Out-Null

<#
# Copy the SEP install files local

Log-Message "Copying SEP install files"

$SEPSource = Join-Path $softwareSource -ChildPath 'Symantec\Symantec Endpoint Protection\12.1.6318.6100'

$SEPDest = Join-Path $SoftwareStaging -ChildPath 'SEP'

# Invoke-Command -ComputerName $FullVmName -Credential $DomainCredential -ScriptBlock { If ( !(Test-Path -Path $args[0] -PathType Container) ) { New-Item -Path $args[0] -ItemType Directory } } -ArgumentList $SEPDest | Out-Null

$ScriptText = "If ( !(Test-Path -Path $SEPDest -PathType Container) ) { New-Item -Path $SEPDest -ItemType Directory }"

Invoke-VMScript -VM $VmName -GuestCredential $DomainCredential -ScriptText $ScriptText | Out-Null

Invoke-VMScript -ScriptText "Copy-Item -Path '$SEPSource\*' -Destination $SEPDest -Force -Recurse" -VM $VmName -GuestCredential $DomainCredential | Out-Null


# Copy the Altiris install files local

Log-Message "Copying Altiris install files"

$AltirisSource = Join-Path $softwareSource -ChildPath 'Symantec\Altiris\7.6.1615.26'

$AltirisDest = Join-Path $SoftwareStaging -ChildPath 'Altiris'

# Invoke-Command -ComputerName $FullVmName -Credential $DomainCredential -ScriptBlock { If ( !(Test-Path -Path $args[0] -PathType Container) ) { New-Item -Path $args[0] -ItemType Directory } } -ArgumentList $AltirisDest | Out-Null

$ScriptText = "If ( !(Test-Path -Path $AltirisDest -PathType Container) ) { New-Item -Path $AltirisDest -ItemType Directory }"

Invoke-VMScript -ScriptText "Copy-Item -Path '$AltirisSource\*' -Destination $AltirisDest -Force -Recurse" -VM $VmName -GuestCredential $DomainCredential | Out-Null
#>


#if ($Event -eq 'true') {

    # Schedule the config script to run at reboot

    Invoke-Command -ComputerName $VmName -Credential $DomainCredential -ScriptBlock {

        Start-Process -FilePath 'schtasks.exe' -ArgumentList ( $args -join " " ) -Wait

    } -ArgumentList $taskParameters

    Log-Message "Script $FullTarget scheduled to run at reboot"

    Log-Message "Config preparation complete. Restarting computer"

    Invoke-Command -ComputerName $VmName -Credential $DomainCredential -ScriptBlock { Restart-Computer -Force }
<#
} else {

    Log-Message "$VmName was built, but with exceptions" -Warning

    Log-Message "$FullTarget needs to be run manually on $FullVmName" -Warning

}
#>
#------------------------------------------------------------------------------
#endregion - Post build process
#------------------------------------------------------------------------------