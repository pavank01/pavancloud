$resourceGroupName = 'MT-1-4-TVVP-RG-2'

$StorageEndPointParms1 = @{
    location = 'westus2'
    privateEndpointName = 'mta1s4tvvpsa2-PE1'
    privateLinkResource = '/subscriptions/84b20a1d-1029-4400-b529-2592f26718dd/resourceGroups/MT-1-4-TVVP-RG-2/providers/Microsoft.Storage/storageAccounts/mta1s4tvvpsa2'
    requestMessage = ''
    subnet = '/subscriptions/84b20a1d-1029-4400-b529-2592f26718dd/resourceGroups/MT-1-4-MATT-RG-1/providers/Microsoft.Network/virtualNetworks/MT-1-4-MATT-VN-1/subnets/S-10.100.1.0-26'
    virtualNetworkId = '/subscriptions/84b20a1d-1029-4400-b529-2592f26718dd/resourceGroups/MT-1-4-MATT-RG-1/providers/Microsoft.Network/virtualNetworks/MT-1-4-MATT-VN-1'
    subnetDeploymentName = 'UpdateSubnetDeployment-20210506110222'
	virtualNetworkResourceGroup = 'MT-1-4-MATT-RG-1'
}

$StorageEndPointParms3 = @{
    location = 'westus2'
    privateEndpointName = 'mta1s4tvvpsa3-PE1'
    privateLinkResource = '/subscriptions/84b20a1d-1029-4400-b529-2592f26718dd/resourceGroups/MT-1-4-TVVP-RG-2/providers/Microsoft.Storage/storageAccounts/mta1s4tvvpsa3'
    requestMessage = ''
    subnet = '/subscriptions/84b20a1d-1029-4400-b529-2592f26718dd/resourceGroups/MT-1-4-MATT-RG-1/providers/Microsoft.Network/virtualNetworks/MT-1-4-MATT-VN-1/subnets/S-10.100.1.0-26'
    virtualNetworkId = '/subscriptions/84b20a1d-1029-4400-b529-2592f26718dd/resourceGroups/MT-1-4-MATT-RG-1/providers/Microsoft.Network/virtualNetworks/MT-1-4-MATT-VN-1'
    subnetDeploymentName = 'UpdateSubnetDeployment-20210506110222'
	virtualNetworkResourceGroup = 'MT-1-4-MATT-RG-1'
}


$Templatefile = "C:\Users\tpham\Downloads\PE_MT1_template\PE_MT1_template.json"

New-AzureRMResourceGroupDeployment -ResourceGroupName $resourceGroupName -TemplateFile $Templatefile -TemplateParameterObject $StorageEndPointParms1 -mode Incremental

New-AzureRMResourceGroupDeployment -ResourceGroupName $resourceGroupName -TemplateFile $Templatefile -TemplateParameterObject $StorageEndPointParms3 -mode Incremental

