﻿[CmdletBinding()]
    param (

		[Parameter(Mandatory=$False)]
        [String]$SourcePath = '\\corp.firstam.com\restricted\ServerOps-Admin\Scripts\Modules\FAAzure',

        [Parameter(Mandatory=$False)]
        [String]$TargetPath = 'C:\Temp\FAAzure'

		)

If ( !(Test-Path -Path $TargetPath -PathType Container) ) {
	
		New-Item -Path $TargetPath -ItemType Directory -ErrorAction Stop

	}

Copy-Item -Path "$SourcePath\*" -Destination $TargetPath -Recurse -Force

Unblock-File -Path "$TargetPath\*"

Copy-Item -Path "$TargetPath\*" -Destination 'C:\Program Files\WindowsPowerShell\Modules\FAAzure' -Recurse -Force