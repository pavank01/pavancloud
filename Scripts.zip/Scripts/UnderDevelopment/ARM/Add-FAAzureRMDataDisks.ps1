﻿[CmdletBinding()]
    param (

        [Parameter(Mandatory=$false, ValueFromPipelineByPropertyName=$True)]
        [validatePattern("^((?!^.{90})([A-Z]{2}(-)[0-9]+-[0-9]+-[A-Z]{4}-RG-[0-9]+))$")]
        [string]$ResourceGroupName,

        [Parameter(Mandatory=$True, ValueFromPipelineByPropertyName=$True)]
        [string]$VmName,

        [Parameter(Mandatory=$True, ValueFromPipelineByPropertyName=$True)]
        [validatePattern("^((?!^.{24})([a-z]{2}a[0-9]+s[0-9]+[a-z]{4}sa[0-9]+))$")]
        [string]$StorageAccountName,

        [Parameter(Mandatory=$True, ValueFromPipelineByPropertyName=$True)]
        [int32]$DiskSize ,

        [Parameter(Mandatory=$True, ValueFromPipelineByPropertyName=$True)]
        [int32]$DiskCount ,

        [Parameter(Mandatory=$False, ValueFromPipelineByPropertyName=$True)]
        [ValidateSet("None","ReadOnly","ReadWrite")]
        [string]$HostCaching = 'None',

		[Parameter(Mandatory=$False, ValueFromPipelineByPropertyName=$True)]
		[switch]$AttachAsPremiumDisk
    )

$DiskVariables = @{

    VmName = $VmName
    StorageAccountName = $StorageAccountName
    DiskSize = $DiskSize
    HostCaching = $HostCaching
    AttachAsPremiumDisk = $AttachAsPremiumDisk

}

for ($Counter = 1; $Counter -le $DiskCount; $Counter++) {

    Add-FAAzureRMVMDataDisk @DiskVariables

}