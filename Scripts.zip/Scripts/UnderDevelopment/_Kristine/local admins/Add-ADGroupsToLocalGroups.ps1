﻿[CmdletBinding()]
param(

    [Parameter(Mandatory=$True)]
    [string]$Computer,
        
    [Parameter(Mandatory=$True)]
    [string]$Group

)

$LocalGroup = [ADSI]("WinNT://" + $Computer + "/Administrators")
     
Write-Output "Adding $Group to $Computer"

$SourceGroup = [ADSI]("WinNT://" + $Group)

$LocalGroup.PSBase.Invoke("Add",$SourceGroup.PSBase.Path)