﻿[CmdletBinding()]
    param (
        
        [string]$ComputerList = 'C:\SCRIPTS\AddLocalAdmins\computers.txt',

        [string]$ADGroupList = 'C:\SCRIPTS\AddLocalAdmins\adgroups.txt',

        [string]$PSScript = 'C:\SCRIPTS\AddLocalAdmins\Add-ADGroupsToLocalGroups.ps1',

        [string]$ErrorLog = 'C:\SCRIPTS\AddLocalAdmins\server_retry.txt'

    )

Try {

    $Computers = Get-Content $ComputerList -ErrorAction Stop

} Catch {

    Write-Warning "I can't find the list of computers."

}

Try {

    $ADGroups = Get-Content $ADGroupList -ErrorAction Stop

} Catch {

    Write-Warning "I can't find the list of AD groups."

}

foreach ($Computer in $Computers) {

    Write-Host "Beginning script on $Computer"

    foreach ($Group in $ADGroups) {

        Try {

            Invoke-Command -ComputerName $Computer -FilePath $PSScript -ArgumentList $Computer,$Group -ErrorAction Stop

        } Catch {

            Write-Warning "Unable to modify $Computer"

            $Computer | Out-File $ErrorLog -Append

            Write-Warning "Logged to $ErrorLog"

        }

    }

    Write-Host "Script has completed on $Computer"

}