Add-FAAzureRMVMDataDisk -ResourceGroupName 'SO-1-4-CLST-RG-1' `
	                        -VmName 'AZUVNSQLCLST001' `
	                        -StorageAccountName 'soa1s4clstsa1' `
	                        -DiskSize '250' `
							-HostCaching ReadWrite					