﻿$azureCredentialPath = 'C:\users\mallison-a\desktop\aadCred.xml'
$windowsCredentialPath = 'C:\users\mallison-a\desktop\domainCred.xml'
$serviceNamePattern = 'SO-1-1-FINT-CS-*'

$azureCred = Import-CliXML -path $azureCredentialPath
$windowsCred = Import-Clixml -path $windowsCredentialPath

$results = .\Check-FINTHealth.ps1 -AzureCredential $azureCred -WindowsCredential $windowsCred -ServiceNamePattern $serviceNamePattern -Verbose

$results | ft
