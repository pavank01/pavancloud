﻿<#	
.SYNOPSIS
Run a PowerShell script against a list of servers defined in an ENVXML file.

.DESCRIPTION
Run a PowerShell script aginst a list of servers defined in an ENVXML file.  The PowerShell script
must be stored in a .ps1 file and additional lines can be provided as a string parameter.

.PARAMETER ConfigFile
The path to the ENVXML file conatining the list of VMs to be used

.PARAMETER ScriptPath
The path to the .ps1 file to be executed on a remote machine

.PARAMETER AdditionalCommands
A string with additional commands that are appended to the .ps1 file for execution.  Use semicolons
to delimit multiple commands.

.PARAMETER Credential
A PowerShell credential to use with the underlying Invoke-Command operation

.EXAMPLE
Invoke-FAAzureEvironmentCommand -ConfigFile .\SO-1-1-AZUR-CS-28.xml' -ScriptPath .\Get-Memory.ps1 -AdditionalCommands ';Get-Memory -detailed'

#>

param (
	[parameter(Mandatory = $true)]
	[string]$ConfigFile,
	
	[parameter(Mandatory = $true)]
	[string]$ScriptPath,
	
	[parameter(Mandatory = $false)]
	[string]$AdditionalCommands,
    
	[parameter(Mandatory = $true)]
	[PSCredential]$Credential

)

# Create a Script Block from a .ps1 file that has the function we want to call

$content = Get-Content -Path $ScriptPath | out-string

if ($AdditionalCommands) {
	$content += ";$AdditionalCommands"
}

$sb = [scriptblock]::Create($content)

# Get a list of servers to run the command against

$xml = [XML](Get-Content -Path $ConfigFile)
$domain = ($xml.ProvisionVMs.Subscription.Cloud.Defaults.Config | Where-Object { $_.Name -eq "Domain" }).Value
$vmList = $xml.ProvisionVMs.Subscription.Cloud.VMs.VM | % { "$($_.Name).$domain" }

# Run the command on each server and return the results

$output = Invoke-Command -ScriptBlock $sb -ComputerName $vmList -Credential $Credential

$output
