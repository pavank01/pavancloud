﻿<#
.DESCRIPTION
Get-FAAzureRMDiskCount will recurse each storage account 
in the specified resource group and return the tier of the
 storage account and a count of the page blobs in the vhds
 container.

.PARAMETER ResourceGroupName
The target resource group.

.EXAMPLE
Get-FAAzureRMDiskCount.ps1 -ResourceGroupName SO-1-4-EOCR-RG-1
#>

[CmdletBinding()]
    param (
               
        [Parameter(Mandatory=$True)]
        [string]$ResourceGroupName

    )

$DiskCount = @()

Try {

    $StorageAccounts = Get-AzureRmStorageAccount -ResourceGroupName $ResourceGroupName -ErrorAction Stop

} Catch {

    Write-Warning "Could not find storage accounts in $ResourceGroupName"

    Exit 0

}



foreach ($StorageAccount in $StorageAccounts) {

    $PageBlobs = @()

    Try {
    
        $Container = $StorageAccount | Get-AzureStorageContainer -Name vhds -ErrorAction Stop
        
        $AllBlobs = $Container | Get-AzureStorageBlob

        foreach ($Blob in $AllBlobs) {

            if ($Blob.BlobType -eq "PageBlob") {

                $PageBlobs += $Blob

            }

        }

        $Properties = [ordered]@{StorageAccount=$StorageAccount.StorageAccountName
                                Tier=$StorageAccount.Sku.Tier
                                DiskCount=$PageBlobs.Count}

        $obj = New-Object -TypeName PSObject -Property $Properties

        $DiskCount += $obj

    } Catch {

        Write-Warning "Could not find the vhds container in $($StorageAccount.StorageAccountName)"

    }

}

$DiskCount | Format-Table -AutoSize