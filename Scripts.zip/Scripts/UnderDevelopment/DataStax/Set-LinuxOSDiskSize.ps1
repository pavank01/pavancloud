﻿$VM = "AZUVNDTXEOCR006"
$RG = 'SO-1-4-EOCR-RG-1'

$MyVM = Get-AzureRmVM -Name $VM -ResourceGroupName $RG

$MyVM | Stop-AzureRmVM -Force

$MyVM.StorageProfile[0].OSDisk[0].DiskSizeGB = 100

Update-AzureRmVM –ResourceGroupName $RG -VM $MyVM