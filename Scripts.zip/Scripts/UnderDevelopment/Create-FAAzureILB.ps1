﻿<#
.DESCRIPTION
Create-FAAzureILB will create a new internal load balancer
in the specified cloud service.

.PARAMETER ServiceName
The name of the target cloud service.

.PARAMETER ILBName
The name of the new internal load balancer.

.PARAMETER SubnetName
The subnet that the new internal load balancer will sit
on.

.PARAMETER StaticVNetIPAddress
The static IP that the new internal load balancer will
use.

.EXAMPLE
.\Create-FAAzureILB.ps1 -ServiceName 'SO-1-1-AZUR-CS-1' -ILBName 'SO-1-1-AZUR-LB-1' -SubnetName 'S-10.64.8.0/23' -StaticVNetIPAddress '10.64.9.240'
#>
[CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]$ServiceName,

        [Parameter(Mandatory=$true)]
        [string]$ILBName,

        [Parameter(Mandatory=$true)]
        [string]$SubnetName,

        [Parameter(Mandatory=$true)]
        [string]$StaticVNetIPAddress

    )

# Specify the naming standard for internal load balancer

$ILBExp  = '(\w{2})-(\d+)-(\d+)-(\w{4})-LB-(\d+)'


# Convert the ILBName to upper case

$ILBName = $ILBName.ToUpper()

	
if ($ILBName -match $ILBExp) {

    Add-AzureInternalLoadBalancer -ServiceName $ServiceName `
                              -InternalLoadBalancerName $ILBName `
                              –SubnetName $SubnetName `
                              –StaticVNetIPAddress $StaticVNetIPAddress

} Else {

    Write-Warning "$ILBName does not match our naming standard."

}