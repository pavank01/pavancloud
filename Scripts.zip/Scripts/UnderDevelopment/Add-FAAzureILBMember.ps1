﻿<#
.DESCRIPTION
Add-FAAzureILBMember will add an existing VM to an existing
internal load balancer.

.PARAMETER ServiceName
The name of the target cloud service.

.PARAMETER VmName
The VM to be added to the internal load balancer.

.PARAMETER EndpointName
The name of the endpoint on the VM.

.PARAMETER LBSetName
The name of the load balancer endpoint.

.PARAMETER Protocol
The protocol used for the endpoint. Accepted values are
TCP or UDP.

.PARAMETER LocalPort
The port used on the VM to listen for requests.

.PARAMETER PublicPort
The port used on the load balancer endpoint to listen for requests.

.PARAMETER ProbePort
The port used for the health check for members of the load balancer.

.PARAMETER ProbeProtocol
The protocol used for the probeport. Accepted values are
TCP or UDP.

.PARAMETER ILBName
The name of the internal load balancer this VM will use.

.PARAMETER LBDistribution
The load balancer distribution algorithm (affinity). This parameter is optional,
as the default value of 'none' does use affinity (5 tuple). Accepted values are
'sourceIP' and 'sourceIPProtocol'.

.EXAMPLE
.\Add-FAAzureILBMember.ps1 -ServiceName 'SO-1-1-AZUR-CS-3' -VmName 'AZUVNWEBAZUR100' -EndpointName 'AZUR-WEB-TCP-80' -LBSetName 'AZUR-WEB-TCP-80-SET' -Protocol tcp -LocalPort 80 -PublicPort 80 -ILBName 'SO-1-1-AZUR-LB-3'
#>

[CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [string]$ServiceName,

        [Parameter(Mandatory=$true)]
        [string]$VmName,

        [Parameter(Mandatory=$true)]
        [string]$EndpointName,

        [Parameter(Mandatory=$true)]
        [string]$LBSetName,

        [Parameter(Mandatory=$true)]
        [ValidateSet("tcp","udp")]
        [string]$Protocol,

        [Parameter(Mandatory=$true)]
        [int]$LocalPort,

        [Parameter(Mandatory=$true)]
        [int]$PublicPort,

        [Parameter(Mandatory=$true)]
        [string]$ILBName,

        [Parameter(Mandatory=$false)]
        [ValidateSet("sourceIP","sourceIPProtocol")]
        [string]$LBDistribution

    )

# Specify the naming standard for endpoint name

$EndpointNameExp  = '(\w{4})-(\w{3})-(\w{3})-(\d+)'

# Convert the endpoint name to upper case

$EndpointName = $EndpointName.ToUpper()

# Specify the naming standard for load balanced set name

$LBSetNameExp  = '(\w{4})-(\w{3})-(\w{3})-(\d+)-SET'

# Convert the load balanced set name to upper case

$LBSetName = $LBSetName.ToUpper()

# Convert the internal load balancer name to upper case

$ILBName = $ILBName.ToUpper()

if (($EndpointName -match $EndpointNameExp) -and ($LBSetName -match $LBSetNameExp)) {

    if ($LBDistribution) {

        Get-AzureVM –ServiceName $ServiceName –Name $VmName |
            Add-AzureEndpoint -Name $EndpointName `
                                -LBSetName $LBSetName `
                                -Protocol $Protocol `
                                -LocalPort $LocalPort `
                                -PublicPort $PublicPort `
                                –DefaultProbe `
                                -InternalLoadBalancerName $ILBName `
                                -LoadBalancerDistribution $LBDistribution |
            Update-AzureVM

    } else {

        Get-AzureVM –ServiceName $ServiceName –Name $VmName |
            Add-AzureEndpoint -Name $EndpointName `
                                -LBSetName $LBSetName `
                                -Protocol $Protocol `
                                -LocalPort $LocalPort `
                                -PublicPort $PublicPort `
                                –DefaultProbe `
                                -InternalLoadBalancerName $ILBName |
            Update-AzureVM

    }

} else {

    Write-Warning "$EndpointName and/or $LBSetName does not match our naming standard."

}