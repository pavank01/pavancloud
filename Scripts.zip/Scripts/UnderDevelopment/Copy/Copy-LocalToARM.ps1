﻿$ResourceGroup = 'SO-1-4-AZUR-RG-1'

$StorageAccount = "soa1s4azursa1"

$DestContainer = 'scripts'

$FilePath = '\\corp.firstam.com\restricted\ServerOps-Admin\Scripts\AzureScriptExtensionScripts\Configure-FAServerStandard.ps1'

$BlobName = 'Configure-FAServerStandard.ps1'
 


$StorageContainer = Get-AzureRmStorageAccount -ResourceGroupName $ResourceGroup -Name $StorageAccount | Get-AzureStorageContainer | where {$_.Name -eq $DestContainer}

$StorageContainer | Set-AzureStorageBlobContent –File $FilePath –Blob $BlobName