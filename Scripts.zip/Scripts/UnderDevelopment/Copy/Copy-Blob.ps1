﻿[CmdletBinding()]
param (
        
    [Parameter(Mandatory=$True)]
    [string]$SrcSubscription,
        
    [Parameter(Mandatory=$True)]
    [string]$SrcStorageAccount,

    [Parameter(Mandatory=$True)]
    [string]$SrcStorageContainer,

    [Parameter(Mandatory=$True)]
    [string]$DestSubscription,

    [Parameter(Mandatory=$True)]
    [string]$DestStorageAccount,

    [Parameter(Mandatory=$True)]
    [string]$DestStorageContainer,

    [Parameter(Mandatory=$True)]
    [string]$BlobName

)

# Get the context for source and destination
# -----------------------------------------------------------

Select-AzureSubscription $SrcSubscription | Out-Null

$SrcKey = Get-AzureStorageKey -StorageAccountName $SrcStorageAccount

$SrcContext = New-AzureStorageContext -StorageAccountName $SrcStorageAccount -StorageAccountKey $SrcKey.Primary

Select-AzureSubscription $DestSubscription | Out-Null

$DestKey = Get-AzureStorageKey -StorageAccountName $DestStorageAccount

$DestContext = New-AzureStorageContext -StorageAccountName $DestStorageAccount -StorageAccountKey $DestKey.Primary

Select-AzureSubscription $SrcSubscription | Out-Null

# Get the blob to copy
# -----------------------------------------------------------

$BlobList = Get-AzureStorageBlob -Blob ($BlobName + "*") -Container $SrcStorageContainer -Context $SrcContext.Context

$SrcBlob = $BlobList[-1]

# Copy Blob Local
# ------------------------------------------

Try {

    $LocalBlobCopy = Start-AzureStorageBlobCopy -ICloudBlob $SrcBlob.ICloudBlob -DestContext $SrcContext -DestContainer $DestStorageContainer -DestBlob $SrcBlob.Name -Force -ErrorAction Stop

} Catch {

    Write-Warning "The blob did not copy." | Out-File -FilePath C:\MyScripts\Output\CopyErrors.txt

}

# Get copy status
# ------------------------------------------

$LocalBlobCopy | Get-AzureStorageBlobCopyState