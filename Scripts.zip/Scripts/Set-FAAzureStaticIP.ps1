﻿<#
.DESCRIPTION
Set-FAAzureStaticIP.ps1 will set a reserved DHCP IP 
address for an Azure VM.

.PARAMETER ServiceName
The cloud service where the target VM resides.

.PARAMETER VmName
The target VM.

.PARAMETER StaticIp
The provisioned IP address which will be set as reserved.

.EXAMPLE
.\Set-FAAzureStaticIP.ps1 -ServiceName SO-1-1-AZUR-CS-1 -VmName AZUVNAPPAZUR010 -StaticIp 10.64.4.225
#>

[CmdletBinding()]
    param (
        [Parameter(Mandatory=$True)]
        [string]$ServiceName,

        [Parameter(Mandatory=$True)]
        [string]$VmName,

        [Parameter(Mandatory=$True)]
        [string]$StaticIp

    )

Get-AzureVM -ServiceName $serviceName -name $vmName |
	Set-AzureStaticVNetIP -IPAddress $staticIP |
    Update-AzureVM