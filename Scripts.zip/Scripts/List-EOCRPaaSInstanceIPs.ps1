﻿$subscriptionName = 'SO-1-AzureSub-1'
$outputFile ="./RoleInstanceList.csv"
$serviceNames = @( "SO-1-1-EOCR-CS-3", "SO-1-1-EOCR-CS-4", "SO-1-1-EOCR-CS-5",
                   "SO-1-1-EOCR-CS-6", "SO-1-1-EOCR-CS-7", "SO-1-1-EOCR-CS-8",
                   "SO-1-1-EOCR-CS-9", "SO-1-1-EOCR-CS-10", "SO-1-1-EOCR-CS-11",
                   "SO-1-1-EOCR-CS-12", "SO-1-1-EOCR-CS-13", "SO-1-1-EOCR-CS-14" )

if ((Get-AzureSubscription -Current).SubscriptionName -ne $subscriptionName) {

    Write-Host "Changing subscription to $subscriptionName..."
    Select-AzureSubscription $subscriptionName | Out-Null

}

If (Test-Path $outputFile) { Remove-Item -Path $outputFile }

'sep=,' | Out-File -FilePath $outputFile
'"ServiceName","InstanceName","IPAddress","InstanceStatus"' | Out-File -FilePath $outputFile -Append

$serviceList = Get-AzureService | ? ServiceName -in $serviceNames

foreach ($service in $serviceList) {

    $deployment = Get-AzureDeployment -ServiceName $service.ServiceName
    
    if ($deployment.SdkVersion)  {

        # This is probably PaaS
        foreach ($roleInstance in $deployment.RoleInstanceList) {

            $output = "{0},{1},{2},{3}" -f $service.ServiceName, $roleInstance.InstanceName, $roleInstance.IPAddress, $roleInstance.InstanceStatus
            $output | Out-File -FilePath $outputFile -Append

        }

    }

}
