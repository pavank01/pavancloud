﻿$resourceGroupName = 'SO-1-3-F5LB-RG-1'

$f51DeploymentParms = @{
    'location' = 'westus'
    'virtualMachineName' = 'AZUVPLTMF5LB001'
    'virtualMachineSize' = 'Standard_D3'
    'adminUsername' = 'faadmin'
    'virtualNetworkResourceGroup' = 'SO-1-3-AZUR-RG-1'
    'virtualNetworkName' = 'SO-1-3-IaaS-VN-1'
    'adminPassword' = 'F@azur3Local'
    'availabilitySetName' = 'F5LB-LTM-AS-1'
    'availabilitySetPlatformFaultDomainCount' = '2'
    'availabilitySetPlatformUpdateDomainCount' = '5'
    'storageAccountName' = 'soa1s3f5lbsa1'
    'managementSubnetName' = 'S-10.64.190.0-26'
    'frontendSubnetName' = 'S-10.64.244.0-23'
    'backendSubnetName' = 'S-10.64.246.0-24'
}

#New-AzureRMResourceGroupDeployment -ResourceGroupName $resourceGroupName -TemplateFile .\Data\Templates\FAF5-3NIC.json -TemplateParameterObject $f51DeploymentParms -mode Incremental

$f52DeploymentParms = @{
    'location' = 'westus'
    'virtualMachineName' = 'AZUVPLTMF5LB002'
    'virtualMachineSize' = 'Standard_D3'
    'adminUsername' = 'faadmin'
    'virtualNetworkResourceGroup' = 'SO-1-3-AZUR-RG-1'
    'virtualNetworkName' = 'SO-1-3-IaaS-VN-1'
    'adminPassword' = 'F@azur3Local'
    'availabilitySetName' = 'F5LB-LTM-AS-1'
    'availabilitySetPlatformFaultDomainCount' = '2'
    'availabilitySetPlatformUpdateDomainCount' = '5'
    'storageAccountName' = 'soa1s3f5lbsa1'
    'managementSubnetName' = 'S-10.64.190.0-26'
    'frontendSubnetName' = 'S-10.64.244.0-23'
    'backendSubnetName' = 'S-10.64.246.0-24'
}

New-AzureRMResourceGroupDeployment -ResourceGroupName $resourceGroupName -TemplateFile .\Data\Templates\FAF5-3NIC.json -TemplateParameterObject $f52DeploymentParms -mode Incremental


