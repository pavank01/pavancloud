#Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

#$cred = Get-Credential
#Add-AzureRMAccount -Credential $cred

#Yes or No prompt for settings change prompt confirmation.
Function promptYesNo {
    while("yes","no" -notcontains $answer)
    {
        $answer = Read-Host "Would you like to set this setting (DENY)? (Yes/No)"
    }
        If ($answer -eq "no") {
            Write-Host "Exiting..." -ForeGroundColor Red
        exit
    }
}

#clears errors
$error.Clear()


#$Filepath = ".\Rollup-IPs.txt"
#$RollupIPs = Get-Content -Path $Filepath

#Primary Rollup IP Address Text File - Sourced in our Repo - MAKE SURE this is in the same folder as this script.
#Also removes spaces in column headers 
$SourceFolder = "."
$SourceFile = "RollupIPs.csv"
$SourcePath = $SourceFolder + "\" + $SourceFile
$SourceHeadersDirty = Get-Content -Path $SourcePath -First 2 | ConvertFrom-Csv
$SourceHeadersCleaned = $SourceHeadersDirty.PSObject.Properties.Name.Trim(' ') -Replace '\s',''
$listofips = Import-CSV -Path $SourcePath -Header $SourceHeadersCleaned | Select-Object -Skip 1
#$listofvms | Format-Table -AutoSize

#RecordsCount
$i = 1
foreach ($ip in $listofips) {
    $i++   
}

$RollupIPCount = $i

Write-Host "INFORMATION: $RollupIPCount RollUp IP Addresses in Array..." -ForegroundColor yellow
Write-Host ""
Write-Host "Loading: Azure Code Block..." -ForeGroundColor Green
Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
Connect-AzAccount
#Enable-AzureRmAlias -Scope CurrentUser

Write-Host "Please enter the following details: "

$SQLServerNameinput = Read-Host -Prompt "Azure SQL Server Name"
$SQLServerName = $SQLServerNameinput.Trim()
$SubscriptionNameInput = Read-Host -Prompt "Azure Subscription Name"
$SubscriptionName = $SubscriptionNameInput.Trim()
$ResourceGroupNameInput = Read-Host -Prompt "Azure Resource Group Name"
$ResourceGroupName = $ResourceGroupNameInput.Trim()

#Logging
$datepre = Get-Date -Format "MMddyyyy"
$datesuf = Get-Date -Format "HHmm"
$loggingpath = "\\corp.firstam.com\restricted\ServerOps-Admin\Scripts\Logs\SQLServer\"
$filename = "$SQLServerName-$datepre-$datesuf-$env:USERNAME.txt"
Write-Host ""
Start-Transcript -Path $Loggingpath$filename -NoClobber
#Logging

Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
Write-Host "Logging into Subscription..." -ForegroundColor Green
Set-AzContext -SubscriptionName $SubscriptionName 
Write-Host ""
Write-Host "Azure SQL Server Details:" -ForegroundColor Green
Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
$sqldetails = Get-AzSqlServer -ResourceGroupName $ResourceGroupName -ServerName $SQLServerName | Select-Object *
$sqldetails
Write-Host ""
Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
Write-Host "Preprocessing: Existing Rules on $SQLServerName" -ForegroundColor Green
Get-AzSqlServerFirewallRule -ResourceGroupName $ResourceGroupName -ServerName $SQLServerName
Write-Host "Status: Done" -ForegroundColor Green
Write-Host ""

$i = 1
foreach ($ip in $listofips) {

    $rollupIpAddress = $ip.RollupIPAddress
    $rollupIpLocation = $ip.Location
    $rollupIpResourceGroupName = $ip.ResourceGroupName
    $rollupIpPaloAltoVMName = $ip.PaloAltoVMName
    $rollupIpSubscriptionName = $ip.SubscriptionName

    if ($rollupIpAddress -eq '') {$RollupIPAddress = $RollupIPAddress -replace "","UNK"}
    if ($rollupIpLocation -eq '') {$rollupIpLocation = $rollupIpLocation -replace "","UNK"}
    if ($rollupIPResourceGroupName -eq '') {$rollupIPResourceGroupName = $rollupIpResourceGroupName -replace "","UNK"}
    if ($rollupIpPaloAltoVMName -eq '') {$rollupIpPaloAltoVMName = $rollupIpPaloAltoVMName -replace "","UNK"}
    if ($rollupIpSubscriptionName -eq '') {$rollupIpSubscriptionName = $rollupIpSubscriptionName -replace "","UNK"}

    #$rollupIpAddress
    #$rollupIpLocation
    #$rollupIpResourceGroupName
    #$rollupIpPaloAltoVMName
    #$rollupIpSubscriptionName

    Write-Host "Adding Rollup IP Address: $rollupIpAddress ($i of $RollUpIpCount)" -ForegroundColor Green
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    
    #Adding Client IP
    New-AzSqlServerFirewallRule -ResourceGroupName $ResourceGroupName -ServerName $SQLServerName -FirewallRuleName "RollupIP-${i}: Loc:$rollupIpLocation RGName:$rollupIpResourceGroupName PA-VMName:$rollupIpPaloAltoVMName SubName:$rollupIpSubscriptionName" -StartIpAddress $rollupIpAddress -EndIpAddress $rollupIpAddress 
    #Remove-AzureRmSqlServerFirewallRule -ResourceGroupName $ResourceGroupName -ServerName $SQLServerName -FirewallRuleName "RollupIP-${i}: Loc:$rollupIpLocation RGName:$rollupIpResourceGroupName PA-VMName:$rollupIpPaloAltoVMName SubName:$rollupIpSubscriptionName"
    
    Write-Host ""
    Write-Host "Status: Added." -ForegroundColor Green
    $i++   
}

Write-Host ""
Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
Write-Host "Postprocessing: Rules on $SQLServerName"
$PostProcessingACL = Get-AzSqlServerFirewallRule -ResourceGroupName $ResourceGroupName -ServerName $SQLServerName 
$PostProcessingACL

Write-Host "Script Finished"
Write-Host ""
Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
Write-Host "Error/Info Log:"
$error
Stop-Transcript