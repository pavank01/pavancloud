﻿function global:New-EncryptionKey {

    Param(

        [Parameter(Mandatory=$true)]
        [ValidateSet(16,24,32)]
        [byte]$Length

    )

    # generate a byte array of the requested length
    $EncryptionKey = ( 1..$Length | % { [byte]( Get-Random -Minimum 0 -Maximum 255 ) } )

    Return $EncryptionKey

}

function global:ConvertTo-Base64String {

    Param(

        [Parameter(Mandatory=$true)]
        [byte[]]$Key

    )

    Return [Convert]::ToBase64String( $Key )

}

function global:ConvertFrom-Base64String {

    Param(

        [Parameter(Mandatory=$true)]
        [string]$String

    )

    Return [Convert]::FromBase64String( $String )

}

function global:Create-PSCredential {

    Param(

        [Parameter(Mandatory=$true)]
        [string]$UserName,

        [Parameter(Mandatory=$true)]
        [SecureString]$Password

    )

    $credential = New-Object -TypeName System.Management.Automation.PSCredential($UserName,$Password)

    Return $credential

}

function global:Read-EncryptedStringFromFile {

    Param(

        [Parameter(Mandatory=$true)]
        [string]$Path,

        [Parameter(Mandatory=$false)]
        [byte[]]$Key

    )

    if ($key) {
        $SecureString = Get-Content -Path $Path | ConvertTo-SecureString -Key $Key
    } Else {
        $SecureString = Get-Content -Path $Path | ConvertTo-SecureString
    }

    Return $SecureString
    
}

function global:Write-EncryptedStringToFile {

    Param(

        [Parameter(Mandatory=$true)]
        [SecureString]$SecureString,

        [Parameter(Mandatory=$true)]
        [string]$Path,

        [Parameter(Mandatory=$false)]
        [byte[]]$Key

    )

    if ($key) {
        $bytes = ConvertFrom-SecureString $SecureString -Key $Key
    } Else {
        $bytes = ConvertFrom-SecureString $SecureString
    }

    $bytes | Out-File $Path

}

function global:Read-PSCredentialFromFile {

    Param(

        [Parameter(Mandatory=$true)]
        [string]$Path,

        [Parameter(Mandatory=$false)]
        [byte[]]$Key

    )

    $json = (Get-Content -Path $Path) -join "`n" | ConvertFrom-Json
    $UserName = $json.UserName

    if ($key) {
        $Password = [string]$json.Password | ConvertTo-SecureString -Key $Key
    } Else {
        $Password = [string]$json.Password | ConvertTo-SecureString 
    }

    $credential = Create-PSCredential -UserName $UserName -Password $Password

    return $credential
    
}

function global:Write-PSCredentialToFile {

    Param(

        [Parameter(Mandatory=$true)]
        [PSCredential]$Credential,

        [Parameter(Mandatory=$true)]
        [string]$Path,

        [Parameter(Mandatory=$false)]
        [byte[]]$Key

    )

    $contents = @{}
    if ($key) {
        $bytes = ConvertFrom-SecureString $Credential.Password -Key $Key
    } Else {
        $bytes = ConvertFrom-SecureString $Credential.Password
    }

    $contents.Add("UserName",$Credential.UserName)
    $contents.Add("Password",$bytes)

    $contents | ConvertTo-Json | Out-File $Path
    
}

<#

    #--------------------------------------------------------------------------------
    # The sample code below can be used to test all of the functions provided
    #--------------------------------------------------------------------------------

    $userName = 'TestUserName'
    $insecurePassword = 'This is NOT safe!'
    $securePassword = $insecurePassword | ConvertTo-SecureString -AsPlainText -Force
    $newCredential = Create-PSCredential -UserName $userName -Password $securePassword

    Write-EncryptedStringToFile -SecureString $securePassword -Path '.\test.string'
    Write-PSCredentialToFile -Credential $newCredential -Path '.\test.credential'

    Remove-Variable @('insecurePassword','securePassword','newCredential')

    $securePassword = Read-EncryptedStringFromFile -Path '.\test.string'
    $newCredential  = Read-PSCredentialFromFile -Path '.\test.credential'

#>
