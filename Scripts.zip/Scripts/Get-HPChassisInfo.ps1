<#
	.SYNOPSIS
		Retrieve HP Chassis Info
	.DESCRIPTION
		Retrieve Server Chassis Info:
			1. Individual Server blade (x16), as well as its detailed info such as HBA HW address (for HP c7000)
			2. Individual InterConnect (x8) (for HP c7000)
			3. Enclosure level Power Consumption (unit: Watt DC) (for HP c7000)
		Requires plink.exe (https://en.wikipedia.org/wiki/PuTTY)
	.NOTES
		Author: Ka Lok Liu
		
	.PARAMETER ChassisBaseName
		Chassis base name, as per FAF naming convention.
		The default is "FAHQSNA09".
		
	.PARAMETER StartSerial
		[REQUIRED] The first Chassis serial identification.
		For example, 	7 	==> FAHQSNA09X07
						35  ==> FAHQSNA09X35
	
	.PARAMETER EndSerial
		The last Chasis serial identification.
		If not given, the script will export the info for a single chassis specified in StartSerial
	
	.PARAMETER ReportType
		Possible options are:
			1) "server" 		==> Server blade info
			2) "interconnect" 	==> InterConnect Info
			3) "power"			==> Power Consumption (Watt DC)
			4) "all"			==> All of the above
		The default is "all".
	
	.PARAMETER ConsolidateReport
		Whether to create a consolidated report with all the chassis.
		If set to $False, reports will be exported per chassis.
		The default is $True.
	
	
	.EXAMPLE
		(for HP c7000) This will export all server, interconnect, and power info on chassis FAHQSNA09X54.
		4 CSV reoprts will be created in the script's folder:
			1) HPChassisBladeInfo.csv			==> General server info for individual blade, such as iLO IP, Serial Number (x8 bays)
			2) HPChassisBladeInfo_Detail.csv	==> Detailed blade info, including all HBA/NIC HW address.
			3) HPChassisInterconnectInfo.csv	==> Interconnect info (x8 bays)
			4) HPChassisPowerSummary.csv		==> Power (Watt DC) consumption for blades, interconnects, and fans.
		
		PS> Get-HPChassisInfo 54

	.EXAMPLE
		(for HP c7000) This will export all server, interconnect, and power info on chassis from FAHQSNA09X06, 07.... FAHQSNA09X54.
		Note: huge reports for 50+ chassis.
		4 CSV reoprts will be created in the script's folder:
			1) HPChassisBladeInfo.csv			==> General server info for individual blade, such as iLO IP, Serial Number (x8 bays)
			2) HPChassisBladeInfo_Detail.csv	==> Detailed blade info, including all HBA/NIC HW address.
			3) HPChassisInterconnectInfo.csv	==> Interconnect info (x8 bays)
			4) HPChassisPowerSummary.csv		==> Power (Watt DC) consumption for blades, interconnects, and fans.
		
		PS> .\Get-HPChassisInfo.ps1 6 64		
	
	.EXAMPLE
		(for HP c7000) This will export the server blade info for chassis FAHQSNA09X06, FAHQSNA09X07... X12. 2 CSV reports will be saved
		to the script's folder:
			1) HPChassisBladeInfo.csv			
			2) HPChassisBladeInfo_Detail.csv	
		
		PS> Get-HPChassisInfo -ChassisBaseName "FAHQSNA09X" -StartSerial 6 -EndSerial 64 -ReportType "server"
		
		
		
#>

Param (
	[Parameter(Mandatory=$False)][String]$ChassisBaseName = "FAHQSNA09X",
	[Parameter(Mandatory=$True, Position=1)][Byte]$StartSerial,
	[Parameter(Mandatory=$False, Position=2)][Byte]$EndSerial,
	[Parameter(Mandatory=$False)][ValidateSet("all","server", "interconnect", "power")][String]$ReportType = "all",
	[Switch]$ConsolidateReport = $True
)

$ErrorActionPreference = "SilentlyContinue"
#modified 2015-12-11

Function Get-NextItems {		# Used by Get-VMHostBladeInfo2
	Param (
		$pLinkOutput,
		$FirstIndex,
		$NextItemType
	)
	
	If (!$fCalled_Get_NextItems) {
		If ($NextItemType -eq "CPU") {
			$endingLine = ""
		}
		Else {
			$endingLine = "*Management Processor Information:*"
		}
		
		$nextIndex = 0
		Do {
			$NextItems += $pLinkOutput[$FirstIndex + $nextIndex].Trim() + "`n"
			$nextIndex++
		}
		#Stop when reaching a blank line
			#Embedded Ethernet
			#    NIC 1: 00:21:5A:AF:96:74
			#    NIC 2: 00:21:5A:AF:96:18
			# <blank line>
			#Mezzanine 1: Emulex LPe1105-HP 4Gb FC HBA for HP c-Class BladeSystem
			#   Port 1: 10:00:00:00:c9:7b:26:82
			#   Port 2: 10:00:00:00:c9:7b:26:83
			# <blank line>
			#Mezzanine 2: NC325m Quad Port 1Gb NIC for c-Class BladeSystem
			#   Port 1: 00:1f:29:ce:8e:b4
			#   Port 2: 00:1f:29:ce:8e:b5
			#   Port 3: 00:1f:29:ce:8e:b6
			#   Port 4: 00:1f:29:ce:8e:b7
			# <blank line>
		#While ($pLinkOutput[$FirstIndex + $nextIndex] -ne "")
		While ($pLinkOutput[$FirstIndex + $nextIndex] -NotLike $endingLine)
		
		#If ($NextItemType -ne "CPU") {$NextItems.Trim() | % {write-host $_}}
		#write-host $NextItems.Count
		
		#$NextItems = $NextItems.Split("`n")
		#If ($NextItemType -ne "CPU") {$NextItems.Trim() | % {write-host $_}}
		
		Return $NextItems
	}
}

Function Format-AddonCardInfo {	# Used by Get-VMHostBladeInfo2
	Param ($AddonCardInfo)
	
	$AddonCardInfo = $AddonCardInfo.Split("`n")
	
	$allAddOnCardsHT = @{}
	$eachAddonCard = @()
	$zz = 0
	$AddonCardInfo | % {
		If ($_ -ne "") {
			$eachAddonCard += $_
		}
		Else {
			$allAddOnCardsHT.Add($zz, $eachAddonCard)
			$eachAddonCard = @()
			$zz++
		}
	}
	
	$FormattedAddonCardInfo = @()
	$mezzCount = 1
	
	$allAddOnCardsHT.GetEnumerator() | Sort Name | % {
		If ($_.Value.Count -ne 0) {
			$hwInfo = $_
			If (($hwInfo.Value[0] -Match "Embedded Ethernet") -OR ($hwInfo.Value[0] -Match "FlexFabric")) {
				$Type1 = "LOM"
				#This is mainly for blades with 2 LOMs (BL660c)
				#$hwInfo.Value[0] should give "FLB Adapter 1: HP FlexFabric 10Gb 2-port 554FLB Adapter"
				If ($hwInfo.Value[0] -Match "Adapter [0-9]:") {
					$Type1 = "LOM" + $matches[0].Replace("Adapter ", "").TrimEnd(":")
				}
			}
			ElseIf ($hwInfo.Value[0] -Match "Mezzanine [0-9]") {
				$Type1 = $matches[0].Replace("anine ", "")
				$Type2 = $hwInfo.Value[0].Split(":")[-1].Trim()
				#write-host $Type1
				#write-host $Type2
				#BL660c may have 3 mezz cards (max).
			}
			Else { 
				#For older OA firmware not showing Mezzanine in the output (Chassis 19)
				#Flex-10 Embedded Ethernet
				#  NIC 1 MAC Address: D8:D3:85:96:E1:AA
				#  NIC 2 MAC Address: D8:D3:85:96:E1:AE
				#iSCSI 1 MAC Address: D8:D3:85:96:E1:AB
				#iSCSI 2 MAC Address: D8:D3:85:96:E1:AF

				#Smart Array P700m
				# Port 1: 30:01:43:80:05:c6:c7:86
				# Port 2: 30:01:43:80:05:c6:c7:84

				#NC325m Quad Port 1Gb NIC for c-Class BladeSystem
				# Port 1: 78:e7:d1:58:72:9c
				# Port 2: 78:e7:d1:58:72:9d

				$Type1 = "Mezz" + $mezzCount
				$Type2 = $hwInfo.Value[0]
				$mezzCount++
			}
			
			
			$hwInfo.Value[1..$hwInfo.Value.Count] | % {
				$fInclude = $True
				$row = ""  | Select Type1, Type2, Port, HWAddr
				If ($Type1 -Like "LOM*") {
					If ($_ -Match "FlexFabric") { #This should never show up.
						#BL660c has two LOM adapters
						#This is for the second LOM adapter
						#$Type1 = "LOM2"
						#$fInclude = $False
					}
					Else {
						$TypeAndHWAddr = $_ -Split "  ([0-9A-Fa-f])"  #Double space "  "
						# Ethernet MAC Port 1-a:     E8:39:35:C4:3C:50
						# Ethernet (NIC 1) LOM1:1-a        D8:9D:67:75:85:88
						# $TypeAndHWAddr[0] = "Ethernet MAC Port 1-a:" OR "Ethernet (NIC 1) LOM1:1-a"
						# $TypeAndHWAddr[1] = "E" 
						# $TypeAndHWAddr[2] = "8:39:35:C4:3C:50"
						
						#works:
						#If ($TypeAndHWAddr[0] -Match "[0-9]-[A-Za-z]") {$Port = $matches[0]}
						#$Type2 = $TypeAndHWAddr[0] -Replace ".[0-9]-[A-Za-z].", ""
						#$HWAddr = $TypeAndHWAddr[-2] + $TypeAndHWAddr[-1]
						
						If ($TypeAndHWAddr[0] -Match "[0-9]-[A-Za-z]") {
							$Port = $matches[0]
							$Type2 = $TypeAndHWAddr[0] -Replace ".[0-9]-[A-Za-z].", ""
							$HWAddr = $TypeAndHWAddr[-2] + $TypeAndHWAddr[-1]	
						}
						Else {
							#For older blade with 2 port 1GB LOM (G5)
							#Embedded Ethernet
							#	NIC 1: 00:21:5A:AF:96:74
							#	NIC 2: 00:21:5A:AF:96:18
							$TypeAndHWAddr = $_ -Split ": "
							#$TypeAndHWAddr[0] = NIC 1
							#$TypeAndHWAddr[1] = 00:21:5A:AF:96:74
							$Port = ($TypeAndHWAddr[0] -Replace "[A-Za-z]").Trim()
							$Type2 = $TypeAndHWAddr[0]
							$HWAddr = $TypeAndHWAddr[1]
						}
					}
				}
				ElseIf ($Type1 -Like "Mezz*") {
				
					#Parsing --
					# Mezzanine 1: HP LPe1205A 8Gb FC HBA for BladeSystem c-Class
					# Port 1: 10:00:28:92:4a:af:a0:60
					# Port 2: 10:00:28:92:4a:af:a0:61
					# Mezzanine 2: HP Ethernet 1Gb 4-port 366M Adapter
					# Port 1: e4:11:5b:98:93:bc
					# Port 2: e4:11:5b:98:93:bd
					# Port 3: e4:11:5b:98:93:be
					# Port 4: e4:11:5b:98:93:bf
					
					If ($_ -match "(?<Name>[^:]+):(?<Value>.+)") {
						#If ($matches.Name -Like "*Mezzanine*") {
						#	$Type1 = $matches.Name.Replace("anine ", "").Trim()
						#	$Type2 = $matches.Value.Trim()
						#	$fInclude = $False
						#}
						#Else {
							$Port = $matches.Name.Replace("Port", "").Trim()
							$HWAddr = $matches.Value.Trim()
						#}
					}
				}
				
				#Done
				If ($fInclude) {
					$row.Type1 = $Type1
					$row.Type2 = $Type2
					$row.Port = $Port
					$row.HWAddr = $HWAddr
					$FormattedAddonCardInfo += $row
				}
			}
		}
	}
	Return $FormattedAddonCardInfo
}

Function Get-Info {				
	Param (
		[Parameter(Mandatory=$TRUE)] $thisKey,
		[Parameter(Mandatory=$False)] $thisFile
	)
	$b1 = $Null
	If ($thisFile) 	{$en = Get-Content $thisFile}
	Else 			{$en = "117.48.6.67.93.62.80.86"}	#for OA
	$en = $en.Split(".")
	$thisKey = [char[]]($thisKey)
	$ii = 0
	$en | % {[char[]]($thisKey[($ii++ % $thisKey.length)] -bXor [int]$_)} | % {$b1 += $_}
	$b1
}

Function Get-VMHostBladeInfo2 {				# Individual Server Bay Details
	Param (
		[String] $IpAddr,
		[String] $oaDNSname,
		[String] $user,
		[String] $passwd,
		[String] $OACmd,
		[String] $plink
	)

	$cmd = $plink + " -ssh -batch -l " + $user + " -pw " + $passwd + " " + $IpAddr + " " + $OACmd

	$skip = $true
	$DetailedBladeInfo = invoke-Expression $cmd
	
	$bladeHardwareInfo = @()
	$Report_Blade = @()
	$Report_BladeExpansion = @()		#Extra individual blade info, not returned to the caller yet 
	
	
	If ($LASTEXITCODE) {
		#If ($thisHost.BMCMAC -eq "Host Not Responding") {$row1.ServerName = "[Host Not Responding]"; $row1.iLO_MAC = $Null}
		##If ($thisHost.VMHost -eq $Null) {$row1.ServerName = "[VM host does not exist in the cluster]"}
		#ElseIf ($thisHost.BMCIP -eq $Null) {$row1.ServerName = "[iLO IP not available in 'Health Status']"}
		#ElseIf ($ConnResult[0] -like "*password*") {$row1.ServerName = "[Access Denied]"}
		#Else {$row1.ServerName = "[Error connecting]"}
		#$fConnError = $True
	}
	Else {
		$i = 0
		$DetailedBladeInfo | % {
			If ($_ -Like "Server Blade #*") {
				$skip = $false
				$fCalled_Get_NextItems = $false
				$bayNum = $_.Split("#")[1].Replace("Information:", "").Trim()
				$ProductName = $Null
				$PartNumber = $Null
				$MBSparePartNumber = $Null
				$SN = $Null
				$ServerName = $Null
				$ROMVer = $Null
				$Memory = $Null
				$iLOVer = $Null
				$iLOFWVer = $Null
				$iLOIPAddr = $Null
				$iLOMacAddr = $Null
				$CPU = $Null
				$LOM = $Null
				$Mezz = $Null
				$iLOName = $Null
			}
			
			ElseIf ($_ -Match "Power Management Controller Version") {

				#This reaches the last section of "show server info all" for each blade.

				$skip = $true
				#$Expansion = (Format-AddonCardInfo $LOM) + (Format-AddonCardInfo $Mezz)
				$Expansion = (Format-AddonCardInfo $LOM) 
				#Return

				#write-host $Expansion.Count
				$count = $Expansion.Count
				If ($consolidate) {
					$count = 1
					$Expansion | % {
						$AllExpansion = $_.Type1 + "`n" 
						$AllType = $_.Type2 + "`n"
						$AllPort = $_.Port + "`n"
						$AllHWAddr = $_.HWAddr + "`n"
					}
					$AllExpansion = $AllExpansion.TrimEnd("`n")
					$AllType = $AllType.TrimEnd("`n")
					$AllPort = $AllPort.TrimEnd("`n")
					$AllHWAddr = $AllHWAddr.TrimEnd("`n")
					
				}
				
				#Updating
				
				$row = "" | Select Chassis, Bay, ProductName, PartNumber, MBSparePartNumber, SN, ServerName, ROMVer, `
							Memory, iLOVer, iLOFWVer, iLOIPAddr, ILOMacAddr, iLOName, CPU
				$row.Chassis = $oaDNSname
				$row.Bay = $BayNum
				$row.ProductName = $ProductName
				$row.PartNumber = $PartNumber
				$row.MBSparePartNumber = $MBSparePartNumber
				$row.SN = $SN
				$row.ServerName = $ServerName
				$row.ROMVer = $ROMVer
				$row.Memory = $Memory
				$row.iLOVer = $iLOVer
				$row.iLOFWVer = $iLOFWVer
				$row.iLOIPAddr = $iLOIPAddr
				$row.ILOMacAddr = $iLOMacAddr
				$row.iLOName = $iLOName
				$row.CPU = ($CPU -Replace ("Memory: " + $Memory)).TrimEnd("`n")
				$Report_Blade += $row
				
				$j = 1
				Do {
					$row2 = "" | Select Chassis, ServerName, Bay, SN, Expansion, Type, Port, HWAddr
					$row2.Chassis = $oaDNSname
					$row2.ServerName = $ServerName
					$row2.SN = $SN
					$row2.Bay = $BayNum
					If ($consolidate) {
						$row2.Expansion = $AllExpansion
						$row2.Type = $AllType
						$row2.Port = $AllPort
					}
					Else {
						$row2.Expansion = $Expansion[$j - 1].Type1
						$row2.Type = $Expansion[$j - 1].Type2
						$row2.Port = $Expansion[$j - 1].Port
						$row2.HWAddr = $Expansion[$j - 1].HWAddr
						
					}
					$j++
					$Report_BladeExpansion += $row2
				} While ($j -le $count)
				

			}
			
			ElseIf ($_ -Like "*No Server Blade Installed*") {
				$skip = $true; $ProductName = "No Server Blade Installed"
				#write-host $bayNum $ProductName
				$row = "" | Select Chassis, Bay, ProductName, PartNumber, MBSparePartNumber, SN, ServerName, ROMVer, `
								Memory, iLOVer, iLOFWVer, iLOIPAddr, ILOMacAddr, iLOName, CPU #, Expansion, Type, Port, HWAddr
				$row.Chassis = $oaDNSname
				$row.Bay = $bayNum 
				$row.ProductName = $ProductName	
				$Report_Blade += $row
			}
			
			ElseIf ($_ -Like "*Bay Subsumed*") {
				$skip = $true; $ProductName = "Bay Subsumed"
				#write-host $bayNum $ProductName
				$row = "" | Select Chassis, Bay, ProductName, PartNumber, MBSparePartNumber, SN, ServerName, ROMVer, `
								Memory, iLOVer, iLOFWVer, iLOIPAddr, ILOMacAddr, iLOName, CPU #, Expansion, Type, Port, HWAddr
				$row.Chassis = $oaDNSname
				$row.Bay = $bayNum 
				$row.ProductName = $ProductName	
				$Report_Blade += $row
			}
			
			Else {
				If ($_ -Match "Product Name") 		{$ProductName = $_.Split(":")[1].Trim()}
				If ($_ -Match "Part Number") 		{$PartNumber = $_.Split(":")[1].Trim()}
				If ($_ -Match "System Board Spare") {$MBSparePartNumber = $_.Split(":")[1].Trim()}
				If ($_ -Match "Serial Number\:")	{$SN = $_.Split(":")[1].Trim()}
				If ($_ -Match "Server Name") 		{$ServerName = $_.Split(":")[1].Trim()}
				If ($_ -Match "ROM Version") 		{$ROMVer = $_.Split(":")[1].Trim()}
				If ($_ -Match "Memory") 			{$Memory = $_.Split(":")[1].Trim()}
				If ($_ -Like "*iLO?") 				{$iLOVer = $_.Split(":")[1].Trim()}
				If ($_ -Match "Firmware Version") 	{$iLOFWVer = $_.Split(":")[1].Trim()}
				If ($_ -Match "IP Address") 		{$iLOIPAddr = $_.Split(":")[1].Trim()}
				If ($_ -Match "MAC Address") 		{$iLOMacAddr = $_.Replace("MAC Address:", "").Trim()}
				If ($_ -Match "CPU 1") 				{$CPU = Get-NextItems -pLinkOutput $DetailedBladeInfo -FirstIndex $i -NextItemType "CPU"}
				If (($_ -Match "Embedded Ethernet") `
					-OR ($_ -Match "FlexFabric"))	{$LOM += Get-NextItems -pLinkOutput $DetailedBladeInfo -FirstIndex $i; $fCalled_Get_NextItems = $True} #BL660c may have 2 LOMs.
				#If ($_ -Match "Mezzanine") 			{$Mezz += Get-NextItems -pLinkOutput $DetailedBladeInfo -FirstIndex $i}
				If (($DetailedBladeInfo[$i - 2] -Match "Management Processor") `
					-AND ($_ -Match "Name"))		{$iLOName = $_.Split(":")[1].Trim()}
			}
			$i++
		}
		#write-host $Report_Blade.count
		#write-host $Report_BladeExpansion.count
		#Return $Report_Blade
		Return @($Report_Blade, $Report_BladeExpansion) #Extra individual blade info, not returned to the caller yet 
	}
}

Function Get-VMHostChassisInterConnect {	# Individual InterConnect Details
	Param (
		[String] $IpAddr,
		[String] $oaDNSname,
		[String] $user,
		[String] $passwd,
		[String] $OACmd,
		[String] $plink
	)

	$cmd = $plink + " -ssh -batch -l " + $user + " -pw " + $passwd + " " + $IpAddr + " " + $OACmd

	$EndofSection = $False
	$skip = $true
	$InterconnectInfo = invoke-Expression $cmd
	$InterConnectResults = @()
	
	If ($LASTEXITCODE) {
		#If ($thisHost.BMCMAC -eq "Host Not Responding") {$row1.ServerName = "[Host Not Responding]"; $row1.iLO_MAC = $Null}
		##If ($thisHost.VMHost -eq $Null) {$row1.ServerName = "[VM host does not exist in the cluster]"}
		#ElseIf ($thisHost.BMCIP -eq $Null) {$row1.ServerName = "[iLO IP not available in 'Health Status']"}
		#ElseIf ($ConnResult[0] -like "*password*") {$row1.ServerName = "[Access Denied]"}
		#Else {$row1.ServerName = "[Error connecting]"}
		#$fConnError = $True
	}
	Else {
		$i = 0
		$InterconnectInfo | % {
			If ($_ -Match "^[1-8]. ") { #eg. "1. Ethernet" / "3. Fibre Channel"....
				
				$bayNum = $_.Split(".")[0]
				
				If ($_ -Match "^[1-8]. \<absent\>") {
					$Product_Name = "No InterConnect Installed"
					$row = "" | Select Chassis, Bay, ProductName, Width, PartNumber, SparePartNumber, SN, InBandIPv4Addr, UserAssignedName, URLMgmt, Manufacturer
					$row.Chassis = $oaDNSname
					$row.Bay = $bayNum 
					$row.ProductName = $Product_Name	
					$InterConnectResults += $row
				}
				ElseIf ($_ -Like "*Bay Subsumed*") { #Not used in InterConnect... assuming all of them with width of "Single".
					$skip = $true; $Product_Name = "Bay Subsumed"
					$row = "" | Select Chassis, Bay, ProductName, Width, PartNumber, SparePartNumber, SN, InBandIPv4Addr, UserAssignedName, URLMgmt, Manufacturer
					$row.Chassis = $oaDNSname
					$row.Bay = $bayNum 
					$row.ProductName = $Product_Name	
					$InterConnectResults += $row
				}
				Else {
					$Product_Name = $Null
					$Manufacturer = $Null
					$Width = $Null
					$PartNumber = $Null
					$SparePartNumber = $Null
					$SN = $Null
					$InBandIPv4Addr = $Null
					$UserAssignedName = $Null
					$URLMgmt = $Null
				}
			}
			
			ElseIf ($EndofSection) { #There is a blank line between each section of Interconnect
				#Updating
				
				$row = "" | Select Chassis, Bay, ProductName, Width, PartNumber, SparePartNumber, SN, InBandIPv4Addr, UserAssignedName, URLMgmt, Manufacturer
				$row.Chassis = $oaDNSname
				$row.Bay = $BayNum
				$row.ProductName = $Product_Name
				$row.Width = $Width
				$row.PartNumber = $PartNumber
				$row.SparePartNumber = $SparePartNumber
				$row.SN = $SN
				$row.InBandIPv4Addr = $InBandIPv4Addr
				$row.UserAssignedName = $UserAssignedName
				$row.URLMgmt = $URLMgmt
				$row.Manufacturer = $Manufacturer

				$InterConnectResults += $row
				
				$EndofSection = $False
			}
			
			

			
			Else {
				If ($_ -Match "Product Name") 				{$Product_Name = $_.Split(":")[1].Trim()}
				If ($_ -Match "Width") 						{$Width = $_.Split(":")[1].Trim()}
				If ($_ -Match "In-Band IPv4 Address") 		{$InBandIPv4Addr = $_.Split(":")[1].Trim()}
				If ($_ -Match "Part Number") 				{$PartNumber = $_.Split(":")[1].Trim()}
				If ($_ -Match "Spare Part Number")  		{$SparePartNumber = $_.Split(":")[1].Trim()}
				If ($_ -Match "Serial Number") 				{$SN = $_.Split(":")[1].Trim()}
				If ($_ -Match "User Assigned Name") 		{$UserAssignedName = $_.Split(":")[1].Trim()}
				If ($_ -Match "URL to Management interface") {$URLMgmt = ($_ -Split(": "))[1].Trim()}
				If ($_ -Match "Manufacturer") 				{$Manufacturer = $_.Split(":")[1].Trim(); $EndofSection = $True}
			}
			$i++
		}
		#write-host $InterConnectResults.count
		Return $InterConnectResults
	}
}

Function Get-EnclosurePowerSummary {		# Enclosure Power Usage Summary -- Added 2015-11-19
	Param (
		[String] $IpAddr,
		[String] $oaDNSname,
		[String] $user,
		[String] $passwd,
		[String] $OACmd,
		[String] $plink
	)

	$cmd = $plink + " -ssh -batch -l " + $user + " -pw " + $passwd + " " + $IpAddr + " " + $OACmd
	
	$EndofSection = $False
	$skip = $true
	$EnclosurePowerSummary = invoke-Expression $cmd
	$EnclosurePowerSummaryResult = @()
	
	#Must be in the order of the "show" command output
	$SectionEnding = "[\s]+\=[\s]+[\d]+"												#"             =   250"
	$SectionEndingForFanPowerSummary = "^[\s]+[\d]+[\s]+[\d]+[\s]+[\d]+[\s]+[\d]+"		#"  10  10   258   500"
	$SectionToParse = @( "Device Bay Power Summary", `
						"Interconnect Bay Power Summary", `
						"Fan Power Summary")

	$serverBay = @()
	$interconnectBay = @()
	$fanSlot = @()
	$thisMoment = Get-Date
	
	$server_interconnectHeaders = "Chassis", "Date", "hwType", "Name", "Bay", "Power_Allocated"
	$fanReportHeaders = @("Chassis", "Date")
	
	If ($LASTEXITCODE) {
		#If ($thisHost.BMCMAC -eq "Host Not Responding") {$row1.ServerName = "[Host Not Responding]"; $row1.iLO_MAC = $Null}
		##If ($thisHost.VMHost -eq $Null) {$row1.ServerName = "[VM host does not exist in the cluster]"}
		#ElseIf ($thisHost.BMCIP -eq $Null) {$row1.ServerName = "[iLO IP not available in 'Health Status']"}
		#ElseIf ($ConnResult[0] -like "*password*") {$row1.ServerName = "[Access Denied]"}
		#Else {$row1.ServerName = "[Error connecting]"}
		#$fConnError = $True
	}
	Else {
		$EnclosurePowerSummary | % {
			If ($_ -Match $SectionToParse[0]) 		{$fInfoType = "server"	}		# "Device Bay Power Summary"
			ElseIf ($_ -Match $SectionToParse[1]) 	{$fInfoType = "interconnect"}	# "Interconnect Bay Power Summary"
			ElseIf ($_ -Match $SectionToParse[2]) 	{$fInfoType = "fan"}			# "Fan Power Summary"
			ElseIf (($fInfoType -eq "fan") -AND ($_ -Match "^Total Fans")) {		# Getting the headers for Fan section
				#"Total Fans        Fan Rule          Present Power   Power Allocated"
				$_ -Replace("\s\s", "_") -Replace("_", ",") -Split(",") | % {
					If ($_) {
						$fanReportHeaders += $_.Trim().Replace(" ", "_")
					}
				}
			}
			ElseIf ($_ -Match "^[\s]+[\d]+") {										# output: 1  snappesxvmwr057.cor         315
				$thisRow = $_.Trim() -Split("[\s]+")
				Switch ($fInfoType) {
					"server" {
						$row = "" | Select $server_interconnectHeaders #"Chassis", "Date", "hwType", "Name", "Bay", "Power_Allocated"
						$row.$($server_interconnectHeaders[0]) = $oaDNSname
						$row.$($server_interconnectHeaders[1]) = $thisMoment 
						$row.$($server_interconnectHeaders[2]) = $fInfoType
						$row.$($server_interconnectHeaders[3]) = $thisRow[1].Split(".")[0]
						$row.$($server_interconnectHeaders[4]) = $thisRow[0]
						$row.$($server_interconnectHeaders[5]) = $thisRow[-1]
						$serverBay += $row
					}
					
					"interconnect" 	{
						$row = "" | Select $server_interconnectHeaders
						$row.$($server_interconnectHeaders[0]) = $oaDNSname
						$row.$($server_interconnectHeaders[1]) = $thisMoment 
						$row.$($server_interconnectHeaders[2]) = $fInfoType
						$row.$($server_interconnectHeaders[3]) = $thisRow[1..($thisRow.Count - 2)] -Join " "
						$row.$($server_interconnectHeaders[4]) = $thisRow[0]
						$row.$($server_interconnectHeaders[5]) = $thisRow[-1]
						$interconnectBay += $row
					}
					
					"fan" {
						If ($thisRow.Count -eq ($fanReportHeaders.Count - 2)) {
							$fanSlot += [PSCustomObject] [Ordered] @{
								hwType = $fInfoType
								$($fanReportHeaders[0]) = $oaDNSname
								$($fanReportHeaders[1]) = $thisMoment 
								$($fanReportHeaders[2]) = $thisRow[0]
								$($fanReportHeaders[3]) = $thisRow[1]
								$($fanReportHeaders[4]) = $thisRow[2]
								$($fanReportHeaders[5]) = $thisRow[3]
							}
						}
					}
				}
			}
		}
		#Convert $fanslot
		#$row = "" | Select $server_interconnectHeaders #"Chassis", "Date", "hwType", "Name", "Bay", "Power_Allocated"
		$fanSlotConverted += [PSCustomObject] [Ordered] @{
			$($server_interconnectHeaders[0]) = $oaDNSname
			$($server_interconnectHeaders[1]) = $thisMoment 
			$($server_interconnectHeaders[2]) = $fanSlot[0].hwType
			$($server_interconnectHeaders[3]) = $fanReportHeaders[2] + ": " + $fanSlot[0].$($fanReportHeaders[2] + "/" + `
														$fanReportHeaders[3] + ": " + $fanSlot[0].$($fanReportHeaders[3]))
			$($server_interconnectHeaders[4]) = "N/A"
			$($server_interconnectHeaders[5]) = $fanSlot[0].$($fanReportHeaders[4])
		}
		$EnclosurePowerSummaryResult = @($serverBay + $interconnectBay + $fanSlotConverted)
		Return $EnclosurePowerSummaryResult
	}
}

Function Get-EnclosureOAIP {				
	Param (
		[Parameter(Mandatory=$TRUE)] [string] $enclName,
		[Parameter(Mandatory=$TRUE)] [String] $user,
		[Parameter(Mandatory=$TRUE)] [String] $passwd,
		[Parameter(Mandatory=$TRUE)] [String] $plink
	)
	#write-host "Get-EnclosureOAIP called"
	
	$cmd = $plink + " -ssh -batch -l " + $user + " -pw " + $passwd + " " + $enclName + " show OA Network Active  2>&1"
	
	$ConnResult = invoke-Expression $cmd
	If ($LASTEXITCODE) {
		If ($ConnResult[0] -Match "Access denied") {$Output = "[Access Denied]"}
		ElseIf ($ConnResult.Count -eq 2) {
			If ($ConnResult[1] -Match "Host does not exist") {
				$Output = "[Host does not exist]"
			} #No DNS entry for the Chassis, eg FAHQDAL01X06
		}
		Else {$Output = "[Error connecting]"}
	}
	Else {
		$ConnResult | % {
			If ($_ -Like "*IPv4 Address*") {
				$Output = $_.Trim().Split(" ")[2]
			}
			ElseIf ($_ -Like "*IP Address*"){ #Returned in FAHQSNA09X19 -- OA with older firmware
				$Output = $_.Trim().Split(" ")[2]
			}
		}
	}
	$Output
}

Function Test-PLinkConnectivity {			
	#Prepare plink
	Param (
		[Parameter(Mandatory=$TRUE)] [string] $ServerAddr,
		[Parameter(Mandatory=$TRUE)] [String] $plink,
		[Parameter(Mandatory=$TRUE)] [String] $user,
		[Parameter(Mandatory=$TRUE)] [String] $passwd,
		[Switch] $plinkInteractiveMode = $False
	)

	#"SHOW" -- A generic command that is applicable to OA or iLO SMASH commands
	If (!$plinkInteractiveMode) {
		$cmd = $plink + " -ssh -batch -l " + $user + " -pw " + $passwd + " " + $ServerAddr + " SHOW 2>&1"
	}
	Else {
		$cmd = "echo yes | " + $plink + " -ssh -l " + $user + " -pw " + $passwd + " " + $ServerAddr + " SHOW 2>&1"
	}
		
	#write-host $cmd
	
	$ConnResult = invoke-Expression $cmd
	#Write-host $LASTEXITCODE
	If ($LASTEXITCODE) {
		If ($ConnResult[0] -Match "Access denied") {
			$Output = "[Access Denied]"
		}
		ElseIf ($ConnResult.Count -eq 2) {
			If ($ConnResult[1].ToString() -Match "Host does not exist") { #No DNS entry for the Chassis, eg FAHQDAL01X06
				$Output = "Host does not exist, check DNS..."
			} 

		}
		Else {$Output = "[Error connecting]"}
	}
	Else {
		#Somehow $LASTEXITCODE is 0 even an error is actually raised.
		#For the first time plink is connected to the target host, key is not stored locally in the registry.
		If ($ConnResult[-1].ToString() -Match "Connection abandoned") {
				#Try using interactive mode, and this will add the public key locally on the running PC.
				#This way later plink.exe call can be run with -batch switch.
				$Output = Test-PLinkConnectivity -ServerAddr $ServerAddr -plink $plink -user $user -passwd $passwd -plinkInteractiveMode:$True
		}
		Else {
			$Output = 0
		}
	}
	#Write-Host $Output
	Return $Output
}


######################################################
## Main
######################################################
#formerly Get-ChassisBladeInfo-3.ps1

$chassisType = "HP"
If (!$EndSerial) {$EndSerial = $StartSerial}

$HPChassis = @()
($StartSerial..$EndSerial) | % {
	$HPChassis += $ChassisBaseName + ($_.ToString("D2"))
}

#OA Commands
$OACommandServerInfo = "show server info all"
$OACommandInterConnectInfo = "show interconnect info all"
$OACommandEnclosurePowerSummary = "show enclosure power_summary"

#plink.exe
$plinkEXE = "C:\windows\system32\plink.exe"
If (!(Test-Path $plinkEXE)) {
	$plinkEXE = ".\plink.exe"
	If (!(Test-Path $plinkEXE)) {Write-Warning "Please make sure plink.exe exists"; Return}
}

#Credential
$user0 = "Administrator"
$passwd1 = Get-Info "Getting OA info"

#Report
$reportPath = ".\"
Switch ($ReportType) {
	"all" 			{$getWhat = "S.I.P"}
	"power" 		{$getWhat = "x.x.P"}
	"server" 		{$getWhat = "S.x.x"}
	"interconnect" 	{$getWhat = "x.I.x"}
}

ForEach ($OAName In $HPChassis) {
	Write-Host "$OAName [", (Get-Date -f "hh:mm:ss"), "]"
	$plinkStatus = Test-PLinkConnectivity -ServerAddr $OAName -plink $plinkEXE -user $user0 -passwd $passwd1

	If ($plinkStatus -eq 0) {
		#This is to obtain the active OA IP -- DNS returns the primary OA only,
		#if this OA is offline, it will not answer "show server info all".
		$OAIPAddr = Get-EnclosureOAIP -enclName $OAName -user $user0 -passwd $passwd1 -plink $plinkEXE
		
		#Test network connectivity to OA using IP address
		$plinkStatus2 = Test-PLinkConnectivity -ServerAddr $OAIPAddr -plink $plinkEXE -user $user0 -passwd $passwd1
		
		#Regex for IPv4 address http://answers.oreilly.com/topic/318-how-to-match-ipv4-addresses-with-regular-expressions/
		If (($OAIPAddr -Match "^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$") -And ($plinkStatus2 -eq 0)) {
			$getWhat.Split(".") | % {
				#Server Report
				If ($_ -eq "S") {
					$rptDate = Get-Date -f "yyyy-MM-dd"
					$tmpServerRpt = Get-VMHostBladeInfo2 -IpAddr $OAIPAddr -oaDNSname $OAName  -user $user0 -passwd $passwd1 -OACmd $OACommandServerInfo -plink $plinkEXE
					$serverReportAll += $tmpServerRpt[0] 		#$Report_Blade
					$serverReportDetailAll += $tmpServerRpt[1]	#$Report_BladeExpansion
					If ($ConsolidateReport) {
						$serverReportAll | Export-CSV ("$reportPath$rptDate`_HPChassisBladeInfo.csv") -NoTypeInfo
						$serverReportDetailAll | Export-CSV ("$reportPath$rptDate`_HPChassisBladeInfo`_Detail.csv") -NoTypeInfo
					}
					Else {
						$serverReportAll | Group Chassis | % {$_.Group | Export-CSV ("$reportPath$rptDate`_HPChassisBladeInfo`_$OAName.csv") -NoTypeInfo}
						$serverReportDetailAll | Group Chassis | % {$_.Group | Export-CSV ("$reportPath$rptDate`_HPChassisBladeInfo`_Detail`_$OAName.csv") -NoTypeInfo}
					}
				}
				#InterConnect Report
				If ($_ -eq "I") {
					$rptDate = Get-Date -f "yyyy-MM-dd"
					$interConnectAll += Get-VMHostChassisInterConnect -IpAddr $OAIPAddr -oaDNSname $OAName  -user $user0 -passwd $passwd1 -OACmd $OACommandInterConnectInfo -plink $plinkEXE
					If ($ConsolidateReport) {
						$interConnectAll  | Export-CSV ("$reportPath$rptDate`_HPChassisInterconnectInfo.csv") -NoTypeInfo
					}
					Else {
						$interConnectAll | Group Chassis | % {$_.Group | Export-CSV ("$reportPath$rptDate`_HPChassisInterconnectInfo`_$OAName.csv") -NoTypeInfo}
					}
				
				}
				#Power Report 
				If ($_ -eq "P") {
					$rptDate = Get-Date -f "yyyy-MM-dd_HHmm"
					$powerReport +=  Get-EnclosurePowerSummary -IpAddr $OAIPAddr -oaDNSname $OAName  -user $user0 -passwd $passwd1 -OACmd $OACommandEnclosurePowerSummary -plink $plinkEXE
					$powerReport | Export-CSV ("$reportPath$rptDate`_HPChassisPowerSummary.csv") -NoTypeInfo
				}
			}
		}
	}
	Else {
		Write-Warning "Error connecting to $OAName -- $plinkStatus"
		#If ($ConsolidateReport) {
		#	$row = "" | Select Chassis, Bay, ProductName
		#	$row.Chassis = $OAName
		#	$row.ProductName = $plinkStatus
		#	$singleReport += $row
		#}
	}
}
Write-Host "Complete [", (Get-Date -f "hh:mm:ss"), "]"


