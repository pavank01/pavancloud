﻿$mailFrom = 'mblackman@firstam.com'
$mailTo = @("mblackman@firstam.com","tpham@firstam.com","mmikhael@firstam.com","MAllison@firstam.com","CPowell@firstam.com","ssingleton@datatree.com","TiMatthews@datatree.com","chrubio@firstam.com","MDexter@firstam.com","SHalim@firstam.com","APham@firstam.com")
#$mailTo = @("mblackman@firstam.com")

$Month = (Get-Date).ToString("yyyy-MM")
$FileName = "./AzureBill-$Month.csv" 
$subject = "Azure Month To Date bill for $Month"

$report = .\Download-FAAzureBillingData.ps1 -Month $Month -FileName $FileName -Report
$body = $report | Where-Object { $_.ApplicationCode -eq 'EOCR' } | Select-Object -Property ApplicationCode,CostType,@{Name='Cost';Expression={[math]::Round($_.Cost,2)}} | ConvertTo-HTML | Out-String
Send-MailMessage -Attachments $FileName -Body $body -BodyAsHtml -From $mailFrom -To $mailTo -Subject $subject -SmtpServer mail.firstam.com
