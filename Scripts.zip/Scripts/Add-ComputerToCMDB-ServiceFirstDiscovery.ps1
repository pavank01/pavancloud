<#
.SYNOPSIS
Add computer to ServiceFirst Discovery.
    
.DESCRIPTION
This script will add a computer or computers to the CMDB (ServiceFirst Discovery).

.PARAMETER ComputerName
The name or names of the computers to add to ServiceFirst (CMDB) Discovery.

.INPUTS
None

.OUTPUTS
None

.NOTES
Version:    1.2
Author:     Chris Throop
Date:       2/12/2019

.EXAMPLE
.\Add-ComputerToCMDB-ServiceFirstDiscovery.ps1 -ComputerName AZUVNAPPFAKE001

.EXAMPLE
.\Add-ComputerToCMDB-ServiceFirstDiscovery.ps1 -ComputerName AZUVNAPPFAKE001,AZUVNAPPFAKE002
#>

#---------------------------------------------------------[Script Parameters]------------------------------------------------------

[CmdletBinding()]
Param (

    [Parameter(ValueFromPipeline,ValueFromPipelineByPropertyName)]
    [Alias("VM","Server")]
    [string[]]$ComputerName

)

#----------------------------------------------------------[Declarations]----------------------------------------------------------

$i = 1
$j = 1
$k = 1
$url = "https://firstam.service-now.com/helpthehelpdesk.jsdbx"
$ScriptInput = ($MyInvocation.MyCommand.Name).Split(".")[0]+"-Input.txt"

#-----------------------------------------------------------[Execution]------------------------------------------------------------

if ($ComputerName) {
    $ComputerName = ($ComputerName | Sort-Object -Unique).ToUpper()
} Else {
    if (!(Test-Path -Path $ScriptInput)) {New-Item -Path $ScriptInput -Value "Server1" > $null}
    Start-Process Notepad $ScriptInput -Wait
    try {
        $ComputerName = (Get-Content $ScriptInput -ErrorAction Stop | Sort-Object -Unique).ToUpper()
    } catch {
        Write-Host Input Error: Is the input file empty?"  " -ForegroundColor Yellow
        Write-Host Check $ScriptInput -ForegroundColor Red
        Exit
    }
}

foreach ($Hostname in $ComputerName) {
    Write-Progress -Id 1 -Activity "Downloading Help The Help Desk script ..." -Status "$i of $($ComputerName.Count) ($Hostname)" -PercentComplete (($i / $ComputerName.Count) * 100) ; $i++
    Write-Host $Hostname": "Downloading the Help The Help Desk script ...
    if(!(Test-Path \\$Hostname\c$\Software)) {mkdir \\$Hostname\c$\Software > $null}
    $output = "\\$Hostname\c$\Software\helpthehelpdesk.js"
    try {
        Write-Verbose "Enable TLS for the Invoke-WebRequest"
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls -bor [Net.SecurityProtocolType]::Tls11 -bor [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $url -OutFile $output -ErrorAction Stop
    } catch {
        if(!(Test-Path $Output)) {
            Copy-Item \\corp.firstam.com\NETLOGON\TIMW\tools\helpthehelpdesk.js -Destination \\$Hostname\c$\Software
        }
    }
}

Write-Progress -Id 2 -Activity "Adding Computers to ServiceFirst CMDB ..." -Status "$($ComputerName)" ; $j++
Invoke-Command -ComputerName $ComputerName -ScriptBlock {
    Write-Host $env:computername": "Adding Computer to ServiceFirst CMDB ...
    cscript //b //nologo C:\Software\helpthehelpdesk.js
}

Write-Progress -Id 3 -Activity "Removing the Help the Help Desk script ..." -Status "$($ComputerName)" ; $k++
Invoke-Command -ComputerName $ComputerName -ScriptBlock {
    Write-Host $env:computername": "Removing the Help the Help Desk script ...
    Remove-Item C:\Software\helpthehelpdesk.js
}