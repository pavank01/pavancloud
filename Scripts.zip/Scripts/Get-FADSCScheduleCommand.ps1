<#
.SYNOPSIS
Generate the schtasks.exe command needed to manually schedule a DSC configuration.

.DESCRIPTION
This script generates the schtasks.exe command needed to manually schedule a DSC configuration.

The resulting command is displayed on the screen and copied to the clipboard.

.PARAMETER serviceName
The name of the cloud service to create the virtual machine in.

.PARAMETER computerNameName
The name of the virtual machine.

.PARAMETER scriptLocation
The drive the Software folder is located on.

.INPUTS
None.

.OUTPUTS
Create-FAAzureStandardVM.ps1 generates a string that is automatically copied to the clipboard.

.EXAMPLE
C:\PS> .\


#>
Param (

    [Parameter(Mandatory=$true)]
    [string]$serviceName,

    [Parameter(Mandatory=$true)]
    [string]$computerName,

    [Parameter(Mandatory=$true)]
    [ValidateSet('C:','D:')]
    [string]$scriptLocation
)

Process {

    $scriptName     = "$computerName.ps1"
    $dscFullTarget  = "$scriptLocation\Software\$serviceName\$scriptName"
    $logFile        = "\\azuvnutlazur001.corp.firstam.com\Logs\$serviceName\$computerName.log"

    $scriptArguments = "-dscUserName retry -dscPassword retry -Logfile $logFile"

    $taskParameters = @('/Create', 
                        '/SC ONSTART', 
                        '/TN "\Microsoft\Windows\Desired State Configuration\FAConfiguration"', 
                        '/RU System', 
                        '/F', 
                        '/RL HIGHEST',
                        '/DELAY 0005:00',
                        "/TR ""PowerShell.exe -ExecutionPolicy Unrestricted -File $dscFullTarget $scriptArguments"" " )

    $command = "schtasks.exe $( $taskParameters -join `" `" )"

    Write-Host "The command to execute is:`n"

    Write-Host "$command" -ForegroundColor Green

    $command | Clip

    Write-Host "`nIt has been copied to your clipboard."

}
