﻿$MailFrom = 'FAHQ-DL-SOMCloudTeam@firstam.com'
$MailTo = @("mblackman@firstam.com","tpham@firstam.com","mmikhael@firstam.com","MAllison@firstam.com","CPowell@firstam.com","ssingleton@datatree.com","TiMatthews@datatree.com","chrubio@firstam.com","MDexter@firstam.com","SHalim@firstam.com","yfarooqi@firstam.com","PNarsina@firstam.com")
#$MailTo = @("mblackman@firstam.com")
$SMTPServer = "mail.firstam.com"

$Date = (Get-Date).ToString("yyyy-MM-dd")
$FullFilePath = "E:\Scripts\Billing\AzureBill-$Date-MTDFull.csv"
$ParseFilePath = "E:\Scripts\Billing\AzureBill-$Date-MTDParse.csv" 
$Subject = "DBS Azure Month To Date bill for $Date"

$FileCheck = Test-Path -Path $ParseFilePath

if ($FileCheck -eq "True") {

    $Report = Import-Csv -Path $ParseFilePath

    $Body = $Report | Where-Object { ($_.ApplicationCode -eq 'EOCR') -or ($_.ApplicationCode -eq 'MSQL') -or ($_.ApplicationCode -eq 'DTCM') } |
        Select-Object -Property ApplicationCode,CostType,@{Name='Cost';Expression={[math]::Round($_.Cost,2)}} |
        ConvertTo-HTML |
        Out-String

    Send-MailMessage -Attachments $FullFilePath -Body $Body -BodyAsHtml -From $MailFrom -To $MailTo -Subject $Subject -SmtpServer $SMTPServer

} else {

    Send-MailMessage -From $MailFrom -To $MailFrom -Subject "DBS MTD Azure bill email error!" -Body "The DBS MTD Azure bill did not get created properly. Look at the scheduled task FAAzure-MailMTDDBSBill on AZUVPUTLAZUR001. We may need to generate a new API access key. Check out the Azure OneNote page on Billing Processes." -SmtpServer $SMTPServer

}