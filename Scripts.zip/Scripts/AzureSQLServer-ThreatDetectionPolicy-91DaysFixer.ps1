###################
## by Joe O'Brien
## 25MAR2022
###################

Function promptYesNo {
    while("yes","no" -notcontains $answer)
    {
        $answer = Read-Host "Would you like to continue? (Yes/No)"
    }
        If ($answer -eq "no") {
            Write-Host "Exiting..." -ForeGroundColor Red
        exit
    }
}      
    
#Input section from user.
Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
Write-Host " VIT FIX: Azure SQL Server threat logs retention is less than 91 days" -ForegroundColor Green
Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
Write-Host "Please enter the following Azure information:"
$sqlInput = Read-Host -Prompt "Azure SQL Servername"
$sqlnameInput = $sqlInput.Trim()
$SQLServerName = $sqlnameInput.ToUpper()
$SubscriptionNameInput = Read-Host -Prompt "Azure Subscription Name"
$SubscriptionName = $SubscriptionNameInput.Trim()
$ResourceGroupNameInput = Read-Host -Prompt "Azure Resource Group Name"
$ResourceGroupName = $ResourceGroupNameInput.Trim()
Write-Host "Done..." -ForegroundColor Green
Write-Host ""
Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

#Setting the correct Subscription as active via Set-AzContext
Write-Host "Logging into the Subscription: $SubscriptionName..." -ForegroundColor Green
Write-Host ""
Set-AzContext -SubscriptionName $SubscriptionName  -ErrorAction Stop
Write-Host "Done..." -ForegroundColor Green
Write-Host ""
Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

#Gets the Threat Dtection Settings and stores as var
Write-Host "GETTING Threat Detection Settings and storing variables for: $SQLServerName..." -ForegroundColor Green
Write-Host ""
$getStoredVariables = Get-AzSqlServerAdvancedThreatProtectionSetting -ResourceGroupName "$ResourceGroupName" -ServerName "$SQLServerName"
Get-AzSqlServerAdvancedThreatProtectionSetting -ResourceGroupName "$ResourceGroupName" -ServerName "$SQLServerName"
$stored_ResourceGroupName = $getStoredVariables.ResourceGroupName
$stored_ServerName = $getStoredVariables.ServerName
$stored_RetentionInDays = $getStoredVariables.RetentionInDays
Write-Host "Done..." -ForegroundColor Green
Write-Host ""
Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

#Value to set retention days to
$modified_RetentionInDays = "91"

#Prompt to say yes or no to begin change
Write-Host "Review the output above and select YES to change RentionInDays from $stored_RetentionInDays to $modified_RetentionInDays..." -ForegroundColor Green
promptYesNo

#execution of the change:
Update-AzSqlServerAdvancedThreatProtectionSetting -RetentionInDays "$modified_RetentionInDays" -ServerName "$stored_ServerName" -ResourceGroupName "$stored_ResourceGroupName"
Write-Host "Done..." -ForegroundColor Green
Write-Host ""

#Does another GET to display the changes
Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green       
Write-Host "Displaying Changed Threat Detection Settings on: $SQLServerName..." -ForegroundColor Green
Write-Host ""
Get-AzSqlServerAdvancedThreatProtectionSetting -ResourceGroupName "$ResourceGroupName" -ServerName "$SQLServerName"