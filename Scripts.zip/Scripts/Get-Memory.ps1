[CmdletBinding()]
param (

    [switch]$Run

)

function Get-Memory {
    [CmdletBinding()]
    param 
    (
        [switch]$Detailed,
        [switch]$Format
    )

$signature = @'
/*
* Item: Windows PSAPI GetPerformanceInfo C# Wrapper
* Source: http://www.antoniob.com/windows-psapi-getperformanceinfo-csharp-wrapper.html 
* Author: Antonio Bakula
*/
using System;
using System.Runtime.InteropServices;

public struct PerfomanceInfoData
{
    public Int64 CommitTotalPages;
    public Int64 CommitLimitPages;
    public Int64 CommitPeakPages;
    public Int64 PhysicalTotalBytes;
    public Int64 PhysicalAvailableBytes;
    public Int64 SystemCacheBytes;
    public Int64 KernelTotalBytes;
    public Int64 KernelPagedBytes;
    public Int64 KernelNonPagedBytes;
    public Int64 PageSizeBytes;
    public int HandlesCount;
    public int ProcessCount;
    public int ThreadCount;
}

public static class PsApiWrapper
{
    [DllImport("psapi.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool 
    GetPerformanceInfo([Out] out PsApiPerformanceInformation PerformanceInformation, 
    [In] int Size);

    [StructLayout(LayoutKind.Sequential)]
    public struct PsApiPerformanceInformation
    {
        public int Size;
        public IntPtr CommitTotal;
        public IntPtr CommitLimit;
        public IntPtr CommitPeak;
        public IntPtr PhysicalTotal;
        public IntPtr PhysicalAvailable;
        public IntPtr SystemCache;
        public IntPtr KernelTotal;
        public IntPtr KernelPaged;
        public IntPtr KernelNonPaged;
        public IntPtr PageSize;
        public int HandlesCount;
        public int ProcessCount;
        public int ThreadCount;
    }

    public static PerfomanceInfoData GetPerformanceInfo()
    {
        PerfomanceInfoData data = new PerfomanceInfoData();
        PsApiPerformanceInformation perfInfo = new PsApiPerformanceInformation();
        if (GetPerformanceInfo(out perfInfo, Marshal.SizeOf(perfInfo)))
        {
            Int64 pageSize = perfInfo.PageSize.ToInt64();
            
            // data in bytes
            data.CommitTotalPages = perfInfo.CommitTotal.ToInt64() * pageSize;
            data.CommitLimitPages = perfInfo.CommitLimit.ToInt64() * pageSize;
            data.CommitPeakPages = perfInfo.CommitPeak.ToInt64() * pageSize;
            data.PhysicalTotalBytes = perfInfo.PhysicalTotal.ToInt64() * pageSize;
            data.PhysicalAvailableBytes = perfInfo.PhysicalAvailable.ToInt64() * pageSize;
            data.KernelPagedBytes = perfInfo.KernelPaged.ToInt64() * pageSize;
            data.KernelNonPagedBytes = perfInfo.KernelNonPaged.ToInt64() * pageSize;
        }
        return data;
    }
}
'@
	
	function Get-Uptime {
		$wmiOS = Get-WmiObject -Class Win32_OperatingSystem
		return (Get-Date) - $wmiOS.ConvertToDateTime($wmiOS.LastBootUpTime)
	}
	
    function Format-HumanReadable {
        param ($size)
        switch ($size) {
            {$_ -ge 1PB}{"{0:#.#'P'}" -f ($size / 1PB); break}
            {$_ -ge 1TB}{"{0:#.#'T'}" -f ($size / 1TB); break}
            {$_ -ge 1GB}{"{0:#.#'G'}" -f ($size / 1GB); break}
            {$_ -ge 1MB}{"{0:#.#'M'}" -f ($size / 1MB); break}
            {$_ -ge 1KB}{"{0:#'K'}" -f ($size / 1KB); break}
            default {"{0}" -f ($size) + "B"}
        }
    }
    
    # Create PerformanceInfoData object
    Add-Type -TypeDefinition $signature
    [PerfomanceInfoData]$w32perf = [PsApiWrapper]::GetPerformanceInfo()

    if ($Detailed) {
        try {
            # Create Win32_PerfRawData_PerfOS_Memory object
            $query = 'SELECT * FROM Win32_PerfRawData_PerfOS_Memory'
            $wmimem = Get-WmiObject -Query $query -ErrorAction Stop
            
            # Create "detailed" PS memory object 
            # Value in bytes for memory attributes
            $memd = New-Object -TypeName PSObject -Property @{
                TotalPhysicalMem = $w32perf.PhysicalTotalBytes
                AvailPhysicalMem = $w32perf.PhysicalAvailableBytes
                CacheWorkingSet = [long]$wmimem.CacheBytes
                KernelWorkingSet = [long]$wmimem.SystemCodeResidentBytes
                DriverWorkingSet = [long]$wmimem.SystemDriverResidentBytes
                CommitCurrent = $w32perf.CommitTotalPages
                CommitLimit = $w32perf.CommitLimitPages
                CommitPeak = $w32perf.CommitPeakPages
                PagedWorkingSet = [long]$wmimem.PoolPagedResidentBytes
                PagedVirtual = $w32perf.KernelPagedBytes
                Nonpaged = $w32perf.KernelNonPagedBytes
				Computer = $env:COMPUTERNAME
				Uptime = Get-Uptime
            }
        } catch {
            $msg = ("Error: {0}" -f $_.Exception.Message)
            Write-Warning $msg
        }
        
        if ($Format) {
            # Format output in human-readable form
            # End of PS pipeline/format right rule option
            Write-Output '-------------'
            Write-Output 'Commit Charge'
            Write-Output '-------------'
            "Current    : $(Format-HumanReadable $memd.CommitCurrent)"
            "Limit`t   : $(Format-HumanReadable $memd.CommitLimit)"
            "Peak`t   : $(Format-HumanReadable $memd.CommitPeak)"
            "Peak/Limit : $("{0:P2}" `
            -f ($memd.CommitPeak / $memd.CommitLimit))"
            "Curr/Limit : $("{0:P2}" `
            -f ($memd.CommitCurrent / $memd.CommitLimit))"
            [Environment]::NewLine
            
            Write-Output '---------------'
            Write-Output 'Physical Memory'
            Write-Output '---------------'
            "Total`t  : $(Format-HumanReadable $memd.TotalPhysicalMem)"
            "Available : $(Format-HumanReadable $memd.AvailPhysicalMem)"
            "CacheWS`t  : $(Format-HumanReadable $memd.CacheWorkingSet)"
            "KernelWS  : $(Format-HumanReadable $memd.KernelWorkingSet)"
            "DriverWS  : $(Format-HumanReadable $memd.DriverWorkingSet)"
            [Environment]::NewLine
            
            Write-Output '-------------'
            Write-Output 'Kernel Memory'
            Write-Output '-------------'
            "PagedWS   : $(Format-HumanReadable $memd.PagedWorkingSet)"
            "PagedVirt : $(Format-HumanReadable $memd.PagedVirtual)"
            "Nonpaged  : $(Format-HumanReadable $memd.Nonpaged)"
            [Environment]::NewLine
        } else {
            $memd.PSObject.TypeNames.Insert(0,'BinaryNature.MemoryDetailed')
            Write-Output $memd
        }
    } else {
        # Create custom "core" memory object 
        # Value in bytes for memory attributes
        $memb = New-Object -TypeName PSObject -Property @{
            TotalPhysicalMem=$w32perf.PhysicalTotalBytes
            AvailPhysicalMem=$w32perf.PhysicalAvailableBytes
            Computer=$env:COMPUTERNAME
        }
        
        if ($Format) {
            $memb | Select-Object @{n="Name";e={$_.Computer}},
                        @{n="Total";e={Format-HumanReadable $_.TotalPhysicalMem}}, 
                        @{n="InUse";e={Format-HumanReadable ($_.TotalPhysicalMem - $_.AvailPhysicalMem)}},
                        @{n="Avail";e={Format-HumanReadable $_.AvailPhysicalMem}},
                        @{n="Use%";e={[int]((($_.TotalPhysicalMem - $_.AvailPhysicalMem) / $_.TotalPhysicalMem) * 100)}}
        } else {
            $memb.PSObject.TypeNames.Insert(0,'BinaryNature.Memory')
            Write-Output $memb
        }
    }
}

if ($run) { Get-Memory -Detailed }