[CmdletBinding()]
Param (
	# ComputerName: Computer name or array of computer names
	[Parameter()]
	[String[]]$ComputerName = $Null,

	# Path: File with computer name or names
	[Parameter()]
	[String]$Path = $Null
)
# ---------------------------------------------------------------------------
Function Format-FileNameWithDate {
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $False)]
		[String]$Prefix,
		[Parameter(Mandatory = $False)]
		[String]$Suffix = ".txt",
		[Parameter(Mandatory = $False)]
		[String]$DateFormat = "yyyy-MM-dd"
	)
	$TextDate = Get-Date -Format $DateFormat
	Return $Prefix + $TextDate + $Suffix
}# ---------------------------------------------------------------------------
Function Test-Null($String) {
	If ($String -eq $Null -or $String -eq "") {
		$True
	} Else {
		$False
	}
}
# ---------------------------------------------------------------------------

$ResultsCSV = Format-FileNameWithDate -Prefix ".\CISHardeningValidate_" -Suffix ".csv" -DateFormat "yyyyMMdd-HHmmss"
$Results = @()
$HasFailed = $False


# The user did not provide a list of computers to process - Assume Local Server
If ([String]::IsNullOrEmpty($ComputerName) -eq $True -and [String]::IsNullOrEmpty($Path) -eq $True) {
	$ComputerName = (Get-ChildItem Env:ComputerName).Value
}

# The user provided a list of computers to process
If ([String]::IsNullOrEmpty($Path) -eq $False -and $HasFailed -eq $False) {
	# The user provided the list of computers to process in a text file
	If ((Test-Path -Path $Path) -eq $True) {
		# File exists so import the computer list
		Write-Host "Importing computer names from $Path"
		$ComputerName = @(Get-Content -Path $Path | ForEach {$_ -Replace('^*[\.](.*)$', '').ToUpper()} | Sort-Object | Select-Object -Unique)
	} Else {
		# Specified file does not exist - Exit Script
		Write-Host "File not found: $Path" -ForegroundColor Yellow -BackgroundColor DarkRed
		$HasFailed = $True
	}
} ElseIf ($ComputerName -ne '' -and $HasFailed -eq $False)  {
	# The user provided the list of computers to process on the command line
	$ComputerName = @($ComputerName | ForEach {$_ -Replace ('^*[\.](.*)$', '').ToUpper()} | Sort-Object | Select-Object -Unique)
}

If ($HasFailed -eq $True) {
	Break
} Else {
	If ($ComputerName -ne (Get-ChildItem Env:ComputerName).Value) {
		# Any server that is not the local server
		$DomainNames = @("fastts.firstam.net", "corp.firstam.com", "datatrace.local", "datatree.local", "intl.crop.firstam.com", "itxprod.ad")

		$ServersResponding = @()
		$ServersNotResponding = @()
		ForEach ($Server In $ComputerName) {
			$IsOnline = $False
			ForEach ($DomainName In $DomainNames) {
				$TempServerName = ("{0}.{1}" -f $Server, $DomainName)
				If (Test-Connection $TempServerName -Quiet -Count 1) {
					Write-Host "$TempServerName is Online" -ForegroundColor Green
					$ServersResponding += $TempServerName
					$IsOnline = $True
					Break
				}
			}
			If ($IsOnline -eq $False) {
				Write-Host "$Server is OFFLINE" -ForegroundColor Red
				$ServersNotResponding += $Server
			}
		}
		If ($ServersResponding.Count -eq 0) {
			Write-Host "No servers are responding" -ForegroundColor Yellow -BackgroundColor DarkRed
			Break
		}
		Write-Host ("Processing {0} Servers" -f $ServersResponding.Count)
		$Results += Invoke-Command -ComputerName $ServersResponding -ErrorAction SilentlyContinue -ScriptBlock {
			$CISRegistryPaths = @(
				'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon|AllocateDASD',
				'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon|ForceUnlockLogon',
				'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon|PasswordExpiryWarning',
				'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon|ScRemoveOption',
				'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon|AutoAdminLogon',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\CredUI|EnumerateAdministrators',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|ConsentPromptBehaviorAdmin',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|ConsentPromptBehaviorUser',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|DisableAutomaticRestartSignOn',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|DisableCAD',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|DontDisplayLastUserName',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|EnableInstallerDetection',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|EnableLUA',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|EnableSecureUIAPaths',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|EnableUIADesktopToggle',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|EnableVirtualization',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|FilterAdministratorToken',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|InactivityTimeoutSecs',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|LegalNoticeCaption',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|LegalNoticeText',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|MSAOptional',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|NoConnectedUser',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|PromptOnSecureDesktop',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|ShutdownWithoutLogon',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\Audit|ProcessCreationIncludeCmdLine_Enabled',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\Kerberos\Parameters|SupportedEncryptionTypes',
				'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|LocalAccountTokenFilterPolicy',
				'HKLM:\Software\Policies\Microsoft\Internet Explorer\Feeds|DisableEnclosureDownload',
				'HKLM:\Software\Policies\Microsoft\Windows NT\Rpc|EnableAuthEpResolution',
				'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services|DeleteTempDirsOnExit',
				'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services|fEncryptRPCTraffic',
				'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services|PerSessionTempDir',
				'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services|DisablePasswordSaving',
				'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services|fAllowToGetHelp',
				'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services|fAllowUnsolicited',
				'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services|fDisableCdm',
				'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services|fPromptForPassword',
				'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services|MinEncryptionLevel',
				'HKLM:\Software\Policies\Microsoft\Windows\CredUI|DisablePasswordReveal',
				'HKLM:\Software\Policies\Microsoft\Windows\EventLog\Application|MaxSize',
				'HKLM:\Software\Policies\Microsoft\Windows\EventLog\Application|Retention',
				'HKLM:\Software\Policies\Microsoft\Windows\EventLog\Security|MaxSize',
				'HKLM:\Software\Policies\Microsoft\Windows\EventLog\Security|Retention',
				'HKLM:\Software\Policies\Microsoft\Windows\EventLog\Setup|MaxSize',
				'HKLM:\Software\Policies\Microsoft\Windows\EventLog\Setup|Retention',
				'HKLM:\Software\Policies\Microsoft\Windows\EventLog\System|MaxSize',
				'HKLM:\Software\Policies\Microsoft\Windows\EventLog\System|Retention',
				'HKLM:\Software\Policies\Microsoft\Windows\Installer|EnableUserControl',
				'HKLM:\Software\Policies\Microsoft\Windows\Installer|AlwaysInstallElevated',
				'HKLM:\Software\Policies\Microsoft\Windows\Network Connections|NC_AllowNetBridge_NLA',
				'HKLM:\Software\Policies\Microsoft\Windows\Network Connections|NC_StdDomainUserSetLocation',
				'HKLM:\Software\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging|EnableScriptBlockLogging',
				'HKLM:\Software\Policies\Microsoft\Windows\PowerShell\Transcription|EnableTranscripting',
				'HKLM:\Software\Policies\Microsoft\Windows\System|DisableLockScreenAppNotifications',
				'HKLM:\Software\Policies\Microsoft\Windows\System|AllowDomainPINLogon',
				'HKLM:\Software\Policies\Microsoft\Windows\System|DontDisplayNetworkSelectionUI',
				'HKLM:\Software\Policies\Microsoft\Windows\System|DontEnumerateConnectedUsers',
				'HKLM:\Software\Policies\Microsoft\Windows\System|EnableSmartScreen',
				'HKLM:\Software\Policies\Microsoft\Windows\System|EnumerateLocalUsers',
				'HKLM:\Software\Policies\Microsoft\Windows\Windows Search|AllowIndexingEncryptedStoresOrItems',
				'HKLM:\Software\Policies\Microsoft\Windows\WinRM\Client|AllowDigest',
				'HKLM:\Software\Policies\Microsoft\Windows\WinRM\Client|AllowUnencryptedTraffic',
				'HKLM:\Software\Policies\Microsoft\Windows\WinRM\Service|AllowBasic',
				'HKLM:\Software\Policies\Microsoft\Windows\WinRM\Service|DisableRunAs',
				'HKLM:\Software\Policies\Microsoft\WindowsStore|AutoDownload',
				'HKLM:\Software\Policies\Microsoft\WindowsStore|DisableOSUpgrade',
				'HKLM:\System\CurrentControlSet\Control\Lsa|CrashOnAuditFail',
				'HKLM:\System\CurrentControlSet\Control\Lsa|EveryoneIncludesAnonymous',
				'HKLM:\System\CurrentControlSet\Control\Lsa|ForceGuest',
				'HKLM:\System\CurrentControlSet\Control\Lsa|LimitBlankPasswordUse',
				'HKLM:\System\CurrentControlSet\Control\Lsa|LmCompatibilityLevel',
				'HKLM:\System\CurrentControlSet\Control\Lsa|NoLMHash',
				'HKLM:\System\CurrentControlSet\Control\Lsa|RestrictAnonymous',
				'HKLM:\System\CurrentControlSet\Control\Lsa|RestrictAnonymousSAM',
				'HKLM:\System\CurrentControlSet\Control\Lsa|SceNoApplyLegacyAuditPolicy',
				'HKLM:\System\CurrentControlSet\Control\Lsa|UseMachineId',
				'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0|AllowNullSessionFallback',
				'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0|NTLMMinClientSec',
				'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0|NTLMMinServerSec',
				'HKLM:\System\CurrentControlSet\Control\Lsa\pku2u|AllowOnlineID',
				'HKLM:\System\CurrentControlSet\Control\SecurePipeServers\Winreg\AllowedExactPaths|Machine',
				'HKLM:\System\CurrentControlSet\Control\SecurePipeServers\Winreg\AllowedPaths|Machine',
				'HKLM:\System\CurrentControlSet\Control\SecurityProviders\WDigest|UseLogonCredential',
				'HKLM:\System\CurrentControlSet\Control\Session Manager|ProtectionMode',
				'HKLM:\System\CurrentControlSet\Control\Session Manager\Kernel|ObCaseInsensitive',
				'HKLM:\System\CurrentControlSet\Control\Session Manager|SafeDllSearchMode',
				'HKLM:\System\CurrentControlSet\Policies\EarlyLaunch|DriverLoadPolicy',
				'HKLM:\System\CurrentControlSet\Services\Eventlog\Security|WarningLevel',
				'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters|AutoDisconnect',
				'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters|EnableForcedLogOff',
				'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters|EnableSecuritySignature',
				'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters|NullSessionPipes',
				'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters|NullSessionShares',
				'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters|RequireSecuritySignature',
				'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters|RestrictNullSessAccess',
				'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters|SMBServerNameHardeningLevel',
				'HKLM:\System\CurrentControlSet\Services\LanmanWorkstation\Parameters|EnablePlainTextPassword',
				'HKLM:\System\CurrentControlSet\Services\LanmanWorkstation\Parameters|EnableSecuritySignature',
				'HKLM:\System\CurrentControlSet\Services\LanmanWorkstation\Parameters|RequireSecuritySignature',
				'HKLM:\System\CurrentControlSet\Services\LDAP|LDAPClientIntegrity',
				'HKLM:\System\CurrentControlSet\Services\NetBT\Parameters|NoNameReleaseOnDemand',
				'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters|DisablePasswordChange',
				'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters|RequireSignOrSeal',
				'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters|RequireStrongKey',
				'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters|SealSecureChannel',
				'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters|SignSecureChannel',
				'HKLM:\System\CurrentControlSet\Services\Tcpip\Parameters|EnableICMPRedirect',
				'HKLM:\System\CurrentControlSet\Services\Tcpip\Parameters|DisableIPSourceRouting',
				'HKLM:\System\CurrentControlSet\Services\Tcpip6\Parameters|DisableIPSourceRouting'
			)
			$FailedCIS = $False
			ForEach ($CISRegistryPath In $CISRegistryPaths) {
				$RegKey = $Null
				$RegKey = $CISRegistryPath.Split('|')
				$CISResult = $Null
				$CISResult = Get-ItemProperty -Path $RegKey[0] -Name $RegKey[1] -ErrorAction SilentlyContinue

				If ($CISResult -eq $Null) {
					$CISResult = "NULL"
					$FailedCIS = $True
				} Else {
					$CISResult = $CISResult.($RegKey[1].ToString())
				}
			}
			If ($FailedCIS -eq $True) {
				$False
			} Else {
				$True
			}
		} | Select-Object @{N="ComputerName";E={$_.PSComputerName}}, @{N="CISHardened";E={$_}} | Sort-Object ComputerName

		If ($Results.Count -gt 0) {
			# We have results so find missing servers
			$MissingServers = Compare-Object -ReferenceObject (($Results | Select-Object @{L="ComputerName";E={$_.ComputerName -Replace('^*[\.](.*)$', '')}} -Unique | Sort ComputerName).ComputerName) -DifferenceObject $ComputerName -PassThru
		} Else {
			# No results returned
			$MissingServers = $ComputerName
		}
		ForEach ($MissingServer In $MissingServers) {
			$Results += "" | Select-Object @{N="ComputerName";E={$MissingServer}}, @{N="CISHardened";E={"UNKNOWN"}}
		}
	} Else {
		# Local Server
		$CISRegistryPaths = @(
			'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon|AllocateDASD',
			'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon|ForceUnlockLogon',
			'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon|PasswordExpiryWarning',
			'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon|ScRemoveOption',
			'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\Winlogon|AutoAdminLogon',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\CredUI|EnumerateAdministrators',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|ConsentPromptBehaviorAdmin',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|ConsentPromptBehaviorUser',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|DisableAutomaticRestartSignOn',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|DisableCAD',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|DontDisplayLastUserName',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|EnableInstallerDetection',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|EnableLUA',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|EnableSecureUIAPaths',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|EnableUIADesktopToggle',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|EnableVirtualization',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|FilterAdministratorToken',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|InactivityTimeoutSecs',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|LegalNoticeCaption',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|LegalNoticeText',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|MSAOptional',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|NoConnectedUser',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|PromptOnSecureDesktop',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|ShutdownWithoutLogon',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\Audit|ProcessCreationIncludeCmdLine_Enabled',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System\Kerberos\Parameters|SupportedEncryptionTypes',
			'HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System|LocalAccountTokenFilterPolicy',
			'HKLM:\Software\Policies\Microsoft\Internet Explorer\Feeds|DisableEnclosureDownload',
			'HKLM:\Software\Policies\Microsoft\Windows NT\Rpc|EnableAuthEpResolution',
			'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services|DeleteTempDirsOnExit',
			'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services|fEncryptRPCTraffic',
			'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services|PerSessionTempDir',
			'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services|DisablePasswordSaving',
			'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services|fAllowToGetHelp',
			'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services|fAllowUnsolicited',
			'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services|fDisableCdm',
			'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services|fPromptForPassword',
			'HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services|MinEncryptionLevel',
			'HKLM:\Software\Policies\Microsoft\Windows\CredUI|DisablePasswordReveal',
			'HKLM:\Software\Policies\Microsoft\Windows\EventLog\Application|MaxSize',
			'HKLM:\Software\Policies\Microsoft\Windows\EventLog\Application|Retention',
			'HKLM:\Software\Policies\Microsoft\Windows\EventLog\Security|MaxSize',
			'HKLM:\Software\Policies\Microsoft\Windows\EventLog\Security|Retention',
			'HKLM:\Software\Policies\Microsoft\Windows\EventLog\Setup|MaxSize',
			'HKLM:\Software\Policies\Microsoft\Windows\EventLog\Setup|Retention',
			'HKLM:\Software\Policies\Microsoft\Windows\EventLog\System|MaxSize',
			'HKLM:\Software\Policies\Microsoft\Windows\EventLog\System|Retention',
			'HKLM:\Software\Policies\Microsoft\Windows\Installer|EnableUserControl',
			'HKLM:\Software\Policies\Microsoft\Windows\Installer|AlwaysInstallElevated',
			'HKLM:\Software\Policies\Microsoft\Windows\Network Connections|NC_AllowNetBridge_NLA',
			'HKLM:\Software\Policies\Microsoft\Windows\Network Connections|NC_StdDomainUserSetLocation',
			'HKLM:\Software\Policies\Microsoft\Windows\PowerShell\ScriptBlockLogging|EnableScriptBlockLogging',
			'HKLM:\Software\Policies\Microsoft\Windows\PowerShell\Transcription|EnableTranscripting',
			'HKLM:\Software\Policies\Microsoft\Windows\System|DisableLockScreenAppNotifications',
			'HKLM:\Software\Policies\Microsoft\Windows\System|AllowDomainPINLogon',
			'HKLM:\Software\Policies\Microsoft\Windows\System|DontDisplayNetworkSelectionUI',
			'HKLM:\Software\Policies\Microsoft\Windows\System|DontEnumerateConnectedUsers',
			'HKLM:\Software\Policies\Microsoft\Windows\System|EnableSmartScreen',
			'HKLM:\Software\Policies\Microsoft\Windows\System|EnumerateLocalUsers',
			'HKLM:\Software\Policies\Microsoft\Windows\Windows Search|AllowIndexingEncryptedStoresOrItems',
			'HKLM:\Software\Policies\Microsoft\Windows\WinRM\Client|AllowDigest',
			'HKLM:\Software\Policies\Microsoft\Windows\WinRM\Client|AllowUnencryptedTraffic',
			'HKLM:\Software\Policies\Microsoft\Windows\WinRM\Service|AllowBasic',
			'HKLM:\Software\Policies\Microsoft\Windows\WinRM\Service|DisableRunAs',
			'HKLM:\Software\Policies\Microsoft\WindowsStore|AutoDownload',
			'HKLM:\Software\Policies\Microsoft\WindowsStore|DisableOSUpgrade',
			'HKLM:\System\CurrentControlSet\Control\Lsa|CrashOnAuditFail',
			'HKLM:\System\CurrentControlSet\Control\Lsa|EveryoneIncludesAnonymous',
			'HKLM:\System\CurrentControlSet\Control\Lsa|ForceGuest',
			'HKLM:\System\CurrentControlSet\Control\Lsa|LimitBlankPasswordUse',
			'HKLM:\System\CurrentControlSet\Control\Lsa|LmCompatibilityLevel',
			'HKLM:\System\CurrentControlSet\Control\Lsa|NoLMHash',
			'HKLM:\System\CurrentControlSet\Control\Lsa|RestrictAnonymous',
			'HKLM:\System\CurrentControlSet\Control\Lsa|RestrictAnonymousSAM',
			'HKLM:\System\CurrentControlSet\Control\Lsa|SceNoApplyLegacyAuditPolicy',
			'HKLM:\System\CurrentControlSet\Control\Lsa|UseMachineId',
			'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0|AllowNullSessionFallback',
			'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0|NTLMMinClientSec',
			'HKLM:\System\CurrentControlSet\Control\Lsa\MSV1_0|NTLMMinServerSec',
			'HKLM:\System\CurrentControlSet\Control\Lsa\pku2u|AllowOnlineID',
			'HKLM:\System\CurrentControlSet\Control\SecurePipeServers\Winreg\AllowedExactPaths|Machine',
			'HKLM:\System\CurrentControlSet\Control\SecurePipeServers\Winreg\AllowedPaths|Machine',
			'HKLM:\System\CurrentControlSet\Control\SecurityProviders\WDigest|UseLogonCredential',
			'HKLM:\System\CurrentControlSet\Control\Session Manager|ProtectionMode',
			'HKLM:\System\CurrentControlSet\Control\Session Manager\Kernel|ObCaseInsensitive',
			'HKLM:\System\CurrentControlSet\Control\Session Manager|SafeDllSearchMode',
			'HKLM:\System\CurrentControlSet\Policies\EarlyLaunch|DriverLoadPolicy',
			'HKLM:\System\CurrentControlSet\Services\Eventlog\Security|WarningLevel',
			'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters|AutoDisconnect',
			'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters|EnableForcedLogOff',
			'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters|EnableSecuritySignature',
			'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters|NullSessionPipes',
			'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters|NullSessionShares',
			'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters|RequireSecuritySignature',
			'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters|RestrictNullSessAccess',
			'HKLM:\System\CurrentControlSet\Services\LanManServer\Parameters|SMBServerNameHardeningLevel',
			'HKLM:\System\CurrentControlSet\Services\LanmanWorkstation\Parameters|EnablePlainTextPassword',
			'HKLM:\System\CurrentControlSet\Services\LanmanWorkstation\Parameters|EnableSecuritySignature',
			'HKLM:\System\CurrentControlSet\Services\LanmanWorkstation\Parameters|RequireSecuritySignature',
			'HKLM:\System\CurrentControlSet\Services\LDAP|LDAPClientIntegrity',
			'HKLM:\System\CurrentControlSet\Services\NetBT\Parameters|NoNameReleaseOnDemand',
			'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters|DisablePasswordChange',
			'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters|RequireSignOrSeal',
			'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters|RequireStrongKey',
			'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters|SealSecureChannel',
			'HKLM:\System\CurrentControlSet\Services\Netlogon\Parameters|SignSecureChannel',
			'HKLM:\System\CurrentControlSet\Services\Tcpip\Parameters|EnableICMPRedirect',
			'HKLM:\System\CurrentControlSet\Services\Tcpip\Parameters|DisableIPSourceRouting',
			'HKLM:\System\CurrentControlSet\Services\Tcpip6\Parameters|DisableIPSourceRouting'
		)
		$FailedCIS = $False
		ForEach ($CISRegistryPath In $CISRegistryPaths) {
			$RegKey = $Null
			$RegKey = $CISRegistryPath.Split('|')
			$CISResult = $Null
			$CISResult = Get-ItemProperty -Path $RegKey[0] -Name $RegKey[1] -ErrorAction SilentlyContinue

			If ($CISResult -eq $Null) {
				$CISResult = "NULL"
				$FailedCIS = $True
			} Else {
				$CISResult = $CISResult.($RegKey[1].ToString())
			}
		}
		If ($FailedCIS -eq $True) {
			$Results += "" | Select-Object @{N="ComputerName";E={$ComputerName}}, @{N="CISHardened";E={"False"}}
		} Else {
			$Results += "" | Select-Object @{N="ComputerName";E={$ComputerName}}, @{N="CISHardened";E={"True"}}
		}
	}
	# Output Results
	$Results | Sort-Object ComputerName | Format-Table -Auto
	$Results | Sort-Object ComputerName | Export-CSV $ResultsCSV -NoTypeInformation
}