<#
	.SYNOPSIS
		Will export all Event Logs for a specific time frame into a single CSV in chronological order.

	.DESCRIPTION
		Will export all Event Logs for a specific time frame into a single CSV in chronological order.

	.PARAMETER StartTime
		Date / Time for first log record.
		* Can use either 12 hour or 24 hour date time formats.

	.PARAMETER EndTime
		Date / Time for last log record.
		* Can use either 12 hour or 24 hour date time formats.

	.PARAMETER IncludeSecurity
		Includes the Security Event Log
		* Normally excluded as it takes a significant amount of time to gather and usually does not provide helpful data

	.OUTPUTS
		CSV File

	.NOTES
		Written by Ryan Amsbury
		v0.5
#>
[CmdletBinding()]
Param (
	# Date / Time for first log record
	[Parameter(Mandatory=$True)]
	[String]$StartTime,

	# Date / Time for last log record
	[Parameter(Mandatory=$True)]
	[String]$EndTime,

	# Include the Security Event Log
	[Parameter(Mandatory=$False)]
	[String]$IncludeSecurity
)
# ---------------------------------------------------------------------------
Function Format-FileNameWithDate {
	# Function to create a file name with the date
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $False)]
		[String]$Prefix,
		[Parameter(Mandatory = $False)]
		[String]$Suffix = ".txt",
		[Parameter(Mandatory = $False)]
		[String]$DateFormat = "yyyy-MM-dd"
	)
	$TextDate = Get-Date -Format $DateFormat
	Return $Prefix + $TextDate + $Suffix
}
# ---------------------------------------------------------------------------
$StartTime = [DateTime](Get-Date -Date $StartTime)
$EndTime = [DateTime](Get-Date -Date $EndTime)

New-Item -ItemType Directory -Path "C:\Temp" -Force | Out-Null
$LogFile = Join-Path -Path "C:\Temp" -ChildPath $(Format-FileNameWithDate -Prefix "GetAllEventLogs_" -Suffix ".csv" -DateFormat "yyyy-MM-dd_HH.mm")
Remove-Item -Path $LogFile -Force -ErrorAction SilentlyContinue | Out-Null

Write-Host
Write-Host "Gathering Event Log Names ... " -NoNewLine -ForegroundColor White
If ($IncludeSecurity -eq $True) {
	# Include Security Event Log
	$EventLogNames = Get-WinEvent -ListLog * | Sort-Object LogName | Select-Object LogName
} Else {
	# Exclude Security Event Log
	$EventLogNames = Get-WinEvent -ListLog * | Sort-Object LogName | Select-Object LogName | Where-Object {$_.LogName -ne "Security"}
}
Write-Host $EventLogNames.Count"Found" -ForegroundColor Green
Write-Host "Collecting Events between $StartTime and $EndTime"
Write-Host
$Results = @()
ForEach ($EventLogName In $EventLogNames) {
	Write-Host $EventLogName.LogName"... " -NoNewLine -ForegroundColor Cyan
	$TempResults = @()
	$TempResults = Get-WinEvent -FilterHashTable @{LogName=$EventLogName.LogName; StartTime=$StartTime; EndTime=$EndTime} -ErrorAction SilentlyContinue | Select-Object @{N="ComputerName";E={(Get-ChildItem Env:ComputerName).Value}}, LogName, @{N="TimeStamp";E={Get-Date -Date $_.TimeCreated -Format "yyyy/MM/dd HH:mm:ss"}}, @{N="Level";E={($_.LevelDisplayName).SubString(0,5).ToUpper()}}, @{N="Source";E={($_.ProviderName)}}, ID, @{N='Message';E={($_.Message -Replace("[^\x20-\x7F]+", " ") -Replace("[\x22|\x27]+", "") -Replace(" - ", "-") -Replace("\s+", " ")).Trim()}}
	If ($TempResults -eq $Null) {
		Write-Host "0 Found" -ForegroundColor Gray
	} ElseIf ($TempResults.Count -gt 1) {
		Write-Host $TempResults.Count"Found" -ForegroundColor Green
		$Results += $TempResults
	} Else {
		Write-Host "1 Found" -ForegroundColor Green
		$Results += $TempResults
	}
	$TempResults = $Null
	[System.GC]::Collect()
}
$Results | Sort-Object TimeStamp, LogName | Select-Object ComputerName, LogName, TimeStamp, Level, Source, Id, Message | Export-CSV $LogFile -Append -NoTypeInformation

Write-Host
Write-Host "Found a total of $($Results.Count) events between $StartTime and $EndTime" -ForegroundColor White
Write-Host "Results are located in $LogFile"
[System.GC]::Collect()
