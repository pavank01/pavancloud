﻿<#
.SYNOPSIS
Modify the CPU and/or memory of a VMware VM.

.DESCRIPTION
A PowerShell script to modify the CPU count and/or amount of memory assigned
to a VM. The script will gracefully shut down the guest OS, make the changes,
and then power the VM back on.

.PARAMETER VmName
The name of the virtual machine to modify.

.PARAMETER CpuCount
The total number of CPUs to assign to the VM.

.PARAMETER MemoryGB
The total amount of memory to assign to the VM in GB.

.PARAMETER Force
This switch will force the script to skip user prompts for CPU and Memory validation. Use this when automating builds.

.EXAMPLE
.\Modify-FAVMwareVM.ps1 -VmName snavnmsbvmwr001 -CpuCount 2

.EXAMPLE
.\Modify-FAVMwareVM.ps1 -VmName snavnmsbvmwr001 -MemoryGB 4

.EXAMPLE
.\Modify-FAVMwareVM.ps1 -VmName snavnmsbvmwr001 -CpuCount 2 -MemoryGB 4

#>

#------------------------------------------------------------------------------
#region - Parameters
#------------------------------------------------------------------------------

[CmdletBinding()]
Param(

    [Parameter(Mandatory=$True)]
    [string]$VmName,

    [Parameter(Mandatory=$false)]
    [int]$CpuCount,

    [Parameter(Mandatory=$false)]
    [int]$MemoryGB,

    [Parameter(Mandatory=$False)]
    [switch]$Force

)

#------------------------------------------------------------------------------
#endregion - Parameters
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Constants
#------------------------------------------------------------------------------

$VmName             = $VmName.ToUpper()
$LogName            = "$VmName.Modify.log"
$LogDirectory       = Get-Date -Format yyyy-MM
$LogPath            = "\\corp.firstam.com\restricted\ServerOps-Admin\Scripts\Logs"
$FullLogPath        = $LogPath + "\" + $LogDirectory + "\" + $LogName
$CpuCountMaxSetting = '4'
$MemoryGBMaxSetting = '8'
$SpecApproval       = ''
$MailFrom           = $($global:DefaultViServer.Name) + '@firstam.com'
$MailTo             = 'FAHQ-DL-SOMCloudTeam@firstam.com'
$MailSubject        = 'VM Modify Alert'
$MailBody           = "$VmName was modified on $($global:DefaultViServer.Name) with $CpuCount CPUs and $MemoryGB GB of memory by $($global:DefaultViServer.User)"
$SMTPServer         = 'mail.firstam.com'

#------------------------------------------------------------------------------
#endregion - Constants
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Functions
#------------------------------------------------------------------------------

Function Log-Message {
    Param(

        [string]$Message,

        [switch]$Warning

    )

    $dateTimeStamp = Get-Date -Format "[yyyy-MM-dd hh:mm:ss]"

    $LogEntry = "<![LOG[$Message]LOG]!><time=`"$(Get-Date -Format HH:mm:ss.ffff)`" " +`
                "date=`"$(Get-Date -Format MM-dd-yyyy)`">"
	
    Add-Content -Path $FullLogPath -Value $LogEntry

    if ($Warning) {

        Write-Host "$dateTimeStamp`t$message" -foregroundcolor "yellow"

    } else {

        Write-Output "$dateTimeStamp`t$message"

    }

}

#------------------------------------------------------------------------------
#endregion - Functions
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Main
#------------------------------------------------------------------------------

Log-Message "Beginning modify of $VmName on $($global:DefaultViServer.Name) by $($global:DefaultViServer.User)"

Log-Message "Logfile located at $FullLogPath"

# Check the CPU and MemoryGB values and alert if it's over the specified values
# Using the Force switch will skip this step

if (!$Force) {

    Log-Message "Validating CPU and MemoryGB"

    if ($CpuCount -gt $CpuCountMaxSetting -or $MemoryGB -gt $MemoryGBMaxSetting) {

        Log-Message "The number of CPUs and/or total memory settings are above the capacity guidelines" -Warning
        Log-Message "Please consult with the Cloud Team before continuing" -Warning

        $SpecApproval = Read-Host "`tContinue build? (Y/N)"

        if ($SpecApproval.ToUpper() -eq 'Y') {

            Log-Message "Continuing modification at user's request"

            Send-MailMessage -From $MailFrom -To $MailTo -Subject $MailSubject -SmtpServer $SMTPServer -Body $MailBody
        
        } else {
    
            Log-Message "Stopping build at user's request"
    
            Exit 0

        }
    }

} else {

    Log-Message "The -Force parameter was used, no CPU or Memory validation called" -Warning

}

$VMInfo = Get-VM -Name $VmName

if ( $VMInfo.PowerState -eq 'PoweredOn' ) {

    # Power off the VM

    Log-Message "Powering off $VmName"

    Stop-VMGuest -VM $VmName -Confirm:$false | Out-Null

    Do {
    
        $VmPowerState = (Get-VM -Name $VmName).PowerState

    } Until (

    $VmPowerState -eq 'PoweredOff'

    )

    Log-Message "$VmName is powered off"

} Else {

    Log-Message "$VmName is powered off"

}

# Change the CPU count if given that parameter

if ($CpuCount) {

    Log-Message "Changing CPU count to $CpuCount"

    Set-VM -VM $VmName -NumCPu $CpuCount -Confirm:$False | Out-Null

}

# Change the memory amount if given that parameter

if ($MemoryGB) {

    Log-Message "Changing the memory amount to $MemoryGB GB"

    Set-VM -VM $VmName -MemoryGB $MemoryGB -Confirm:$False | Out-Null

}

#------------------------------------------------------------------------------
#endregion - Main
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Post modify
#------------------------------------------------------------------------------

Log-Message "Powering on $VmName"

Start-VM -VM $VmName

Log-Message "Modifications are complete"

#------------------------------------------------------------------------------
#endregion - Post modify
#------------------------------------------------------------------------------