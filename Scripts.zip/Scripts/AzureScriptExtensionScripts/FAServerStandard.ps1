#======================================================================
# Parameters
#======================================================================
Param(

    [Parameter(Mandatory=$false)]
    [string]$serviceName,

    [Parameter(Mandatory=$false)]
    [string]$softwareSource,

    [Parameter(Mandatory=$false)]
    [string]$softwareStaging,

    [Parameter(Mandatory=$false)]
    [string]$dscSource,

    [Parameter(Mandatory=$false)]
    [string]$dscUserName,

    [Parameter(Mandatory=$false)]
    [string]$dscPassword,

    [Parameter(Mandatory=$false)]
    [string]$Logfile
   
)

$dscScript = "$env:COMPUTERNAME.ps1"
$dscScriptZIP = $dscScript + ".zip"
$flagFile = "C:\FAConfiguration.done"

#======================================================================
# Functions
#======================================================================

# 2015-09-29 - mallison - Setup proper parameters for Log-Message function
Function Log-Message {
    Param(
        [Parameter(Mandatory=$true)]
        [string]$Status,

        [Parameter(Mandatory=$true)]
        [string]$Message,

        [Parameter(Mandatory=$true)]
        [string]$Logfile

    )
    
    $LogEntry = "<![LOG[$Message]LOG]!><time=`"$(Get-Date -Format HH:mm:ss.ffff)`" " +`
                "date=`"$(Get-Date -Format MM-dd-yyyy)`" component=`"$env:COMPUTERNAME`" type=`"Verbose`" status=`"$Status`">"

    Add-Content -Path $LogFile -Value $LogEntry

    Write-Host $Message
}

Function Install-FAPackage {
    Param(
        [Parameter(Mandatory=$true)]
        [string]$applicationName,

        [Parameter(Mandatory=$true)]
        [string]$sourceFolder,

        [Parameter(Mandatory=$true)]
        [string]$tempFolder,

        [Parameter(Mandatory=$true)]
        [string]$installCommand,

        [Parameter(Mandatory=$false)]
        $installArguments

    )

    Log-Message -Status "InProgress" -Message "Preparing for installation of $applicationName" -Logfile $Logfile

	If ( !(Test-Path -Path $tempFolder -PathType Container) ) {
	
		New-Item -Path $tempFolder -ItemType Directory

	}

    # Copy the package to the local staging folder
    Log-Message -Status "InProgress" -Message "Copying package from $sourceFolder to $tempFolder" -Logfile $Logfile
    Copy-Item -Path "$sourceFolder\*" -Destination $tempFolder -Recurse -Force
   
    # Install the application from the local copy
    if ($installArguments) {

        Log-Message -Status "InProgress" -Message "Executing $installCommand with arguments $installArguments" -Logfile $Logfile

        Start-Process -WorkingDirectory $tempFolder -FilePath $installCommand -ArgumentList $installArguments -Wait 

    } Else {
    
        Log-Message -Status "InProgress" -Message "Executing $installCommand..." -Logfile $Logfile

        Start-Process -WorkingDirectory $tempFolder -FilePath $installCommand -Wait 

    }

    Log-Message -Status "InProgress" -Message "Installation of $applicationName complete." -Logfile $Logfile
    
}

Function Install-FAConfiguration {
    Param(
        [Parameter(Mandatory=$true)]
        [string]$sourceFolder,

        [Parameter(Mandatory=$true)]
        [string]$tempFolder,

        [Parameter(Mandatory=$true)]
        [string]$installCommand,

        [Parameter(Mandatory=$true)]
        [string]$Arguments

    )

    Log-Message -Status "InProgress" -Message "Preparing for application of DSC..." -Logfile $Logfile

    Log-Message -Status "InProgress" -Message "Checking for DSC source $sourceFolder for $installCommand..." -Logfile $Logfile

    $dscFullSource = Join-Path $sourceFolder -ChildPath $installCommand
    $dscFullTarget = Join-Path $tempFolder -ChildPath $installCommand
    $modulesFolder = "$env:ProgramFiles\WindowsPowerShell\Modules"

    if ( Test-Path $dscFullSource ) {

        Log-Message -Status "InProgress" -Message "Scheduling DSC script $dscFullTarget to run at reboot..." -Logfile $Logfile

        # Check to see if the temporary folder exists; create if necessary
	    If ( !(Test-Path -Path $tempFolder -PathType Container) ) {
	
		    New-Item -Path $tempFolder -ItemType Directory

	    }

        # Check to see if the PowerShell Modules folder exists; create if necessary
        If ( !(Test-Path -Path $modulesFolder -PathType Container) ) {
            
            New-Item -Path $modulesFolder -ItemType Directory

        }
        
        $taskParameters = @('/Create', 
                            '/SC ONSTART', 
                            '/TN "\Microsoft\Windows\Desired State Configuration\FAConfiguration"', 
                            '/RU System', 
                            '/F', 
                            '/RL HIGHEST',
                            '/DELAY 0005:00',
                            "/TR ""PowerShell.exe -ExecutionPolicy Unrestricted -File $dscFullTarget $Arguments"" " )
        
        # Copy .ps1.zip file to local directory
        Copy-Item -Path "$sourceFolder\$dscScriptZIP" -Destination $tempFolder -Force

        # Extract dependent DSC modules to a staging directory
        [System.Reflection.Assembly]::LoadWithPartialName("System.IO.Compression.FileSystem") | Out-Null
        [System.IO.Compression.ZipFile]::ExtractToDirectory("$tempFolder\$dscScriptZIP", "$tempFolder\Modules") | Out-File $Logfile -Append
      
        # Move the main script out of the Modules folder we created
        Move-Item "$tempFolder\Modules\$dscScript" -Destination "$tempFolder\$dscScript" -Force

        # Copy any PowerShell Modules to their correct location
        #Copy-Item "$tempFolder\Modules\*" -Destination "$modulesFolder" -Recurse -Force
        Robocopy.exe "$tempFolder\Modules" "$modulesFolder" /S /E /NP
       
        Log-Message -Status "Complete" -Message "Extracted dependent DSC modules (we think)" -Logfile $Logfile

        Start-Process -FilePath 'schtasks.exe' -ArgumentList ( $taskParameters -join " " ) -Wait

        Log-Message -Status "Complete" -Message "Added Scheduled Task" -Logfile $Logfile
        
    } Else {

        Log-Message -Status "InProgress" -Message "No matching DSC file present at source.  Nothing to do." -Logfile $Logfile

    }

    Log-Message -Status "InProgress" -Message "DSC preparation complete." -Logfile $Logfile

}

# 2015-09-10 - mblackman - Added function to diable timesync with Azure host and use AD
Function Disable-TimeSync {

    $TimeSyncRegistryPath = "REGISTRY::HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\W32Time\TimeProviders\VMICTimeProvider"
    $TimeSyncRegistryKeyName = "Enabled"
    Set-ItemProperty -Path $TimeSyncRegistryPath -Name $TimeSyncRegistryKeyName -Value 0
    w32tm /config /syncfromflags:DOMHIER /update
    net stop w32time
    net start w32time
    w32tm /resync /force

}

# Set pagefile to a set size
# 2017-04019 - mblackman - added
Function Set-PageFileSize
{
	Param(
        
        [Parameter(Mandatory=$true)]
        [string]$DL,
        
        [Parameter(Mandatory=$true)]
        [int]$InitialSize,
        
        [Parameter(Mandatory=$true)]
        [int]$MaximumSize
        
    )
	
	#The AutomaticManagedPagefile property determines whether the system managed pagefile is enabled. 
	#This capability is not available on windows server 2003,XP and lower versions.
	#Only if it is NOT managed by the system and will also allow you to change these.
	$IsAutomaticManagedPagefile = Get-WmiObject -Class Win32_ComputerSystem |Foreach-Object{$_.AutomaticManagedPagefile}
	If($IsAutomaticManagedPagefile)
	{
		#We must enable all the privileges of the current user before the command makes the WMI call.
		$SystemInfo=Get-WmiObject -Class Win32_ComputerSystem -EnableAllPrivileges
		$SystemInfo.AutomaticManagedPageFile = $false
		[Void]$SystemInfo.Put()
	}
	
	Write-Verbose "Setting pagefile on $DL"
	
	#configuring the page file size
	$PageFile = Get-WmiObject -Class Win32_PageFileSetting -Filter "SettingID='pagefile.sys @ $DL'"
	
	Try
	{
		If($PageFile -ne $null)
		{
			$PageFile.Delete()
		}
			Set-WmiInstance -Class Win32_PageFileSetting -Arguments @{name="$DL\pagefile.sys"; InitialSize = 0; MaximumSize = 0} `
			-EnableAllPrivileges |Out-Null
			
			$PageFile = Get-WmiObject Win32_PageFileSetting -Filter "SettingID='pagefile.sys @ $DL'"
			
			$PageFile.InitialSize = $InitialSize
			$PageFile.MaximumSize = $MaximumSize
			[Void]$PageFile.Put()
			
			Write-Host  "Execution Results: Set page file size on ""$DL"" successful."
			Write-Warning "Pagefile configuration changed on computer '$Env:COMPUTERNAME'. The computer must be restarted for the changes to take effect."
	}
	Catch
	{
		Write-Host "Execution Results: No Permission - Failed to set page file size on ""$DL"""
	}
}

# Disable TLS 1.0 and other things
# 2017-04-19 - mblackman - added
Function Disable-TLS {

    <#
    .SYNOPSIS
    Configuring Server with SSL/TLS Best Practices...

    .DESCRIPTION
    A PowerShell script to set best practices for TLS by disabling & enabling protocols and ciphers.
    Disabled Protocols: Multi-Protocol Unified Hello, PCT 1.0, SSL 2.0, SSL 3.0, TLS 1.0
    Disabled Ciphers: DES 56/56, NULL, RC2 128/128, RC2 40/128, RC2 56/128, RC4 40/128, RC4 56/128, RC4 64/128, RC4 128/128
    Enabled Protocols: TLS 1.1, TLS 1.2
    Enabled Ciphers: AES 128/128, AES 256/256, Triple DES 168/168

    .INPUTS
    None.  You cannot pipe input to Set-TLSSecurity.ps1.

    .OUTPUTS
    None.  Set-TLSSecurity.ps1 does not generate any output.

    #>

    Write-Host '****** Saving Registry *******'
    Write-Host '--------------------------------------------------------------------------------'

    $timestamp = Get-Date -Format s | Foreach-Object {
        
            $_ -replace ":", "."
        
    }

    $TARGETDIR = 'C:\_SvrOpsBackup'

    if(!(Test-Path -Path $TARGETDIR )) {

        New-Item -ItemType directory -Path $TARGETDIR
    
    }

    Reg export HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL $TARGETDIR\Schannel_$timestamp.txt
    Reg export HKLM\SOFTWARE\Policies\Microsoft\Cryptography\Configuration $TARGETDIR\Cryptography_$timestamp.txt


    Write-Host 'Registry has been saved to' $TARGETDIR
    Write-Host '--------------------------------------------------------------------------------'


    Write-Host 'Configuring IIS with SSL/TLS Deployment Best Practices...'
    Write-Host '--------------------------------------------------------------------------------'

    # Disable Multi-Protocol Unified Hello
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\Multi-Protocol Unified Hello\Server' -name Enabled -value 0 -PropertyType 'DWord' -Force | Out-Null
    Write-Host 'Multi-Protocol Unified Hello has been disabled.'

    # Disable PCT 1.0
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\PCT 1.0\Server' -name 'Enabled' -value 0 -PropertyType 'DWord' -Force | Out-Null
    Write-Host 'PCT 1.0 has been disabled.'

    # Disable SSL 2.0 (PCI Compliance)
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -name 'Enabled' -value 0 -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
    Write-Host 'SSL 2.0 has been disabled.'

    # Disable SSL 3.0 (PCI Compliance) and enable "Poodle" protection
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -name 'Enabled' -value 0 -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
    Write-Host 'SSL 3.0 has been disabled.'

    # Add and Enable TLS 1.0 for client and server SCHANNEL communications
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -name 'Enabled' -value 0 -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server' -name 'DisabledByDefault' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
    Write-Host 'TLS 1.0 has been disabled.'

    # Add and Enable TLS 1.1 for client and server SCHANNEL communications
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' -Force | Out-Null
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Client' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null
    Write-Host 'TLS 1.1 has been enabled.'

    # Add and Enable TLS 1.2 for client and server SCHANNEL communications
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -Force | Out-Null
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Client' -name 'DisabledByDefault' -value 0 -PropertyType 'DWord' -Force | Out-Null
    Write-Host 'TLS 1.2 has been enabled.'

    # Re-create the ciphers key.
    New-Item 'HKLM:SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers' -Force | Out-Null

    # Disable insecure/weak ciphers.
    $insecureCiphers = @(

        'DES 56/56',
        'NULL',
        'RC2 128/128',
        'RC2 40/128',
        'RC2 56/128',
        'RC4 40/128',
        'RC4 56/128',
        'RC4 64/128',
        'RC4 128/128'

    )

    Foreach ($insecureCipher in $insecureCiphers) {

        $key = (Get-Item HKLM:\).OpenSubKey('SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers', $true).CreateSubKey($insecureCipher)
        $key.SetValue('Enabled', 0, 'DWord')
        $key.close()
        Write-Host "Weak cipher $insecureCipher has been disabled."
    
    }

    # Enable new secure ciphers.
    # - RC4: It is recommended to disable RC4, but you may lock out WinXP/IE8 if you enforce this. This is a requirement for FIPS 140-2.
    # - 3DES: It is recommended to disable these in near future.
    $secureCiphers = @(

        'AES 128/128',
        'AES 256/256',
        'Triple DES 168'

    )

    Foreach ($secureCipher in $secureCiphers) {

        $key = (Get-Item HKLM:\).OpenSubKey('SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers', $true).CreateSubKey($secureCipher)
        New-ItemProperty -path "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\$secureCipher" -name 'Enabled' -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
        $key.close()
        Write-Host "Strong cipher $secureCipher has been enabled."

    }

    # Set hashes configuration.
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\MD5' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\MD5' -name Enabled -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA' -name Enabled -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
    
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA256' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA256' -name Enabled -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
    
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA384' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA384' -name Enabled -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
    
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA512' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Hashes\SHA512' -name Enabled -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
        


    # Set KeyExchangeAlgorithms configuration.
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\Diffie-Hellman' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\Diffie-Hellman' -name Enabled -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null
    
    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\ECDH' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\ECDH' -name Enabled -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

    New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\PKCS' -Force | Out-Null
    New-ItemProperty -path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\KeyExchangeAlgorithms\PKCS' -name Enabled -value '0xffffffff' -PropertyType 'DWord' -Force | Out-Null

    # Set cipher suites order as secure as possible (Enables Perfect Forward Secrecy).
    $cipherSuitesOrder = @(

        'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P521',
        'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P384',
        'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P256',
        'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P521',
        'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P384',
        'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P256',
        'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P521',
        'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P384',
        'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P256',
        'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P521',
        'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P384',
        'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P256',
        'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384_P521',
        'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384_P384',
        'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P521',
        'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P384',
        'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P256',
        'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384_P521',
        'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384_P384',
        'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P521',
        'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P384',
        'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P256',
        'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P521',
        'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P384',
        'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P256',
        'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P521',
        'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P384',
        'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P256',
        'TLS_RSA_WITH_AES_256_GCM_SHA384',
        'TLS_RSA_WITH_AES_128_GCM_SHA256',
        'TLS_RSA_WITH_AES_256_CBC_SHA256',
        'TLS_RSA_WITH_AES_128_CBC_SHA256',
        'TLS_RSA_WITH_AES_256_CBC_SHA',
        'TLS_RSA_WITH_AES_128_CBC_SHA'

    )

    $cipherSuitesAsString = [string]::join(',', $cipherSuitesOrder)

    New-ItemProperty -path 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002' -name 'Functions' -value $cipherSuitesAsString -PropertyType 'String' -Force | Out-Null

    Write-Host '--------------------------------------------------------------------------------'
    Write-Host 'NOTE: After the system has been rebooted you can verify your server'
    Write-Host '      configuration at https://www.ssllabs.com/ssltest/'
    Write-Host "--------------------------------------------------------------------------------`n"fs

}

#======================================================================
# Main
#======================================================================

Log-Message -Status "Starting" -Message  "Beginning prereq install" -Logfile $Logfile

# Check for flag file and abort if found
If (Test-Path -Path $flagFile) {

    Log-Message -Status "Complete" -Message  "Script has been previously run.  Exiting." -Logfile $Logfile
    Exit 0

}

# Identify the OS version for when we need it
#   - "6.1.7601" = Windows 2008 R2
#   - "6.2.9200" = Windows 2012
$osVersion = ( Get-WMIObject -Class Win32_OperatingSystem -Namespace root/cimv2).Version

# Allow all PowerShell scripts to run 
#   - This may not survive the PowerShell 4 install

Log-Message -Status "InProgress" -Message "Setting PowerShell Execution Policy to Unrestricted" -Logfile $Logfile

If ( (Get-ExecutionPolicy -Scope LocalMachine) -ne "Unrestricted" ) {
	Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope LocalMachine -Force
}

# If Windows 2008 R2, enable PowerShell Remoting
#   - 2015-09-25 - mblackman - Changed from winrm quickcofig.
if ($osVersion -eq "6.1.7601") {

    Enable-PSRemoting -Force

}

# Disable Windows Firewall
Log-Message -Status "InProgress" -Message "Disabling Windows Firewall" -Logfile $Logfile
netsh advfirewall set AllProfiles state off

# 2015-09-10 - mblackman - Disable Time Sync
# 2015-09-29 - mallison - Setup proper Log-Message syntax, added -Status and -Logfile parameters
Log-Message -Status "InProgress" -Message "Disabling Time Sync with host" -Logfile $Logfile
Disable-TimeSync

if ($osVersion -eq "6.2.9200") {

    # Install KB2840622 to fix known issue with Server 2012 and MSMQ
    # 2017-04-19 - mblackman -added install
    Install-FAPackage -applicationName 'KB2840622' `
                          -sourceFolder ( Join-Path $softwareSource -ChildPath 'PKG\Microsoft\Windows Server\Hotfixes\KB2840622' ) `
                          -tempFolder ( Join-Path $softwareStaging -ChildPath 'KB2840622' ) `
                          -installCommand 'wusa.exe' `
                          -installArguments @('Windows8-RT-KB2840622-v2-x64.msu', '/quiet', '/norestart')

}

# Install Symantec Endpoint Protection
# 2016-07-27 - mblackman - Changed version number to 12.1.7004.6500.
Install-FAPackage -applicationName 'Symantec Endpoint Protection' `
                  -sourceFolder ( Join-Path $softwareSource -ChildPath 'PKG\Symantec\Symantec Endpoint Protection\12.1.7004.6500\64-bit' ) `
                  -tempFolder ( Join-Path $softwareStaging -ChildPath 'SEP' ) `
                  -installCommand 'setup.cmd'

# Install Altiris
# 2015-10 -05 - mblackman - Altiris version updated to 7.6.1615.26
Install-FAPackage -applicationName 'Altiris' `
                  -sourceFolder ( Join-Path $softwareSource -ChildPath 'PKG\Symantec\Altiris\7.6.1615.26' ) `
                  -tempFolder ( Join-Path $softwareStaging -ChildPath 'Altiris' ) `
                  -installCommand 'setup.cmd'

# Install Tanium
# 2017-04-04 - mblackman - Tanium version 6.0.314.1540 added
Install-FAPackage -applicationName 'Tanium' `
                  -sourceFolder ( Join-Path $SoftwareSource -ChildPath 'PKG\Tanium\Tanium\6.0.314.1540' ) `
                  -tempFolder ( Join-Path $SoftwareStaging -ChildPath 'Tanium' ) `
                  -installCommand 'setup.cmd'

# 2015-09-10 - mblackman - Install the Telnet Client feature
# 2015-09-29 - mallison - Added logging for TelnetClient install
Log-Message -Status "InProgress" -Message "Installing TelnetClient" -Logfile $Logfile
if ($osVersion -eq "6.1.7601") {

    # Windows 2008 R2
    dism /online /Enable-Feature /FeatureName:TelnetClient

} else {

    # Windows 12 and beyond
    Install-WindowsFeature -Name Telnet-Client

}

# Set pagefile to 4GB
# 2017-04-14 - mblackman - function added
Log-Message -Status "InProgress" -Message "Setting pagefile to 4GB" -LogFile $Logfile
Set-PageFileSize -DL "C:" -InitialSize 4096 -MaximumSize 4096

# Disable TLS 1.0
# 2017-04-13 - mblackman - function added
Log-Message -Status "InProgress" -Message "Disabling TLS 1.0" -LogFile $Logfile
Disable-TLS

# Install Windows Management Framework v4 / PowerShell 4 if necessary
# 2015-09-25 - mblackman - Split 2008 R2 and 2012 OS patching. Added .NET 4.5.1 to 2008 R2 builds for Powershell upgrade
# 2015-10-01 - mallison - Changed '-ne' to '-lt' to allow for newer versions of PowerShell
If ( ($PSVersionTable).PSVersion -lt "4.0" ) {

    #put a default so WMF is installed no matter what (if PSVersion is not 4.0)

	switch ($osVersion) {
	
		"6.1.7601" { 

            # Windows 2008 R2
            Install-FAPackage -applicationName '.NET Framework 4.5.1' `
                              -sourceFolder ( Join-Path $softwareSource -ChildPath 'PKG\Microsoft\.NET Framework\4.5.1' ) `
                              -tempFolder ( Join-Path $softwareStaging -ChildPath '.NET Framework' ) `
                              -installCommand 'setup.cmd' `

            Install-FAPackage -applicationName 'Microsoft Management Framework 4.0' `
                              -sourceFolder ( Join-Path $softwareSource -ChildPath 'PKG\Microsoft\Windows Management Framework\4.0' ) `
                              -tempFolder ( Join-Path $softwareStaging -ChildPath 'Windows Management Framework' ) `
                              -installCommand 'wusa.exe' `
                              -installArguments @('Windows6.1-KB2819745-x64-MultiPkg.msu', '/quiet', '/norestart')

        }
		
		"6.2.9200" { 
        
            # Windows 2012
            Install-FAPackage -applicationName 'Microsoft Management Framework 4.0' `
                                  -sourceFolder ( Join-Path $softwareSource -ChildPath 'PKG\Microsoft\Windows Management Framework\4.0' ) `
                                  -tempFolder ( Join-Path $softwareStaging -ChildPath 'Windows Management Framework' ) `
                                  -installCommand 'wusa.exe' `
                                  -installArguments @('Windows8-RT-KB2799888-x64.msu', '/quiet', '/norestart')

        }
        
        default {

            Log-Message -Status "InProgress" -Message "Error: Unable to determine which PowerShell installer to use!" -Logfile $Logfile
        
        }

	}

}

# Check for DSC Configuration
If ($dscSource) {

    if ($dscUserName -and $dscPassword) {

        Install-FAConfiguration -sourceFolder ( Join-Path $dscSource -ChildPath $serviceName ) `
                                -tempFolder (Join-Path $softwareStaging -ChildPath $serviceName ) `
                                -installCommand $dscScript `
                                -Arguments " -DSCUserName $dscUserName -DSCPassword $dscPassword -Logfile $Logfile"

    } Else {
                            
        Install-FAConfiguration -sourceFolder ( Join-Path $dscSource -ChildPath $serviceName ) `
                                -tempFolder (Join-Path $softwareStaging -ChildPath $serviceName ) `
                                -installCommand $dscScript `
                                -Arguments " -Logfile $Logfile"
                            
    }
    
}

if ($osVersion -eq "6.1.7601") {

    # Install KB3080079 to fix RDP protocol on 2008R2 servers with TLS 1.0 disabled
    # 2017-04-17 - mblackman -added install
    Install-FAPackage -applicationName 'KB3080079' `
                          -sourceFolder ( Join-Path $softwareSource -ChildPath 'PKG\Microsoft\Windows Server\HotFixes\KB3080079' ) `
                          -tempFolder ( Join-Path $softwareStaging -ChildPath 'KB3080079' ) `
                          -installCommand 'wusa.exe' `
                          -installArguments @('Windows6.1-KB3080079-x64.msu', '/quiet', '/norestart')

}

Write-Output "FAServerStandard.ps1 completed at $(Get-Date)." | Out-File -FilePath $flagFile -Append

Log-Message -Status "Complete" -Message "Restarting computer" -Logfile $Logfile

#Restart-Computer -Force
shutdown.exe /r /t 300 /d p:2:4 /c "Restart initiated from FAServerStandard.ps1"

Exit 0
