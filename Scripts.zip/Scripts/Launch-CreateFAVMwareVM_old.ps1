﻿<#
.SYNOPSIS
A wrapper script used to launch the Create-FAVMwareStandardVM.ps1 script.

.DESCRIPTION
A PowerShell script to launch the Create-FAVMwareStandardVM.ps1 script which will target a particular cluster location
based on VM type.

.PARAMETER VMName
The name of the virtual machine to create.

.PARAMETER CpuCount
The number of CPUs to assign to the VM.

.PARAMETER MemoryGB
The amount of memory to assign to the VM in GB.

.PARAMETER Environment
The target environment to build the VM in. Options are "Production","Production-FAST","Production-Large",
"NonProduction","NonProduction-FAST","NonProduction-Large","DisasterRecovery","DisasterRecovery-FAST","DisasterRecovery-Large".

.PARAMETER Folder
The name of the vSphere folder to build the VM in.

.PARAMETER Template
The template used for your operating system choice. Options will be a standard build for each version of OS.

.PARAMETER AdminPassword
The local admin password. This is a plain text string, so best practice is to use a throw away password and then change it to our default from the server.

.PARAMETER DomainJoin
The fully qualified name of a domain to be joined. This parameter is optional.

.PARAMETER OUPath
The OU to be used for the domain join. This parameter is optional unless domainJoin is specified.

.PARAMETER DomainCredential
The AD credential object to be used for the domain join. The format for user name must follow the following pattern: user-a@fully qualified domain name.
This parameter is optional unless domainJoin is specified. The default value will prompt for credentials.

.PARAMETER Force
This switch will force the script to skip user prompts for CPU and Memory validation, and the AD Object check. Use this when automating builds.

.INPUTS
None.  You cannot pipe input to Launch-CreateFAVMwareVM.ps1.

.OUTPUTS
None.  Launch-CreateFAVMwareVM.ps1 does not generate any output.

.EXAMPLE
.\Launch-CreateFAVMwareVM.ps1 -VMName snavnmsjvmwr808 -CpuCount 2 -MemoryGB 4 -Environment NonProduction -Folder _vm-mgmt -Template FAStandard2012R2 -AdminPassword 'pa$$Word' -DomainJoin 'corp.firstam.com' -OUPath 'ou=cloudteam,ou=environments,ou=servers,ou=datacenter,dc=corp,dc=firstam,dc=com'

Creates a VM in an AD domain. The script will prompt for domain credentials

.EXAMPLE
.\Launch-CreateFAVMwareVM.ps1 -VMName snavnmsjvmwr808 -CpuCount 2 -MemoryGB 4 -Environment NonProduction -Folder _vm-mgmt -Template FAStandard2012R2 -AdminPassword 'pa$$Word'

Creates a standalone VM.

.EXAMPLE
.\Launch-CreateFAVMwareVM.ps1 -VMName snavnmsjvmwr808 -CpuCount 8 -MemoryGB 24 -Environment NonProduction -Folder _vm-mgmt -Template FAStandard2012R2 -AdminPassword 'pa$$Word' -DomainJoin 'corp.firstam.com' -OUPath 'ou=cloudteam,ou=environments,ou=servers,ou=datacenter,dc=corp,dc=firstam,dc=com' -force

Creates a VM and skips any prompts for existing AD object or over capacity settings.

#>

#------------------------------------------------------------------------------
#region - Parameters
#------------------------------------------------------------------------------
[CmdletBinding(DefaultParameterSetName='NoDomain')]
Param(

    [Parameter(Mandatory=$True)]
    [string]$VMName,

    [Parameter(Mandatory=$True)]
    [int]$CpuCount,

    [Parameter(Mandatory=$True)]
    [int]$MemoryGB,

    [Parameter(Mandatory=$True)]
    [ValidateSet("Production","Production-FAST","Production-Large","NonProduction","NonProduction-FAST","NonProduction-Large","DisasterRecovery","DisasterRecovery-FAST","DisasterRecovery-Large")]
    [string]$Environment,

    [Parameter(Mandatory=$True)]
    [string]$Folder,

    #TVP - Added "FAStandard2016_Shell"
    [Parameter(Mandatory=$True)]
    [ValidateSet("FAStandard2008R2","FAStandard2012","FAStandard2012R2","FAStandard2016_Shell","FAStandard2012R2_Shell")]
    [string]$Template,

    [Parameter(Mandatory=$True)]
    [string]$AdminPassword,

    [Parameter(ParameterSetName='Domain',Mandatory=$True)]
    [string]$DomainJoin,

    [Parameter(ParameterSetName='Domain',Mandatory=$True)]
    [PSCredential]$DomainCredential,

    [Parameter(ParameterSetName='Domain',Mandatory=$True)]
    [string]$OUPath,

    [Parameter(Mandatory=$False)]
    [switch]$Force,

    #TVP Added Below
    [Parameter(Mandatory=$False)]
    [switch]$Shell
)
#------------------------------------------------------------------------------
#endregion - Parameters
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Constants
#------------------------------------------------------------------------------

$BuildTargetPath = '\\corp.firstam.com\restricted\ServerOps-Admin\Scripts\Data\VMware\VMwareBuildTargets.txt'

#------------------------------------------------------------------------------
#endregion - Constants
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Main
#------------------------------------------------------------------------------

Try {

    # determine which environment the VM will use
    $environmentOptions = (Get-Content -Path $BuildTargetPath) -join "`n" | ConvertFrom-Json -ErrorAction Stop

    $BuildTarget = $environmentOptions | Where-Object {$_.Name -eq $Environment}

    # check for current vCenter server connection and logoff if there is one
    if ($global:DefaultVIServer) {

        Disconnect-VIServer -Server * -Confirm:$False -ErrorAction Stop

    }

    # connect to the appropriate vCenter server
    Connect-VIServer -Server $BuildTarget.ServerName -ErrorAction Stop

} Catch {

    Write-Warning $Error[0]

    Exit 0

}

# pass the following variables to the build script Create-FAVMwareStandardVM.ps1
# TVP - added "if" statement below for Shell VMs
# RA - 01-12-2018 - Added AdminPassword to the BuildVariables when -Shell is used. It is required by Create-FAVMwareStandardVM.ps1 so automation was broken

if ($shell) {

    $BuildVariables = @{

        VMName = $VMName
        CpuCount = $CpuCount
        MemoryGB = $MemoryGB
        Cluster = $BuildTarget.ClusterName
        DatastoreCluster = $BuildTarget.DatastoreClusterName
        Folder = $Folder
        PortGroup = $BuildTarget.PortGroupName
        Template = $Template
        Shell = $shell
        AdminPassword = $AdminPassword
        Force = $Force
    }

}

elseif ($DomainJoin) {

    $BuildVariables = @{

        VMName = $VMName
        CpuCount = $CpuCount
        MemoryGB = $MemoryGB
        Cluster = $BuildTarget.ClusterName
        DatastoreCluster = $BuildTarget.DatastoreClusterName
        Folder = $Folder
        PortGroup = $BuildTarget.PortGroupName
        Template = $Template
        AdminPassword = $AdminPassword
        DomainJoin = $DomainJoin
        DomainCredential = $DomainCredential
        OUPath = $OUPath
        Force = $Force

    }

} else {

    $BuildVariables = @{

        VMName = $VMName
        CpuCount = $CpuCount
        MemoryGB = $MemoryGB
        Cluster = $BuildTarget.ClusterName
        DatastoreCluster = $BuildTarget.DatastoreClusterName
        Folder = $Folder
        PortGroup = $BuildTarget.PortGroupName
        Template = $Template
        AdminPassword = $AdminPassword
        Force = $Force

    }

}


.\Create-FAVMwareStandardVM.ps1 @BuildVariables

#------------------------------------------------------------------------------
#endregion - Main
#------------------------------------------------------------------------------