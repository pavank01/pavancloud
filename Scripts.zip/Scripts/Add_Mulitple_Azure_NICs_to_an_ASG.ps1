﻿Set-AzContext -SubscriptionName EVDI-P-AzureSub-6

$ResourceGroupName = "EVDI-P-6-EVDI-RG-1"

$asgName = "EVDI-VDA-ASG-6"

$VMNames = Get-AzVM

 
foreach ($VMName in $VMNames) {
   
    $nic = Get-AzNetworkInterface -ResourceId $VmName.NetworkProfile.NetworkInterfaces.id
    $Asg = Get-AzApplicationSecurityGroup -ResourceGroupName $ResourceGroupName -Name $Asgname
  
  
    $nic.IpConfigurations[0].ApplicationSecurityGroups = $asg
    $nic | Set-AzNetworkInterface
 
}
