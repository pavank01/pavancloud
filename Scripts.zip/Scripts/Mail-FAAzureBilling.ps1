﻿$mailFrom = 'mblackman@firstam.com'
#$mailTo = @("mblackman@firstam.com","tpham@firstam.com","lwarner@firstam.com","mmikhael@firstam.com","MAllison@firstam.com")
$mailTo = @("mblackman@firstam.com")

$Month = (Get-Date).AddMonths(-1).ToString("yyyy-MM")
$FileName = "./AzureBill-$Month.csv" 
$subject = "Azure bill for $Month"

$report = .\Download-FAAzureBillingData.ps1 -LastMonth -FileName $FileName -Report
$body = $report | Where-Object { $_.ApplicationCode -eq 'EOCR' } | Select-Object -Property ApplicationCode,CostType,@{Name='Cost';Expression={[math]::Round($_.Cost,2)}} | ConvertTo-HTML | Out-String
Send-MailMessage -Attachments $FileName -Body $body -BodyAsHtml -From $mailFrom -To $mailTo -Subject $subject -SmtpServer mail.firstam.com
