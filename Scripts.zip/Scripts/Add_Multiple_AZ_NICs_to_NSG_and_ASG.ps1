﻿#Set Parameters - Subscription Name line 3, RG Name - line 5, and NSG name - line 7

Set-AzContext -SubscriptionName EVDI-P-AzureSub-6 

$resourceGroupName = 'EVDI-P-6-EVDI-RG-1'

$NetworkSecurityGroup = 'EVDI-VDA-NSG-6'

$asgName = "EVDI-VDA-ASG-6"

# Extract list of NICs in the RG

$NICs = Get-AzNetworkInterface

# Extract the name of each NIC

Foreach ($NIC in $NICs) {
$NICinterfaces = $NICs.Name
}

# Associate each NIC with the NSG

foreach ($NICinterface in $NICinterfaces) {

$nic = Get-AzNetworkInterface -ResourceGroupName $resourceGroupName -Name $NICinterface
$nsg = Get-AzNetworkSecurityGroup -ResourceGroupName $resourceGroupName -Name $NetworkSecurityGroup
$nic.NetworkSecurityGroup = $nsg
$nic | Set-AzNetworkInterface
} 

# Associate each NIC with the ASG

$VMNames = Get-AzVM
 
foreach ($VMName in $VMNames) {
   
    $nic = Get-AzNetworkInterface -ResourceId $VmName.NetworkProfile.NetworkInterfaces.id
    $Asg = Get-AzApplicationSecurityGroup -ResourceGroupName $resourceGroupName -Name $Asgname
    $nic.IpConfigurations[0].ApplicationSecurityGroups = $Asg
    $nic | Set-AzNetworkInterface
 
}