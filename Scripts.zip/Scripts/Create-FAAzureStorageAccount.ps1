﻿<#
.DESCRIPTION
New-FAAzureStorageAccount.ps1 will create a new storage
account in the specified cloud service. It will automatically
create a 'vhds' storage container and turn on logging and
metrics for the new storage account.

.PARAMETER StorageAccountName
The name of the new storage account.

.PARAMETER Location
The geographic location for the new storage account. The
default value is 'West US'.

.PARAMETER Type
The type of storage to use. The default value is 
'Standard LRS'.

.PARAMETER StorageContainer
The name of the automatically created storage 
container. The default value is 'vhds'.

.PARAMETER Permission
The permission settings for the newly created storage 
container. The default setting is 'Off'.

.EXAMPLE
.\New-FAAzureStorageAccount.ps1 -StorageAccountName soa1s1azursa1
#>
[CmdletBinding()]
    param (
        [Parameter(Mandatory=$True,ValueFromPipeline=$True)]
        [string]$StorageAccountName,

        [Parameter(Mandatory=$False)]
        [ValidateSet("West US")]
        [string]$Location = 'West US',

        [Parameter(Mandatory=$False)]
        [ValidateSet("Standard_LRS","Standard_ZRS","Standard_GRS","Standard_RAGRS","Premium_LRS")]
        [string]$Type = 'Standard_LRS',

        [Parameter(Mandatory=$False)]
        [string]$StorageContainer = "vhds",

        [Parameter(Mandatory=$False)]
        [string]$Permission = 'Off'

    )

# Specify the naming standard for storage accounts

$StorageExp  = '(\w{2})a(\d+)s(\d+)(\w{4})sa(\d+)'

# Convert the ServiceName to lower case

$StorageAccountName = $StorageAccountName.ToLower()
	

if ($StorageAccountName -match $StorageExp) {

    Write-Verbose "Storage account name matches our naming standard."

    Write-Verbose "Checking to see if the storage account already exists."

    $StorageStatus = Test-AzureName -Storage $StorageAccountName

    if ($StorageStatus -eq "$True") {

        Write-Warning "$StorageAccountName already exists."

    } Else {

        # Create the storage account

        Write-Verbose "Creating storage account $StorageAccountName in location $Location."

        New-AzureStorageAccount -StorageAccountName $StorageAccountName -Type $Type -Location $Location

        # Gather the key and context of the new storage account

        $Key = Get-AzureStorageKey -StorageAccountName $StorageAccountName

        $Context = New-AzureStorageContext -StorageAccountName $StorageAccountName -StorageAccountKey $Key.Primary

        # Create the vhds storage container which is needed in every storage account

        Write-Verbose "Creating storage container $StorageContainer in storage account $StorageAccountName."

        New-AzureStorageContainer -Name $StorageContainer -Permission $Permission -Context $Context

        # Turn on logging

        Write-Verbose "Turning on logging."

        Set-AzureStorageServiceLoggingProperty -ServiceType Blob -RetentionDays 7 -LoggingOperations All -Context $Context

        # Turn on Metrics

        Write-Verbose "Turning on metrics"

        Set-AzureStorageServiceMetricsProperty -ServiceType Blob -MetricsType Hour -RetentionDays 7 -MetricsLevel ServiceAndApi -Context $Context
    }

} Else {

    Write-Warning "Storage account name provided does NOT match our naming standard." -ErrorAction Stop

}

