﻿param(

    [Parameter(Mandatory=$True)]
    [string]$vmSubscription,

    [Parameter(Mandatory=$True)]
    [string]$vmService,
        
    [Parameter(Mandatory=$True)]
    [string]$vmToRestore = $null,

    [Parameter(Mandatory=$True)]
    [string]$backupSubscription,

    [Parameter(Mandatory=$True)]
    [string]$backupStorageAccount,

    [Parameter(Mandatory=$True)]
    [string]$backupStorageContainer,

    $storageAccountKeys = @{},

    $storageAccountContexts = @{},

    $diskList = @(),

    $ExportFolder = "E:\Scripts\XMLExports",

    $ExportFileName = $vmToRestore + ".xml",

    $ExportPath = (Join-Path $ExportFolder $ExportFileName)

)

function GetOSDiskInfo {

    param (

        [Parameter(Mandatory=$True)]
        $VM

    )

    $osDisk = Get-AzureOSDisk -VM $vm

    $diskInfo = @{
                    "StorageAccountName" = $osDisk.MediaLink.Host.Split(".")[0]
                    "MediaLink" = $osDisk.MediaLink
                    "DiskName" = $osDisk.DiskName
                    "Container" = $osDisk.MediaLink.LocalPath.Split("/")[1]
                    "BlobName" = $osDisk.MediaLink.LocalPath.Split("/")[2]
                }

    return $diskInfo

}

function GetDataDiskInfo {

    param (

        [Parameter(Mandatory=$True)]
        $VM

    )

    $tempDiskList = @()

    $dataDisks = Get-AzureDataDisk -VM $vm

    foreach ($dataDisk in $dataDisks) {

        $diskInfo = @{
                        "StorageAccountName" = $dataDisk.MediaLink.Host.Split(".")[0]
                        "MediaLink" = $dataDisk.MediaLink
                        "DiskName" = $dataDisk.DiskName
                        "Container" = $dataDisk.MediaLink.LocalPath.Split("/")[1]
                        "BlobName" = $dataDisk.MediaLink.LocalPath.Split("/")[2]
                    }

        $tempDiskList += $diskInfo

    }

    return $tempDiskList

}





# Setup the environment
# -----------------------------------------------------------------

Select-AzureSubscription $backupSubscription | Out-Null
 
if ( !$storageAccountKeys.ContainsKey($backupStorageAccount) ) {

    $storageAccountKeys.Item($backupStorageAccount) = (Get-AzureStorageKey -StorageAccountName $backupStorageAccount).Primary
    $storageAccountContexts.Item($backupStorageAccount) = New-AzureStorageContext -StorageAccountName $backupStorageAccount -StorageAccountKey $storageAccountKeys.Item($backupStorageAccount)

}



# Pick the VM to restore

Select-AzureSubscription $vmSubscription | Out-Null


$VM = Get-AzureVM -ServiceName $vmService -Name $vmToRestore 





# Get the Disk Information
# -----------------------------------------------------------------

$diskList += GetOSDiskInfo -VM $VM  
$diskList += GetDataDiskInfo -VM $VM





# Get all the necessary storage account keys and connections
# -----------------------------------------------------------------

foreach ($disk in $diskList) {

    if ( !$storageAccountKeys.ContainsKey($disk.StorageAccountName) ) {

        $storageAccountKeys.Item($disk.StorageAccountName) = (Get-AzureStorageKey -StorageAccountName $disk.StorageAccountName).Primary

        $storageAccountContexts.Item($disk.StorageAccountName) = New-AzureStorageContext -StorageAccountName $disk.StorageAccountName `
                                                                                         -StorageAccountKey $storageAccountKeys.Item($disk.StorageAccountName)

    }

}




# Deprovision VM

# Remove-AzureVM -ServiceName $vmService -Name $vmToRestore







<#
# Restore Process
#

foreach ($disk in $diskList) {

    # Wait for the OS disk to be unattached to the VM

    While ( (Get-AzureDisk -DiskName $disk.DiskName).AttachedTo ) {
    
        Start-Sleep 5

    }

    # Remove the disks

    Remove-AzureDisk -DiskName $disk.DiskName -DeleteVHD


    # Restore VHD from backup

    Select-AzureSubscription $backupSubscription | Out-Null

    Start-AzureStorageBlobCopy -srcContext $storageAccountContexts.Item($backupStorageAccount) -SrcContainer $BackupStorageContainer -SrcBlob $disk.blobName -destContext $storageAccountContexts.Item($disk.StorageAccountName) -DestContainer $disk.container -Force


    
    Select-AzureSubscription $vmSubscription | Out-Null

    Get-AzureStorageBlobCopyState -Container $disk.container -Blob $disk.blobName -WaitForComplete

    Add-AzureDisk -DiskName $disk.DiskName -MediaLocation $disk.MediaLink.AbsoluteUri -OS Windows

}



# Reprovision VM

Import-AzureVM -Path $ExportPath | New-AzureVM -ServiceName $vmService

#>
