﻿# get the encrypted password and create the login credentials.
# import the CSV file with the intended cloud services to backup.

$pathToSecureTxt = 'E:\Scripts'
$backupPassword = Get-Content "$pathToSecureTxt\secureBackupPassword.txt" | ConvertTo-SecureString
$backupCred = New-Object -TypeName System.Management.Automation.PSCredential("fahq-sa-azureutil@fahqrasoazure1firstam156.onmicrosoft.com",$backupPassword)
$FACloudServices = Import-Csv E:\Scripts\FAAzureServices.csv

# login to Azure

Add-AzureAccount -Credential $backupCred | Out-Null

# select the source subscription and storage account

foreach ($Service in $FACloudServices) {

    if ((Get-AzureSubscription -Current).SubscriptionName -ne $Service.vmSubscription) {

    #Write-Host "Changing subscription to $subscriptionName..."
    Select-AzureSubscription $subscriptionName | Out-Null

}


    #Set-AzureSubscription -SubscriptionName $Service.vmSubscription -CurrentStorageAccountName $Service.prodStorageAccount

    E:\Scripts\Get-FAAzureBackupStatus.ps1 -vmSubscription $Service.vmSubscription `
                                   -serviceToBackup $Service.serviceToBackup `
                                   -vmToBackup $Service.vmToBackup `
                                   -backupSubscription $Service.backupSubscription `
                                   -backupStorageAccount $Service.backupStorageAccount `
                                   -backupStorageContainer $Service.backupStorageContainer
}