﻿[CmdletBinding()]
param(

    [Parameter(Mandatory=$True)]
    [string]$vmSubscription,

    [Parameter(Mandatory=$True)]
    [string]$serviceToBackup,

    [Parameter()]
    [string]$vmToBackup = $null,

    [Parameter(Mandatory=$True)]
    [string]$backupSubscription,

    [Parameter(Mandatory=$True)]
    [string]$backupStorageAccount,

    [Parameter(Mandatory=$True)]
    [string]$backupStorageContainer,

    $maxVHDCopies = 3,

    $storageAccountKeys = @{},

    $storageAccountContexts = @{},

    $diskList = @(),
        
    $Date = (Get-Date).tostring("MMddyyyy")

)

# -----------------------------------------------------------------
# - Functions
# -----------------------------------------------------------------

function GetOSDiskInfo {

    param (

        [Parameter(Mandatory=$True)]
        $VM

    )

    $osDisk = Get-AzureOSDisk -VM $vm

    $diskInfo = @{
                    "StorageAccountName" = $osDisk.MediaLink.Host.Split(".")[0]
                    "Container" = $osDisk.MediaLink.LocalPath.Split("/")[1]
                    "BlobName" = $osDisk.MediaLink.LocalPath.Split("/")[2]
                }

    Write-Output $diskInfo

}

function GetDataDiskInfo {

    param (

        [Parameter(Mandatory=$True)]
        $VM

    )

    $tempDiskList = @()

    $dataDisks = Get-AzureDataDisk -VM $vm

    foreach ($dataDisk in $dataDisks) {

        $diskInfo = @{
                        "StorageAccountName" = $dataDisk.MediaLink.Host.Split(".")[0]
                        "Container" = $dataDisk.MediaLink.LocalPath.Split("/")[1]
                        "BlobName" = $dataDisk.MediaLink.LocalPath.Split("/")[2]
                    }

        $tempDiskList += $diskInfo

    }

    Write-Output $tempDiskList

}

function GetBackupCopyState {

    param (

        [Parameter(Mandatory=$true)]
        $Blob,

        [Parameter(Mandatory=$true)]
        $context,

        [Parameter(Mandatory=$true)]
        [string]$container

    )
 
    # Get the state of all backups
    Get-AzureStorageBlob -Blob $Blob -Context $context -Container $container | Get-AzureStorageBlobCopyState

}


# Setup the environment
# -----------------------------------------------------------------

Select-AzureSubscription $backupSubscription | Out-Null
 
if ( !$storageAccountKeys.ContainsKey($backupStorageAccount) ) {

    $storageAccountKeys.Item($backupStorageAccount) = (Get-AzureStorageKey -StorageAccountName $backupStorageAccount).Primary
    $storageAccountContexts.Item($backupStorageAccount) = New-AzureStorageContext -StorageAccountName $backupStorageAccount -StorageAccountKey $storageAccountKeys.Item($backupStorageAccount)

}

# Get the VM to work on
# -----------------------------------------------------------------

Select-AzureSubscription $vmSubscription | Out-Null

if ($vmToBackup) {

    $vmList = Get-AzureVM -ServiceName $serviceToBackup -Name $vmToBackup

}

else {

    $vmList = Get-AzureVM -ServiceName $serviceToBackup

}


# Get the Disk Information
# -----------------------------------------------------------------

foreach ($vm in $vmList) {

    $diskList += GetOSDiskInfo -VM $vm  
    $diskList += GetDataDiskInfo -VM $vm

}

# Get all the necessary storage account keys and connections
# -----------------------------------------------------------------

foreach ($disk in $diskList) {

    if ( !$storageAccountKeys.ContainsKey($disk.StorageAccountName) ) {

        $storageAccountKeys.Item($disk.StorageAccountName) = (Get-AzureStorageKey -StorageAccountName $disk.StorageAccountName).Primary

        $storageAccountContexts.Item($disk.StorageAccountName) = New-AzureStorageContext -StorageAccountName $disk.StorageAccountName `
                                                                                         -StorageAccountKey $storageAccountKeys.Item($disk.StorageAccountName)

    }

}
 
# Used for reporting of the copy status
# -----------------------------------------------------------------

foreach ($disk in $diskList) {

    $CopyResults = GetBackupCopyState -blob ($disk.BlobName.Split(".")[0] + '*') -context $storageAccountContexts.Item($backupStorageAccount) -container $backupStorageContainer

        foreach ($Copy in $CopyResults) {
            $Properties = @{'ComputerDisk'=($Copy.Source.AbsolutePath.Split("/")[2]);
                            'Status'=$Copy.Status;
                            'DataCopied GB'=(("{0:N1}" -f ($Copy.BytesCopied/1GB)));
                            'TotalData GB'=(("{0:N1}" -f ($Copy.TotalBytes/1GB)));
                            'CompletionTime'=$Copy.CompletionTime}

            $obj = New-Object -TypeName PSObject -Property $Properties

            Write-Output $obj 
                        
        }

}