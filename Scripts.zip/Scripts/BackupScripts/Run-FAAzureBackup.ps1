﻿[CmdletBinding()]
param(

    [Parameter(Mandatory=$True)]
    [string]$vmSubscription,

    [Parameter(Mandatory=$True)]
    [string]$serviceToBackup,

    
    [Parameter()]
    [string]$vmToBackup = $null,

    [Parameter(Mandatory=$True)]
    [string]$backupSubscription,

    [Parameter(Mandatory=$True)]
    [string]$backupStorageAccount,

    [Parameter(Mandatory=$True)]
    [string]$backupStorageContainer,

    $maxVHDCopies = 3,

    $storageAccountKeys = @{},

    $storageAccountContexts = @{},

    $diskList = @(),

    $Date = (Get-Date).tostring("MMddyyyy"),

    $LogFile = $Date + "_BackupLog.txt",

    $PathToLogFile = "E:\Scripts\Logs\$LogFile",

    $PathToExportFile = "E:\Scripts\XMLExports"

)

# -----------------------------------------------------------------
# - Functions
# -----------------------------------------------------------------

function GetOSDiskInfo {

    param (

        [Parameter(Mandatory=$True)]
        $VM

    )

    $osDisk = Get-AzureOSDisk -VM $vm

    $diskInfo = @{
                    "StorageAccountName" = $osDisk.MediaLink.Host.Split(".")[0]
                    "Container" = $osDisk.MediaLink.LocalPath.Split("/")[1]
                    "BlobName" = $osDisk.MediaLink.LocalPath.Split("/")[2]
                }

    return $diskInfo

}

function GetDataDiskInfo {

    param (

        [Parameter(Mandatory=$True)]
        $VM

    )

    $tempDiskList = @()

    $dataDisks = Get-AzureDataDisk -VM $vm

    foreach ($dataDisk in $dataDisks) {

        $diskInfo = @{
                        "StorageAccountName" = $dataDisk.MediaLink.Host.Split(".")[0]
                        "Container" = $dataDisk.MediaLink.LocalPath.Split("/")[1]
                        "BlobName" = $dataDisk.MediaLink.LocalPath.Split("/")[2]
                    }

        $tempDiskList += $diskInfo

    }

    return $tempDiskList

}

function SnapshotAndCopyBlob {

    param (
        [Parameter(Mandatory=$True)]
        $srcContext,

        [Parameter(Mandatory=$True)]
        $srcContainer,

        [Parameter(Mandatory=$True)]
        $srcBlobName,

        [Parameter(Mandatory=$True)]
        $destContext,

        [Parameter(Mandatory=$True)]
        $destContainer,

        [Parameter(Mandatory=$false)]
        $destBlobName = $srcBlobName
        
    )

    $srcBlob = Get-AzureStorageBlob -context $srcContext `
                                    -container $srcContainer `
                                    -Blob $srcBlobName

    Write-Output "Creating snapshot of $srcBlobName" >> $pathToLogFile
    
    
    # Actually create a snapshot
    $srcBlobSnapshot = $srcBlob.ICloudBlob.CreateSnapshot()

    # Begin an async copy to the destination
    $BlobCopy = Start-AzureStorageBlobCopy -ICloudBlob $srcBlobSnapshot `
                               -DestContext $destContext `
                               -DestContainer $destContainer `
                               -DestBlob $destBlobName `
                               -Force

    Write-Output "Copying $destBlobName Snapshot to $backupStorageAccount in the $destContainer container" >> $pathToLogFile
    
}
    

function CleanupOldSnapshots {

    param (

        [Parameter(Mandatory=$true)]
        $context,

        [Parameter(Mandatory=$true)]
        [string]$container,

        [Parameter(Mandatory=$true)]
        [string]$blobName,

        [Parameter(Mandatory=$true)]
        [int]$maxCopies
    )

    # Now list with all the snapshots by adding a wildcard
    $blobList = Get-AzureStorageBlob -context $context -container $container -Blob $blobName

    $blobList | Format-Table

    $numberOfBlobs = $blobList.Count

    # Cleanup older snapshots
    if ($numberOfBlobs -gt $maxCopies) {

      # Identify which Blob to work on - this needs to get more sophisticated
      # Right now we target the oldest snapshot because count-1 should be the source
      $blobToDelete = $numberofBlobs - 2

      # Make sure we're actually working with a snapshot
      if ($blobList[$blobToDelete].ICloudBlob.IsSnapshot) { 
  
        # Delete snapshot
        Write-Output "Delete old snapshot $blobName" >> $pathToLogFile

        write-host "Delete old snapshot $($blobList[$blobToDelete].ICloudBlob.SnapshotQualifiedStorageUri.PrimaryUri.AbsoluteUri)"

        $blobList[$blobToDelete].ICloudBlob.Delete() 
  
      }

    }

}

function GetBackupCopyState {

    param (

        [Parameter(Mandatory=$true)]
        $context,

        [Parameter(Mandatory=$true)]
        [string]$container

    )
 
    # Get the state of all backups
    Get-AzureStorageBlob -Context $context -Container $container | Get-AzureStorageBlobCopyState

}




# Initialize Log file
# -----------------------------------------------------------------

# Check if Log folder exists

$logDir = Split-Path $pathToLogFile -errorAction SilentlyContinue

if ($logDir -ne $null -and !(Test-Path $logDir)) {
    # Log File directory does not exist. Create new folder

    New-Item -Path $logDir -ItemType Container -Force | out-Null

}

# Start the log file entry with the date, time, and server name.
Get-Date >> $pathToLogFile


# Check if Export folder exists

if ($PathToExportFile -ne $null -and !(Test-Path $PathToExportFile)) {
    # Export directory does not exist. Create new folder

    New-Item -Path $PathToExportFile -ItemType Container -Force | out-Null

}



# Setup the environment
# -----------------------------------------------------------------

Select-AzureSubscription $backupSubscription | Out-Null
 
if ( !$storageAccountKeys.ContainsKey($backupStorageAccount) ) {

    $storageAccountKeys.Item($backupStorageAccount) = (Get-AzureStorageKey -StorageAccountName $backupStorageAccount).Primary
    $storageAccountContexts.Item($backupStorageAccount) = New-AzureStorageContext -StorageAccountName $backupStorageAccount -StorageAccountKey $storageAccountKeys.Item($backupStorageAccount)

}


# Get the VM to work on
# -----------------------------------------------------------------

Select-AzureSubscription $vmSubscription | Out-Null

if ($vmToBackup) {

    $vmList = Get-AzureVM -ServiceName $serviceToBackup -Name $vmToBackup

}

else {

    $vmList = Get-AzureVM -ServiceName $serviceToBackup

}


# Export XML file for each VM
# -----------------------------------------------------------------

foreach ($vm in $vmList) {

    $ExportFileName = $vm.InstanceName + ".xml"

    Get-AzureVM -ServiceName $serviceToBackup -Name $vm.InstanceName | Export-AzureVM -Path (Join-Path $PathToExportFile $ExportFileName) | Out-Null

    Write-Output "Exporting XML file for $($vm.InstanceName) to $PathToExportFile" >> $pathToLogFile

}


# Get the Disk Information
# -----------------------------------------------------------------

foreach ($vm in $vmList) {

    $diskList += GetOSDiskInfo -VM $vm  
    $diskList += GetDataDiskInfo -VM $vm

}

# Get all the necessary storage account keys and connections
# -----------------------------------------------------------------

foreach ($disk in $diskList) {

    if ( !$storageAccountKeys.ContainsKey($disk.StorageAccountName) ) {

        $storageAccountKeys.Item($disk.StorageAccountName) = (Get-AzureStorageKey -StorageAccountName $disk.StorageAccountName).Primary

        $storageAccountContexts.Item($disk.StorageAccountName) = New-AzureStorageContext -StorageAccountName $disk.StorageAccountName `
                                                                                         -StorageAccountKey $storageAccountKeys.Item($disk.StorageAccountName)

    }

}
 


# Clean up any older snapshots
# -----------------------------------------------------------------

foreach ($disk in $diskList) {

    CleanupOldSnapshots -context $storageAccountContexts.Item($disk.StorageAccountName) `
                        -container $disk.Container `
                        -blobName ($disk.BlobName.Split(".")[0] + '*') `
                        -maxCopies $maxVHDCopies

}


# Create snapshots and start the blob copy
# -----------------------------------------------------------------

foreach ($disk in $diskList) {

    SnapshotAndCopyBlob -srcContext $storageAccountContexts.Item($disk.StorageAccountName) `
                        -srcContainer $disk.Container `
                        -srcBlobName $disk.BlobName `
                        -destContext $storageAccountContexts.Item($backupStorageAccount) `
                        -destContainer $backupStorageContainer `
                        -destBlobname $disk.BlobName

}