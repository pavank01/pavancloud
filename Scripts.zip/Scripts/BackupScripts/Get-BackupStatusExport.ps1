﻿$CopyStatusFile = "CopyStatus.htm"

$CopyStatusPath = "E:\Scripts\Reports"

$FullPath = Join-Path $CopyStatusPath $CopyStatusFile

$CopyStatus = @()

$CopyStatus2 = @()

$PathToWebRoot = "C:\inetpub\wwwroot"

$Date = (Get-Date).tostring("MM/dd/yyyy")

$CopyResults = & "E:\Scripts\Launch-GetFAAzureBackupStatus.ps1"

foreach ($Result in $CopyResults) {

    foreach ($Status in $Result.CopyInfo.Status) {

        if ($Result.CopyInfo.Status -eq "Success") {
    
            $ServerStatus = "Success"

        } Else {

            $ServerStatus = "Failed"

        }

    }

    $Completed = $Result.CopyInfo | Sort-Object -Property CompletionTime -Descending | Select-Object -First 1

    $CopyStatus += $Result | Select-Object -Property VM,@{name="CopyStatus";expression={$ServerStatus}},@{name="Completed";expression={$Completed.CompletionTime.DateTime}}

    <#
    $CopyStatus2 += $Result.CopyInfo | 
                    Select-Object -Property ComputerDisk,Status,'TotalData GB','DataCopied GB',CompletionTime |
                    ConvertTo-Html -Fragment
    #>
}

$CloudService = $CopyResults | Select-Object -First 1 | Select-Object -ExpandProperty CloudService

$HtmlFragments = $CopyStatus | ConvertTo-Html -Fragment

ConvertTo-Html -Title "Azure Snapshot Copy Status" -CssUri table_format.css -Head "<h1>Azure Snapshot Copy Status $Date</h1>" -Body $HtmlFragments | Out-File $FullPath -Force

Copy-Item -Path $FullPath -Destination $PathToWebRoot -Force