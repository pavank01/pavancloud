###################################################################
# First American Terraform Readiness Script
#   By Joe O'Brien 05/06/2022
#   v1.0
#
#   !!USE AT YOUR OWN RISK, CURRENTLY BEING DEVELOPED!!
#
# - AWS Powershell Login, readies the user for Terraform Usage.
# - Current version is for POC / Validation
# - Currently only option 2 is supported (AWS via AWS-Azure-Login)
#
###################################################################

#function to provide an exit

function PromptYesNo {
    while ("yes","no" -notcontains $yorn_answer)
    {
        $yorn_answer = Read-Host "Continue? (Yes/No)"
    }
        if ($yorn_answer -eq "no"){
            Write-Host "Exiting..." -ForegroundColor Red
        exit
        }
}

#START OF SCRIPT, MAIN MENU SELECTION
Clear-Host
Write-Host "-----------------------------------------------------"          -ForegroundColor Green
Write-Host "First American - Terraform Launcher"                            -ForegroundColor Green
Write-Host "-----------------------------------------------------"          -ForegroundColor Green
Write-Host ""                                                               -ForegroundColor Green
Write-Host "Available Options:"                                             -ForegroundColor Yellow
Write-Host "- Option 1: Prerequisites Check - Node.JS + Aws-Azure-Login"    -ForegroundColor Yellow
Write-Host "- Option 2: Prepare - Terraform AWS (AWS-Azure-Login)"          -ForegroundColor Yellow
Write-Host "- Option 3: Prepare - Terraform Azure (Azure Powershell)"       -ForegroundColor Yellow
Write-Host "- Option 4: Cancel"                                             -ForegroundColor Yellow
Write-Host "" 
$launchOption = Read-Host "Please make a numeric selection from the options above"
switch ($launchOption) {
    1 {$launchOption = "Prereqs"}
    2 {$launchOption = "AWS"}
    3 {$launchOption = "Azure"}
    4 {
        Write-Host "Canceling..."                                     -ForegroundColor Red
        exit
    }
    default{
        Write-Host "No Match Found..."
        exit
    }
}

if ($launchOption -eq "Prereqs"){
    Clear-Host
}

if ($launchOption -eq "AWS"){
    Clear-Host
    Write-Host "-----------------------------------------------------"                      -ForegroundColor Green
    Write-Host "Option 2: Prepare - Terraform AWS (AWS-Azure-Login)"
    Write-Host "-----------------------------------------------------"                      -ForegroundColor Green
    Write-Host ""
    Write-Host "Starting:   Import AWS Powershell Module..."                                -ForegroundColor Yellow
    Import-Module AWSPowershell -ErrorAction Stop
    Write-Host "Finished:   Import AWS Powershell Module..."                                -ForegroundColor Green
    Write-Host ""
    
    #AWS Account ID
    $awsAccountIDInput = Read-Host -Prompt "AWS Account ID"
    $awsAccountID = $awsAccountIDInput.Trim()

    ####################################################################################
    # Commonly used First American AWS Regions: 
    #   us-west-1, us-west-2, us-east-1, us-east-2
    #
    #  List of additional regions:
    #  - eu-north-1
    #  - ap-south-1
    #  - eu-west-3
    #  - eu-west-2
    #  - eu-west-1
    #  - ap-northeast-3
    #  - ap-northeast-2
    #  - ap-northeast-1
    #  - sa-east-1
    #  - ca-central-1
    #  - ap-southeast-1
    #  - ap-southeast-2
    #  - eu-central-1
    #
    ####################################################################################
    $awsAccountRegioninput = Read-Host -Prompt "AWS Account Region [default: US-WEST-2]"
    $awsAccountRegionInputTrim = $awsAccountRegioninput.Trim()
    $awsAccountRegion = $awsAccountRegionInputTrim.ToUpper()
    if ($awsAccountRegion -eq "") {
        $awsAccountRegion = "US-WEST-2"
    }

    #AWS Role ARN Information
    $awsRoleNameinput = Read-Host -Prompt "AWS Role Name [default: FirstAm_super-pds]"
    $awsRoleName = $awsRoleNameinput.Trim()
    if ($awsRoleName -eq "") {
        $awsRoleName = "FirstAm_super-pds"
    } 
    #$roleName = "FirstAm_super-pds"
    $roleArn = "arn:aws:iam::" + $awsAccountID + ":role/$awsRoleName"

    #AWS-Azure-Login Profile 
    $awsAzureLoginProfileNameInput = Read-Host -Prompt "AWS-Azure-Login Profile Name [default: xacc-n-0]"
    $awsAzureLoginProfileName = $awsAzureLoginProfileNameInput.Trim()
    if ($awsAzureLoginProfileName -eq "") {
        $awsAzureLoginProfileName = "xacc-n-0"
    } 
    Write-Host ""
    Write-Host "Debug Info:"                                                                                            -ForegroundColor Yellow
    Write-Host "awsAccountID:               $awsAccountID"                                                              -ForegroundColor Green
    Write-Host "awsAccountRegion:           $awsAccountRegion"                                                          -ForegroundColor Green
    Write-Host "roleArn:                    $roleArn"                                                                   -ForegroundColor Green
    Write-Host "awsAzureLoginProfileName:   $awsAzureLoginProfileName"                                                  -ForegroundColor Green
    Write-Host ""

    PromptYesNo

    #Logging into AWS via Powershell and AWS-Azure-Login (in NPM)
    Write-Host ""
    Write-Host "Starting:   AWS-Azure-Login via Powershell..."                                                          -ForegroundColor Yellow  
    Write-Host ""
    aws-azure-login --profile $awsAzureLoginProfileName
    $roleSessionName = "TerraformScript"
    $assumerole = aws sts assume-role --role-arn $rolearn --role-session-name $roleSessionName --profile $awsAzureLoginProfileName --no-verify-ssl
    $assumerolevars = $assumerole  | ConvertFrom-Json 

    ForEach ($x in $assumerolevars){
        $env:AWS_Access_Key_ID = $x.Credentials.AccessKeyId
        $env:AWS_SECRET_Access_Key = $x.Credentials.SecretAccessKey
        $env:AWS_SESSION_TOKEN = $x.Credentials.SessionToken
    }
    $Env:AWS_DEFAULT_REGION="$awsAccountRegion"
    
    Write-Host ""
    Write-Host "Finished:   AWS-Azure-Login via Powershell..."                                                          -ForegroundColor Green  
}

if ($launchOption -eq "Azure"){
    Clear-Host
}