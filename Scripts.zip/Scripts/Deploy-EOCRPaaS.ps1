﻿[CmdletBinding(DefaultParameterSetName='List')]
Param(

    [Parameter(ParameterSetName='List',Mandatory=$False)]
    [switch]$list,

    [Parameter(ParameterSetName='Remove',Mandatory=$True)]
    [switch]$remove,
   
    [Parameter(ParameterSetName='Deploy',Mandatory=$True)]
    [switch]$deploy,

    [Parameter(ParameterSetName='Remove',Mandatory=$False)]
    [Parameter(ParameterSetName='Deploy',Mandatory=$False)]
    [switch]$all
   
)

Begin {

    #--------------------------------------------------------------------------------
    # Parameter type things
    #--------------------------------------------------------------------------------
    # new build - named out 6/13/2017
    #$sourcePkgDirectory  = '\\dtrasna09cifs01\PRS\OCRDroneII - Package\app.publish'

    # older build - in use as of 6/13/2017
    $sourcePkgDirectory  = '\\dtrasna09cifs01.datatrace.local\PRS\OCRDroneII - Package\app.publish\Before new flexible framework'
    $sourcePkgName       = 'DataTrace.Cloud.OCRAgent.cspkg'

    $sourceCfgDirectory  = '\\corp.firstam.com\Departments\IT\Azure\Scripts\Data\DBS'

    $subscriptionName = 'SO-1-AzureSub-1'

    $applicationStorageAccount = 'soa1s1eocrsa1'

    $serviceNames = @( "SO-1-1-EOCR-CS-9", "SO-1-1-EOCR-CS-10", "SO-1-1-EOCR-CS-11", "SO-1-1-EOCR-CS-14" )   
    
    #$serviceNames = @( "SO-1-1-EOCR-CS-14" )

    #--------------------------------------------------------------------------------
    # Calculated variables
    #--------------------------------------------------------------------------------
    $srcPackage = Join-Path $sourcePkgDirectory -ChildPath $sourcePkgName
    $originalStorageAccount = ''

    $action = $PSCmdlet.ParameterSetName

    #--------------------------------------------------------------------------------
    # Environment setup
    #--------------------------------------------------------------------------------
    if ((Get-AzureSubscription -Current).SubscriptionName -ne $subscriptionName) {

        Write-Host "Changing subscription to $subscriptionName..."
        Select-AzureSubscription $subscriptionName | Out-Null

    }

    # Record what the current default storage account is
    $originalStorageAccount = (Get-AzureSubscription -Current).CurrentStorageAccountName
    
    # May need to change the prior line to the following for newer versions of the module
    #$originalStorageAccount = (Get-AzureSubscription -Current).GetAccountName()

    # Change the current stoage account to the one desired if they are different
    # This allows the uploaded code to go to the desired location
    If ($originalStorageAccount -ne $applicationStorageAccount){

        Set-AzureSubscription -SubscriptionName $subscriptionName -CurrentStorageAccount $applicationStorageAccount

    }

}

Process {

    #--------------------------------------------------------------------------------
    # Iterate through each service performing the requested action
    #--------------------------------------------------------------------------------
    foreach ($serviceName in $serviceNames) {

        $srcConfig = Join-Path $sourceCfgDirectory -ChildPath "$serviceName.cscfg"

        if ( (Test-Path $srcPackage) -and (Test-Path $srcConfig) ) {

            switch ($action) {

                "Remove" {
                
                    Write-Host "Removing deployment for service $serviceName"

                    Remove-AzureDeployment -ServiceName $serviceName -Slot Production -Force

                    if ($all) {

                        Write-Host "Removing cloud service $serviceName"

                        Remove-AzureService -ServiceName $serviceName -Force

                    }

                }

                "Deploy" {

                    if ($all) {

                        Write-Host "Creating cloud service $serviceName"

                        New-AzureService -ServiceName $serviceName -Location 'West US'

                    }

                    Write-Host "Creating deployment for service $serviceName"

                    New-AzureDeployment -ServiceName $serviceName -Slot Production -Package $srcPackage -Configuration $srcConfig

                }

                Default {

                    # $list will also go here because it's the default action
                    # no point in mentioning it twice

                    Write-Host "Listing deployment for service $serviceName"
                    $deployment = Get-AzureDeployment -ServiceName $serviceName -Slot Production
                    $deployment | Format-Table ServiceName, Slot, Status, VNetName

                }

            }

        } else {

            Write-Host "Missing source package and/or configuration.  Unable to continue."

        }

    }

}

End {

    #--------------------------------------------------------------------------------
    # Environment cleanup   
    #--------------------------------------------------------------------------------
    If ($originalStorageAccount -ne $applicationStorageAccount){

        # Restore the default storage account to its prior setting
        Set-AzureSubscription -SubscriptionName $subscriptionName -CurrentStorageAccount $originalStorageAccount

    }

}
