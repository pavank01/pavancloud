﻿<#
.DESCRIPTION
Add-FAAzureDataDisk.ps1 will add an additional data drive 
to an Azure VM.

.PARAMETER ServiceName
The cloud service where the target VM resides.

.PARAMETER VmName
The target VM.

.PARAMETER StorageAccount
The storage account where the disks will reside.

.PARAMETER DiskSize
The size of the new disk, in GB.

.PARAMETER LUN
The LUN number, starting from 0. This parameter is optional.
If this parameter is not used the next available LUN number will
be used.

.PARAMETER HostCaching
The host level caching settings of the disk. Acceptable values
are "None", "ReadOnly", and "ReadWrite". The default is "None".

.EXAMPLE
.\Add-FAAzureDisk.ps1 -ServiceName SO-1-1-AZUR-CS-1 -VmName AZUVNAPPAZUR010 -StorageAccount soa1s1azursa1 -DiskSize 50 -LUN 0 -HostCaching ReadWrite
#>

[CmdletBinding()]
    param (
        [Parameter(Mandatory=$True)]
        [string]$ServiceName,

        [Parameter(Mandatory=$True)]
        [string]$VmName,

        [Parameter(Mandatory=$True)]
        [string]$StorageAccount,

        [Parameter(Mandatory=$True)]
        [int32]$DiskSize,

        [Parameter(Mandatory=$False)]
        [ValidateSet("0","1","2","3","4","5","6","7","8","9","10")]
        [string]$LUN,

        [Parameter(Mandatory=$False)]
        [ValidateSet("None","ReadOnly","ReadWrite")]
        [string]$HostCaching = 'None'

    )

# Change VM name to uppercase

$VmName = $VmName.ToUpper()


# Gather data disk information from VM

Write-Verbose "Gathering data disk info from $VmName."

$DiskInfo = Get-AzureVM -ServiceName $ServiceName -Name $VmName |
    Get-AzureDataDisk


# Check if a LUN number was provided. If not, use the next available LUN number

if (!($LUN)) {

    Write-Verbose "No LUN number specified, using the next available LUN."

    # Calculate the new LUN number

    $LUN = ($DiskInfo.Count -1) + 1

}

foreach ($Disk in $DiskInfo) {

    if ($LUN -eq $Disk.Lun) {

        Write-Warning "LUN $LUN is already in use, specify another."

        Exit

    }

}

# Add the disk

Write-Verbose "Adding LUN $LUN to $VmName."

Get-AzureVM -ServiceName $ServiceName -name $VmName |
	Add-AzureDataDisk -CreateNew -DiskSizeInGB $DiskSize -DiskLabel "$VmName-Data$LUN" -HostCaching $HostCaching -LUN $LUN `
        -MediaLocation "https://$StorageAccount.blob.core.windows.net/vhds/$VmName-Data$LUN.vhd" |

Update-AzureVM