﻿[CmdletBinding(DefaultParameterSetName='LastMonth')]
Param(

    [Parameter(Mandatory=$true,ParameterSetName='LastMonth')]
    [switch]$LastMonth,

    [Parameter(Mandatory=$true,ParameterSetName='All')]
    [switch]$All,

    [Parameter(Mandatory=$true,ParameterSetName='Month')]
    [string]$Month,

    [Parameter(Mandatory=$false)]
    [string]$FileName,

    [Parameter(Mandatory=$false)]
    [switch]$Report

)

$EnrollmentNbr = "54474952"
# primary key regenerated on 2017-04-07, effective through 2017-10-07
$Key = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IlE5WVpaUnA1UVRpMGVPMmNoV19aYmh1QlBpWSJ9.eyJFbnJvbGxtZW50TnVtYmVyIjoiNTQ0NzQ5NTIiLCJJZCI6Ijk1ZTZjZDU0LTBiYjUtNDU5Zi1iZTVjLTJlOTZjNTRkOGQ3NSIsIlJlcG9ydFZpZXciOiJFbnRlcnByaXNlIiwiUGFydG5lcklkIjoiIiwiRGVwYXJ0bWVudElkIjoiIiwiQWNjb3VudElkIjoiIiwiaXNzIjoiZWEubWljcm9zb2Z0YXp1cmUuY29tIiwiYXVkIjoiY2xpZW50LmVhLm1pY3Jvc29mdGF6dXJlLmNvbSIsImV4cCI6MTUwNzM4MDMyNSwibmJmIjoxNDkxNTY5MTI1fQ.AyMi6tRDSm7JArujBefcuzYnynrXZhuvSPPLgzaMkJAF03pz6hBtROe-t7K0bP5-Fu87cwj4pZWSRv5z-s_3NxEUQTpf6xKXXPPUV8Jzhr3ub_8ZozWlM_jl-OZyYqs9zLRje7pFvMsj5Eu_7D-_hhrhIBQZ4UfL6a8PXiyI56fhlXBVw6bfhYDLNuOfFGR3V-r0mGJaLz25WEGymy27o466-NV-3saAMcgH7R8PYpftlxnbXT-CD8UT4rYQM_or1N3IbGWk6L_tOdy1EPVitaw75iNyUDYV2Hdm-BP3IeM05wKIbbHdVLhLmLRkv2wuYLbK_iNUpRCbDA1SfJb9Wg"

if ( $LastMonth ) {

    $Month = (Get-Date).AddMonths(-1).ToString("yyyy-MM")

}

if ( $Month ) {

    if ( !$FileName ) { 
        $FileName = "E:\Scripts\Billing\AzureBill-$Month.csv" 
    }

    E:\Scripts\Download-AzureBillingData.ps1 -EnrollmentNbr $EnrollmentNbr -Key $Key -Month $Month -filename $FileName

} else {

    if ( !$FileName ) { 
    
        $FileName = "./AzureBill-All.csv" 
    }
    
    E:\Scripts\Download-AzureBillingData.ps1 -EnrollmentNbr $EnrollmentNbr -Key $Key -filename $FileName

}

if ( $Report ) {

    $BillSummary = E:\Scripts\Parse-AzureBill -csvFileName $FileName
    $BillSummary
    
}
