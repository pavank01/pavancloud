# ---------------------------------------------------------------------------
# Version 2.0 - Initial Release - Version 2 used to match version of existing
#               Set-TLSSecurity_v2_Disable_TLS1.0.ps1 script
# Version 2.1 - Fixed issue with use in PowerShell v2
# Version 2.2 - Minor changes for readability
# Version 2.3 - Minor appearance changes
# Version 2.5 - Modified text so status would be more apparent
#               Added color definition legend at bottom to clarify status text
#               Added support for Windows version defaults (2008 - 2016)
#               Added support for Windows 2008 SP2 KB4019276
#               Added ServerName, Domain, Windows Version to top of display
#
# Version 3.0 - Complete rewrite as there are 10 (not 3) different states
#               possible in the Registry. This script is temporary until
#               the full new Set / Get scripts are completed
#
# ---------------------------------------------------------------------------
Function IsNumeric {
	# Returns $True if $TempValue can be evaluated as a number even if quoted
	# Returns $False if $TempValue cannot be evaluated as a number
	Param ($TempValue)
	Add-Type -Assembly Microsoft.VisualBasic
	[Microsoft.VisualBasic.Information]::IsNumeric($TempValue)
}
# ---------------------------------------------------------------------------
Function Write-Line {
	# Examples:
	# Write-Line "-" -Length 25 -BackgroundColor White -ForegroundColor Black
	# Write-Line "-=" -Length 25
	# Write-Line "_" -Length 40 -ForegroundColor White -BackgroundColor Blue
	# Write-Line "#" -BackgroundColor White -ForegroundColor Blue -Length 80
	# Write-Line -Text "-+-" -Length 100 -BackgroundColor DarkRed -ForegroundColor White
	[CmdletBinding()]
    Param(
    	[Parameter(Mandatory=$False,Position=0)][string]$Text = "_",
		[Parameter(Mandatory=$False)][Int]$Length = ([Console]::WindowWidth - 1),
        [Parameter(Mandatory=$False)][string]$ForegroundColor = [Console]::ForegroundColor,
        [Parameter(Mandatory=$False)][string]$BackgroundColor = [Console]::BackgroundColor
        )
    Begin {}
    Process {
		If ($Length -le $Text.Length) {
			Write-Host $Text -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor
		} Else {
			$CurrentLength = 0
			$NewText = ""
			Do {
				$NewText = $NewText.ToString() + $Text.ToString()
				$CurrentLength = $CurrentLength + 1
			} Until ($CurrentLength -ge $Length)
			$NewText = $NewText.SubString(0, $Length)
		    Write-Host $NewText -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor
		}
	}
	End {}
}
# ---------------------------------------------------------------------------
Function Write-Centered {
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $False,
				   Position = 0)]
		[string]$Text,
		[Parameter(Mandatory = $False)]
		[Int]$Length = ([Console]::WindowWidth - 1),
		[Parameter(Mandatory = $False)]
		[string]$ForegroundColor = [Console]::ForegroundColor,
		[Parameter(Mandatory = $False)]
		[string]$BackgroundColor = [Console]::BackgroundColor
	)
	Begin { }
	Process {
		$LengthOf = $Text.Length
		If ($Length -le $LengthOf) {
			Write-Host $Text -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor
		} Else {
			$LengthBefore = [Math]::Round(($Length / 2) - [Math]::Round(($Text.Length / 2)))
			$LengthAfter = $Length - ($LengthBefore + $LengthOf)
			If ($LengthBefore -gt $LengthAfter) {
				$Temp = $LengthAfter
				$LengthAfter = $LengthBefore
				$LengthBefore = $Temp
			}
			If (($LengthAfter - $LengthBefore) -gt 1) {
				$LengthBefore = $LengthBefore + 1
				$LengthAfter = $LengthAfter - 1
			}
			$NewText = ''.PadLeft($LengthBefore, ' ')
			$NewText = $NewText + $Text
			$NewText = $NewText + ''.PadRight($LengthAfter, ' ')
			Write-Host $NewText -ForegroundColor $ForegroundColor -BackgroundColor $BackgroundColor
		}
	}
	End { }
}
# ---------------------------------------------------------------------------
Function Get-MicrosoftUpdates {
	Param (
		[String[]]$HotfixID = $Null
	)
	$Session = New-Object -ComObject Microsoft.Update.Session
	$Searcher = $Session.CreateUpdateSearcher()
	$HistoryCount = $Searcher.GetTotalHistoryCount()
	If ($HistoryCount -eq 0) {
		$Hotfixes = Get-Hotfix | Select-Object HotfixID, Description, @{N="InstalledOn";E={(Get-Date -Date $_.InstalledOn -Format "MM/dd/yyyy")}}
	} Else {
		$Hotfixes = $Searcher.QueryHistory(0,$HistoryCount) | Select-Object @{N="HotfixID";E={$Null}}, @{N="Description";E={$_.Title+". "+$_.Description}}, @{N="InstalledOn";E={(Get-Date -Date $_.Date -Format "MM/dd/yyyy")}}
	}
	ForEach ($Hotfix In $Hotfixes) {
		If ($Hotfix.HotfixID -eq $Null -or $Hotfix.HotfixID -eq "") {
			If ($Hotfix.Description -Match "KB[0-9]{6,}") {
				$Hotfix.HotfixID = ($Matches[0]).ToUpper()
			} ElseIf ($ID.Description -Match "KB[0-9]{6,}") {
				$Hotfix.HotfixID = ($Matches[0]).ToUpper()
			} Else {
				$Hotfix.HotfixID = "N/A"
			}
		}
	}
	If ($HotfixID -eq $Null) {
		$Hotfixes | Select-Object HotfixID, Description, InstalledOn
	} Else {
		$HotfixSubset = @()
		ForEach ($ID In $HotfixID) {
			$HotfixSubset += $Hotfixes | Where-Object {$_.HotfixID -eq $ID.ToUpper()}
		}
		$HotfixSubset | Select-Object HotfixID, Description, InstalledOn
	}
}
# ---------------------------------------------------------------------------
Function Get-ProtocolState {
	# Using $Args to allow processing of ANY variable Type
	#
	# Syntax:
	#     Get-ProtocolState Enabled DisabledByDefault
	#
	$Enabled = $Args[0]
	$DisabledByDefault = $Args[1]
	If (IsNumeric $Enabled) {
		If ($Enabled -eq 0) {
			# Enabled is DISABLED / FALSE - Zero only
			$Enabled_Valid = $True
			$Enabled_State = $False
		} Else {
			# Enabled is ENABLED / TRUE - Any valid Integer (positive / negative) except zero
			$Enabled_Valid = $True
			$Enabled_State = $True
		}
	} Else {
		If ($Enabled.GetType().Name -eq "String") {
			# If Enabled is a String Type
			If ($Enabled -eq "Null") {
				# Enabled Registry Key does not exist or is empty so use OS Default
				$Enabled_Valid = $True
				$Enabled_State = "Default"
			} Else {
				# Something is not right
				$Enabled_Valid = $False
				$Enabled_State = "INVALID"
			}
		} Else {
			# Something is not right
			$Enabled_Valid = $False
			$Enabled_State = "INVALID"
		}
	}
	If (IsNumeric $DisabledByDefault) {
		If ($DisabledByDefault -eq 0) {
			# DisabledByDefault is DISABLED / FALSE - Zero only
			$DisabledByDefault_Valid = $True
			$DisabledByDefault_State = $False
		} Else {
			# DisabledByDefault is ENABLED / TRUE - Any valid Integer (positive / negative) except zero
			$DisabledByDefault_Valid = $True
			$DisabledByDefault_State = $True
		}
	} Else {
		If ($DisabledByDefault.GetType().Name -eq "String") {
			# If DisabledByDefault is a String Type
			If ($DisabledByDefault -eq "Null") {
				# DisabledByDefault Registry Key does not exist or is empty so use OS Default
				$DisabledByDefault_Valid = $True
				$DisabledByDefault_State = "Default"
			} Else {
				# Something is not right
				$DisabledByDefault_Valid = $False
				$DisabledByDefault_State = "INVALID"
			}
			If ($DisabledByDefault -eq "N/A") {
				# DisabledByDefault Registry Key not required for this configuration
				$DisabledByDefault_Valid = $True
				$DisabledByDefault_State = "N/A"
			}
		} Else {
			# Something is not right
			$DisabledByDefault_Valid = $False
			$DisabledByDefault_State = "INVALID"
		}
	}
	If ($Enabled_Valid -eq $True -and $DisabledByDefault_Valid -eq $True) {
		# Both values are valid so determine protocol status
		# Enabled_State is DISABLED / FALSE -------------------------------------
		If ($Enabled_State -eq $False -and $DisabledByDefault_State -eq $False) {
			# DISABLED
			Return "DISABLED"
		}
		If ($Enabled_State -eq $False -and $DisabledByDefault_State -eq $True) {
			# DISABLED
			Return "DISABLED"
		}
		If ($Enabled_State -eq $False -and $DisabledByDefault_State -eq "Default") {
			# DISABLED but some protocols need both set to be valid
			Return ("INCORRECT ({0}/{1})" -f $Enabled, $DisabledByDefault)
		}
		If ($Enabled_State -eq $False -and $DisabledByDefault_State -eq "N/A") {
			# DISABLED - DisabledByDefault Registry Key not required for this configuration
			Return "DISABLED"
		}
		# Enabled_State is ENABLED / TRUE --------------------------------------
		If ($Enabled_State -eq $True -and $DisabledByDefault_State -eq $False) {
			# ENABLED
			Return "ENABLED"
		}
		If ($Enabled_State -eq $True -and $DisabledByDefault_State -eq $True) {
			# DISABLED
			Return "DISABLED"
		}
		If ($Enabled_State -eq $True -and $DisabledByDefault_State -eq "Default") {
			# ENABLED but some protocols need both set to be valid
			#Return "ENABLED-Default"
			Return ("INCORRECT ({0}/{1})" -f $Enabled, $DisabledByDefault)
		}
		If ($Enabled_State -eq $True -and $DisabledByDefault_State -eq "N/A") {
			# ENABLED - DisabledByDefault Registry Key not required for this configuration
			Return "ENABLED"
		}
		# Enabled_State is not configured --------------------------------------------
		If ($Enabled_State -eq "Default" -and $DisabledByDefault_State -eq $False) {
			# ENABLED but some protocols need both set to be valid
			#Return "Default-DISABLED"
			Return ("INCORRECT ({0}/{1})" -f $Enabled, $DisabledByDefault)
		}
		If ($Enabled_State -eq "Default" -and $DisabledByDefault_State -eq $True) {
			# DISABLED but some protocols need both set to be valid
			#Return "Default-ENABLED"
			Return ("INCORRECT ({0}/{1})" -f $Enabled, $DisabledByDefault)
		}
		If ($Enabled_State -eq "Default" -and $DisabledByDefault_State -eq "Default") {
			# Default
			# Return ("Default ({0}/{1})" -f $Enabled, $DisabledByDefault)
			Return "Default"
		}
		If ($Enabled_State -eq "Default" -and $DisabledByDefault_State -eq "N/A") {
			# Default - DisabledByDefault Registry Key not required for this configuration
			# Return ("Default ({0})" -f $Enabled)
			Return "Default"
		}
	} Else {
		# One or both values are incorrect so protocol status is INVALID -------------
		Return ("INVALID-CONFIG ({0}/{1})" -f $Enabled, $DisabledByDefault)
	}
}
# ---------------------------------------------------------------------------
# Get server and Windows details
$OSInfo = Get-WmiObject -Class Win32_OperatingSystem -ErrorAction SilentlyContinue | Select-Object @{L="ComputerName";E={$_.CSName}}, @{L="Domain";E={$Null}}, @{L="OperatingSystem";E={($_.Caption -Replace('Microsoft',' ') -Replace('Server',' ') -Replace('[^\x20-\x7E]+', ' ') -Replace('\s+', ' ')).Trim()}}, @{L="OS";E={($_.Caption -Replace('Microsoft',' ') -Replace('Windows',' ') -Replace('Server',' ') -Replace('Standard',' ') -Replace('Enterprise',' ') -Replace('Datacenter',' ') -Replace('Essentials',' ') -Replace('Foundation',' ') -Replace('[^\x20-\x7E]+', ' ') -Replace('\s+', '')).Trim()}}, @{L="SP";E={$_.ServicePackMajorVersion}}, @{L="OSArchitecture";E={$_.OSArchitecture -Replace('\-bit', '')}}, @{L="Version";E={[System.Version]$_.Version}}
$OSInfo.Domain = (Get-WmiObject -Class Win32_ComputerSystem | Select-Object @{Label="Domain"; Expression={$_.Domain.ToLower()}}).Domain

$Notes = $Null
# ----------------------------------------------------------------------------
# Windows 2008
# Looks for KB4019276 that adds TLS 1.1/1.2 support to Windows 2008 SP2
# TLS 1.1/1.2 is not possible in Windows 2008 RTM or SP1
# TLS 1.0 cannot be disabled in Windows 2008 as RDP does not support TLS 1.1/1.2
$KB4019276_2008SP2 = $False
If ($OSInfo.OS -eq "2008" -and $OSInfo.SP -ge 2) {
	Write-Host
	Write-Host "Windows 2008 SP2 - Scanning for KB4019276 ..." -ForegroundColor Cyan
	Write-Host
	$KB4019276_2008SP2 = If ((Get-MicrosoftUpdates -HotfixID KB4019276).HotfixID -ne $Null) {$True} Else {$False}
}
If ($OSInfo.OS -eq "2008" -and $OSInfo.SP -ge 2 -and $KB4019276_2008SP2 -eq $True) {
	# TLS1.1/TLS1.2 Supported - TLS1.0 CANNOT BE DISABLED
	$Notes = "TLS1.0 CANNOT BE DISABLED"
} ElseIf ($OSInfo.OS -eq "2008" -and $OSInfo.SP -ge 2 -and $KB4019276_2008SP2 -eq $False) {
	# TLS1.1/TLS1.2 Not Supported - Install KB4019276 - TLS1.0 CANNOT BE DISABLED
	$Notes = "TLS1.1/1.2 Not Supported - Install KB4019276 - TLS1.0 Cannot be Disabled"
} ElseIf ($OSInfo.OS -eq "2008" -and $OSInfo.SP -lt 2) {
	# TLS1.1/TLS1.2 Not Supported - Install SP2 and KB4019276 - TLS1.0 CANNOT BE DISABLED
	$Notes = "TLS1.1/1.2 Not Supported - Install SP2 and KB4019276 - TLS1.0 Cannot be Disabled"
}
# ----------------------------------------------------------------------------
# Windows 2008 R2
# Looks for KB3080079 that adds TLS 1.1/1.2 support to RDP in Windows 2008 SP1
# TLS 1.1/1.2 support for RDP is not possible in Windows 2008 R2 RTM
$KB3080079_2008R2SP1 = $False
If ($OSInfo.OS -eq "2008R2" -and $OSInfo.SP -ge 1) {
	Write-Host
	Write-Host "Windows 2008 R2 SP1 - Scanning for KB3080079 ..." -ForegroundColor Cyan
	Write-Host
	$KB3080079_2008R2SP1 = If ((Get-MicrosoftUpdates -HotfixID KB3080079).HotfixID -ne $Null) {$True} Else {$False}
}
If ($OSInfo.OS -eq "2008R2" -and $OSInfo.SP -ge 1 -and $KB3080079_2008R2SP1 -eq $True) {
	# TLS1.1/TLS1.2 for RDP Supported
	$Notes = $Null
} ElseIf ($OSInfo.OS -eq "2008R2" -and $OSInfo.SP -ge 1 -and $KB3080079_2008R2SP1 -eq $False) {
	# TLS1.1/TLS1.2 for RDP Not Supported - Install KB3080079 - TLS1.0 CANNOT BE DISABLED YET
	$Notes = "TLS1.1/1.2 RDP Not Supported - Install KB3080079 - TLS1.0 Cannot be Disabled Yet"
} ElseIf ($OSInfo.OS -eq "2008R2" -and $OSInfo.SP -lt 1) {
	# TLS1.1/TLS1.2 for RDP Not Supported - Install SP1 and KB3080079 - TLS1.0 CANNOT BE DISABLED YET
	$Notes = "TLS1.1/1.2 RDP Not Supported - Install SP1 and KB3080079 - TLS1.0 Cannot be Disabled Yet"
}

$RegistryKeys = @{
	"Protocols\TLS 1.0\Server\DisabledByDefault"            = "Null";
	"Protocols\TLS 1.0\Server\Enabled"                      = "Null";
	"Protocols\TLS 1.0\Client\DisabledByDefault"            = "Null";
	"Protocols\TLS 1.0\Client\Enabled"                      = "Null";
	"Protocols\TLS 1.1\Server\DisabledByDefault"            = "Null";
	"Protocols\TLS 1.1\Server\Enabled"                      = "Null";
	"Protocols\TLS 1.1\Client\DisabledByDefault"            = "Null";
	"Protocols\TLS 1.1\Client\Enabled"                      = "Null";
	"Protocols\TLS 1.2\Server\DisabledByDefault"            = "Null";
	"Protocols\TLS 1.2\Server\Enabled"                      = "Null";
	"Protocols\TLS 1.2\Client\DisabledByDefault"            = "Null";
	"Protocols\TLS 1.2\Client\Enabled"                      = "Null";
	"Protocols\SSL 2.0\Server\DisabledByDefault"            = "Null";
	"Protocols\SSL 2.0\Server\Enabled"                      = "Null";
	"Protocols\SSL 3.0\Server\DisabledByDefault"            = "Null";
	"Protocols\SSL 3.0\Server\Enabled"                      = "Null";
	"Protocols\Multi-Protocol Unified Hello\Server\Enabled" = "Null";
	"Protocols\PCT 1.0\Server\Enabled"                      = "Null";
	"Ciphers\NULL\Enabled"                                  = "Null";
	"Ciphers\DES 56\56\Enabled"                             = "Null";
	"Ciphers\RC2 40\128\Enabled"                            = "Null";
	"Ciphers\RC2 56\128\Enabled"                            = "Null";
	"Ciphers\RC2 128\128\Enabled"                           = "Null";
	"Ciphers\RC4 40\128\Enabled"                            = "Null";
	"Ciphers\RC4 56\128\Enabled"                            = "Null";
	"Ciphers\RC4 64\128\Enabled"                            = "Null";
	"Ciphers\RC4 128\128\Enabled"                           = "Null";
	"Ciphers\AES 128\128\Enabled"                           = "Null";
	"Ciphers\AES 256\256\Enabled"                           = "Null";
	"Ciphers\Triple DES 168\Enabled"                        = "Null";
	"Hashes\MD5\Enabled"                                    = "Null";
	"Hashes\SHA\Enabled"                                    = "Null";
	"Hashes\SHA256\Enabled"                                 = "Null";
	"Hashes\SHA384\Enabled"                                 = "Null";
	"Hashes\SHA512\Enabled"                                 = "Null";
	"KeyExchangeAlgorithms\Diffie-Hellman\Enabled"          = "Null";
	"KeyExchangeAlgorithms\ECDH\Enabled"                    = "Null";
	"KeyExchangeAlgorithms\PKCS\Enabled"                    = "Null"
}
$KeyList = Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders' -Recurse -ErrorAction SilentlyContinue | ForEach-Object {(Get-ItemProperty $_.PSPath).PSPath -Replace ([RegEx]::Escape('Microsoft.PowerShell.Core\Registry::HKEY_LOCAL_MACHINE'), 'HKLM:')}
$KeyList = $KeyList | Where-Object {$_} | Sort-Object
ForEach ($Key In $KeyList) {
    $RegValues = (Get-ItemProperty $Key -ErrorAction SilentlyContinue).PSObject.Properties | Where-Object {$_.Name -notlike "PS*"} | Select-Object Name, Value, @{N = "DataType"; E = {$_.TypeNameOfValue}}
    ForEach ($RegValue In $RegValues) {
        $Name = $Key + "\" + $RegValue.Name
        $Name = ($Name -Replace ("HKLM\:\\SYSTEM\\CurrentControlSet\\Control\\SecurityProviders\\SCHANNEL\\", "")).Trim()
        $Name = ($Name -Replace ("/", "\")).Trim()
        If ($Name -like "*Ciphers*" -or $Name -like "*Protocols*" -or $Name -like "*KeyExchangeAlgorithms*" -or $Name -like "*Hashes*") {
            Switch ($RegValue.DataType) {
                "System.Byte[]" {
                    $Value = [Array]$RegValue.Value
                }
                "System.Int32" {
                    #$Value = [Int32]$RegValue.Value
                    $Value = [Int64]$RegValue.Value
                }
                "System.UInt32" {
                    #$Value = [UInt32]$RegValue.Value
                    $Value = [Int64]$RegValue.Value
                    #$Value = '0x' + ([System.Convert]::ToString($RegValue.Value, 16)).PadLeft(8, "0")
                }
                "System.Int64" {
                    $Value = [Int64]$RegValue.Value
                }
                "System.UInt64" {
                    #$Value = [UInt64]$RegValue.Value
                    $Value = [Int64]$RegValue.Value
                }
                "System.String" {
                    $Value = [String]$RegValue.Value
                }
                "System.String[]" {
                    $Value = [Array]$RegValue.Value
                }
                Default {
                    $Value = $RegValue.Value
                }
            }
			$RegistryKeys.Set_Item($Name, $Value)
			$Value = $Null
        }
    }
}

If ($OSInfo.SP -eq 0) {
	$OperatingSystem = "{0} ({1}-bit)" -f $OSInfo.OperatingSystem, $OSInfo.OSArchitecture
} Else {
	$OperatingSystem = "{0} SP{1} ({2}-bit)" -f $OSInfo.OperatingSystem, $OSInfo.SP, $OSInfo.OSArchitecture
}

If ([System.Version]$OSInfo.Version -lt [System.Version]'10.0') {
	$ExpectedCipherSuitesOrder = @(
		'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P521',
		'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P384',
		'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P256',
		'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P521',
		'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P384',
		'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P256',
		'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P521',
		'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P384',
		'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P256',
		'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P521',
		'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P384',
		'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P256',
		'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384_P521',
		'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384_P384',
		'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P521',
		'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P384',
		'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P256',
		'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384_P521',
		'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384_P384',
		'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P521',
		'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P384',
		'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P256',
		'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P521',
		'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P384',
		'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P256',
		'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P521',
		'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P384',
		'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P256',
		'TLS_RSA_WITH_AES_256_GCM_SHA384',
		'TLS_RSA_WITH_AES_128_GCM_SHA256',
		'TLS_RSA_WITH_AES_256_CBC_SHA256',
		'TLS_RSA_WITH_AES_128_CBC_SHA256',
		'TLS_RSA_WITH_AES_256_CBC_SHA',
		'TLS_RSA_WITH_AES_128_CBC_SHA'
	)
} Else {
	$ExpectedCipherSuitesOrder = @(
		'TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384',
		'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256',
		'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384',
		'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256',
		'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA',
		'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA',
		'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384',
		'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256',
		'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384',
		'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256',
		'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA',
		'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA',
		'TLS_RSA_WITH_AES_256_GCM_SHA384',
		'TLS_RSA_WITH_AES_128_GCM_SHA256',
		'TLS_RSA_WITH_AES_256_CBC_SHA256',
		'TLS_RSA_WITH_AES_128_CBC_SHA256',
		'TLS_RSA_WITH_AES_256_CBC_SHA',
		'TLS_RSA_WITH_AES_128_CBC_SHA'
	)
}

$CurrentCipherSuitesOrder = @(((Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002').PSObject.Properties | Where-Object {$_.Name -notlike "ps*"} | Select-Object Value).Value -Split ",")

If ($CurrentCipherSuitesOrder -ne $Null) {
	$CipherSuitesEqual = @(Compare-Object $ExpectedCipherSuitesOrder $CurrentCipherSuitesOrder -SyncWindow 0).Length -eq 0
	If ($CipherSuitesEqual -eq $True) {
		$CipherOrder = "CORRECT ORDER"
	} Else {
		$CipherOrder = "INCORRECT ORDER"
	}
} Else {
	$CipherOrder = "Default"
}


$TLSConfig = New-Object PSObject -Property @{
	'ComputerName'         = $OSInfo.ComputerName
	'OperatingSystem'      = $OperatingSystem
	'Domain'               = $OSInfo.Domain
	'Notes'                = $Notes
	'TLS_1.0_Server'       = (Get-ProtocolState $RegistryKeys.Item("Protocols\TLS 1.0\Server\Enabled") $RegistryKeys.Item("Protocols\TLS 1.0\Server\DisabledByDefault"))
	'TLS_1.0_Client'       = (Get-ProtocolState $RegistryKeys.Item("Protocols\TLS 1.0\Client\Enabled") $RegistryKeys.Item("Protocols\TLS 1.0\Client\DisabledByDefault"))
	'TLS_1.1_Server'       = (Get-ProtocolState $RegistryKeys.Item("Protocols\TLS 1.1\Server\Enabled") $RegistryKeys.Item("Protocols\TLS 1.1\Server\DisabledByDefault"))
	'TLS_1.1_Client'       = (Get-ProtocolState $RegistryKeys.Item("Protocols\TLS 1.1\Client\Enabled") $RegistryKeys.Item("Protocols\TLS 1.1\Client\DisabledByDefault"))
	'TLS_1.2_Server'       = (Get-ProtocolState $RegistryKeys.Item("Protocols\TLS 1.2\Server\Enabled") $RegistryKeys.Item("Protocols\TLS 1.2\Server\DisabledByDefault"))
	'TLS_1.2_Client'       = (Get-ProtocolState $RegistryKeys.Item("Protocols\TLS 1.2\Client\Enabled") $RegistryKeys.Item("Protocols\TLS 1.2\Client\DisabledByDefault"))
	'SSL_2.0_Server'       = (Get-ProtocolState $RegistryKeys.Item("Protocols\SSL 2.0\Server\Enabled") $RegistryKeys.Item("Protocols\SSL 2.0\Server\DisabledByDefault"))
	'SSL_3.0_Server'       = (Get-ProtocolState $RegistryKeys.Item("Protocols\SSL 3.0\Server\Enabled") $RegistryKeys.Item("Protocols\SSL 3.0\Server\DisabledByDefault"))
	'PCT_1.0_Server'       = (Get-ProtocolState $RegistryKeys.Item("Protocols\PCT 1.0\Server\Enabled") "N/A")
	'Unified_Hello'        = (Get-ProtocolState $RegistryKeys.Item("Protocols\Multi-Protocol Unified Hello\Server\Enabled") "N/A")
	'Hash_MD5'             = (Get-ProtocolState $RegistryKeys.Item("Hashes\MD5\Enabled") "N/A")
	'Hash_SHA'             = (Get-ProtocolState $RegistryKeys.Item("Hashes\SHA\Enabled") "N/A")
	'Hash_SHA256'          = (Get-ProtocolState $RegistryKeys.Item("Hashes\SHA256\Enabled") "N/A")
	'Hash_SHA384'          = (Get-ProtocolState $RegistryKeys.Item("Hashes\SHA384\Enabled") "N/A")
	'Hash_SHA512'          = (Get-ProtocolState $RegistryKeys.Item("Hashes\SHA512\Enabled") "N/A")
	'Algorithm_DHE'        = (Get-ProtocolState $RegistryKeys.Item("KeyExchangeAlgorithms\Diffie-Hellman\Enabled") "N/A")
	'Algorithm_ECDH'       = (Get-ProtocolState $RegistryKeys.Item("KeyExchangeAlgorithms\ECDH\Enabled") "N/A")
	'Algorithm_PKCS'       = (Get-ProtocolState $RegistryKeys.Item("KeyExchangeAlgorithms\PKCS\Enabled") "N/A")
	'Cipher_NULL'          = (Get-ProtocolState $RegistryKeys.Item("Ciphers\NULL\Enabled") "N/A")
	'Cipher_AES_128'       = (Get-ProtocolState $RegistryKeys.Item("Ciphers\AES 128\128\Enabled") "N/A")
	'Cipher_AES_256'       = (Get-ProtocolState $RegistryKeys.Item("Ciphers\AES 256\256\Enabled") "N/A")
	'Cipher_DES_56'        = (Get-ProtocolState $RegistryKeys.Item("Ciphers\DES 56\56\Enabled") "N/A")
	'Cipher_RC2_40'        = (Get-ProtocolState $RegistryKeys.Item("Ciphers\RC2 40\128\Enabled") "N/A")
	'Cipher_RC2_56'        = (Get-ProtocolState $RegistryKeys.Item("Ciphers\RC2 56\128\Enabled") "N/A")
	'Cipher_RC2_128'       = (Get-ProtocolState $RegistryKeys.Item("Ciphers\RC2 128\128\Enabled") "N/A")
	'Cipher_RC4_40'        = (Get-ProtocolState $RegistryKeys.Item("Ciphers\RC4 40\128\Enabled") "N/A")
	'Cipher_RC4_56'        = (Get-ProtocolState $RegistryKeys.Item("Ciphers\RC4 56\128\Enabled") "N/A")
	'Cipher_RC4_64'        = (Get-ProtocolState $RegistryKeys.Item("Ciphers\RC4 64\128\Enabled") "N/A")
	'Cipher_RC4_128'       = (Get-ProtocolState $RegistryKeys.Item("Ciphers\RC4 128\128\Enabled") "N/A")
	'Cipher_3DES_168'      = (Get-ProtocolState $RegistryKeys.Item("Ciphers\Triple DES 168\Enabled") "N/A")
	'Cipher_Order'         = $CipherOrder
}


$TLSConfig = $TLSConfig | Select-Object ComputerName, Domain, OperatingSystem, Notes, TLS_1.0_Server, TLS_1.0_Client, TLS_1.1_Server, TLS_1.1_Client, TLS_1.2_Server, TLS_1.2_Client, SSL_2.0_Server, SSL_3.0_Server, PCT_1.0_Server, Unified_Hello, Hash_MD5, Hash_SHA, Hash_SHA256, Hash_SHA384, Hash_SHA512, Algorithm_DHE, Algorithm_ECDH, Algorithm_PKCS, Cipher_NULL, Cipher_AES_128, Cipher_AES_256, Cipher_DES_56, Cipher_RC2_40, Cipher_RC2_56, Cipher_RC2_128, Cipher_RC4_40, Cipher_RC4_56, Cipher_RC4_64, Cipher_RC4_128, Cipher_3DES_168, Cipher_Order



$C1 = ($TLSConfig.PSObject.Properties | Where-Object {$_.Name -ne "ComputerName" -and $_.Name -ne "OperatingSystem" -and $_.Name -ne "Notes"} | ForEach {$_.Name.Length} | Measure-Object -Maximum).Maximum
$C2 = ($TLSConfig.PSObject.Properties | Where-Object {$_.Name -ne "ComputerName" -and $_.Name -ne "OperatingSystem" -and $_.Name -ne "Notes"} | ForEach {$_.Value.Length} | Measure-Object -Maximum).Maximum

$Length = (($C1 + $C2) * 2 + 10)
If ($TLSConfig.Notes.Length -gt $Length) {
	$C2 = $C2 + [Math]::Ceiling((($TLSConfig.Notes.Length + 2) - $Length) / 2)
	$Length = $TLSConfig.Notes.Length + 2
}

Write-Host
Write-Line "-" -Length $Length -ForegroundColor DarkCyan -BackgroundColor DarkCyan
Write-Centered $TLSConfig.ComputerName -Length $Length -ForegroundColor White -BackgroundColor DarkCyan
Write-Centered $TLSConfig.Domain -Length $Length -ForegroundColor White -BackgroundColor DarkCyan
Write-Centered $TLSConfig.OperatingSystem -Length $Length -ForegroundColor White -BackgroundColor DarkCyan
If ($TLSConfig.Notes -ne $Null) {
	Write-Centered $TLSConfig.Notes -Length $Length -ForegroundColor Yellow -BackgroundColor DarkCyan
}
Write-Line "-" -Length $Length -ForegroundColor DarkCyan -BackgroundColor DarkCyan

Function Show-Status {
	[CmdletBinding()]
	Param (
		[Parameter()]
		[Int]$C1,
		[Parameter()]
		[Int]$C2,
		[Parameter()]
		[PSObject]$Settings
	)
	$Counter = 0
	$Settings.PSObject.Properties | ForEach {
		$Name = $_.Name -Replace ("_", " ")
		$Counter = $Counter + 1
		If ($_.Value -like "Enabled*" -or $_.Value -eq "Correct Order") {
			# Enabled Green
			Write-Host (" {0,-$C1} : {1,-$C2}  " -f $Name, $_.Value) -ForegroundColor Green -NoNewLine
		} ElseIf ($_.Value -like "Disabled*" -or $_.Value -eq "Incorrect Order") {
			# Disabled Red
			Write-Host (" {0,-$C1} : {1,-$C2}  " -f $Name, $_.Value) -ForegroundColor Red -NoNewLine

		} Else {
			# Other Yellow
			Write-Host (" {0,-$C1} : {1,-$C2}  " -f $Name, $_.Value) -ForegroundColor Yellow -NoNewLine
		}
		If  ($Counter -ge 2) {
			Write-Host
			$Counter = 0
		}
	}
	If  ($Counter -gt 0) {
		#Write-Host
		Write-Host
	} Else {
		#Write-Host
	}
}

$Temp = $TLSConfig | Select-Object TLS_*, SSL_*
Show-Status -C1 $C1 -C2 $C2 -Settings $Temp
Write-Line "-" -Length $Length -ForegroundColor DarkGray

$Temp = $TLSConfig | Select-Object PCT_*, Unified_*
Show-Status -C1 $C1 -C2 $C2 -Settings $Temp
Write-Line "-" -Length $Length -ForegroundColor DarkGray

$Temp = $TLSConfig | Select-Object Hash_*
Show-Status -C1 $C1 -C2 $C2 -Settings $Temp
Write-Line "-" -Length $Length -ForegroundColor DarkGray

$Temp = $TLSConfig | Select-Object Algorithm_*
Show-Status -C1 $C1 -C2 $C2 -Settings $Temp
Write-Line "-" -Length $Length -ForegroundColor DarkGray

$Temp = $TLSConfig | Select-Object Cipher_*
Show-Status -C1 $C1 -C2 $C2 -Settings $Temp
Write-Line "-" -Length $Length -ForegroundColor DarkCyan -BackgroundColor DarkCyan
Write-Host
Write-Host "  " -ForegroundColor DarkGreen -BackgroundColor Green -NoNewLine
Write-Host "  Setting is ENABLED" -ForegroundColor Green
Write-Host "  " -ForegroundColor DarkRed -BackgroundColor Red -NoNewLine
Write-Host "  Setting is DISABLED" -ForegroundColor Red
Write-Host "  " -ForegroundColor DarkYellow -BackgroundColor Yellow -NoNewLine
Write-Host "  Setting is Windows DEFAULT or INCORRECT - Please Review!" -ForegroundColor Yellow
Write-Host
