﻿<#
.SYNOPSIS
Create an Azure VM.

.DESCRIPTION
A PowerShell script to create an Azure VM with the specified parameters for selected image, storage account,
instance size, virtual network and subnet.  Windows VMs are automatically placed in the Pacific Standard
Time Zone.

.PARAMETER vmName
The name of the virtual machine to create.

.PARAMETER imageLabel
The image label to be used.  Wildcards can be used.  A list of images can be obtained by using Get-AzureVMImage | Format-List Label

.PARAMETER instanceSize,
The size of the virtual machine.  Options are:
    ExtraSmall, Small, Medium, Large, ExtraLarge, A5, A6, A7, A8, A9,
    Standard_D1, Standard_D2, Standard_D3, Standard_D4,
    Standard_D11, Standard_D12, Standard_D13, Standard_D14,
    Standard_G3

.PARAMETER storageAccountName
The name of the storage account to be used for the VHD.  The path used will be https://<storageAccountName>.blob.core.windows.net/vhds/.  The VHD will be the <servername>-OS.vhd.

.PARAMETER serviceName
The name of the cloud service to create the virtual machine in.

.PARAMETER vnetName
The name of the virtual network to place the virtual machine on.

.PARAMETER subnetName
The name of the subnet to place the virtual machine on.

.PARAMETER adminUserName
The user name for the administrator account.  This cannot be Administrator.

.PARAMETER adminPassword
The password for the administrator account.

.PARAMETER domainJoin
The name of a domain to be joined.  These parameters are ignored if the selected opreating system is Linux.  This parameter is optional.

.PARAMETER domainOU
The OU to be used for the domain join.  This parameter is optional unless domainJoin is specified.

.PARAMETER domainCredential
The credential object to be used for the domain join.  This parameter is optional unless domainJoin is specified

.INPUTS
None.  You cannot pipe input to Create-FAAzureStandardVM.ps1.

.OUTPUTS
None.  Create-FAAzureStandardVM.ps1 does not generate any output.

.EXAMPLE
C:\PS> .\Create-FAAzureStandardVM.ps1 -vmName 'test-vm-09' -imageLabel 'Windows Server 2008 R2 SP1*' -instanceSize 'Small' -storageAccountName 'mtestsg1' -serviceName 'M-Test-CS-0' -vnetName 'M-Test-VNet-1' -subnetName 'VNet-1-Subnet-A-3' -adminUserName 'Matt' -adminPassword 'Mulberry\w2014'

C:\PS> .\Create-FAAzureStandardVM.ps1 -vmName 'test-vm-09' -imageLabel 'Windows Server 2008 R2 SP1*' -instanceSize 'Small' -storageAccountName 'mtestsg1' -serviceName 'M-Test-CS-0' -vnetName 'M-Test-VNet-1' -subnetName 'VNet-1-Subnet-A-3' -adminUserName 'Matt' -adminPassword 'Mulberry\w2014' -domainJoin 'corp.firstam.com' -domainOU 'CN=Computers,DC=corp,DC=firstam,DC=com' -domainCredential $(Get-Credential)

#>

#----------------------------------------------------------------------
#  Define parameters
#----------------------------------------------------------------------

[CmdletBinding(DefaultParameterSetName='NoDomain')]
Param(

    [Parameter(Mandatory=$True)]
    [string]$vmName,
	
    [Parameter(Mandatory=$True)]
    [string]$imageLabel,

    [Parameter(Mandatory=$True)]
    [ValidateSet("ExtraSmall","Small","Medium","Large","ExtraLarge","A5","A6","A7","A8","A9","Standard_D1","Standard_D2","Standard_D3","Standard_D4","Standard_D11","Standard_D12","Standard_D13","Standard_D14","Standard_DS3","Standard_G3","Standard_GS3")]
    [string]$instanceSize,
   
    [Parameter(Mandatory=$True)]
    [string]$storageAccountName,

    [Parameter(Mandatory=$True)]
    [string]$serviceName,

    [Parameter(Mandatory=$True)]
    [string]$vnetName,

    [Parameter(Mandatory=$True)]
    [string]$subnetName,

    [Parameter(Mandatory=$True)]
    [string]$adminUserName,
   
    [Parameter(Mandatory=$True)]
    [string]$adminPassword,
    
    [Parameter(ParameterSetName='Domain',Mandatory=$True)]
    [string]$domainJoin,
   
    [Parameter(ParameterSetName='Domain',Mandatory=$True)]
    [string]$domainOU,

    [Parameter(ParameterSetName='Domain',Mandatory=$True)]
    [PSCredential]$domainCredential
   
)

Begin {

    # Checks your current subscription name and uses that to determine the proper storage account to reference
    # for $scriptStorageAccount.
    # Updated by mblackman 8/12/2015

    $pattern = '([A-Z]{2})-(\d+)-AzureSub-(\d+)'

    $currentSubName = $(Get-AzureSubscription -Current).SubscriptionName

    if ( $currentSubName -match $pattern ) {

        $currentSubOwner  = $Matches[1]
        $currentSubAcct   = $Matches[2]
        $currentSubNumber = $Matches[3]

    } else {

        Write-Error "Unable to continue due to naming standard violation of current subscription"
    
    }

$scriptStorageAccount = "{0}a{1}s{2}azursa1" -f $currentSubOwner.ToLower(),$currentSubAcct,$currentSubNumber

    #----------------------------------------------------------------------
    #  Things that should probably be parameters but aren't
    #----------------------------------------------------------------------

    $scriptContainer = 'scripts'
    $scriptFileName = @('Configure-FAServerStandard.ps1')
    $scriptRun = 'Configure-FAServerStandard.ps1'

}

Process {

    #----------------------------------------------------------------------
    #  Construct calculated variables
    #----------------------------------------------------------------------

    $vmName = $vmName.ToUpper()

    $image = ( Get-AzureVMImage | 
                Where-Object -Property Label -like $imageLabel | 
                sort-object -property PublishedDate -Descending | 
                Select-Object -First 1 )

    $imageName = $image.ImageName
    $imageOS   = $image.OS

    $storageContainerURL = "https://$storageAccountName.blob.core.windows.net/vhds/"

    #----------------------------------------------------------------------
    #  Create the virtual machine
    #----------------------------------------------------------------------

    $newAzureVM = New-AzureVMConfig -ImageName $imageName `
                      -InstanceSize $instanceSize `
                      -Name $vmName `
                      -DiskLabel 'OS' `
                      -MediaLocation "$storageContainerURL$vmName-OS.vhd"

    switch ($imageOS) {

        "Windows" { 
                    if($domainJoin) {

                        $newAzureVM = $newAzureVM | Add-AzureProvisioningConfig -WindowsDomain `
                                                        -AdminUsername $adminUserName `
                                                        -Password $adminPassword `
                                                        -JoinDomain $domainJoin `
                                                        -MachineObjectOU $domainOU `
                                                        -Domain ($domainCredential.UserName).Split('\')[0] `
                                                        -DomainUserName ($domainCredential.UserName).Split('\')[1] `
                                                        -DomainPassword $domainCredential.GetNetworkCredential().Password `
                                                        -TimeZone 'Pacific Standard Time' `
                                                        -NoRDPEndpoint `
                                                        -NoWinRMEndpoint

                    } Else {
        
                        $newAzureVM = $newAzureVM | Add-AzureProvisioningConfig -Windows `
                                                        -AdminUsername $adminUserName `
                                                        -Password $adminPassword `
                                                        -TimeZone 'Pacific Standard Time' `
                                                        -NoRDPEndpoint `
                                                        -NoWinRMEndpoint

                    }

                  }

        "Linux"   {
                    $newAzureVM = $newAzureVM | Add-AzureProvisioningConfig -Linux `
                                                    -LinuxUser $adminUserName `
                                                    -Password $adminPassword `
                                                    -NoSSHEndpoint
                  }

    }

    $newAzureVM = $newAzureVM | Set-AzureSubnet -SubnetNames $subnetName

    # if we have joined the domain, run the configuration script
    if ($domainJoin) {

        $newAzureVM = $newAzureVM | Set-AzureVMCustomScriptExtension -ContainerName $scriptContainer `
                                        -StorageAccountName $scriptStorageAccount `
                                        -FileName $scriptFileName `
                                        -Run $scriptRun `
                                        -Argument "-serviceName $serviceName -dscScript $vmName.ps1"
    }

    write-host "Creating $imageOS VM named $vmName"

    $newAzureVM | New-AzureVM -ServiceName $serviceName -VNetName $vnetName

}

End {

    # Put any cleanup activities here

}