<#
.SYNOPSIS
Remove HotFixes on a Windows 2012 server until .NET 3.5 successfully installs
    
.DESCRIPTION
This script will remove HotFixes one at a time on a Windows 2012 server and then attempt to install .NET 3.5 repeatedly until it successfully installs.

.INPUTS
None

.OUTPUTS
None

.NOTES
Version:    1.1
Author:     Mark Skiba, Chris Throop
Date:       2/14/2019

.EXAMPLE
.\Remove-HotFixesUntil.Net3.5Installs.ps1

#>

#----------------------------------------------------------[Declarations]----------------------------------------------------------

$SxSLocationRoot = "C:\TEMP"
$SxSLocation = "c:\temp\SxS"
$SxSLocationSource1 = "\\fahqsna09dfil01\software\Microsoft\DotNet\3.5\Windows Server 2012 R2\SxS"
$SxSLocationSource2 = "\\azuvputlazur001.corp.firstam.com\software\PKG\Microsoft\Windows Server\2012\sources\sxs"
$ListOfHotfixesKnownProblematic = "KB4095875","KB4054999","KB4014581","KB2966828","KB4344153","KB4457045","KB4459924","KB4457009"
$ListOfHotfixes = Get-Hotfix | Sort-Object HotFixID -Desc
$ListOfHotFixes | Export-CSV "$SxSLocationRoot\hotfixes.csv" -NoTypeInformation
$OSVersion = (get-itemproperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Name ProductName).ProductName

#-----------------------------------------------------------[Execution]------------------------------------------------------------

if ($OSVersion -match "2012") {

    # Test SxS source file location
    if (test-path -Path "$SxSLocationSource2") {
        $SxSLocationSource = $SxSLocationSource2
    } elseif (test-path -Path "$SxSLocationSource1") {
        $SxSLocationSource = $SxSLocationSource1
    } else {
        Write-Warning -Message "Unable to reach SxS Source ... exiting script."
        exit
    }
    
    # If missing, copy SxS files local
    if (!(Get-Item $SxSLocation -ErrorAction SilentlyContinue)) {
        Write-Host $SxSLocation is missing! Attempting to copy the files ... -ForegroundColor Yellow
        mkdir $SxSLocationRoot
        mkdir $SxSLocation
        robocopy "$SxSLocationSource" $SxSLocation /s /e /r:0 /w:0
    }

    # Remove known problematic hotfixes first
    foreach ($item in $ListOfHotfixesKnownProblematic) {
        $Result = Install-WindowsFeature -Name Net-Framework-Core -Source "$SxSLocation" -ErrorAction SilentlyContinue
        if ($Result.ExitCode -eq "NoChangeNeeded") {
            $Result.ExitCode
            $Result
            Exit
        } elseif ($Result.ExitCode -match "Success") {
            $Result.ExitCode
            $Result
            Exit
        } else {
            $Result.ExitCode
        }
        $HotFixId = $item
        Write-Host "$HotFixId " -NoNewline
        $SearchUpdates = DISM.exe /Online /Get-packages | findstr "Package_for" 
        $PackageName = $SearchUpdates.replace("Package Identity : ", "") | findstr $HotfixID 
        $DISMResult = DISM.exe /Online /Remove-Package /PackageName:$PackageName /quiet /norestart
    }

    # Remove the remaining hotfixes in descending order
    foreach ($item in $ListOfHotfixes) {
        $Result = Install-WindowsFeature -Name Net-Framework-Core -Source "$SxSLocation" -ErrorAction SilentlyContinue
        if ($Result.ExitCode -eq "NoChangeNeeded") {
            $Result.ExitCode
            $Result
            Exit
        } elseif ($Result.ExitCode -match "Success") {
            $Result.ExitCode
            $Result
            Exit
        } else {
            $Result.ExitCode
        }
        $HotFixId = $item.HotFixId
        Write-Host "Removing $HotFixId ... .NET 3.5 Install Status: " -NoNewline
        $SearchUpdates = DISM.exe /Online /Get-packages | findstr "Package_for" 
        $PackageName = $SearchUpdates.replace("Package Identity : ", "") | findstr $HotfixID 
        $DISMResult = DISM.exe /Online /Remove-Package /PackageName:$PackageName /quiet /norestart
    }

} else {
    Write-Host This script applies to only to Windows 2012 -ForegroundColor Yellow
}