﻿# Import the Azure module
Import-Module Azure 

# Using the location of the Azure module as a guide, go to where the Express Route module should be
$azureModulePath = (Get-Module Azure).Path
cd "$azureModulePath\..\ExpressRoute"

# Import the Express Route module
Import-Module .\ExpressRoute.psd1

# Select the subscription we will be using
Select-AzureSubscription SO-1-AzureSub-1

# Commands to get information - helpful for validation of syntax, but not necessary
# Get-AzureDedicatedCircuitServiceProvider | ? Name -eq "Equinix"                                                                                           
# Get-AzureDedicatedCircuitServiceProvider | ? Name -eq "Equinix" | select -ExpandProperty DedicatedCircuitBandwidths                                       
# Get-AzureDedicatedCircuitServiceProvider | ? Name -eq "Equinix" | select -ExpandProperty DedicatedCircuitLocations

# Uncomment the next line to actually create a circuit if you run this
# New-AzureDedicatedCircuit -CircuitName "SO-1-1-AZUR-ER-1" -Bandwidth "500" -Location "Silicon Valley" -ServiceProviderName "Equinix"

# Temp Cicuit to fix public peer issue
# New-AzureDedicatedCircuit -CircuitName "SO-1-1-AZUR-ER-2" -Bandwidth "500" -Location "Silicon Valley" -ServiceProviderName "Equinix"

<#  Output from our first run

# Real Circuit

Bandwidth                        : 500
CircuitName                      : SO-1-1-AZUR-ER-1
Location                         : Silicon Valley
ServiceKey                       : 01b77e14-af50-4645-b382-8b3003ec49ec
ServiceProviderName              : equinix
ServiceProviderProvisioningState : NotProvisioned
Status                           : Enabled


# Temp Circuit

Bandwidth                        : 500
CircuitName                      : SO-1-1-AZUR-ER-2
Location                         : Silicon Valley
ServiceKey                       : 07573ca9-bc5c-4304-abc7-df91e69414e4
ServiceProviderName              : equinix
ServiceProviderProvisioningState : NotProvisioned
Status                           : Enabled

#>


# Service key from your previously created and provisioned circuit 
$ServiceKey = '01b77e14-af50-4645-b382-8b3003ec49ec'
$tempServiceKey = '07573ca9-bc5c-4304-abc7-df91e69414e4'

# MD5 Hash to authenticate BGP sessions 
# - We decided not do use this - didn't know if the format needed dashes or not 
#$MD5Hash = "[your MD5 hash password]" 

# Subnets used for configuring private peering 
$private_Subnet_Primary   = "10.64.255.0/30" 
$private_Subnet_Secondary = "10.64.255.4/30" 

# Subnets used for configuring public peering 
$public_Subnet_Primary    = "10.64.255.8/30"
$public_Subnet_Secondary  = "10.64.255.12/30"

# Subnets used for configuring public peering 
$temp_public_Subnet_Primary    = "10.64.255.16/30"
$temp_public_Subnet_Secondary  = "10.64.255.20/30"

# Autonomous System Number - this is updated, we originally tried 65260
$ASN = "4323" 

# VLAN ID for private peering 
$VLANPrivate = "100" # Selected by TWT

# VLAN ID for public
$VLANPublic  = "101" # Selected by TWT
$tempVLANPublic  = "102" # Selected by TWT

<# ---- Commented out for safety ----

# Create the private peering configuration 
New-AzureBGPPeering -ServiceKey $ServiceKey `
                    -PrimaryPeerSubnet $private_Subnet_Primary `
                    -SecondaryPeerSubnet $private_Subnet_Secondary `
                    -PeerAsn $ASN `
                    -VlanId $VLANPrivate `
                    –AccessType Private  


#>

<# Result from prior command (note: this was redone later - updated results below):

AzureAsn            : 12076
PeerAsn             : 65260
PrimaryAzurePort    : EQIX-SJC-06GMR-CIS-3-PRI-A
PrimaryPeerSubnet   : 10.64.255.0/30
SecondaryAzurePort  : EQIX-SJC-06GMR-CIS-4-SEC-A
SecondaryPeerSubnet : 10.64.255.4/30
State               : Enabled
VlanId              : 100

#>

<# ---- Commented out for safety ----

# Create the public peering configuration 
New-AzureBGPPeering -ServiceKey $ServiceKey `
                    -PrimaryPeerSubnet $public_Subnet_Primary `
                    -SecondaryPeerSubnet $public_Subnet_Secondary `
                    -PeerAsn $ASN `
                    -VlanId $VLANPublic `
                    -AccessType Public  

#>

<# Result from prior command (note: this was redone later - updated results below):

AzureAsn            : 12076
PeerAsn             : 65260
PrimaryAzurePort    : EQIX-SJC-06GMR-CIS-3-PRI-A
PrimaryPeerSubnet   : 10.64.255.8/30
SecondaryAzurePort  : EQIX-SJC-06GMR-CIS-4-SEC-A
SecondaryPeerSubnet : 10.64.255.12/30
State               : Enabled
VlanId              : 101

#>


<#

# Create the temp private peering configuration 
New-AzureBGPPeering -ServiceKey $tempServiceKey `
                    -PrimaryPeerSubnet $temp_public_Subnet_Primary `
                    -SecondaryPeerSubnet $temp_public_Subnet_Secondary `
                    -PeerAsn $ASN `
                    -VlanId $tempVLANPublic `
                    –AccessType Public

#>

<#  Output from the above

AzureAsn            : 12076
PeerAsn             : 4323
PrimaryAzurePort    : EQIX-SJC-06GMR-CIS-3-PRI-A
PrimaryPeerSubnet   : 10.64.255.16/30
SecondaryAzurePort  : EQIX-SJC-06GMR-CIS-4-SEC-A
SecondaryPeerSubnet : 10.64.255.20/30
State               : Enabled
VlanId              : 102

#>


<# ----- Used to fix environment after initial ASN set incorrectly

Set-AzureBGPPeering -ServiceKey $ServiceKey `
                    -PrimaryPeerSubnet $private_Subnet_Primary `
                    -SecondaryPeerSubnet $private_Subnet_Secondary `
                    -PeerAsn $ASN `
                    -VlanId $VLANPrivate `
                    –AccessType Private

#>

<# Output from the above

AzureAsn            : 12076
PeerAsn             : 4323
PrimaryAzurePort    : EQIX-SJC-06GMR-CIS-3-PRI-A
PrimaryPeerSubnet   : 10.64.255.0/30
SecondaryAzurePort  : EQIX-SJC-06GMR-CIS-4-SEC-A
SecondaryPeerSubnet : 10.64.255.4/30
State               : Enabled
VlanId              : 100

#>

<# ----- Used to fix environment after initial ASN set incorrectly

Set-AzureBGPPeering -ServiceKey $ServiceKey `
                    -PrimaryPeerSubnet $public_Subnet_Primary `
                    -SecondaryPeerSubnet $public_Subnet_Secondary `
                    -PeerAsn $ASN `
                    -VlanId $VLANPublic `
                    –AccessType Public

#>

<# Output from the above

AzureAsn            : 12076
PeerAsn             : 4323
PrimaryAzurePort    : EQIX-SJC-06GMR-CIS-3-PRI-A
PrimaryPeerSubnet   : 10.64.255.8/30
SecondaryAzurePort  : EQIX-SJC-06GMR-CIS-4-SEC-A
SecondaryPeerSubnet : 10.64.255.12/30
State               : Enabled
VlanId              : 101

#>

# Connect the VNETs to Express Route

# New-AzureDedicatedCircuitLink -ServiceKey $ServiceKey -VNetName "SO-1-1-IaaS-VN-1"

# New-AzureDedicatedCircuitLink -ServiceKey $ServiceKey -VNetName "SO-1-1-PaaS-VN-1"

# New-AzureDedicatedCircuitLink -ServiceKey $ServiceKey -VNetName "SO-1-1-PaaS-VN-2"

# New-AzureDedicatedCircuitLink -ServiceKey $ServiceKey -VNetName "SO-1-1-PaaS-VN-3"

# Removing PaaS-VN2 and renaming to IaaS-VN2
# Remove-AzureDedicatedCircuitLink -ServiceKey $ServiceKey -VNetName "SO-1-1-PaaS-VN-2"
# New-AzureDedicatedCircuitLink -ServiceKey $ServiceKey -VNetName "SO-1-1-IaaS-VN-2"

# VNETs for SO-1-AzureSub-4 subscription

# New-AzureDedicatedCircuitLinkAuthorization -ServiceKey '01b77e14-af50-4645-b382-8b3003ec49ec' -Description 'SO-1-AzureSub-4'

# New-AzureDedicatedCircuitLink -ServiceKey $ServiceKey -VNetName "SO-1-4-IaaS-VN-1"

# New-AzureDedicatedCircuitLink -ServiceKey $ServiceKey -VNetName "SO-1-4-IaaS-VN-2"

# New-AzureDedicatedCircuitLink -ServiceKey $ServiceKey -VNetName "SO-1-4-IaaS-VN-3"

# New-AzureDedicatedCircuitLink -ServiceKey $ServiceKey -VNetName "SO-1-4-PaaS-VN-1"


<# ---------- Stopped here ---------- #>

