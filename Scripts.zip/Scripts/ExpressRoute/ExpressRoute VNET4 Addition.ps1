﻿# Import the Azure module
Import-Module Azure 

# Using the location of the Azure module as a guide, go to where the Express Route module should be
$azureModulePath = (Get-Module Azure).Path
cd "$azureModulePath\..\ExpressRoute"

# Import the Express Route module
Import-Module .\ExpressRoute.psd1

# Select the subscription we will be using
Select-AzureSubscription SO-1-AzureSub-4

# Commands to get information - helpful for validation of syntax, but not necessary
# Get-AzureDedicatedCircuitServiceProvider | ? Name -eq "Equinix"                                                                                           
# Get-AzureDedicatedCircuitServiceProvider | ? Name -eq "Equinix" | select -ExpandProperty DedicatedCircuitBandwidths                                       
# Get-AzureDedicatedCircuitServiceProvider | ? Name -eq "Equinix" | select -ExpandProperty DedicatedCircuitLocations

# Uncomment the next line to actually create a circuit if you run this
# New-AzureDedicatedCircuit -CircuitName "SO-1-1-AZUR-ER-1" -Bandwidth "500" -Location "Silicon Valley" -ServiceProviderName "Equinix"

# Temp Cicuit to fix public peer issue
# New-AzureDedicatedCircuit -CircuitName "SO-1-1-AZUR-ER-2" -Bandwidth "500" -Location "Silicon Valley" -ServiceProviderName "Equinix"

# Run the below and change the description to what the subscription would be.
# PS P:\> New-AzureDedicatedCircuitLinkAuthorization -ServiceKey '01b77e14-af50-4645-b382-8b3003ec49ec' -Description "SO-1-AzureSub-4" -MicrosoftIds 'fahq-ra-soazure1@firstam.com'
<# Output from above
cmdlet New-AzureDedicatedCircuitLinkAuthorization at command pipeline position 1
Supply values for the following parameters:
(Type !? for Help.)
Limit: 4
Description         : SO-1-AzureSub-4
Limit               : 4
LinkAuthorizationId : d801c051-e3b8-4f8d-a7c4-e1afa74d3a11
MicrosoftIds        : fahq-ra-soazure1@firstam.com
Used                : 0

#>

# Run the below to verify that the circuit is authorized
# PS P:\> Get-AzureAuthorizedDedicatedCircuit
<# Ouput from command
Bandwidth                        : 500
CircuitName                      : SO-1-1-AZUR-ER-1
Location                         : Silicon Valley
MaximumAllowedLinks              : 4
ServiceKey                       : 01b77e14-af50-4645-b382-8b3003ec49ec
ServiceProviderName              : equinix
ServiceProviderProvisioningState : Provisioned
Status                           : Enabled
UsedLinks                        : 0 
#>

# Make sure that the Gateways are created in AZURE for each VNET below before continuing.

# VNETs for SO-1-AzureSub-4 subscription

# New-AzureDedicatedCircuitLink -ServiceKey $ServiceKey -VNetName "SO-1-4-IaaS-VN-1"

# New-AzureDedicatedCircuitLink -ServiceKey $ServiceKey -VNetName "SO-1-4-IaaS-VN-2"

# New-AzureDedicatedCircuitLink -ServiceKey $ServiceKey -VNetName "SO-1-4-IaaS-VN-3"

# New-AzureDedicatedCircuitLink -ServiceKey $ServiceKey -VNetName "SO-1-4-PaaS-VN-1"

# Or run the commands below
# New-AzureDedicatedCircuitLink -ServiceKey '01b77e14-af50-4645-b382-8b3003ec49ec' -VNetName "SO-1-4-IaaS-VN-1" 
# New-AzureDedicatedCircuitLink -ServiceKey '01b77e14-af50-4645-b382-8b3003ec49ec' -VNetName "SO-1-4-IaaS-VN-2" 
# New-AzureDedicatedCircuitLink -ServiceKey '01b77e14-af50-4645-b382-8b3003ec49ec' -VNetName "SO-1-4-IaaS-VN-3" 
# New-AzureDedicatedCircuitLink -ServiceKey '01b77e14-af50-4645-b382-8b3003ec49ec' -VNetName "SO-1-4-PaaS-VN-1"
<# ---------- Stopped here ---------- #>

