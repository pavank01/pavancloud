##################################
# ASG NIC Membership
# by. Joe O'Brien 1/29/2021 - V1.1

$cred = Get-Credential
Add-AzureRMAccount -Credential $cred
Write-Host "Please enter the following information related to the Application Security Group:"
$ASGName = Read-Host -Prompt 'ASG: Name: '
$SubscriptionName = Read-Host -Prompt 'ASG: Subscription Name: '
$ResourceGroupName = Read-Host -Prompt 'ASG: Resource Group Name: '

#Login to Azure using Get-Credentials
Write-Host ""
Write-Host "Logging into Subscription------------------------------------------------"
Set-AzureRMContext -SubscriptionName $SubscriptionName
Write-Host ""

#Find NIC members of an ASG
Write-Host "List of NICs associated to ASG--------------------------------------------"
Get-AzureRmNetworkInterface | Where-Object { $_.IpConfigurations.ApplicationSecurityGroups.Id -like "*$ASGName*" } | select-object -property Name | format-list| Out-String | ForEach-Object { $_.Trim() }
Write-Host ""