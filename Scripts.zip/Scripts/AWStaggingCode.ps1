#Set Profile using One note page- AWS CLI configuration and Profile set up

aws-azure-login --profile xacc-n-0

#Id_ceng contains Accound Ids for which taggings has to be retrieved

$AccountIdList = (get-content "C:\Users\swsahoo\Desktop\AWS-Tag\Id_ceng.txt")
$count = 0  #this is a check to confirm total account numbers
ForEach ($AccountId in $AccountIdList){
    $count++
    $arn = "arn:aws:iam::$AccountId" + ":role/FirstAm_super-pds"
    $assume_role = aws sts assume-role --role-arn $arn --role-session-name test-tagDetails --profile xacc-n-0 --no-verify-ssl 
    $a = $assume_role  | ConvertFrom-Json  
  
    ForEach ($x in $a){
        $env:AWS_Access_Key_ID = $x.Credentials.AccessKeyId
        $env:AWS_SECRET_Access_Key = $x.Credentials.SecretAccessKey
        $env:AWS_SESSION_TOKEN = $x.Credentials.SessionToken
    }

    $data = aws ec2 describe-tags --query 'Tags[?ResourceType==`instance`]' --region us-east-2 --no-verify-ssl
    $h = $data | ConvertFrom-Json
    $hg = $h | Group-Object ResourceID
    $report = @()
    ForEach ($i In $hg) {
        $report += [PSCustomObject][Ordered]@{
        instanceID      = $i.Name  # <-- i-01f4c9f8cfd47a63e
        Name            = ( $i.Group | Where-Object {$_.Key.Trim() -eq "Name"} ).Value
        ApplicationID   = ( $i.Group | Where-Object {$_.Key.Trim() -eq "ApplicationID"} ).Value
        ApplicationName = ( $i.Group | Where-Object {$_.Key.Trim() -eq "ApplicationName"} ).Value
        ApplicationServiceName = ( $i.Group | Where-Object {$_.Key.Trim() -eq "ApplicationServiceName"} ).Value
        BusinessApplicationNumber = ( $i.Group | Where-Object {$_.Key.Trim() -eq "BusinessApplicationNumber"} ).Value
        ApplicationServiceNumber = ( $i.Group | Where-Object {$_.Key.Trim() -eq "ApplicationServiceNumber"} ).Value
        BusinessApplicationName = ( $i.Group | Where-Object {$_.Key.Trim() -eq "BusinessApplicationName"} ).Value
        AWSAccountId = $AccountId
    }
}
$report | Export-CSV C:\Users\swsahoo\Desktop\AWS-Tag\aws-tagreport-nonProd.csv -noTypeInfo -Append
}
Write-Host "Count:  $count" #confirms total aws account numbers

