﻿Param(

    [Parameter(Mandatory=$false)]
    [pscredential]$DomainCred = $null,

    [Parameter(Mandatory=$false)]
    [string]$ConfigFile

)

#Load Globals

[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")

# 2015-03-24 : MA : Commented out to allow for exit commands to return error codes
#$ErrorActionPreference = "Stop"

Function Gen-DSCConfig {

    #region - Get Config
	$Role = $VM.Role.Name
	$Version = $VM.Role.Version
	$Env = $Cloud.Environment
	$BuildList = @($DSCConfig.Composite.Roles.Role | Where-Object {$_.Name -eq $Role -and $_.Version -eq $Version} | ForEach-Object {$_.Components.Component})
	$VMName = $vm.Name
	$Variables = $null
	$Installables = $null
	$Modules = $null
	$CIList = $null
	ForEach ($build in $BuildList) {

        If ($Build.Variable) {
			$Variables += $Build.Variable + "`r`n"
		}

		$Installables += @($DSCConfig.Composite.Installables.Installable | Where-Object {$_.Name -eq $Build.Name})

    }
    
    foreach ($Installable in $Installables) {
    
        If ($Installable.Variable) {
            $Variables += $Installable.Variable
        }
        
        ForEach-Object {
            $Installable.Resource | Where-Object {$_.Name -ne $null} | ForEach-Object {
                $Modules += @($_.Name)
            }
        }

        $CIList += $Installable.CfgItem

    }
    #endregion - Get Config
    
    #region - Build Composite
    $Composite = "
        Param (
            [Parameter(Mandatory=`$false)]
            [string]`$dscUserName,

            [Parameter(Mandatory=`$false)]
            [string]`$dscPassword,

            [Parameter(Mandatory=`$true)]
            [string]`$Logfile
        )

        `$SoftwareSource = `"$SoftwareSource`"
        `$LocalSoftwareSource = `"$LocalSoftwareSource`"
        `$Env = `"$Env`"

        $($Variables)

        Function Log-Message(`$Status,`$Message) {
            
            `$LogEntry = `"<![LOG[`$Message]LOG]!><time=```"`$(Get-Date -Format HH:mm:ss.ffff)```" date=```"`$(Get-Date -Format MM-dd-yyyy)```" component=```"`$env:COMPUTERNAME```" type=```"Verbose```" status=```"`$Status```">`"
            
            Add-Content -Path `$LogFile -Value `$LogEntry

            Write-Host `$Message
        }

        Log-Message -Status `"Starting`" -Message `"Starting DSC Script on `$env:COMPUTERNAME`" -Logfile `$Logfile
        
        # 2015-09-04 - mblackman - Check for PowerShell version less than 4.0 and exit if it is not present.
        If ( (`$PSVersionTable).PSVersion -lt `"4.0`" ) {
        
            Log-Message -Status `"Error`" -Message `"PowerShell 4.0 is not installed.  Aborting.`" -Logfile `$Logfile
            Throw `"Unable to continue - PowerShell 4.0 is not installed.`"

        }

        #Start WinRM if not running (Delayed Start on reboot)
        If ( (Get-Service -Name `"WinRM`").Status -ne `"Running`" ) {
            Start-Service -Name WinRM
            Log-Message -Status `"InProgress`" -Message `"Started WinRM`" -Logfile `$Logfile
        }
        
        # 2015-09-04 - mblackman - Enable remote management (needed for 2012 R2).
        winrm quickconfig -q -force

        If ( (Get-ExecutionPolicy -Scope LocalMachine) -ne `"Unrestricted`" ) {
            Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope LocalMachine -Force
            Log-Message -Status `"InProgress`" -Message `"Setting PowerShell Execution Policy to Unrestricted`" -Logfile `$Logfile
        }

        #Export Cert for DSC
        `$Cert = Get-ChildItem Cert:\LocalMachine\My | ? { `$_.Subject -eq `"CN=$CertSubjectName`" }

        `$CertFile= `"$LocalSoftwareSource\DSCInstall.cer`"

        Export-Certificate -Cert `$Cert -FilePath `$CertFile

        #Turn on analytic event log
        wevtutil.exe set-log `“Microsoft-Windows-Dsc/Analytic`” /q:true /e:true 

        `$MOFConfig= 
        @{ 
            AllNodes = @( 
               @{ 
                   NodeName = `"localhost`" 
                   CertificateFile = `$CertFile 
                   Thumbprint = `$Cert.Thumbprint 
                } 
            ) 
         } 

        Configuration $VMName {
        "

    If ($Modules) {
        $Composite += "
            Import-DscResource -modulename $($Modules -join',')
        "
    }

    $Composite += "
            Node 'localhost' {
                $CIList

                Script StopDSCLog {
                    GetScript = { @{ Result = `$Null } }
                    SetScript = {
                        `$Message = `"Finished Executing DSC Configuration on `$env:COMPUTERNAME`"
                        `$Status = `"Complete`"
                        `$LogEntry = `"<![LOG[`$Message]LOG]!><time=```"`$(Get-Date -Format HH:mm:ss.ffff)```" date=```"`$(Get-Date -Format MM-dd-yyyy)```" component=```"`$env:COMPUTERNAME```" type=```"Verbose```" status=```"`$Status```">`"

                        Add-Content -Path `"`$using:LogFile`" -Value `$LogEntry
                    }
                    TestScript = { `$False }
                }
                
                # Turn off DSC analytic logging
                Script TurnOffAnalyticLogging {
                    GetScript = { @{ Result = `$Null } }
                    # When TestScript returns `$False, SetScript will be called during runtime. If `$True, SetScript will be not be called
                    TestScript = {
                        If (((wevtutil.exe get-log `“Microsoft-Windows-Dsc/Analytic`”)[1].Split(`"  `")[1]) -ne `"false`") {
                            `$True
                        } Else {
                            `$False
                        } 
                    }
                    # turn off logging
                    SetScript = { C:\Windows\System32\wevtutil.exe set-log Microsoft-Windows-Dsc/Analytic /q:true /e:false }
                }
                
                # Allow reboots if needed
                LocalConfigurationManager {
                    RebootNodeIfNeeded = `$true
                    CertificateID = `$Cert.Thumbprint
                }

            }
        }
        $VMName -ConfigurationData `$MOFConfig -OutputPath .\Mof
         
        Set-DscLocalConfigurationManager .\Mof -Verbose
         
        # Remove the scheduled task
        schtasks.exe /Delete /TN `"\Microsoft\Windows\Desired State Configuration\FAConfiguration`" /F

        Start-DscConfiguration -Path .\Mof
        "

    #endregion - Build Composite
    
    #region - Build Config

    If ( !(Test-Path -Path $DSCSource\$($Cloud.Name) -PathType Container) ) {
	
	    New-Item -Path $DSCSource\$($Cloud.Name) -ItemType Directory

	}
        
    $Composite | Out-File -FilePath "$DSCSource\$($Cloud.Name)\$VMName.ps1" -Force

    Publish-AzureVMDscConfiguration -ConfigurationPath "$DSCSource\$($Cloud.Name)\$VMName.ps1" -ConfigurationArchivePath "$DSCSource\$($Cloud.Name)\$VMName.ps1.zip" -Force
       
    #endregion - Build Config
}

Function Get-Confirmation($Message) {

    $caption = "Attention!"
    $yesNoButtons = 4

    $YN = [System.Windows.Forms.MessageBox]::Show($message, $caption, $yesNoButtons, "Question")
    
    Return $YN
}

Function Get-FileName($Title) {   

     $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
     $OpenFileDialog.title = $Title
     $OpenFileDialog.filter = "All files (*.*)| *.*"
     $OpenFileDialog.ShowDialog() | Out-Null
     $OpenFileDialog.filename

} #end function Get-FileName

Function Get-pwd($msg) {

    $vmpwcomp = ""
    While ($vmpwcomp -ne 0) {
	    #Read initial Password input and encrypt
	    [System.Security.SecureString]$vmpwSecureStringValue = Read-Host $msg -AsSecureString 
	    [String]$vmpw = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($vmpwSecureStringValue))
			
	    #Ask for Password verification and encrypt
	    [System.Security.SecureString]$vmpwconfirmSecureStringValue = Read-Host $msg " -Confirmation" -AsSecureString 
	    [String]$vmpwconfirm = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($vmpwconfirmSecureStringValue))
			
	    $vmpwcomp = [string]::Compare($vmpw, $vmpwconfirm, $False)
        If ($vmpwcomp -ne 0) {Log-Message -Status "Error" -Message "Passwords must match" -Logfile $Logfile}

    }

    #When passwords match, put password in variable

    Return $vmpw

}

Function Ingest-XML($xmllist,$msg) {

    # if XML file path wasn't provided
    If (!$xmllist) {

        # open a dialog box to prompt for it
        $xmllist = Get-Filename($msg)

    }

    If ( $xmllist -and (Test-Path $xmllist) ) {

        # Read the XML file
        $xmlobjects = [XML] (Get-Content -path $xmllist)
        Return $xmlobjects

    } Else { 

        Write-Error "Configuration file not found: $xmllist"
        Exit 1
        break

    }

}

Function Log-Message($Status,$Message) {
    
    $LogEntry = "<![LOG[$Message]LOG]!><time=`"$(Get-Date -Format HH:mm:ss.ffff)`" " +`
                "date=`"$(Get-Date -Format MM-dd-yyyy)`" component=`"$vmName`" type=`"Verbose`" status=`"$Status`">"
	
    Add-Content -Path $LogFile -Value $LogEntry

    Write-Host $Message
}

Function New-VMConfig ($VM) {

    If ($vm.config) {
    
        # dynamically construct variables that override the defaults for the configuration
        $VM.Config | ForEach-Object {
        
            Invoke-Expression ("`$" + $_.Name + " = `"" + $_.Value + "`"")
        
        }

    }
   
    #----------------------------------------------------------------------
    #  Construct calculated variables
    #----------------------------------------------------------------------

    $AdminPassword = "A!2"
    $rand = New-Object System.Random
	    #Generate a new 10 character password
    1..10 | ForEach { $AdminPassword = $AdminPassword + [char]$rand.next(33,127) }
    
    #Format OS disk label with name components
	$osfulldisklabel = ($vm.Name).ToUpper() + "-OS"
	$osmediapath = $OSContainerPath + $osfulldisklabel + ".vhd"
			
	# TODO: Fix #5
    #Format disk label with name components
	$ddfulldisklabel = ($vm.Name).ToUpper() + "-Data" + $LunNbr
	$ddmediapath = $DDContainerPath + $ddfulldisklabel + ".vhd"

    $DSCCert = (Get-ChildItem Cert:\LocalMachine\My | ? { $_.Subject -eq "CN=$CertSubjectName" })
    
    $image = ( Get-AzureVMImage | 
			    Where-Object -Property Label -like $imageLabel | 
                sort-object -property PublishedDate -Descending | 
                Select-Object -First 1 )

    #$imageName = $image.ImageName
    $imageName = 'a699494373c04fc0bc8f2bb1389d6106__Windows-Server-2012-Datacenter-20180111-en.us-127GB.vhd'

    $imageOS   = $image.OS

    #----------------------------------------------------------------------
    #  Create the virtual machine
    #----------------------------------------------------------------------

    $newAzureVM = New-AzureVMConfig -ImageName $imageName `
                      -InstanceSize $instanceSize `
                      -Name $vmName `
                      -DiskLabel 'OS' `
                      -MediaLocation $osmediapath

    switch ($imageOS) {

        "Windows" { 
                    if($domain) {

                        $newAzureVM = $newAzureVM | Add-AzureProvisioningConfig -WindowsDomain `
                                                        -AdminUsername $adminUserName `
                                                        -Password $adminPassword `
                                                        -TimeZone $MachineTimeZone `
                                                        -JoinDomain $domain `
                                                        -MachineObjectOU $domainOU `
                                                        -Domain ($domainCred.UserName).Split('\')[0] `
                                                        -DomainUserName ($domainCred.UserName).Split('\')[1] `
                                                        -DomainPassword $domainCred.GetNetworkCredential().Password `
                                                        -X509Certificates $DSCCert `
                                                        -NoRDPEndpoint `
                                                        -NoWinRMEndpoint

                    } Else {
    
                        $newAzureVM = $newAzureVM | Add-AzureProvisioningConfig -Windows `
                                                        -AdminUsername $adminUserName `
                                                        -Password $adminPassword `
                                                        -TimeZone $MachineTimeZone `
                                                        -X509Certificates $DSCCert `
                                                        -NoRDPEndpoint `
                                                        -NoWinRMEndpoint

                    }

                  }

        "Linux"   {
                    $newAzureVM = $newAzureVM | Add-AzureProvisioningConfig -Linux `
                                                    -LinuxUser $adminUserName `
                                                    -Password $adminPassword `
                                                    -NoSSHEndpoint
                  }

    }

    $newAzureVM = $newAzureVM | Set-AzureSubnet -SubnetNames $subnetName

    #Set Static if specified
    If($IPAddress) {

        $newAzureVM = $newAzureVM | Set-AzureStaticVNETIP -IPAddress $IPAddress
        Log-Message -Status "InProgress" -Message "Static IP Configured on $VMName" -Logfile $Logfile

    }

    # if we have joined the domain, run the configuration script
    If($domain) {

        $newAzureVM = $newAzureVM | Set-AzureVMCustomScriptExtension -ContainerName $scriptContainer `
                                        -StorageAccountName $scriptStorageAccount `
                                        -FileName $scriptFileName `
                                        -Run $scriptFileName `
                                        -Argument "-serviceName $($Cloud.Name) -softwareSource $softwareSource -SoftwareStaging $LocalSoftwareSource -dscSource $dscSource -LogFile $Logfile"
    }

    Log-Message -Status "InProgress" -Message "Creating $imageOS VM named $vmName" -Logfile $Logfile

    Return $newAzureVM

}

Function Set-Subscription($Subscription,$StorageAcct) {

    $CurrentSubscription = Get-AzureSubscription -Current

    If ($CurrentSubscription.SubscriptionName -ne $Subscription) {
        Select-AzureSubscription -Current -SubscriptionName $Subscription
        $CurrentSubscription = Get-AzureSubscription -Current
    }
    If ($CurrentSubscription.CurrentStorageAccountName -ne $StorageAcct) {
        Set-AzureSubscription -SubscriptionName $Subscription -CurrentStorageAccount $StorageAcct
    }

}

### Script Body###
$VMXML = Ingest-XML -xmllist $ConfigFile -msg "Please select the VM Config XML file"

# Select the azure subscription and default storage account specified in the config file
Set-Subscription ($VMXML.ProvisionVMs.Subscription).Name ($VMXML.ProvisionVMs.Subscription).StorageAcct

$Cloud = $VMXML.ProvisionVMs.Subscription.Cloud

# Check to see if the cloud service doesn't exist
# TODO: Fix #1
If ( !( Get-AzureService | Where-Object { $_.ServiceName -eq $Cloud.Name } ) ) {

    #Check for dns name availability

    If (Test-AzureName –Service $Cloud.Name) {
    
        # the cloud service name is taken - AND it's not ours
        # so realistically if we get here we should just fail

        Write-Host "Service Name DNS record already exists creation of $($Cloud.Name) will be skipped"
        Continue

    } Else {

        #If it does not exist, and is available, create Cloud Service before provisioning VM

        Write-Host "InProgress" -Message "Creating Service"
        New-AzureService -Location $Cloud.Location -ServiceName $Cloud.Name
   
    }

}

# Set default variables based on 'Config' elements in the XML structure
$Cloud.Defaults.Config | Where-Object {$_.Name -ne $null} | ForEach-Object {
    Invoke-Expression ("`$" + $_.Name + " = `"" + $_.Value + "`"")
}

# Read DSC XML file specified in the Environment XML file
If (Test-Path "$DSCConfigFile") {

    Try { 

        $DSCConfig = [XML] (Get-Content "$DSCConfigFile") 

    } Catch { 

        Write-Error "Invalid DSC configuration file: $DSCConfigFile" 
        Exit 1

    }

} Else {

    # TODO: Fix #2
    Write-Error  "Missing DSC configuration file: $DSCConfigFile"
    Exit 1
    Break

}

# Prompt for Domain userid/password if needed
# TODO: Fix #3
If ($Domain) {
    If (!$DomainCred) {
        $DomainCred = Get-Credential -Message "Please Enter the username and pwd that has permissions to join the domain: $($Domain)" -UserName "corp\username"
    }
}

# Create an array of VM definitions from the Environment XML structure
$VMs = $Cloud.VMs | ForEach-Object { $_.VM }

foreach ($VM in $VMs) {

    $vmName = $VM.Name.ToUpper()

    $startTime = Get-Date

    Write-Host "`nBeginning processing of VM $vmName at $($startTime.ToString('T'))..."
    
	# Check for the existence of the VM in the current cloud service
    # TODO: Fix #4
    If ( !( Get-AzureVM -ServiceName $Cloud.Name | Where { $_.Name -eq $VMName } ) ) {

		#Initialize Log file
		$Logfile = "$CentralLogTarget\$($Cloud.Name)\$vmName.log"

		If ( !( Test-Path (Split-Path $Logfile) ) ) { New-Item -Path (Split-Path $Logfile) -ItemType Directory }

		Log-Message -Status "Starting" -Message "*** Starting build of $($VM.name) ***" -Logfile $Logfile 

		Gen-DSCConfig

		$NewVMConfig = New-VMConfig -VM $VM

		$elapsedTime = Measure-Command { New-AzureVM -ServiceName $Cloud.Name -VNetName $Cloud.vNet -VMs $NewVMConfig }
        $stopTime = Get-Date
      
        Write-Host "Created VM $vmName in $(($stopTime-$startTime).TotalMinutes) minutes ($($elapsedTime.TotalMinutes) in Azure VM creation)."

        Log-Message -Status "Complete" -Message "Azure New-VM complete" -Logfile $Logfile
		
	} Else {

		Write-Host "VM $vmName already exists.  Skipping to next VM."
        Continue

    }

}

# Return an errorlevel based onthe number of errors that have occurred
# Zero indicates no errors
Exit $Error.Count
