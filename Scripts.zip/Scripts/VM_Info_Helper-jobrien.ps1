#######################################################################################
# by Joe O'Brien, 1/14/2021, easy tool to check vSphere for helpful information on VM.
#  - Usefull for Mapping, System Identification...etc.
#######################################################################################

#Imports Needed Modules
Import-Module VMware.VimAutomation.Core
Import-Module VMware.VimAutomation.Vds

#Prompt User for Questions, stores as variables
$vCenter = Read-Host -Prompt 'vCenter Name'
$VMname = Read-Host -Prompt 'VM'

#Connection to vSphere, verifies VM exists
Connect-VIServer -Server $vCenter
$vm = Get-VM -Name $VMname

#Report Output
Write-Host ""
Write-Host "------------------------------------------"
Write-Host "vCenter: '$vCenter'" 
Write-Host "VMName: '$vm'"
Get-VM $vm | Select-Object Notes | format-list| Out-String | ForEach-Object { $_.Trim() }
Write-Host "------------------------------------------"
Write-Host "'$vm' Custom Attributes"
Write-Host "---------------------"
$vm | Get-Annotation | select-object Name, Value | format-table -autosize | Out-String | ForEach-Object { $_.Trim() }
Write-Host "------------------------------------------"
Write-Host "'$vm' Disk Information"
(Get-VMGuest $VMname).disks | select-object | Out-String | ForEach-Object { $_.Trim() }
Write-Host "-------------------END--------------------"
