﻿[CmdletBinding()]
Param (

    [Parameter(Mandatory=$false)]
    [string]$ConfigFile,

    [switch]$Continuous

)
#Load Globals

[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")

$ErrorActionPreference = "Stop"

Function Get-BuildStatus {
    
    $logfile = $null
    $UIHeight = "50" #$Host.UI.RawUI.WindowSize.Height - 2
    $UIWidth = "120" #$Host.UI.RawUI.WindowSize.Width
    $UILineCount = 0
   
    $Statuses = @()
    $Output = @()
    $Duration = @()
    
    $CR = $False

    If ($CR -eq $False) {
    
        If ($UILineCount -le $UIHeight) {
        
            Write-Host $Component -ForegroundColor "White";$UILineCount++
            
        }
        
        $CR = $True
        
    }
        
    $Logfile = "$LogfilePath\$VM.log"

    If (Test-Path $Logfile) {

        Write-Host "$VM`: Reading $VM.log" -ForegroundColor White

        $StatusList = @(Get-Content ($Logfile))

        $StatusList | ForEach-Object {

            $StatusItem = $_
            $Message = ($StatusItem.Split('[[]]'))[2]
            $LogVars = ((((($StatusItem.Split('[[]]'))[4]).Split('=')).Replace('"', "")).Split(' '))
            $Time = $LogVars[1]
            $Date = $LogVars[3]
            $Duration += "$Date $Time"
            $Statuses += ($LogVars[9]).Replace('>',"")
            $Output += $VM + ": " + $Message + ": " + $Date + ": " + $Time + " " + ($LogVars[9]).Replace('>',"")
    
        }

        $Count = $StatusList.Count
        $StartTime = Get-Date ($Duration[0])
        $EndTime = Get-Date ($Duration[($count -1)])
        $BuildTime = $EndTime - $StartTime
        $TimeInState = (Get-Date) - $EndTime

        If ($Continuous.isPresent) {

            for ($i=0; $i -lt $count; $i++) {

                $Display = $Output[$i]
                $Status = $Statuses[$i]
                
                If ($Display.Length -ge $UIWidth) {

                    $Display = $Display.Substring(0,$UIWidth - 1)
                
                } ElseIf ($Display.Length -lt $UIWidth) {

                    $Pad = " " * ($UIWidth - $Display[$i].Length - 1)
                    $Display = $Display + $Pad
                
                }
        
                Switch ($Status){

                    "Starting"   { $Foreground = "Magenta" }
                    "InProgress" { $Foreground = "Cyan" }
                    "Complete"   { $Foreground = "Green" }
                    "Error"      { $Foreground = "Red" }
                    Default      { $Foreground = "Yellow" }
                
                }
            
                $Host.UI.RawUI.CursorPosition = $UICursor
                Write-Host $Display -ForegroundColor $Foreground
                Sleep 1
        
            }
        
        } Else {
    
            $Display = $Output[($count -1)]
            $Status = $Statuses[($count -1)]
        
            If ($Display.Length -ge $UIWidth) {

                $Display = $Display.Substring(0,$UIWidth - 1)
            
            } ElseIf ($Display.Length -lt $UIWidth) {

                $Pad = " " * ($UIWidth - $Display.Length - 1)
                $Display = $Display + $Pad
            
            }
        
            Switch ($Status) {

                "Starting"   { $Foreground = "Magenta" }
                "InProgress" { $Foreground = "Cyan" }
                "Complete"   { $Foreground = "Green" }
                "Error"      { $Foreground = "Red" }
                Default      { $Foreground = "Yellow" }

            }
        
            Write-Host $Display -ForegroundColor $Foreground
            Sleep 1

        }

        Write-Host "Build time for $VM was $($BuildTime.TotalHours) Hours"
        Write-Host "Time since last state change for $VM was $($TimeInState.TotalHours) Hours"
        Write-Host "`n" -NoNewLine

    } Else {
        
        Write-Host "Cannot find log file $Logfile" -ForegroundColor Red
    
    }

}

Function Get-Confirmation($Message){

    $caption = "Attention!"
    $yesNoButtons = 4

    $YN = [System.Windows.Forms.MessageBox]::Show($message, $caption, $yesNoButtons, "Question")
    
    Return $YN

}

Function Get-FileName($Title) {   

     $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
     $OpenFileDialog.title = $Title
     $OpenFileDialog.filter = "All files (*.*)| *.*"
     $OpenFileDialog.ShowDialog() | Out-Null
     $OpenFileDialog.filename

} #end function Get-FileName

Function Ingest-XML($xmllist,$msg){
    If (!$xmllist) {

        $xmllist = Get-Filename($msg)

    }

    If ($xmllist -and (Test-Path $xmllist)) {
    
        $xmlobjects = [XML] (Get-Content -path $xmllist)
        Return $xmlobjects

    } Else { 
    
        Write-Host "File not found"
        break
        
    }

}

Function Set-Subscription($Subscription,$StorageAcct){

    $CurrentSubscription = Get-AzureSubscription -Current

    If ($CurrentSubscription.SubscriptionName -ne $Subscription) {
        Select-AzureSubscription -Current -SubscriptionName $Subscription
        $CurrentSubscription = Get-AzureSubscription -Current
    }
    If ($CurrentSubscription.CurrentStorageAccountName -ne $StorageAcct){
        Set-AzureSubscription -SubscriptionName $Subscription -CurrentStorageAccount $StorageAcct
    }

}

### Script Body ###
$VMXML = Ingest-XML -xmllist $ConfigFile -msg "Please select the VM Config XML file"

Set-Subscription ($VMXML.ProvisionVMs.Subscription).Name ($VMXML.ProvisionVMs.Subscription).StorageAcct

$LogfilePath = "$(($VMXML.ProvisionVMs.Subscription.Cloud.Defaults.Config | Where-Object {$_.Name -eq "centralLogTarget"}).Value)\$($VMXML.ProvisionVMs.Subscription.Cloud.Name)"

Write-Host "Reading log files from $LogfilePath" -ForegroundColor Yellow

$VMs = @(($VMXML.ProvisionVMs.Subscription.Cloud.VMs.VM).Name)

foreach ($VM in $VMs) {
    $UICursor = $Host.UI.RawUI.CursorPosition
    Get-BuildStatus
}
