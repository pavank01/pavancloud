$SourceFolder = "."
$SourceFile = "AWSAccountsList.csv"
$SourcePath = $SourceFolder + "\" + $SourceFile
$SourceHeadersDirty = Get-Content -Path $SourcePath -First 2 | ConvertFrom-Csv
$SourceHeadersCleaned = $SourceHeadersDirty.PSObject.Properties.Name.Trim(' ') -Replace '\s',''

$listofawsaccounts = Import-CSV -Path $SourcePath -Header $SourceHeadersCleaned | Select-Object -Skip 1
$listofawsaccounts | Format-Table -AutoSize

#$listofawsaccounts

#RecordsCount
$i = 0
foreach ($awsaccount in $listofawsaccounts) {
    $i++   
}
$awsAccountTotalCount = $i

$i = 1
foreach ($awsaccount in $listofawsaccounts) {
    $awsID = $awsaccount.ID
    $awsAccountName = $awsaccount.AccountName
    $awsEmailAddress = $awsaccount.EmailAddress
    $awsJoinedMethod = $awsaccount.JoinedMethod
    $awsJoinedTimestamp = $awsaccount.JoinedTimestamp
    $awsPortalApp = $awsaccount.PortalApp
    $awsDescription = $awsaccount.Description
    $awsAccountDate = $awsaccount.AccountDate
    $awsEnvironment = $awsaccount.Environment

    if ($awsID -eq '') {$awsID = $awsID -replace "","UNK"}
    if ($awsAccountName -eq '') {$awsAccountName = $awsAccountName -replace "","UNK"}
    if ($awsEmailAddress -eq '') {$awsEmailAddress = $awsEmailAddress -replace "","UNK"}
    if ($awsJoinedMethod -eq '') {$awsJoinedMethod = $awsJoinedMethod -replace "","UNK"}
    if ($awsJoinedTimestamp -eq '') {$awsJoinedTimestamp = $awsJoinedTimestamp -replace "","UNK"}
    if ($awsPortalApp -eq '') {$awsPortalApp = $awsPortalApp -replace "","UNK"}
    if ($awsDescription -eq '') {$awsDescription = $awsDescription -replace "","UNK"}
    if ($awsAccountDate -eq '') {$awsAccountDate = $awsAccountDate -replace "","UNK"}
    if ($awsEnvironment -eq 'P') {$awsEnvironment = "Production"}
    if ($awsEnvironment -eq 'S') {$awsEnvironment = "Sandbox"}
    if ($awsEnvironment -eq 'N') {$awsEnvironment = "Non-Production"}
    if ($awsEnvironment -eq 'D') {$awsEnvironment = "Development"}

    Write-Host "AWS Account ($i of $awsAccountTotalCount)" -ForegroundColor Green
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    Write-Host "ID:                 $awsID"
    Write-Host "AccountName:        $awsAccountName"
    Write-Host "EmailAddress:       $awsEmailAddress"
    Write-Host "JoinedMethod:       $awsJoinedMethod"
    Write-Host "JoinedTimestamp:    $awsJoinedTimestamp"
    Write-Host "PortalApp:          $awsPortalApp"
    Write-Host "Description:        $awsDescription"
    Write-Host "AccountDate:        $awsAccountDate"
    Write-Host "Environment:        $awsEnvironment"
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
#    DO STUFF FOR EACH: Add-AzStorageAccountNetworkRule -ResourceGroupName $ResourceGroupName -Name $SA -IPAddressOrRange $rollupIpAddress | Out-Null
#    Write-Host "Status: Added." -ForegroundColor Green
#    Write-Host ""
    $i++    
}

#Examples

#$listofawsaccounts
#$listofawsaccounts.id

#$nonprodawsaccounts = $listofawsaccounts | where Environment -notlike "P"
#$prodawsaccounts = $listofawsaccounts | where Environment -eq "P"