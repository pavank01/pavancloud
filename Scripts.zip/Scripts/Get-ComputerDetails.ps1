<#
	.SYNOPSIS
		Displays some basic computer information

	.DESCRIPTION
		Get-ComputerDetails.ps1 displays the following basic system information:
		* Computer Name
		* Operating System Version
		* Service Pack
		* OS Bit Depth (32/64)
		* GB of Installed Memory
		* Number of Logical CPU Cores
		* Physical or Virtual
		* PowerShell Version
		* Last Reboot Date

	.PARAMETER ComputerName
		Computer name or array of computer names to process
		Provide as Fully Qualified Domain Names or the script will assume the same Domain as the computer running the script
		Can use a combination of Fully Qualified Domain Names and simple computer names
		Using the -DomainName parameter will append DomainName to any computer names that are not Fully Qualified Domain Names

	.PARAMETER DomainName
		Domain name to use for all computer names that are not Fully Qualified Domain Names
		If not specified script will assume the same Domain as the computer running the script

	.EXAMPLE
		.\Get-ComputerDetails.ps1 -ComputerName "AZUVNADMFINT241", "AZUVNDLVFINT241", "AZUVNSQLFINT241", "SNAVPMGTOTRS002.CORP.FIRSTAM.COM", "dfwpdclsfast011.fastts.firstam.net", "FEVASNA09SSQL12", "FEVASNA09VAPP01" -DomainName FASTTS.FIRSTAM.NET | Format-Table -AutoSize

		ComputerName                       OperatingSystem            SP OSBit MemoryGB Cores Type     PS  LastBoot
		------------                       ---------------            -- ----- -------- ----- ----     --  --------
		AZUVNADMFINT241.fastts.firstam.net Windows 2012 Datacenter     0 64         3.5     2 Virtual  5.1 3/28/2018 10:55:05 AM
		AZUVNDLVFINT241.fastts.firstam.net Windows 2012 Datacenter     0 64         1.7     1 Virtual  4.0 3/28/2018 11:32:06 AM
		AZUVNSQLFINT241.fastts.firstam.net Windows 2012 R2 Datacenter  0 64           7     4 Virtual  4.0 3/28/2018 11:32:48 AM
		DFWPDCLSFAST011.fastts.firstam.net Windows 2012 R2 Standard    0 64       511.9   128 Physical 4.0 2/17/2018 9:54:44 PM
		FEVASNA09SSQL12.fastts.firstam.net Windows 2008 R2 Standard    1 64          12    24 Physical 2.0 3/8/2018 6:03:29 PM
		FEVASNA09VAPP01.fastts.firstam.net Windows 2008 R2 Standard    1 64           2     1 Virtual  2.0 3/8/2018 5:53:05 PM
		SNAVPMGTOTRS002.corp.firstam.com   Windows 2012 R2 Standard    0 64          24     4 Virtual  5.1 3/24/2018 10:30:11 PM

	.EXAMPLE
		$Servers = "AZUVNADMFINT241", "AZUVNDLVFINT241", "AZUVNSQLFINT241", "SNAVPMGTOTRS002.CORP.FIRSTAM.COM", "dfwpdclsfast011.fastts.firstam.net", "FEVASNA09SSQL12", "FEVASNA09VAPP01"
		.\Get-ComputerDetails.ps1 -ComputerName $Servers -DomainName fastts.firstam.net | Format-Table -AutoSize

		Produces the same output as EXAMPLE 1

	.NOTES
		2018/03/28 - Initial Release [Ryan Amsbury]
#>

[CmdletBinding()]
Param (
	[Parameter()]
	[String[]]$ComputerName = (Get-WmiObject -Class Win32_ComputerSystem | Select-Object @{Label="FQDN"; Expression={$_.Name.ToUpper()+"."+$_.Domain.ToLower()}}).FQDN,

	[Parameter()]
	[String]$DomainName = (Get-WmiObject -Class Win32_ComputerSystem | Select-Object @{Label="Domain"; Expression={$_.Domain.ToLower()}}).Domain
)

$ComputerName = @($ComputerName | ForEach-Object {If ($_ -notmatch '^*[\.](.*)$') {If ($DomainName -ne $Null -and $DomainName -ne "") {("{0}.{1}" -f $_, $DomainName)} Else {$_}} Else {$_}}) | Select-Object -Unique

$ComputerName = @($ComputerName | ForEach-Object {([Regex]::Match($_, '^[^\.]*').Value).ToUpper()+([Regex]::Match($_, '^*[\.](.*)$').Value).ToLower()})

Invoke-Command -ComputerName $ComputerName -ScriptBlock {
	$Win32_OperatingSystem = Get-WmiObject -Class Win32_OperatingSystem | Select-Object @{L="PS";E={"{0}.{1}" -f $PSVersionTable.PSVersion.Major, $PSVersionTable.PSVersion.Minor}}, @{L="OperatingSystem";E={($_.Caption -Replace('Microsoft',' ') -Replace('Server',' ') -Replace('[^\x20-\x7E]+', ' ') -Replace('\s+', ' ')).Trim()}}, @{L="SP";E={$_.ServicePackMajorVersion}}, @{L="OSBit";E={$_.OSArchitecture -Replace('\-bit', '')}}, @{N="MemoryGB";E={[Math]::Round($_.TotalVisibleMemorySize/1MB, 1, "AwayFromZero")}}, @{N="Cores";E={$Null}}, @{L="Type";E={$Null}}, @{N="LastBoot";E={$_.ConvertToDateTime($_.LastBootUpTime)}}
	$Win32_ComputerSystem = Get-WmiObject -Class Win32_ComputerSystem | Select-Object Model, NumberOfLogicalProcessors
	$Win32_OperatingSystem.Cores = $Win32_ComputerSystem.NumberOfLogicalProcessors
	If ($Win32_ComputerSystem -like "*virtual*") {
		$Win32_OperatingSystem.Type = "Virtual"
	} Else {
		$Win32_OperatingSystem.Type = "Physical"
	}
	$Win32_OperatingSystem
} | Select-Object @{L="ComputerName";E={$_.PSComputerName}}, OperatingSystem, SP, OSBit, MemoryGB, Cores, Type, PS, LastBoot | Sort-Object ComputerName
