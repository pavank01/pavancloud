﻿#------------------------------------------------------------------------------
#region - Constants
#------------------------------------------------------------------------------

$SoftwareSource     = '\\corp.firstam.com\Restricted\ServerOps-Admin\Software\PKG'
$SoftwareStaging    = 'C:\Software'
$FlagFile           = "C:\Software\FAConfiguration.done"
$VmName             = $(Get-WmiObject -Class win32_computersystem -ComputerName localhost).Name
$LogName            = "$VmName.log"
$LogDirectory       = Get-Date -Format yyyy-MM
$LogPath            = "\\corp.firstam.com\Restricted\ServerOps-Admin\Scripts\Logs"
$FullLogPath        = $LogPath + "\" + $LogDirectory + "\" + $LogName

#------------------------------------------------------------------------------
#endregion - Constants
#------------------------------------------------------------------------------

If ( !(Test-Path -Path $LogPath\$LogDirectory -PathType Container) ) {
	
	    New-Item -Path $LogPath\$LogDirectory -ItemType Directory | Out-Null

}


#------------------------------------------------------------------------------
#region - Functions
#------------------------------------------------------------------------------
Function Log-Message {
    Param(

        [string]$Message

    )

    $DateTimeStamp = Get-Date -Format "[yyyy-MM-dd hh:mm:ss]"

    $LogEntry = "<![LOG[$Message]LOG]!><time=`"$(Get-Date -Format HH:mm:ss.ffff)`" " +`
                "date=`"$(Get-Date -Format MM-dd-yyyy)`">"
	
    Add-Content -Path $FullLogPath -Value $LogEntry

    Write-Output "$DateTimeStamp`t$Message"

}

Function Install-FAPackage {
    Param(

        [Parameter(Mandatory=$true)]
        [string]$ApplicationName,

        [Parameter(Mandatory=$true)]
        [string]$SourceFolder,

        [Parameter(Mandatory=$true)]
        [string]$TempFolder,

        [Parameter(Mandatory=$true)]
        [string]$InstallCommand,

        [Parameter(Mandatory=$false)]
        $InstallArguments

    )

    Log-Message "Preparing for installation of $ApplicationName"

	If ( !(Test-Path -Path $TempFolder -PathType Container) ) {
	
		New-Item -Path $TempFolder -ItemType Directory

	}

    # Copy the package to the local staging folder
    Log-Message "Copying package from $sourceFolder to $tempFolder"
    Copy-Item -Path "$sourceFolder\*" -Destination $tempFolder -Recurse -Force
    
    # Install the application from the local copy
    if ($InstallArguments) {

        Log-Message "Executing $InstallCommand with arguments $InstallArguments"

        Start-Process -WorkingDirectory $TempFolder -FilePath $InstallCommand -ArgumentList $InstallArguments -Wait

    } Else {
    
        Log-Message "Executing $InstallCommand..."

        Start-Process -WorkingDirectory $TempFolder -FilePath $InstallCommand -Wait

    }

    Log-Message "Installation of $ApplicationName complete."
    
}

Function Set-PageFileSize
{
	Param(
        
        [Parameter(Mandatory=$true)]
        [string]$DL,
        
        [Parameter(Mandatory=$true)]
        [int]$InitialSize,
        
        [Parameter(Mandatory=$true)]
        [int]$MaximumSize
        
    )
	
	#The AutomaticManagedPagefile property determines whether the system managed pagefile is enabled. 
	#This capability is not available on windows server 2003,XP and lower versions.
	#Only if it is NOT managed by the system and will also allow you to change these.
	$IsAutomaticManagedPagefile = Get-WmiObject -Class Win32_ComputerSystem |Foreach-Object{$_.AutomaticManagedPagefile}
	If($IsAutomaticManagedPagefile)
	{
		#We must enable all the privileges of the current user before the command makes the WMI call.
		$SystemInfo=Get-WmiObject -Class Win32_ComputerSystem -EnableAllPrivileges
		$SystemInfo.AutomaticManagedPageFile = $false
		[Void]$SystemInfo.Put()
	}
	
	Write-Verbose "Setting pagefile on $DL"
	
	#configuring the page file size
	$PageFile = Get-WmiObject -Class Win32_PageFileSetting -Filter "SettingID='pagefile.sys @ $DL'"
	
	Try
	{
		If($PageFile -ne $null)
		{
			$PageFile.Delete()
		}
			Set-WmiInstance -Class Win32_PageFileSetting -Arguments @{name="$DL\pagefile.sys"; InitialSize = 0; MaximumSize = 0} `
			-EnableAllPrivileges |Out-Null
			
			$PageFile = Get-WmiObject Win32_PageFileSetting -Filter "SettingID='pagefile.sys @ $DL'"
			
			$PageFile.InitialSize = $InitialSize
			$PageFile.MaximumSize = $MaximumSize
			[Void]$PageFile.Put()
			
			Write-Host  "Execution Results: Set page file size on ""$DL"" successful."
			Write-Warning "Pagefile configuration changed on computer '$Env:COMPUTERNAME'. The computer must be restarted for the changes to take effect."
	}
	Catch
	{
		Write-Host "Execution Results: No Permission - Failed to set page file size on ""$DL"""
	}
}

#------------------------------------------------------------------------------
#endregion - Functions
#------------------------------------------------------------------------------


#------------------------------------------------------------------------------
#region - Main
#------------------------------------------------------------------------------

# Check for flag file and abort if found
If (Test-Path -Path $FlagFile) {

    Log-Message "Script has been previously run.  Exiting."
    Exit 0

}

# Keep track of the OS Version
$osVersion = ( Get-WMIObject -Class Win32_OperatingSystem -Namespace root/cimv2).Version

# 2016-07-22 - mblackman - Fix for 2008R2 license not activating
if ($osVersion -eq "6.1.7601") {

    Log-Message "Trying to activate 2008R2 license"

    cscript c:\windows\system32\slmgr.vbs /ato

}

# Allow all PowerShell scripts to run (this may not survive the PowerShell 5 install)
# 2017-04-13 - mblackman - Removed this setting from the VMware template and added it to script
Log-Message "Setting PowerShell Execution Policy to Unrestricted"

If ( (Get-ExecutionPolicy -Scope LocalMachine) -ne "Unrestricted" ) {
	Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Scope LocalMachine -Force
}

# Disable Windows Firewall
# 2017-04-13 - mblackman - Removed this setting from the VMware template and added it to script
Log-Message "Disabling Windows Firewall"
netsh advfirewall set AllProfiles state off

# Install the Telnet Client feature
# 2017-04-13 - mblackman - Removed this setting from the VMware template and added it to script
Log-Message "Installing the Telnet client"
if ($osVersion -eq "6.1.7601") {

    # Windows 2008 R2
    dism /online /Enable-Feature /FeatureName:TelnetClient

} else {

    # Windows 12 and beyond
    Install-WindowsFeature -Name Telnet-Client

}

if ($osVersion -eq "6.1.7601") {

    # Install KB3080079 to fix RDP protocol on 2008R2 servers with TLS 1.0 disabled
    # 2017-04-17 - mblackman -added install
    Install-FAPackage -applicationName 'KB3080079' `
                          -sourceFolder ( Join-Path $softwareSource -ChildPath 'Microsoft\Windows Server\HotFixes\KB3080079' ) `
                          -tempFolder ( Join-Path $softwareStaging -ChildPath 'KB3080079' ) `
                          -installCommand 'wusa.exe' `
                          -installArguments @('Windows6.1-KB3080079-x64.msu', '/quiet', '/norestart')

}

if ($osVersion -eq "6.2.9200") {

    # Install KB2840622 to fix known issue with Server 2012 and MSMQ
    # 2017-04-19 - mblackman -added install
    Install-FAPackage -applicationName 'KB2840622' `
                          -sourceFolder ( Join-Path $softwareSource -ChildPath 'Microsoft\Windows Server\Hotfixes\KB2840622' ) `
                          -tempFolder ( Join-Path $softwareStaging -ChildPath 'KB2840622' ) `
                          -installCommand 'wusa.exe' `
                          -installArguments @('Windows8-RT-KB2840622-v2-x64.msu', '/quiet', '/norestart')

}

# Install Symantec Endpoint Protection
# 2016-07-27 - mblackman -SEP version updated to 12.1.7004.6500
Install-FAPackage -applicationName 'Symantec Endpoint Protection' `
                  -sourceFolder ( Join-Path $SoftwareSource -ChildPath 'Symantec\Symantec Endpoint Protection\12.1.7004.6500\64-bit' ) `
                  -tempFolder ( Join-Path $SoftwareStaging -ChildPath 'SEP' ) `
                  -installCommand 'setup.cmd'

# Install Altiris
# 2015-10 -02 - mblackman - Altiris version updated to 7.6.1615.26
Install-FAPackage -applicationName 'Altiris' `
                  -sourceFolder ( Join-Path $SoftwareSource -ChildPath 'Symantec\Altiris\7.6.1615.26' ) `
                  -tempFolder ( Join-Path $SoftwareStaging -ChildPath 'Altiris' ) `
                  -installCommand 'setup.cmd'

# Install Networker
# 2016-03-16 - mblackman - Networker version 8.2.2.4 added
Install-FAPackage -applicationName 'Networker' `
                  -sourceFolder ( Join-Path $SoftwareSource -ChildPath 'EMC\NetWorker\8.2.2.4\64-Bit Windows' ) `
                  -tempFolder ( Join-Path $SoftwareStaging -ChildPath 'NetWorker' ) `
                  -installCommand 'setup.cmd'

# Install Tanium
# 2017-04-04 - mblackman - Tanium version 6.0.314.1540 added
Install-FAPackage -applicationName 'Tanium' `
                  -sourceFolder ( Join-Path $SoftwareSource -ChildPath 'Tanium\Tanium\6.0.314.1540' ) `
                  -tempFolder ( Join-Path $SoftwareStaging -ChildPath 'Tanium' ) `
                  -installCommand 'setup.cmd'

# Set TLS Settings
Install-FAPackage -applicationName 'Set-TLSSettings' `
                  -sourceFolder ( Join-Path $SoftwareSource -ChildPath 'FirstAmerican\TLSSettings\1.0' ) `
                  -tempFolder ( Join-Path $SoftwareStaging -ChildPath 'TLSSettings' ) `
                  -installCommand 'setup.cmd'

<#
# Install Configuration Manager
# 2017-04-13 - mblackman - Configuration Manager version 5.0.8412.1004 added
Install-FAPackage -applicationName 'ConfigurationManager' `
                  -sourceFolder ( Join-Path $SoftwareSource -ChildPath 'Microsoft\System Center Configuration Manager\5.0.8412.1004' ) `
                  -tempFolder ( Join-Path $SoftwareStaging -ChildPath 'ConfigurationManager' ) `
                  -installCommand 'setup.cmd'                  
#>

# Set pagefile to 4GB
# 2017-04-14 - mblackman - function added
Log-Message "Setting pagefile to 4GB"
Set-PageFileSize -DL "C:" -InitialSize 4096 -MaximumSize 4096

#------------------------------------------------------------------------------
#endregion - Main
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Post configure process
#------------------------------------------------------------------------------

Log-Message "Removing the scheduled job"

schtasks.exe /Delete /TN "\Microsoft\Windows\Desired State Configuration\FAConfiguration" /F

Write-Output "FAServerStandard.ps1 completed at $(Get-Date)." | Out-File -FilePath $FlagFile -Append -Force

Log-Message "Install activities completed. Restarting computer"

Restart-Computer -Force

#------------------------------------------------------------------------------
#endregion - Post configure process
#------------------------------------------------------------------------------