
# Enabe NON-PROD Storage account Diagnostic logging for Blob,Table and Queue 
$context = Get-AzSubscription -SubscriptionName 'AZUR-P-AzureSub-1'
Set-AzContext $context
$EventHubAuthorizationRuleID = (Get-AzEventHubAuthorizationRule -ResourceGroupName "AZUR-P-1-SCES-RG-1" -Namespace "AZUR-P-1-SCES-EH-2" | ?{$_.Id -like "*ActivityManagePolicy*"}).Id
$Eventhubname = (Get-AzEventHub -ResourceGroupName "AZUR-P-1-SCES-RG-1" -Namespace "AZUR-P-1-SCES-EH-2" | ?{$_.Name -like "*operational*"}).Name


$context = Get-AzSubscription -SubscriptionName 'AZUR-N-AzureSub-1' # Enter Storage account subscription
Set-AzContext $context
$ResourceGroup = (Get-AzResourceGroup -Name 'AZUR-N-1-SALP-RG-2').ResourceGroupName # Enter Storage account Resource group name
$storageAccount = Get-AzStorageAccount -ResourceGroupName $ResourceGroup -Name 'azurans1salpsa1' # Enter Storage account name

##BLOB-Diagnostic
$ResourceID = $storageAccount.ID + "/blobServices/default"

Set-AzDiagnosticSetting -ResourceId $ResourceID -StorageAccountId $($storageAccount.Id)`
-Enabled $true -Category StorageRead,StorageWrite,StorageDelete -EventHubName $Eventhubname -EventHubAuthorizationRuleId $EventHubAuthorizationRuleID -Name 'BLOB-Diagnostic'

##TABLE-Diagnostic
$ResourceID = $storageAccount.ID + "/tableServices/default"

Set-AzDiagnosticSetting -ResourceId $ResourceID -StorageAccountId $($storageAccount.Id)`
-Enabled $true -Category StorageRead,StorageWrite,StorageDelete -EventHubName $Eventhubname -EventHubAuthorizationRuleId $EventHubAuthorizationRuleID -Name 'TABLE-Diagnostic'

##QUEUE-Diagnostic
$ResourceID = $storageAccount.ID + "/queueServices/default"

Set-AzDiagnosticSetting -ResourceId $ResourceID -StorageAccountId $($storageAccount.Id)`
-Enabled $true -Category StorageRead,StorageWrite,StorageDelete -EventHubName $Eventhubname -EventHubAuthorizationRuleId $EventHubAuthorizationRuleID -Name 'QUEUE-Diagnostic'

##FILE-Diagnostic
$ResourceID = $storageAccount.ID + "/FILEServices/default"

Set-AzDiagnosticSetting -ResourceId $ResourceID -StorageAccountId $($storageAccount.Id)`
-Enabled $true -Category StorageRead,StorageWrite,StorageDelete -EventHubName $Eventhubname -EventHubAuthorizationRuleId $EventHubAuthorizationRuleID -Name 'FILE-Diagnostic'