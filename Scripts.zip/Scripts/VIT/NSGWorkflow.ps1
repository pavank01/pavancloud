login-AzureRMaccount # Login to the azure RM account using your credentials.

Set-AzureRMContext -SubscriptionName 'AZUR-P-AzureSub-1' #Enter the subscription name.
$RG = Get-AzureRmResourceGroup -Name 'AZUR-P-1-SFDY-RG-1' # Enter the resourcegroup for the NSG
$NSG = (Get-AzureRmNetworkSecurityGroup -Name SFDY-APP-NSG-1 -ResourceGroupName $rg.ResourceGroupName).Name #Enter the NSG Name.

     $nsgFlowLogStorageId = (Get-AzureRmStorageAccount | ?{$_.StorageAccountName -like "azuraps1sosgsa1" -and $_.Location -like "$($rg.location)"}).Id #Change the SOSG SA according to the subscription and region.
     $logAnalyticsWorkspaceId = '/subscriptions/e63b08c3-d314-48d8-b10a-c58199bb78b1/resourceGroups/AZUR-P-1-AZUR-RG-3/providers/Microsoft.OperationalInsights/workspaces/AZUR-P-1-AZUR-OI-1'
     $networkWatcher = Get-AzureRmNetworkWatcher -ResourceGroupName NetworkWatcherRg -Name "NetworkWatcher_$($RG.location)"
     $NSGResourceID = (Get-AzureRmNetworkSecurityGroup -Name $NSG -ResourceGroupName $rg.ResourceGroupName).Id

    $networkSecurityGroupDiagnostics = @{
        Name             = 'Diagnostics'
        WorkspaceId      = $logAnalyticsWorkspaceId
        Categories       = @('NetworkSecurityGroupEvent', 'NetworkSecurityGroupRuleCounter')
        Enabled          = $true
        RetentionEnabled = $false
        RetentionInDays  = 0
    }

    $networkSecurityGroupFlowLogs = @{
        NetworkWatcher   = $networkWatcher
        StorageAccountId = $nsgFlowLogStorageId
        EnableFlowLog    = $true
        EnableRetention  = $true
        RetentionInDays  = 91
        }
    Set-AzureRmDiagnosticSetting -ResourceId $NSGResourceID @networkSecurityGroupDiagnostics -Verbose
    Set-AzureRmNetworkWatcherConfigFlowLog -TargetResourceId $NSGResourceID @networkSecurityGroupFlowLogs -Verbose
