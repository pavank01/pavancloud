<#
	.SYNOPSIS
		Documents a physical or virtual servers disk volume mount details
	.DESCRIPTION
		Documents a physical or virtual servers disk volume mount details. It uses DiskPart, SysInternals� DiskExt, EMC�s Inq, and WMI to provide a detailed drive layout including Windows disk number, online state, mount path, drive label, total drive size, drive free space, page file size, drive type, SAN ID, and Windows volume ID.
	.PARAMETER Object
		Outputs the details as an object for further manipulation with PowerShell in the pipeline
	.NOTES
		2017/09/07 - Added BlockSize [Ryan Amsbury]
		2017/02/06 - Initial Release [Ryan Amsbury]
#>
[CmdletBinding()]
Param (
	[Parameter(Mandatory = $False)]
	[Switch]$Object = $False
)
# ---------------------------------------------------------------------------
#
$LastUpdated = "09/07/2017"
#
# ---------------------------------------------------------------------------
Function Format-FileNameWithDate {
	Param (
		[String]$Prefix,
		[String]$Suffix,
		[String]$DateFormat
	)
	If ($DateFormat -eq $Null -or $DateFormat -eq "") {
		$DateFormat = "yyyy-MM-dd"
	}
	$TextDate = Get-Date -Format $DateFormat
	Return $Prefix+$TextDate+$Suffix
}
# ---------------------------------------------------------------------------
If ($Object -eq $False) {
	Write-Host
	Write-Host ("  Last Updated on {0}  " -f $LastUpdated) -ForegroundColor Black -BackgroundColor DarkGray
	Write-Host
}
# ---------------------------------------------------------------------------
# Run and import Sysinternals DiskExt.exe output
$DiskExtOutput = .\diskext.exe /accepteula | Where-Object {$_ -match "Volume: " -or $_ -match "Mounted at: " -or $_ -match "Disk: "}
If ($DiskExtOutput -eq $Null) {
	Write-Host "Error retrieving Sysinternals DiskExt.exe output. Possible reasons are:" -ForegroundColor Yellow -BackgroundColor Red
	Write-Host "* DiskExt.exe may not be in the current folder. Make sure the EXE is located with the script." -ForegroundColor Yellow
	Write-Host "    Latest version can be found here: https://technet.microsoft.com/en-us/sysinternals/diskext" -ForegroundColor Gray
	Write-Host "* PowerShell not elevated with Admin rights. Run PowerShell elevated as Administrator." -ForegroundColor Yellow
	Write-Host "* Multiple runs in the same PowerShell session causes issues. Close and reopen PowerShell." -ForegroundColor Yellow
	Break
}
$DiskExtDetails = @()
ForEach ($DiskExt In $DiskExtOutput) {
	If ($DiskExt -like "*Volume:*") {
		$TempVolume = $Null
		$TempVolume = ($DiskExt -Replace "Volume:", "").Trim()
	}
	If ($DiskExt -like "*Mounted at:*") {
		$TempMount = $Null
		$TempMount = ($DiskExt -Replace "Mounted at:", "").Trim()
	}
	If ($DiskExt -like "*Disk:*") {
		$TempDisk = $Null
		$TempDisk = ($DiskExt -Replace "Disk:", "").Trim()
		# Ignore volumes on disk 0 that are not mounted
		If (!($TempDisk -eq 0 -and $TempMount -eq "<unmounted>")) {
			$DiskExtTemp = New-Object PSObject
			Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "DiskID" -Value $TempDisk
			Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "MountPath" -Value $TempMount
			Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "VolumeID" -Value $TempVolume
			Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "ServerName" -Value "N/A"
			Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "Status" -Value "N/A"
			Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "DriveType" -Value "N/A"
			Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "WWN" -Value "N/A"
			Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "SANID" -Value "N/A"
			Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "Label" -Value ""
			Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "FileSystem" -Value "N/A"
			Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "BlockSizeKB" -Value "N/A"
			Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "TotalGB" -Value "N/A"
			Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "FreeGB" -Value "N/A"
			Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "PageFileGB" -Value "N/A"
			$DiskExtDetails += $DiskExtTemp
		}
	}
}

# ---------------------------------------------------------------------------
# Run and import DiskPart output
$DiskPartOutput = "list disk" | diskpart | Where-Object {$_ -match "Offline" -or $_ -match "Online" -or $_ -match "Reserved"}
If ($DiskExtOutput -eq $Null) {
	Write-Host "Error retrieving DiskPart output. Possible reasons are:" -ForegroundColor Yellow -BackgroundColor Red
	Write-Host "* PowerShell not elevated with Admin rights. Run PowerShell elevated as Administrator." -ForegroundColor Yellow
	Write-Host "* Multiple runs in the same PowerShell session causes issues. Close and reopen PowerShell." -ForegroundColor Yellow
	Break
}
ForEach ($DiskPart In $DiskPartOutput) {
	$TempArray = $DiskPart.Split() | Where-Object {$_}
	$Found = $False
	ForEach ($DiskExt In ($DiskExtDetails | Sort-Object MountPath)) {
		If ($DiskExt.DiskID -eq ([Int]($TempArray[1]))) {
			$DiskExt.Status = $TempArray[2]
			$Found = $True
			Break
		}
	}
	If ($Found -eq $False) {
		$DiskExtTemp = New-Object PSObject
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "VolumeID" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "ServerName" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "Status" -Value $TempArray[2]
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "DriveType" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "WWN" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "SANID" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "MountPath" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "DiskID" -Value ([Int]$TempArray[1])
		#Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "DiskID" -Value (([Int]$TempArray[1]).ToString("000"))
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "Label" -Value ""
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "FileSystem" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "BlockSizeKB" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "TotalGB" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "FreeGB" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "PageFileGB" -Value "N/A"
		$DiskExtDetails += $DiskExtTemp
	}
}

# ---------------------------------------------------------------------------
# Run and import EMC inq.exe output
$OSBitDepth = (Get-WmiObject Win32_Processor).AddressWidth
If ($OSBitDepth -eq 64) {
	$EMCOutput = .\inq.windowsamd64.exe -no_dots | Select-String "\\.\PHYSICALDRIVE" -SimpleMatch | ForEach-Object {$_ -Split ("\\.\PHYSICALDRIVE", 0, "SimpleMatch")} | Where-Object {$_}
	$EMCOutput2 = .\inq.windowsamd64.exe -no_dots -wwn | Select-String "\\.\PHYSICALDRIVE" -SimpleMatch | ForEach-Object {$_ -Split ("\\.\PHYSICALDRIVE", 0, "SimpleMatch")} | Where-Object {$_}
} Else {
	$EMCOutput = .\inq.wnt.exe -no_dots | Select-String "\\.\PHYSICALDRIVE" -SimpleMatch | ForEach-Object {$_ -Split ("\\.\PHYSICALDRIVE", 0, "SimpleMatch")} | Where-Object {$_}
	$EMCOutput2 = .\inq.wnt.exe -no_dots -wwn | Select-String "\\.\PHYSICALDRIVE" -SimpleMatch | ForEach-Object {$_ -Split ("\\.\PHYSICALDRIVE", 0, "SimpleMatch")} | Where-Object {$_}
}
If ($EMCOutput -eq $Null -or $EMCOutput2 -eq $Null) {
	Write-Host "Error retrieving EMC Inq.WindowsAMD64.exe output. Possible reasons are:" -ForegroundColor Yellow -BackgroundColor Red
	Write-Host "* inq.*.exe may not be in the current folder. Make sure the EXE is located with the script." -ForegroundColor Yellow
	Write-Host "    Latest version can be found here: ftp://ftp.emc.com/pub/symm3000/inquiry/" -ForegroundColor Gray
	Write-Host "    x86 = inq.wnt_exe (please rename to inq.wnt.exe)" -ForegroundColor Gray
	Write-Host "    x64 = inq.windowsamd64_exe (please rename to inq.windowsamd64.exe)" -ForegroundColor Gray
	Write-Host "* PowerShell not elevated with Admin rights. Run PowerShell elevated as Administrator." -ForegroundColor Yellow
	Write-Host "* Multiple runs in the same PowerShell session causes issues. Close and reopen PowerShell." -ForegroundColor Yellow
	Break
}
ForEach ($EMCDrive In $EMCOutput) {
	$TempArray = $EMCDrive -Split (" :", 0, "SimpleMatch") | Where-Object {$_}
	$Found = $False
	ForEach ($DiskExt In ($DiskExtDetails | Sort-Object MountPath)) {
		If ($DiskExt.DiskID -eq ([Int]($TempArray[0]))) {
			$DiskExt.DriveType = ($TempArray[1]).Trim()+' '+($TempArray[2]).Trim()
			If (($TempArray[4]).Trim() -eq $Null -or ($TempArray[4]).Trim() -eq "") {
				$DiskExt.SANID = "N/A"
			} Else {
				If (($TempArray[2]).Trim() -eq "SYMMETRIX") {
					# Get 5 characters from 'SER NUM' xx99999xxx
					$DiskExt.SANID = $TempArray[4].SubString(2,5)
				} ElseIf (($TempArray[2]).Trim() -eq "XtremApp") {
					# Get 5 characters from 'SER NUM' xxxxxxxxxx99999
					$DiskExt.SANID = $TempArray[4].SubString(11,5)
				} Else {
					$DiskExt.SANID = $TempArray[4]
				}
			}
			ForEach ($EMCDrive2 In $EMCOutput2) {
				$TempArray2 = $EMCDrive2 -Split (" :", 0, "SimpleMatch") | Where-Object {$_}
				If ($DiskExt.DiskID -eq ([Int]($TempArray2[0]))) {
					If (($TempArray2[3]).Trim() -eq $Null -or ($TempArray2[3]).Trim() -eq "") {
						$DiskExt.WWN = "N/A"
					} Else {
						$DiskExt.WWN = ($TempArray2[3]).Trim()
					}
				}
			}
			$Found = $True
			Break
		}
	}
	If ($Found -eq $False) {
		$DiskExtTemp = New-Object PSObject
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "VolumeID" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "ServerName" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "Status" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "DriveType" -Value $TempArray[1]
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "WWN" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "SANID" -Value $TempArray[4]
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "MountPath" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "DiskID" -Value ([Int]$TempArray[0])
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "DiskIDSort" -Value (([Int]$TempArray[0]).ToString("000"))
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "Label" -Value ""
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "FileSystem" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "BlockSizeKB" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "TotalGB" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "FreeGB" -Value "N/A"
		Add-Member -InputObject $DiskExtTemp -MemberType NoteProperty -Name "PageFileGB" -Value "N/A"
		$DiskExtDetails += $DiskExtTemp
	}
}

# ---------------------------------------------------------------------------
# Gather WMI data for volumes and page files
$DiskVolumes = Get-WmiObject Win32_Volume | Where-Object {$_.DriveType -eq 3} | Select-Object __Server, DeviceID, Label, Name, FileSystem, @{Name="BlockSizeKB";Expression={[Math]::Round($_.BlockSize/1KB,0)}}, @{Name="CapacityGB";Expression={[Math]::Round($_.Capacity/1GB,0)}}, @{Name="FreeSpaceGB";Expression={[Math]::Round($_.Freespace/1GB,0)}}, PageFilePresent
$PageFileUsage = Get-WmiObject Win32_PageFileUsage | Select-Object @{Name="Name";Expression={[io.path]::GetPathRoot($_.Name)}}, @{Name="PageFileBaseSize";Expression={[Math]::Round($_.AllocatedBaseSize/1KB,1)}}
ForEach ($DiskExt In $DiskExtDetails) {
	$DiskExt.ServerName = ($DiskVolumes | Select-Object -First 1).__Server
	$ServerName = $DiskExt.ServerName
	ForEach ($Volume In $DiskVolumes) {
		If ($DiskExt.MountPath -eq $Volume.Name) {
			$DiskExt.Label = $Volume.Label
			$DiskExt.TotalGB = $Volume.CapacityGB
			$DiskExt.FreeGB = $Volume.FreeSpaceGB
			$DiskExt.FileSystem = $Volume.FileSystem
			$DiskExt.BlockSizeKB = $Volume.BlockSizeKB
			ForEach ($PageFile In $PageFileUsage) {
				If ($DiskExt.MountPath -eq $PageFile.Name) {
					$DiskExt.PageFileGB = $PageFile.PageFileBaseSize
					Break
				}
			}
			Break
		}
	}
}

# ---------------------------------------------------------------------------
# Clean up the VolumeID for readability and put [] around SANID, WWN, and VolumeID to fix Excel
ForEach ($DiskExt In $DiskExtDetails) {
	$TempString = $Null
	$TempString = $DiskExt.VolumeID -Replace ([Regex]::Escape("\\?\Volume{"), "")
	$TempString = $TempString -Replace ([Regex]::Escape("}\"), "")
	$DiskExt.VolumeID = $TempString
	If ($DiskExt.SANID -ne "N/A") {
		$DiskExt.SANID = ("[{0}]" -f ($DiskExt.SANID).ToUpper())
	}
	If ($DiskExt.WWN -ne "N/A") {
		$DiskExt.WWN = ("[{0}]" -f ($DiskExt.WWN).ToUpper())
	}
	If ($DiskExt.VolumeID -ne "N/A") {
		$DiskExt.VolumeID = ($DiskExt.VolumeID).ToUpper()
	}
}

# ---------------------------------------------------------------------------
# Save full results
$Path = Split-Path -Path $Script:MyInvocation.MyCommand.Path
$FileName = [io.path]::GetFileNameWithoutExtension((Split-Path -Path $Script:MyInvocation.MyCommand.Path -Leaf))
$NewFileName = Join-Path -Path $Path -ChildPath ($FileName+"_"+$ServerName+"_")
$ExportFileName = Format-FileNameWithDate -Prefix $NewFileName -Suffix ".csv" -DateFormat "yyyy-MM-dd_HHmm"
$DiskExtDetails | Sort-Object MountPath | Select-Object ServerName, DiskID, Status, FileSystem, BlockSizeKB, MountPath, Label, TotalGB, FreeGB, PageFileGB, DriveType, SANID, WWN, VolumeID | Export-CSV $ExportFileName -Delimiter "," -NoTypeInformation

# ---------------------------------------------------------------------------
# Return an Object or display simplified results
If ($Object -eq $True) {
	Return $DiskExtDetails
} Else {
	$DiskExtDetails | Sort-Object MountPath | Format-Table ServerName, DiskID, Status, FileSystem, BlockSizeKB, MountPath, Label, TotalGB, SANID, WWN, DriveType -Auto
	Write-Host "CSV File Name:"$ExportFileName
	Write-Host
}
