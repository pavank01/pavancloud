#Please ensure the CSV file is under c:\temp.
#edit the CSV file with teh VMs that you would like to increase disk space for.
#the script will increase the VM disk space +20GB.
#You will still need to ensure that the disk is increased in the OS.

Import-Csv -Path 'C:\Temp\testvms.csv' | %{
    $VMx = $_.Name
    $vm = get-vm |?{$_.Name -eq $VMx}
    $HD = get-harddisk -VM $vm.Name -Name "Hard disk 1"
    $NewCap = [decimal]::round($HD.CapacityGB + 20)
    $HD | Set-harddisk -CapacityGB  $NewCap
 }
 