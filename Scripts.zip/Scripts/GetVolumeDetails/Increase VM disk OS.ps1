
#This is work in progress for Invoke-VMScript
#$VMs= 'SNAVNADMFEVA001'
#$GuestUser='faadmin'
#$GuestPassword='xxxxxxxx'


#Invoke-VMScript -VM $VM -ScriptText "ECHO RESCAN > C:\DiskPart.txt && ECHO SELECT Volume C >> C:\DiskPart.txt && ECHO EXTEND >> C:\DiskPart.txt && ECHO EXIT >> C:\DiskPart.txt && DiskPart.exe /s C:\DiskPart.txt && DEL C:\DiskPart.txt /Q" -ScriptType BAT -GuestUser $GuestUser -GuestPassword $GuestPassword
#Invoke-VMScript -vm $VM -ScriptText "echo select vol c > c:\diskpart.txt && echo extend >> c:\diskpart.txt && diskpart.exe /s c:\diskpart.txt" -GuestUser $GuestUser -GuestPassword $GuestPassword -ScriptType BAT

#Run powershell with elevated rights:
#run the below command to enter in a remote PowerSehll session:
Enter-PSSession SNAVNADMFINT111.fastts.firstam.net

#Multiple server connections:
$s1, $s2, $s3 = New-PSSession -ComputerName Server01,Server02,Server03
#or
$s = New-PSSession -ComputerName Server01, Server02

Update-HostStorageCache
$MaxSize = (Get-PartitionSupportedSize -DriveLetter c).sizeMax
Resize-Partition -DriveLetter c -Size $MaxSize

Exit-PSSession
