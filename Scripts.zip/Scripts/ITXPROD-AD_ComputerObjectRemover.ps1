################################################################################
Import-Module ActiveDirectory
Import-Module DNSServer
Import-Module NetTCPIP
Function AD-ComputerObject-Cleanup {

    #$ServerName = "DFWVPWEBFRDG017"
    $ServerNameInput = Read-Host -Prompt "ServerName: (NO FQDN)"
    $ServerName = $ServerNameInput.Trim()


    #$DomainName = Read-Host "Domain Name: (ex: ITXPROD.ad)"
    $DomainName = "ITXPROD.ad"

    #$DNSServerName = Read-Host "DNS ServerName: (FQDN, ex: ITXPROD.ad)"
    $DNSServerName = "SNAVPDCGADPA002"

    #$DNSZoneName = Read-Host "DNS ZoneName: (ex: ITXPROD.ad)"
    $DNSZoneName = "ITXPROD.ad"

    $pinger = Resolve-DNSName $ServerName
    $IP = $pinger.IPaddress

    $DomainDN = Get-ADDomain -identity $DomainName | select-object -property  DistinguishedName
    Write-Host = "-------------------------------------" -ForeGroundColor Green
    Write-Host = "Server Name: $ServerName"
    Write-Host = "Server IP Address: $IP"
    Write-Host = "Domain Name: $DomainName"
    Write-Host = "Domain Distinguished Name: $DomainDN"
    Write-Host = "DNS Server Name: $DNSServerName"
    Write-Host = "DNS Zone Name: $DNSZoneName"
    Write-Host = "-------------------------------------" -ForeGroundColor Green

    $Shell = New-Object -ComObject "WScript.Shell"
    $Button = $Shell.Popup("Verify the console detalis (GREEN). Click OK to begin clean-up process.", 0, "Important", 0) 

    Write-Host = "Start: Getting Computer Information------" -ForeGroundColor Green
    Get-ADComputer -Filter {Name -eq $ServerName} -SearchBase $DomainDN.distinguishedname -Server $DNSServerName
    Write-Host = "Complete: Getting Computer Information---" -ForeGroundColor Green
    Write-Host = ""

    Write-Host = ""
    Write-Host = "Start: AD Object Delete-----------------" -ForeGroundColor Green
    Get-ADComputer -Filter {Name -eq $ServerName} -SearchBase $DomainDN.distinguishedname -Server $DNSServerName | Remove-ADComputer
    Write-Host = "Complete: AD Object Delete--------------" -ForeGroundColor Green
    Write-Host = ""

    Write-Host = ""
    Write-Host = "Start: DNS Record Deletion----------------" -ForeGroundColor Green

    #$RecordType = Read-Host "Please Input the Type of DNS Record It Is (A, CNAME, TXT, etc...)"
    $RecordType = "A"
    $NodeDNS = $null
    $NodeDNS = Get-DnsServerResourceRecord -ZoneName $DNSZoneName -ComputerName $DNSServerName -Node $ServerName -RRType $RecordType -ErrorAction SilentlyContinue
    Write-Host = ""
    Write-Host = "Start: DNS Record Details----------------" -ForeGroundColor Green
    $NodeDNS
    Write-Host = "Complete: DNS Record Details-------------" -ForeGroundColor Green
    Write-Host = ""
    if($NodeDNS -eq $null){
        Write-Host "The DNS A Record You Were Looking For Was Not Found" -ForeGroundColor Red
    } else {
        Remove-DnsServerResourceRecord -ZoneName $DNSZoneName -ComputerName $DNSServerName -RecordData $IP -Name $ServerName -RRType $RecordType -Force -Confirm:$true -ErrorAction Stop
        Write-Host "Your DNS A Record $ServerName Has Been Removed" -ForeGroundColor Green
    }
    Write-Host = "Complete: DNS Record Deletion----------------" -ForeGroundColor Green
    Write-Host = ""

}

AD-ComputerObject-Cleanup