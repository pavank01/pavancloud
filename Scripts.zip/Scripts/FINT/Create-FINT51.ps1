# User Defined Variables
$FINTNumber = '51'
$UserNameAzure = 'cthroop@firstam.com'
$UserNameAD = 'cthroop-a@corp.firstam.com'
# Fixed Variables
$ApplicationName = 'FAST'
$EnvironmentName = 'FINT' + ' ' + $FINTNumber
$RMContext = 'SO-1-AzureSub-4'
$ResourceGroupName = 'SO-1-4-FINT-RG-' + $FINTNumber
$StorageAccountName = 'soa1s4fintsa' + $FINTNumber
$ConfigFile = '.\' + $ResourceGroupName + '.xml'
$SQLVM1 = 'AZUVNSQLFINT' + $FINTNumber + '1'
$SQLVM2 = 'AZUVNSQLFINT' + $FINTNumber + '2'
$SQLVM3 = 'AZUVNSQLFINT' + $FINTNumber + '3'
$SQLVM1b = 'AZUVNSQLFINT' + $FINTNumber + '1.fastts.firstam.net'
$SQLVM2b = 'AZUVNSQLFINT' + $FINTNumber + '2.fastts.firstam.net'
$SQLVM3b = 'AZUVNSQLFINT' + $FINTNumber + '3.fastts.firstam.net'

# Establish Credentials
if(!$cred) {$cred = Get-Credential -UserName $UserNameAzure -Message "Enter your Azure credentials"}
if(!$dCred) {$dCred = Get-Credential -UserName $UserNameAD -Message "Enter your CORP -A credentials"}

Add-AzureRmAccount -Credential $cred
Set-AzureRmContext -SubscriptionName $RMContext

# Check for Resource Group and add if needed
try {
    Get-AzureRmResourceGroup -ResourceGroupName $ResourceGroupName -ErrorAction Stop
} catch {
    New-FAAzureRMResourceGroup -ResourceGroupName $StorageAccountName -ApplicationName $ApplicationName -EnvironmentName $EnvironmentName -Location westus
}

# Create the FINT environment
Create-FAAzureEnvironment -ConfigFile $ConfigFile -DomainCred $dCred

# Add the SQL Server Data Disks
Add-FAAzureRMVMDataDisk -ResourceGroupName $ResourceGroupName -VmName $SQLVM1 -StorageAccountName $StorageAccountName -DiskSize '250' -HostCaching ReadWrite -Verbose
Add-FAAzureRMVMDataDisk -ResourceGroupName $ResourceGroupName -VmName $SQLVM2 -StorageAccountName $StorageAccountName -DiskSize '128' -HostCaching ReadWrite -Verbose
Add-FAAzureRMVMDataDisk -ResourceGroupName $ResourceGroupName -VmName $SQLVM3 -StorageAccountName $StorageAccountName -DiskSize '128' -HostCaching ReadWrite -Verbose

# Format the SQL Server Data Disks
Invoke-Command -ComputerName $SQLVM1b,$SQLVM2b,$SQLVM3b -ScriptBlock {Stop-Service ShellHWDetection -Verbose}
Start-Sleep 5
Invoke-Command -ComputerName $SQLVM1b,$SQLVM2b,$SQLVM3b -ScriptBlock {Get-Disk | Where-Object partitionstyle -eq ‘raw’ | Initialize-Disk -PartitionStyle GPT -PassThru | New-Partition -AssignDriveLetter -UseMaximumSize | Format-Volume -FileSystem NTFS -NewFileSystemLabel SQLData -AllocationUnitSize 65536 -Confirm:$false}
Invoke-Command -ComputerName $SQLVM1b,$SQLVM2b,$SQLVM3b -ScriptBlock {Start-Service ShellHWDetection -Verbose}

<#
if (!(Test-Path -Path $ConfigFile)) {
    Write-Host "('.\' + $ResourceGroupName + '.xml') not found!" -ForegroundColor Yellow
    EXIT
}
EXIT
#>