﻿$outputProperties = @{
  ServiceName = ''
  ServerName = ''
  EndPointName = ''
  EndPointProtocol = ''
  EndPointLocalPort = ''
  EndPointPort = ''
  EndPointVip = ''
  Internal = $false
}

$output = New-Object PSObject -Property $outputProperties

$endpointCount = 0

$serviceList = Get-AzureService

foreach ($service in $serviceList) {

  $vmList = Get-AzureVM -ServiceName $service.ServiceName

  $output.ServiceName = $service.ServiceName
  
  foreach ($vm in $vmList) {

    $output.ServerName = $vm.Name

    $endpointList = Get-AzureEndpoint -VM $vm

    foreach ($endpoint in $endpointList) {

      $output.EndPointName = $endpoint.Name
      $output.EndPointProtocol = $endpoint.Protocol
      $output.EndPointLocalPort = $endpoint.LocalPort
      $output.EndPointVip = $endpoint.Vip
      $output.EndPointPort = $endpoint.Port
      $output.Internal = [bool]($endpoint.InternalLoadBalancerName)
          
      $endpointCount += 1

      $output | format-table ServiceName,ServerName,EndPointName,EndPointProtocol,EndPointLocalPort,EndPointVip,EndPointPort,Internal

    }

  }
  
}

Write-Host "$endpointCount endpoints found."
