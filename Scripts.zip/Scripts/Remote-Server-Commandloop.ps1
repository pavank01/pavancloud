﻿# Remote Server Execution by Joe O'Brien
# 1/28/2021 - version 1.0

#List of local Modules for import
#Import-Module NetTCPIP

$cred = Get-Credential

#Create this Text file on your desktop, or update the path below
$Filepath = "$env:USERPROFILE\Desktop\Server-List.txt"
$VMs = Get-Content -Path $Filepath

foreach ($VM in $VMs) 
{
    $s = New-PSSession -ComputerName $VM -Credential $cred -ThrottleLimit 16
    Invoke-Command -Session $s -ScriptBlock {
        #---Remote Logic Start---

        #---Remote Logic End---
    Exit-PSSession
    }
}