#Logging
#$datepre = Get-Date -Format "MMddyyyy"
#$datesuf = Get-Date -Format "HHmm"
#$loggingpath = "$env:USERPROFILE\Desktop\"
#$filename = "$AWSScriptLog-$datepre-$datesuf-$env:USERNAME.txt"
#Write-Host ""
#Start-Transcript -Path $Loggingpath$filename -NoClobber

########################################################################################################


$reportpath = "$env:USERPROFILE\Desktop\aws-tagreport-ProdandNonprod.csv"
#$reportpath = "$env:USERPROFILE\Desktop\aws-tagreport-Prod.csv"

$SourceFolder = "C:\publish\scripts"
$SourceFile = "AWSAccountsList.csv"
$SourcePath = $SourceFolder + "\" + $SourceFile
$SourceHeadersDirty = Get-Content -Path $SourcePath -First 2 | ConvertFrom-Csv
$SourceHeadersCleaned = $SourceHeadersDirty.PSObject.Properties.Name.Trim(' ') -Replace '\s',''

$listofawsaccounts = Import-CSV -Path $SourcePath -Header $SourceHeadersCleaned | Select-Object -Skip 1
#$listofawsaccounts | Format-Table -AutoSize

#$prodawsaccounts = $listofawsaccounts | where Environment -eq "P"
#$nonprodawsaccounts = $listofawsaccounts | where Environment -notlike "P"

$prodawsaccounts = $listofawsaccounts | Where-Object {
    ($_.Environment -eq "P") -and ($_.Environment -notlike "")
}
$nonprodawsaccounts = $listofawsaccounts | Where-Object {
    ($_.Environment -notlike "P") -and ($_.Environment -notlike "")
}
$unknownawsaccounts = $listofawsaccounts | where Environment -eq ""
#$unknownawsaccounts

#RecordsCount
$i = 0
foreach ($awsaccount in $nonprodawsaccounts) {
    $i++   
}
$nonprodawsaccountscount = $i
Write-host = "There are $i Non-Production Accounts in the CSV." -ForegroundColor Green
$i = 0
foreach ($awsaccount in $prodawsaccounts) {
    $i++   
}
$prodawsaccountscount = $i
Write-host = "There are $i Production Accounts in the CSV." -ForegroundColor Green
$i = 0
foreach ($awsaccount in $unknownawsaccounts) {
    $i++   
}
$unknownawsaccountscount = $i
Write-host ""
Write-host = "There are $i Accounts WITHOUT an Environment Code (P/N/S) in the CSV. Skipping." -ForegroundColor Red
Write-Host "    SOURCE: AWSAccountList.csv in the CloudEnginnering Repository." -ForegroundColor Yellow  
Write-Host "    INFO: This file is created from http://test.cloudmanagement.firstam.net/AWSAccountList.html" -ForegroundColor Yellow    
Write-host "    NOTE: The following Accounts will not be processed." -ForegroundColor Yellow
foreach ($awsaccount in $unknownawsaccounts) {
    $excludedaccountid = $awsaccount.id
    $excludedaccountname = $awsaccount.AccountName
    Write-Host "---------------------------------------"
    Write-Host "ID:               $excludedaccountid"    
    Write-Host "AccountName:      $excludedaccountname"
}
$unknownawsaccountscount = $i
Write-host "---------------------------------------"

#Set Profile using One note page- AWS CLI configuration and Profile set up
Write-Host "Starting Non-Production Servers" -ForegroundColor Green
Write-Host ""
aws-azure-login --profile xacc-n-0

#Id_ceng contains Accound Ids for which taggings has to be retrieved

#$AccountIdList = (get-content "C:\Users\swsahoo\Desktop\AWS-Tag\Id_ceng.txt")
$count = 1  #this is a check to confirm total account numbers
ForEach ($awsaccount in $nonprodawsaccounts){
    
    $awsID = $awsaccount.ID
    $awsAccountname = $awsaccount.AccountName
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    Write-Host "Processing $count of $nonprodawsaccountscount)" -ForegroundColor Green
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    Write-Host "AWS AccountName = $awsAccountname"
    Write-Host "AWS AccountID = $awsID"
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    $arn = "arn:aws:iam::$awsID" + ":role/FirstAm_super-pds"
    $assume_role = aws sts assume-role --role-arn $arn --role-session-name test-tagDetails --profile xacc-n-0 --no-verify-ssl 
    $a = $assume_role  | ConvertFrom-Json 
    $count++     
  
    ForEach ($x in $a){
        $env:AWS_Access_Key_ID = $x.Credentials.AccessKeyId
        $env:AWS_SECRET_Access_Key = $x.Credentials.SecretAccessKey
        $env:AWS_SESSION_TOKEN = $x.Credentials.SessionToken
    }

    $awsregion = "us-east-2"    
    Write-Host "$awsregion-----------------------------------------------------------" -ForegroundColor Green    
    $data = aws ec2 describe-tags --query 'Tags[?ResourceType==`instance`]' --region $awsregion --no-verify-ssl
    $h = $data | ConvertFrom-Json
    $hg = $h | Group-Object ResourceID
    $report = @()
    ForEach ($inst In $hg) {
        $report += [PSCustomObject][Ordered]@{
        EC2InstanceName             = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "Name"} ).Value
        AWSAccountId                = $awsID
        AWSAccountName              = $awsAccountname
        ApplicationID               = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "ApplicationID"} ).Value
        ApplicationName             = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "ApplicationName"} ).Value
        ApplicationServiceName      = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "ApplicationServiceName"} ).Value
        BusinessApplicationNumber   = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "BusinessApplicationNumber"} ).Value
        ApplicationServiceNumber    = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "ApplicationServiceNumber"} ).Value
        BusinessApplicationName     = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "BusinessApplicationName"} ).Value
        EC2instanceID               = $inst.Name  # <-- i-01f4c9f8cfd47a63e
        EC2regionName               = $awsregion
        }
    }
    $report | Export-CSV $reportpath -noTypeInfo -Append

    $awsregion = "us-west-2"
    Write-Host "$awsregion-----------------------------------------------------------" -ForegroundColor Green    
    $data = aws ec2 describe-tags --query 'Tags[?ResourceType==`instance`]' --region $awsregion --no-verify-ssl
    $h = $data | ConvertFrom-Json
    $hg = $h | Group-Object ResourceID
    $report = @()
    ForEach ($inst In $hg) {
        $report += [PSCustomObject][Ordered]@{
        EC2InstanceName             = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "Name"} ).Value
        AWSAccountId                = $awsID
        AWSAccountName              = $awsAccountname
        ApplicationID               = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "ApplicationID"} ).Value
        ApplicationName             = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "ApplicationName"} ).Value
        ApplicationServiceName      = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "ApplicationServiceName"} ).Value
        BusinessApplicationNumber   = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "BusinessApplicationNumber"} ).Value
        ApplicationServiceNumber    = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "ApplicationServiceNumber"} ).Value
        BusinessApplicationName     = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "BusinessApplicationName"} ).Value
        EC2instanceID               = $inst.Name  # <-- i-01f4c9f8cfd47a63e
        EC2regionName               = $awsregion
        }
    }
    $report | Export-CSV $reportpath -noTypeInfo -Append
}
Write-Host "END-----------------------------------------------------------" -ForegroundColor Green


Write-Host "Starting Production Servers" -ForegroundColor Green
Write-Host ""
aws-azure-login --profile xacc-p-0
##############################################################################################################################################################
$count = 1  #this is a check to confirm total account numbers
ForEach ($awsaccount in $prodawsaccounts){
    
    $awsID = $awsaccount.ID
    $awsAccountname = $awsaccount.AccountName
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    Write-Host "Processing $count of $prodawsaccountscount)" -ForegroundColor Green
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    Write-Host "AWS AccountName = $awsAccountname"
    Write-Host "AWS AccountID = $awsID"
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    $arn = "arn:aws:iam::$awsID" + ":role/FirstAm_super-pds"
    $assume_role = aws sts assume-role --role-arn $arn --role-session-name test-tagDetails --profile xacc-p-0 --no-verify-ssl 
    $a = $assume_role  | ConvertFrom-Json 
    $count++     
  
    ForEach ($x in $a){
        $env:AWS_Access_Key_ID = $x.Credentials.AccessKeyId
        $env:AWS_SECRET_Access_Key = $x.Credentials.SecretAccessKey
        $env:AWS_SESSION_TOKEN = $x.Credentials.SessionToken
    }

    $awsregion = "us-east-2"    
    Write-Host "$awsregion-----------------------------------------------------------" -ForegroundColor Green    
    $data = aws ec2 describe-tags --query 'Tags[?ResourceType==`instance`]' --region $awsregion --no-verify-ssl
    $h = $data | ConvertFrom-Json
    $hg = $h | Group-Object ResourceID
    $report = @()
    ForEach ($inst In $hg) {
        $report += [PSCustomObject][Ordered]@{
        EC2InstanceName             = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "Name"} ).Value
        AWSAccountId                = $awsID
        AWSAccountName              = $awsAccountname
        ApplicationID               = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "ApplicationID"} ).Value
        ApplicationName             = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "ApplicationName"} ).Value
        ApplicationServiceName      = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "ApplicationServiceName"} ).Value
        BusinessApplicationNumber   = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "BusinessApplicationNumber"} ).Value
        ApplicationServiceNumber    = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "ApplicationServiceNumber"} ).Value
        BusinessApplicationName     = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "BusinessApplicationName"} ).Value
        EC2instanceID               = $inst.Name  # <-- i-01f4c9f8cfd47a63e
        EC2regionName               = $awsregion
        }
    }
    $report | Export-CSV $reportpath -noTypeInfo -Append

    $awsregion = "us-west-2"
    Write-Host "$awsregion-----------------------------------------------------------" -ForegroundColor Green    
    $data = aws ec2 describe-tags --query 'Tags[?ResourceType==`instance`]' --region $awsregion --no-verify-ssl
    $h = $data | ConvertFrom-Json
    $hg = $h | Group-Object ResourceID
    $report = @()
    ForEach ($inst In $hg) {
        $report += [PSCustomObject][Ordered]@{
        EC2InstanceName             = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "Name"} ).Value
        AWSAccountId                = $awsID
        AWSAccountName              = $awsAccountname
        ApplicationID               = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "ApplicationID"} ).Value
        ApplicationName             = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "ApplicationName"} ).Value
        ApplicationServiceName      = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "ApplicationServiceName"} ).Value
        BusinessApplicationNumber   = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "BusinessApplicationNumber"} ).Value
        ApplicationServiceNumber    = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "ApplicationServiceNumber"} ).Value
        BusinessApplicationName     = ( $inst.Group | Where-Object {$_.Key.Trim() -eq "BusinessApplicationName"} ).Value
        EC2instanceID               = $inst.Name  # <-- i-01f4c9f8cfd47a63e
        EC2regionName               = $awsregion
        }
    }
    $report | Export-CSV $reportpath -noTypeInfo -Append
}
Write-Host "END-----------------------------------------------------------" -ForegroundColor Green

#$report | Export-CSV $reportpath -noTypeInfo -Append
Write-Host "Count:  $count" #confirms total aws account numbers

#Stop-Transcript