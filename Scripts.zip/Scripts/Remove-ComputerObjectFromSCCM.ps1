<#
.SYNOPSIS
Removes the computer object from SCCM.
    
.DESCRIPTION
When imaging a computer with a name that has been previously imaged with SCCM, you need to remove it from SCCM first prior to imaging.

.PARAMETER ComputerName
The name or names of the computers to remove from SCCM as computer object(s).

.INPUTS
None

.OUTPUTS
None

.NOTES
Version:    2.1
Author:     Mark Skiba, Chris Throop
Date:       2/12/2019

.EXAMPLE
.\Remove-ComputerObjectFromSCCM.ps1 -ComputerName AZUVNAPPFAKE001

.EXAMPLE
.\Remove-ComputerObjectFromSCCM.ps1 -ComputerName AZUVNAPPFAKE001,AZUVNAPPFAKE002
#>

#---------------------------------------------------------[Script Parameters]------------------------------------------------------

[CmdletBinding()]
param (
    [Parameter(Mandatory=$true)]
    [string[]] $ComputerName
)

#----------------------------------------------------------[Declarations]----------------------------------------------------------

$SecretKey = "eb89a0e9-2b08-4c03-a052-9a8cbacbdcf8"
$URI = "http://snavpmgtsccm001.corp.firstam.com/ConfigMgrWebService/ConfigMgr.asmx"

#-----------------------------------------------------------[Execution]------------------------------------------------------------

Write-Host "" ; Write-Host "Attempting to Remove Computer Object(s) from SCCM ..."
$ComputerName | ForEach-Object ($_) {
    $Computer = $_
    # Remove Computer Object from SCCM
    try {
        $WebService = New-WebServiceProxy -Uri $URI -ErrorAction Stop

        # Delete Computer Object from SCCM
        $Invocation = $WebService.RemoveCMDeviceByName($SecretKey, $Computer)
        if($Invocation -eq "1") {
                    Write-Host "$Computer removed from SCCM" -ForegroundColor Green
            } else {
                    Write-Host "$Computer not found in SCCM [Code $Invocation]" -ForegroundColor Yellow
            }
        }
        catch [System.Exception] {
        Write-Warning -Message "[FAILED] An error occured while attempting to calling web service. Error message: $($_.Exception.Message)"
    }
}