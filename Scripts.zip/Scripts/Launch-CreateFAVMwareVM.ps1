﻿<#
.SYNOPSIS
A wrapper script used to launch the Create-FAVMwareStandardVM.ps1 script.

.DESCRIPTION
A PowerShell script to launch the Create-FAVMwareStandardVM.ps1 script which will target a particular cluster location
based on VM type.

.PARAMETER VMName
The name of the virtual machine to create.

.PARAMETER CpuCount,
The number of CPUs to assign to the VM.

.PARAMETER MemoryGB
The amount of memory to assign to the VM in GB.

.PARAMETER Environment
The target environment to build the VM in. Options are "Production","Production-FAST","Production-Large",
"NonProduction","NonProduction-FAST","NonProduction-Large","DisasterRecovery","DisasterRecovery-FAST","DisasterRecovery-Large".

.PARAMETER Folder
The name of the vSphere folder to build the VM in.

.PARAMETER Template
The template used for your operating system choice. Options will be a standard build for each version of OS.

.PARAMETER AdminPassword
The local admin password. This is a plain text string, so best practice is to use a throw away password and then change it to our default from the server.

.PARAMETER DomainJoin
The fully qualified name of a domain to be joined. This parameter is optional.

.PARAMETER OUPath
The OU to be used for the domain join. This parameter is optional unless domainJoin is specified.

.PARAMETER DomainCredential
The AD credential object to be used for the domain join. The format for user name must follow the following pattern: user-a@fully qualified domain name.
This parameter is optional unless domainJoin is specified. The default value will prompt for credentials.

.PARAMETER ApplicationName
Application Name for CMDB

.PARAMETER ApplicationID
Application ID for CMDB

.PARAMETER EnvironmentName
Environment Name fpor CMDB

.PARAMETER SkipMap
Skip CMDB Mapping Process but will be notified to managment

.PARAMETER Force
This switch will force the script to skip user prompts for CPU and Memory validation, and the AD Object check. Use this when automating builds.

.INPUTS
None.  You cannot pipe input to Launch-CreateFAVMwareVM.ps1.

.OUTPUTS
None.  Launch-CreateFAVMwareVM.ps1 does not generate any output.

.EXAMPLE
.\Launch-CreateFAVMwareVM.ps1 -VMName snavnmsjvmwr808 -CpuCount 2 -MemoryGB 4 -Environment NonProduction -Folder _vm-mgmt -Template FAStandard2012R2 -AdminPassword 'pa$$Word' -DomainJoin 'corp.firstam.com' -OUPath 'ou=cloudteam,ou=environments,ou=servers,ou=datacenter,dc=corp,dc=firstam,dc=com'

Creates a VM in an AD domain. The script will prompt for domain credentials

.EXAMPLE
.\Launch-CreateFAVMwareVM.ps1 -VMName snavnmsjvmwr808 -CpuCount 2 -MemoryGB 4 -Environment NonProduction -Folder _vm-mgmt -Template FAStandard2012R2 -AdminPassword 'pa$$Word'

Creates a standalone VM.

.EXAMPLE
.\Launch-CreateFAVMwareVM.ps1 -VMName snavnmsjvmwr808 -CpuCount 8 -MemoryGB 24 -Environment NonProduction -Folder _vm-mgmt -Template FAStandard2012R2 -AdminPassword 'pa$$Word' -DomainJoin 'corp.firstam.com' -OUPath 'ou=cloudteam,ou=environments,ou=servers,ou=datacenter,dc=corp,dc=firstam,dc=com' -force

Creates a VM and skips any prompts for existing AD object or over capacity settings.

.EXAMPLE
.\Launch-CreateFAVMwareVM.ps1 -VMName snavnmsjvmwr808 -CpuCount 2 -MemoryGB 4 -Environment NonProduction -Folder _vm-mgmt -Template FAStandard2016_Shell -Shell -ApplicationName 'Microsoft Azure - Test' -ApplicationID APP0002496 -EnvironmentName 'Test'

Creates a VM and AutoMaps the server to Application.

.EXAMPLE
.\Launch-CreateFAVMwareVM.ps1 -VMName snavnmsjvmwr808 -CpuCount 2 -MemoryGB 4 -Environment NonProduction -Folder _vm-mgmt -Template FAStandard2016_Shell -Shell -ApplicationName 'Microsoft Azure - Test' -ApplicationID APP0002496 -EnvironmentName 'Test' -skipMap

Creates a VM and skips Automapping of server to Application.
#>

#------------------------------------------------------------------------------
#region - Parameters
#------------------------------------------------------------------------------
[CmdletBinding(DefaultParameterSetName='NoDomain')]
Param(

    [Parameter(Mandatory=$True)]
    [string]$VMName,

    [Parameter(Mandatory=$True)]
    [int]$CpuCount,

    [Parameter(Mandatory=$True)]
    [int]$MemoryGB,

    [Parameter(Mandatory=$True)]
    [ValidateSet("Production","Production-FAST","Production-Large","NonProduction","NonProduction-FAST","NonProduction-Large","DisasterRecovery","DisasterRecovery-FAST","DisasterRecovery-Large")]
    [string]$Environment,

    [Parameter(Mandatory=$True)]
    [string]$Folder,

    #TVP - Added "FAStandard2016_Shell"
    [Parameter(Mandatory=$True)]
    [ValidateSet("FAStandard2008R2","FAStandard2012","FAStandard2012R2","FAStandard2016_Shell","FAStandard2012R2_Shell")]
    [string]$Template,

    [Parameter(Mandatory=$True)]
    [string]$AdminPassword,

    [Parameter(ParameterSetName='Domain',Mandatory=$True)]
    [string]$DomainJoin,

    [Parameter(ParameterSetName='Domain',Mandatory=$True)]
    [PSCredential]$DomainCredential,

    [Parameter(ParameterSetName='Domain',Mandatory=$True)]
    [string]$OUPath,

    [Parameter(Mandatory=$False)]
    [switch]$Force,
    
    # BAN -- Added three Mandatory paramenters(ApplicationName,ApplicationID,EnvironmentName) and one switch parameter (SkipMap)

    [Parameter(Mandatory=$True)]
    [string]$ApplicationName,

    [Parameter(Mandatory=$True)]
    [string]$ApplicationServiceNumber,

    [Parameter(Mandatory=$True)]
    [string]$EnvironmentName,

    [Parameter(Mandatory = $false)]
    [switch]$SkipMap,

    #TVP Added Below
    [Parameter(Mandatory=$False)]
    [switch]$Shell
)
#------------------------------------------------------------------------------
#endregion - Parameters
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Constants
#------------------------------------------------------------------------------

$BuildTargetPath = '.\VMwareBuildTargets.txt'

#------------------------------------------------------------------------------
#endregion - Constants
#------------------------------------------------------------------------------
# BAN -- Added Auto Mapping - Begin

function Test-CMDBApplication{
	[CmdletBinding()]
	param(
		[parameter(Mandatory = $true)]
		$ApplicationServiceNumber,
		[parameter(Mandatory = $true)]
		$ServerName,
		[parameter(Mandatory = $true)]
		$UserName
	)
	Begin{
		
		$ServiceURI = "http://facmdbmapping.firstam.net/api/map?app_id=$ApplicationServiceNumber&server_name=$ServerName&username=$UserName"

	}
	Process{
		$response = Invoke-WebRequest -Uri $ServiceURI -Method Post -UseDefaultCredentials -UseBasicParsing

		$responseObj = $response.Content | ConvertFrom-Json

		if($responseObj.Status -eq "Created"){
			$status = New-Object -TypeName psobject -Property @{
						status = "$ServerName Created in the database"
						error = ""
					  }
					  return $status
		}
		elseif($responseObj.Status -eq "Mapped"){
			
			$status = New-Object -TypeName psobject -Property @{
						status = "Server $ServerName mapped successfully with Application in CMDB"
						error = ""
					  }
			 return $status
		}
		elseif($responseObj.Status -eq "AlreadyMapped"){
			$status = New-Object -TypeName psobject -Property @{
						status = "Server $ServerName Already mapped with Application in CMDB"
						error = ""
					  }
			 return $status
		}
		else{
			$status = New-Object -TypeName psobject -Property @{
						status = $responseObj.Error
						error = $responseObj.Error
					  }
			return $status
		}
	}
	End{
	
	}

}

if(-not $PSBoundParameters["SkipMap"]){
    $status = Test-CMDBApplication -ApplicationServiceNumber $ApplicationServiceNumber -ServerName $VMName -UserName $env:UserName
    if($status.error -ne "") {
        throw [Exception] $status.error 
        Write-Host "Error: $($status.status)" -ForegroundColor Yellow
    }
    else{
        Write-Host $status.status 
        Write-Host "$($status.status)" 
    }
}
else{
    Write-Host "Executing script: 'Launch-CreateFAVMWareVM.ps1'. VM Mapping Skiped by the user $($env:UserName)"
    #Send mail to product owners, Tarek and Tuan.
    #region 
 $user= [System.Security.Principal.WindowsIdentity]::GetCurrent().Name -split '\\'
        $usermail=$user[1] -split '-'
        $usermail1= $usermail[0]

$MailFrom           = $($global:DefaultViServer.Name) + '@firstam.com'
$MailTo             = "$usermail1@firstam.com","tpham@firstam.com","tghalwash@firstam.com","VShubhand@firstam.com"
$MailSubject        = 'SkipMap Alert'
$MailBody           = @"
$($global:DefaultViServer.User) used the SkipMap during the VM-Build.
Server Name = $VMName 
vCentre = $($global:DefaultViServer.Name)
Application ID = $ApplicationServiceNumber 
Application Name = $ApplicationName 

"@
$SMTPServer         = 'mail.firstam.com'
Send-MailMessage -From $MailFrom -To $MailTo -Subject $MailSubject -SmtpServer $SMTPServer -Body $MailBody
    #endregion
    Write-Verbose "VM Mapping Skiped by the user $($env:UserName)"
}

#Auto Mapping - End
#------------------------------------------------------------------------------
#region - Main
#------------------------------------------------------------------------------

Try {

    # determine which environment the VM will use
    $environmentOptions = (Get-Content -Path $BuildTargetPath) -join "`n" | ConvertFrom-Json -ErrorAction Stop

    $BuildTarget = $environmentOptions | Where-Object {$_.Name -eq $Environment}

    # check for current vCenter server connection and logoff if there is one
    if ($global:DefaultVIServer) {

        Disconnect-VIServer -Server * -Confirm:$False -ErrorAction Stop

    }

    # connect to the appropriate vCenter server
    Connect-VIServer -Server $BuildTarget.ServerName -ErrorAction Stop

} Catch {

    Write-Warning $Error[0]

    Exit 0

}

# pass the following variables to the build script Create-FAVMwareStandardVM.ps1
# TVP - added "if" statement below for Shell VMs
# RA - 01-12-2018 - Added AdminPassword to the BuildVariables when -Shell is used. It is required by Create-FAVMwareStandardVM.ps1 so automation was broken

if ($shell) {

    $BuildVariables = @{

        VMName = $VMName
        CpuCount = $CpuCount
        MemoryGB = $MemoryGB
        Cluster = $BuildTarget.ClusterName
        DatastoreCluster = $BuildTarget.DatastoreClusterName
        Folder = $Folder
        PortGroup = $BuildTarget.PortGroupName
        Template = $Template
        Shell = $shell
        AdminPassword = $AdminPassword
        ApplicationName = $ApplicationName
        ApplicationServiceNumber   = $ApplicationServiceNumber
        EnvironmentName = $EnvironmentName

    }

}

elseif ($DomainJoin) {

    $BuildVariables = @{

        VMName = $VMName
        CpuCount = $CpuCount
        MemoryGB = $MemoryGB
        Cluster = $BuildTarget.ClusterName
        DatastoreCluster = $BuildTarget.DatastoreClusterName
        Folder = $Folder
        PortGroup = $BuildTarget.PortGroupName
        Template = $Template
        AdminPassword = $AdminPassword
        DomainJoin = $DomainJoin
        DomainCredential = $DomainCredential
        OUPath = $OUPath
        Force = $Force
        ApplicationName = $ApplicationName
        ApplicationServiceNumber   = $ApplicationServiceNumber
        EnvironmentName = $EnvironmentName

    }

} else {

    $BuildVariables = @{

        VMName = $VMName
        CpuCount = $CpuCount
        MemoryGB = $MemoryGB
        Cluster = $BuildTarget.ClusterName
        DatastoreCluster = $BuildTarget.DatastoreClusterName
        Folder = $Folder
        PortGroup = $BuildTarget.PortGroupName
        Template = $Template
        AdminPassword = $AdminPassword
        Force = $Force
        ApplicationName = $ApplicationName
        ApplicationServiceNumber   = $ApplicationServiceNumber
        EnvironmentName = $EnvironmentName

    }

}


.\Create-FAVMwareStandardVM.ps1 @BuildVariables

# BAN -- Updating Custom Attributes to the VM - Begin
$date=Get-Date
$CreatedBy=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name
#Get-VM -Name $VMName  | Set-Annotation -CustomAttribute "Application" -Value $ApplicationName | Out-Null
if(Get-VM -Name $VMName |Get-Annotation -CustomAttribute "Application" -ErrorAction SilentlyContinue){
    New-CustomAttribute -TargetType "VirtualMachine" -Name "Application" -ErrorAction SilentlyContinue| Out-Null
    Get-VM -Name $VMName  | Set-Annotation -CustomAttribute "Application" -Value $ApplicationName |Out-Null
    
    }
    else{
    
    Get-VM -Name $VMName   | Set-Annotation -CustomAttribute "Application" -Value $ApplicationName |Out-Null
    }
#Get-VM -Name $VMName  | Set-Annotation -CustomAttribute "ApplicationID" -Value $ApplicationID | Out-Null
if(Get-VM -Name $VMName |Get-Annotation -CustomAttribute "ApplicationServiceNumber" -ErrorAction SilentlyContinue ){
    New-CustomAttribute -TargetType "VirtualMachine" -Name "ApplicationServiceNumber" -ErrorAction SilentlyContinue | Out-Null
    Get-VM -Name $VMName  | Set-Annotation -CustomAttribute "ApplicationServiceNumber" -Value $ApplicationServiceNumber | Out-Null
    
    }
    else{
    
    Get-VM -Name $VMName   | Set-Annotation -CustomAttribute "ApplicationServiceNumber" -Value $ApplicationServiceNumber |Out-Null
    }
#Get-VM -Name $VMName  | Set-Annotation -CustomAttribute "Environment (Prod/DEV/Test)" -Value $EnvironmentName | Out-Null
if(Get-VM -Name $VMName |Get-Annotation -CustomAttribute "Environment (Prod/DEV/Test)" -ErrorAction SilentlyContinue){
    New-CustomAttribute -TargetType "VirtualMachine" -Name "Environment (Prod/DEV/Test)" -ErrorAction SilentlyContinue | Out-Null
    Get-VM -Name $VMName  | Set-Annotation -CustomAttribute "Environment (Prod/DEV/Test)" -Value $EnvironmentName | Out-Null
    
    }
    else{
    
    Get-VM -Name $VMName   | Set-Annotation -CustomAttribute "Environment (Prod/DEV/Test)" -Value $EnvironmentName |Out-Null
    }
#Get-VM -Name $VMName  | Set-Annotation -CustomAttribute "CreatedBy" -Value $CreatedBy | Out-Null
if(Get-VM -Name $VMName |Get-Annotation -CustomAttribute "CreatedBy" -ErrorAction SilentlyContinue ) {
    New-CustomAttribute -TargetType "VirtualMachine" -Name "CreatedBy" -ErrorAction SilentlyContinue | Out-Null
    Get-VM -Name $VMName  | Set-Annotation -CustomAttribute "CreatedBy" -Value $CreatedBy | Out-Null
    
    }
    else{
    
    Get-VM -Name $VMName   | Set-Annotation -CustomAttribute "CreatedBy" -Value $CreatedBy |Out-Null
    }
#Get-VM -Name $VMName  | Set-Annotation -CustomAttribute "CreatedOn" -Value $date | Out-Null
if(Get-VM -Name $VMName |Get-Annotation -CustomAttribute "CreatedOn" -ErrorAction SilentlyContinue){
    New-CustomAttribute -TargetType "VirtualMachine" -Name "CreatedOn" -ErrorAction SilentlyContinue | Out-Null
    Get-VM -Name $VMName  | Set-Annotation -CustomAttribute "CreatedOn" -Value $date | Out-Null
    
    }
    else{
    
    Get-VM -Name $VMName   | Set-Annotation -CustomAttribute "CreatedOn" -Value $date |Out-Null
    }#Updating Custom Attributes to the VM - End 

#------------------------------------------------------------------------------
#endregion - Main
#------------------------------------------------------------------------------