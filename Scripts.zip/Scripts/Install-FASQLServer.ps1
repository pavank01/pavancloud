﻿<#
.SYNOPSIS
Install Microsoft SQL Server using a configuration file.

.DESCRIPTION
A PowerShell script to install Microsoft SQL Server using a SQL 
configuration file in a manner that supports an unattended installation.  
The script support creating a local cache of the SQL installation media as 
well as several optional parameters for common SQL configurations. 

Please review https://msdn.microsoft.com/en-us/library/ms144259(v=sql.120).aspx 
for information on the configuration file and paramters.

.PARAMETER Source
The path to the folder containing source files for the SQL installation.

.PARAMETER ConfigurationFile
The path to the SQL configuration file to be used for the installation.

.PARAMETER Instance
The name of the SQL Server instance.  This paramter is used for SQL 
InsanceName and InstanceID.  If not specified, the default instance of 
'MSSQLSERVER' will be used. 

.PARAMETER InstallSQLDataDir
The default root folder for all SQL database folders.

.PARAMETER SQLBackupDir
The default folder to be used for SQL backup files.  If not specified, this 
will use the default location of <InstallSQLDataDir>\<SQLInstanceID>\MSSQL\Back 

.PARAMETER SQLUserDBDir
The default folder to be used for SQL database files.  If not specified, 
this will use the default location of <InstallSQLDataDir>\<SQLInstanceID>\MSSQL\Data

.PARAMETER SQLUserDBLogDir
The default folder to be used for SQL transaction log files.  If not specified, 
this will use the default location of <InstallSQLDataDir>\<SQLInstanceID>\MSSQL\Data

.PARAMETER SQLTempDBDir
The default folder to be used for SQL TempDB database files.  If not specified, 
this will use the default location of <InstallSQLDataDir>\ <SQLInstanceID>\MSSQL\Data

.PARAMETER SQLTempDBLogDir 
The default folder to be used for SQL TempDB transaction log files.  If not 
specified, this will use the default location of <InstallSQLDataDir>\ <SQLInstanceID>\MSSQL\Data

.PARAMETER SQLAgentSvcCred
A PSCredential object containing the service account and password to be used 
for the SQL Server Agent.  This is used to pass the AGTSVCACCOUNT and 
AGTSVCPASSWORD parameters to the SQL installer.  

It is recommended that you 
create the PSCredential object in advance and pass it as a parameter, but 
creating it on the fly will work as well.  Both options below are valid:     

Pre-create:
        $SvcCred = Get-Credential
        <command> -SQLSvcCred $SvcCred
        
    On the fly:
        <command> -SQLSvcCred $(Get-Credential)

Please review https://msdn.microsoft.com/en-us/library/ms143504(v=sql.120).aspx#Default_Accts 
for information on SQL Server Service accounts.

.PARAMETER SQLSvcCred
A PSCredential object containing the service account and password to be used 
for the SQL Server Database Engine.  This is used to pass the SQLSVCACCOUNT and 
SQLSVCPASSWORD parameters to the SQL installer.

It is recommended that you create the PSCredential object in advance and pass 
it as a parameter, but creating it on the fly will work as well.  Both options 
below are valid:

    Pre-create:
        $SvcCred = Get-Credential
        <command> -SQLSvcCred $SvcCred
        
    On the fly:
        <command> -SQLSvcCred $(Get-Credential)

Please review https://msdn.microsoft.com/en-us/library/ms143504(v=sql.120).aspx#Default_Accts for information
on SQL Server Service accounts.

.PARAMETER SQLSysAdminAccounts
The users or groups to be members of the sysadmin role.  If not specified the 
local Administrators group will be used.

This can be specified as a single value such as "domain\group" or an array with 
multiple values such as @('domain\group','domain\user','domain\other group2').

.PARAMETER LocalCacheDrive
An optional parameter instructing the script to copy the contents of the Source 
folder to a local folder prior to installation.  This parameter is the drive 
letter only (e.g. D:) and works in conjunction with the LocalCacheFolder and 
Force parameters.

.PARAMETER LocalCacheFolder
If LocalCacheDrive is specified, this parameter specifies name of a folder 
under <LocalCacheDrive>\Software to be used for the local copy of the SQL 
installation files.  If not specified, a random folder name in GUID format will 
be used.

.PARAMETER Force
A switch used when LocalCacheDrive has been specified and the LocalCacheFolder 
contains files.  If specified, all content in the LocalCacheFolder will be 
replaced with the files from the Source.

.PARAMETER Interactive
A switch to override the unattended installation and allow changes to be made 
or verified during the installation process.

.INPUTS
None.  You cannot pipe input to Install-FASQLServer.

.OUTPUTS
None.  Install-FASQLServer does not generate any output beyond status information.

.EXAMPLE
C:\PS> .\Install-FASQLServer.ps1 -Source \\server\share\SQL2014\Standard 
        -ConfigurationFile \\server\share\SQL\configs\config.ini 
        -InstallSQLDataDir 'D:\SQLData'

C:\PS> .\Install-FASQLServer.ps1 -Source \\server\share\SQL2014\Standard 
        -ConfigurationFile \\server\share\SQL\configs\config.ini
        -InstallSQLDataDir 'D:\SQLData' -LocalCacheDrive 'D:' 
        -LocalCacheFolder 'SQL2014-Standard'
#>

#------------------------------------------------------------------------------
#region - Parameters
#------------------------------------------------------------------------------
[CmdletBinding( SupportsShouldProcess=$true, DefaultParameterSetName='UseRemoteSource' )]
Param (

    [Parameter(Mandatory=$true)]
    [string]$Source,

    [Parameter(Mandatory=$true)]
    [string]$ConfigurationFile,

    [Parameter(Mandatory=$false)]
    [string]$Instance = 'MSSQLSERVER',

    [Parameter(Mandatory=$true)]
    [string]$InstallSQLDataDir,

    [Parameter(Mandatory=$false)]
    [string]$SQLBackupDir,

    [Parameter(Mandatory=$false)]
    [string]$SQLUserDBDir,

    [Parameter(Mandatory=$false)]
    [string]$SQLUserDBLogDir,

    [Parameter(Mandatory=$false)]
    [string]$SQLTempDBDir,

    [Parameter(Mandatory=$false)]
    [string]$SQLTempDBLogDir,

    [Parameter(Mandatory=$false)]
    [PSCredential]$SQLAgentSvcCred,

    [Parameter(Mandatory=$false)]
    [PSCredential]$SQLSvcCred,
    
    [Parameter(Mandatory=$false)]
    [string[]]$SQLSysAdminAccounts,

    [Parameter(Mandatory=$true,ParameterSetName='UseLocalSource')]
    [ValidateSet("C:", "D:", "E:", "F:", "G:", "H:", "I:", "J:", "K:", "L:", "M:", "N:", "O:", "P:", "Q:", "R:", "S:", "T:", "U:", "V:", "W:", "X:", "Y:", "Z:")]
    [string]$LocalCacheDrive,

    [Parameter(Mandatory=$false,ParameterSetName='UseLocalSource')]
    [string]$LocalCacheFolder = [GUID]::NewGuid().Guid,

    [Parameter(Mandatory=$false,ParameterSetName='UseLocalSource')]
    [switch]$Force,

    [Parameter(Mandatory=$false)]
    [switch]$Interactive

)
#------------------------------------------------------------------------------
#endregion - Parameters
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Constants
#------------------------------------------------------------------------------

$LocalCacheParentFolder = 'Software'

#------------------------------------------------------------------------------
#endregion - Constants
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Validate that the source folder exists
#------------------------------------------------------------------------------

if ( Test-Path -Path $Source ) {

    Write-Verbose "Source is $Source"

} else {

    Throw "Cannot use specified Source, $Source does not exist"

}
#------------------------------------------------------------------------------
#endregion - Validate that the source folder exists
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Validate that the configuration file exists
#------------------------------------------------------------------------------

if ( Test-Path -Path $ConfigurationFile ) {

    # Make sure the Configuration File is a fully qualified path
    $ConfigurationFile = $(Get-Item -Path $ConfigurationFile).FullName
    Write-Verbose "ConfigurationFile is $ConfigurationFile"

} else {

    Throw "Cannot use specified ConfigurationFile, $ConfigurationFile does not exist"

}
#------------------------------------------------------------------------------
#endregion - Validate that the configuration file exists
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Check local cache folder
#------------------------------------------------------------------------------

if ($LocalCacheDrive) {

    # Make sure the drive exists
    if ( Test-Path -Path $LocalCacheDrive ) {

        # Calculate the InstallSource based on parameters passsed
        $InstallSource = Join-Path -Path $(Join-Path -Path $LocalCacheDrive -ChildPath $LocalCacheParentFolder) -ChildPath $LocalCacheFolder

    } else {

        # The LocalCacheDrive does not exist
        Throw "Cannot use specified LocalCacheDrive, $LocalCacheDrive does not exist"
        
    }

} else {

    # Not using a local cache, install from the source
    $InstallSource = $Source

}

Write-Verbose "The InstallationSource will be $InstallSource"

#------------------------------------------------------------------------------
#endregion - Check local cache folder
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Populate the local source if we're using one
#------------------------------------------------------------------------------

If ( $PSCmdlet.ParameterSetName -eq 'UseLocalSource' ) {

    # Make sure the folder is empty
    
    if (Test-Path -Path $InstallSource) {

        # The folder exists
        
        $InstallSourceFolder = Get-Item -Path $InstallSource

        if ( ( ( $InstallSourceFolder.GetDirectories().Count + $InstallSourceFolder.GetFiles().Count ) -ne 0 ) -and -not $Force ) {

            Throw "The destination folder $InstallSource is not empty.  Specify the -Force paramter to replace files in the target folder."

        }

    } else {

        # The folder does not exist, create it

        if ( $PSCmdlet.ShouldProcess("Create LocalCacheFolder") ) {
            New-Item -Path $InstallSource -ItemType 'Directory' | Out-Null
        } else {
            Write-Host "New-Item -Path $InstallSource -ItemType 'Directory' | Out-Null"
        }

    }

    Write-Host 'Copying files to local source...'

    if ( $PSCmdlet.ShouldProcess("Install SQL Server") ) {
        robocopy "$Source" "$InstallSource" /MIR /NP 
    } else {
        Write-Host "robocopy `"$Source`" `"$InstallSource`" /MIR /NP "
    }

}
#------------------------------------------------------------------------------
#endregion - Populate the local source if we're using one
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Build the installation command
#------------------------------------------------------------------------------

$InstallCommand = 'setup.exe'
$InstallArguments = @("/ConfigurationFile=`"$ConfigurationFile`"")

if ( $Instance ) {
    $InstallArguments += "/INSTANCENAME=`"$Instance`"" 
    $InstallArguments += "/INSTANCEID=`"$Instance`"" 

    # If we're not using the default SQL instance check the service accounts
    if ( $Instance -ne 'MSSQLSERVER' ) {

        # If a servvice account for SQL agent wasn't provided it, specify one
        if ( -not $SQLAgentSvcCred ) { 
            $InstallArguments += "/AGTSVCACCOUNT=`"NT Service\SQLAgent`$$Instance`""
        }

        # If a servvice account for SQL engine wasn't provided it, specify one
        if ( -not $SQLSvcCred ) { 
            $InstallArguments += "/SQLSVCACCOUNT=`"NT Service\MSSQL`$$Instance`""
        }

    }

}

if ( $InstallSQLDataDir ) { 
    $InstallArguments += "/INSTALLSQLDATADIR=`"$InstallSQLDataDir`"" 
}

if ( $SQLBackupDir ) { 
    $InstallArguments += "/SQLBACKUPDIR=`"$SQLBackupDir`"" 
}

if ( $SQLUserDBDir ) { 
    $InstallArguments += "/SQLUSERDBDIR=`"$SQLUserDBDir`"" 
}

if ( $SQLUserDBLogDir ) { 
    $InstallArguments += "/SQLUSERDBLOGDIR=`"$SQLUserDBLogDir`"" 
}

if ( $SQLTempDBDir ) { 
    $InstallArguments += "/SQLTEMPDBDIR=`"$SQLTempDBDir`"" 
}

if ( $SQLTempDBLogDir ) { 
    $InstallArguments += "/SQLTEMPDBDIR=`"$SQLTempDBDir`"" 
}

if ( $SQLAgentSvcCred) { 
    $InstallArguments += "/AGTSVCACCOUNT=`"$($SQLAgentSvcCred.UserName)`""
    $InstallArguments += "/AGTSVCPASSWORD=`"$($SQLAgentSvcCred.GetNetworkCredential().Password)`""
}

if ( $SQLSvcCred) { 
    $InstallArguments += "/SQLSVCACCOUNT=`"$($SQLSvcCred.UserName)`""
    $InstallArguments += "/SQLSVCPASSWORD=`"$($SQLSvcCred.GetNetworkCredential().Password)`""
}

if ( $SQLSysAdminAccounts ) { 
    #$InstallArguments += "/SQLSYSADMINACCOUNTS=`"$SQLSysAdminAccounts`""
    $InstallArguments += "/SQLSYSADMINACCOUNTS="+$( ($SQLSysAdminAccounts | % { "`"$_`"" } ) -join ' ' )
}

if ( $Interactive ) {

    $InstallArguments += "/IACCEPTSQLSERVERLICENSETERMS=`"False`""
    $InstallArguments += "/QUIET=`"False`""
    $InstallArguments += "/QUIETSIMPLE=`"False`""

}
#------------------------------------------------------------------------------
#endregion - Build the installation command
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
#region - Perform the installation
#------------------------------------------------------------------------------

Write-Verbose "Running '$InstallCommand' with arguments `'$($InstallArguments -join ' ' )`'"

# Write-Host $("{0} {1}" -f $InstallCommand, ($InstallArguments -join " "))

if ( $PSCmdlet.ShouldProcess("Install SQL Server") ) {

    #Start-Process -WorkingDirectory $InstallSource -FilePath $InstallCommand -ArgumentList ( $InstallArguments -join " " ) -Wait
    Start-Process -WorkingDirectory $InstallSource -FilePath $InstallCommand -ArgumentList $InstallArguments -Wait

} else {

    #Write-Host "Start-Process -WorkingDirectory $InstallSource -FilePath $InstallCommand -ArgumentList ( $InstallArguments -join `" `" ) -Wait"
    Write-Host "Start-Process -WorkingDirectory $InstallSource -FilePath $InstallCommand -ArgumentList $InstallArguments -Wait"

}
#------------------------------------------------------------------------------
#endregion - Perform the installation
#------------------------------------------------------------------------------
