Import-Module VMware.VimAutomation.Core
Import-Module VMware.VimAutomation.Vds

Function poweroffVM(){

[CmdletBinding()]
Param(

    [Parameter(Mandatory=$True)]
    [string]$Vcentre,

    [Parameter(Mandatory=$True)]
    [string]$VM,

    [Parameter(Mandatory=$True)]
    [string]$Task
    )


#$Vcentre= 'snappvspvmwr011'
#Mention the Vcentre server
Connect-VIServer $Vcentre


$OutputObj = @()

 $VMDetails=Get-VM $VM 
if ($VM -match "vsp")
{
   Write-host "You are trying to delete the Vcentre Server $VM" -ForegroundColor Red
   Exit(0)
}
else
{
    if($VMDetails.PowerState -ne 'PoweredOff'){
    Write-Host "Powering off $VM"
    Stop-VM $VM -Confirm:$true Out-Null
        
    #Gets the NIC details
        $GetNetworkApapterDetails=Get-VM $VM |Get-NetworkAdapter Out-Null
        
    #set the nic to 'VM Network'
        Set-NetworkAdapter -NetworkAdapter $GetNetworkApapterDetails -NetworkName "VM Network"  -Confirm:$false  Out-Null

    #writes VM Notes
    #Begin    
        $oldnote=$VMDetails.Notes 
        $Line1="`r`n"+"Server powered off by $env:USERNAME on $(Get-Date) as per the Task $Task"
        $Line2="`r`n"+"Nic's has been changed from $($GetNetworkApapterDetails.NetworkName) to 'VM Network'"
        $TexttoAppend= $Line1 + $Line2
        Set-VM $VM -notes "$($OldNote)$TexttoAppend" -Confirm:$false 
    #end
        } 
    else
    {
    #Gets the NIC details
    Write-host "VM $vm is already powered off state"
        $GetNetworkApapterDetails=Get-VM $VM |Get-NetworkAdapter 
        
    #set the nic to 'VM Network'
        Set-NetworkAdapter -NetworkAdapter $GetNetworkApapterDetails -NetworkName "VM Network"  -Confirm:$false 
        
    #writes VM Notes
        #Begin    
        $oldnote=$VMDetails.Notes 
        $Line2="`r`n"+"Nic's has been changed from $($GetNetworkApapterDetails.NetworkName) to 'VM Network' on $(Get-Date)"+"`r`n"
        Set-VM $VM -notes "$($OldNote)$Line2" -Confirm:$false 
        #end

    }
}

    $OutputObj += New-Object PSObject -Property @{
    "Name" = $VM
    "Network Adpaters"= $GetNetworkApapterDetails.NetworkName
    "Task to power off"=$Task
    }
    $csvName = "C:\_Scripts\Poweroff VMs and MoveToVMnetwork\PoweroffVMsandMoveToVMnetwork_" + $Vcentre +"_" + (Get-Date -f "yyyy-MM-dd_") +  "Info.csv"
 
 $OutputObj |Export-CSV $csvName -NoTypeInfo
 }

 #calls the poweroffvm function
 		
 poweroffvm 

 