﻿Import-Module VMware.VimAutomation.Core
Import-Module VMware.VimAutomation.Vds


Function Removevm(){

[CmdletBinding()]
Param(

    [Parameter(Mandatory=$True)]
    [string]$Vcentre

    )
# Change the Vcentre server (Prod-SNAPPVSPVMWR010, Non-Prod - snappvspvmwr011, DR - dfwvdvspvmwr010)

Connect-VIServer $Vcentre

$OutputObj = @()
$Servernotfound = @()
$Filepath = "$env:USERPROFILE\Desktop\VMListToBeDeleted.txt"
$VMs = Get-Content -Path $Filepath
foreach ($VM in $VMs) {
if(Get-VM -Name $VM -ErrorAction SilentlyContinue){
    $VMDetails=Get-VM -Name $VM
    $VMHardDisk = Get-HardDisk -VM $VM -DiskType "rawVirtual","rawPhysical" |Select-Object Name,ScsiCanonicalName
    $Vmcluster=Get-Cluster -VM $VM
    if ($VMDetails.PowerState -ne 'PoweredOff') {
        write-host "VM $VM is in powered ON state, Do you realy want to power off the VM $VM" -ForegroundColor Red -NoNewline
        $decomconfirmation = Read-Host " (Yes/NO)" 
        if($decomconfirmation -in @("Yes","Y","yes")){ 
        Stop-VM $VM -Confirm:$True |Out-Null
        Remove-VM -VM $VM -DeletePermanently -RunAsync -Confirm:$True |Out-Null
         
        }
    }
    else {
        Remove-VM -VM $VM -DeletePermanently -RunAsync -Confirm:$false |Out-Null
    }
    
    $OutputObj += New-Object PSObject -Property  @{
    "Name" = $VM
    "WWN's"= ($VMHardDisk.ScsiCanonicalName) -join ","
    "Cluster"=$Vmcluster.Name
    "Deleted By"=$env:USERNAME
    }
}
else{
write-host "$VM not Found in Vcentre"
$Servernotfound += New-Object PSObject -Property @{
    "Name" = $VM
    "Status" = "Server Not Found "
}
}
}


$LogDirectory       = Get-Date -Format yyyy-MM
$LogPath            = "\\corp.firstam.com\Restricted\ServerOps-Admin\Scripts\Reports\Remove-VM"

If ( !(Test-Path -Path $LogPath\$LogDirectory -PathType Container) ) {
	
	    New-Item -Path $LogPath\$LogDirectory -ItemType Directory | Out-Null

	}


$csvName = "$LogPath\$LogDirectory\" + "VM's removed from $Vcentre"+"_"+  "Info.csv" 
 
$OutputObj |Export-CSV $csvName -NoTypeInfo -Append

$Header = @"
<style>
TABLE {border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;}
TH {border-width: 1px; padding: 3px; border-style: solid; border-color: black; background-color: #6495ED;}
TD {border-width: 1px; padding: 3px; border-style: solid; border-color: black;}
</style>
"@
$Output= $OutputObj | ConvertTo-Html -Head $Header

$mailFrom = 'SNAVPUTLVMWR001@firstam.com'
$mailTo = @("SOMHyperVisorSystems@firstam.com")
$subject = "LUN details of Deleted server by script"
$body = @"

Below are the Server and LUN details :
 
$Output
"@

Send-MailMessage -BodyAsHtml $body -From $mailFrom -To $mailTo -Subject $subject -SmtpServer mail.firstam.com -Attachments $csvName
Disconnect-VIServer $Vcentre -Confirm:$false

}

Removevm

$Servernotfound
        