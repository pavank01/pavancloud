﻿<#

.SYNOPSIS
Parse an Azure bill that is in CSV format

.DESCRIPTION
A PowerShell script to parse an Azure bill.  

The script assumes the CSV headers are on line 3 of the file and relies on the following fields in the CSV:
    'Account Name' (formerly AccountName)
    'Subscription Name' (formerly SubscriptionName)
    'Meter Category' (formerly Service)
    'Meter Sub-Category' (formerly ServiceType)
    'Consumed Service' (formerly ServiceInfo)
    'Instance ID' (formerly Component)
    'ExtendedCost'

.PARAMETER csvFileName
The file to be parsed.  File must be in CSV format.

.INPUTS
None.

.OUTPUTS
None.

.EXAMPLE
C:\PS> .\Parse-AzureBill.ps1 -csvFileName 'DetailedUsage.DetailedUsage.December.02.22.02.11030.csv'

#>

#----------------------------------------------------------------------
# Parameters
#----------------------------------------------------------------------

[CmdletBinding()]
Param (

    [Parameter(Mandatory=$true,Position=1)]
    [string]$csvFileName

)


# Application Variables
#----------------------------------------------------------------------

$BillingInformation = @{}

# Functions
#----------------------------------------------------------------------

function RecordCost {

    param (

        $ApplicationCode,
        $CostType,
        $Cost
        
    )
    
    #Write-Verbose $("Recording`t{0}`t{1}`t{2}" -f $ApplicationCode, $CostType, $Cost)
    
    if ( $BillingInformation.ContainsKey( $ApplicationCode ) ) {

        $tempInfo = $BillingInformation.Item( $ApplicationCode )
        
        if ( $tempInfo.ContainsKey( $CostType ) ) {

            $tempCost = $tempInfo.Item( $CostType )

        } else {


            $tempCost = 0

        }

    } else {


        $tempInfo = @{}
        $tempCost = 0

    }

    $tempCost += $Cost
    $tempInfo[ $CostType ] = $tempCost
    $BillingInformation[ $ApplicationCode ] = $tempInfo

}

function CalcTotalCost {

    param (

        $List

    )

    Return ($List | Measure-Object -Property ExtendedCost -Sum).Sum
}

function CaptureDetailedCosts {

    param (

        $DetailedList 
    
    )


    foreach ( $DetailLine in $DetailedList ) {


        Switch ($DetailLine.'Consumed Service') {


            'Compute' {

                $DetailLine.'Instance ID' -match '(\w{2})-(\d+)-(\d+)-(\w{4})-CS-(\d+)' | Out-Null
                $ApplicationCode = $matches[4].ToUpper()
                $CostType = 'Compute'

            }

            'Storage' {

                $DetailLine.'Instance ID' -match '(\w{2})a(\d+)s(\d+)(\w{4})sa(\d+)' | Out-Null
                $ApplicationCode = $matches[4].ToUpper()
                $CostType = 'Storage'

            }
            # added breakdown of search services - mblackman - 2016-11-28
            'Search' {

                $DetailLine.'Instance ID' -match '(\w{2})-(\d+)-(\d+)-(\w{4})-as-(\d+)' | Out-Null
                $ApplicationCode = $matches[4].ToUpper()
                $CostType = 'Search'

            }

            Default {

                # Changed app code from Infrastructure to AZUR - mblackman - 2016-10-20
                $ApplicationCode = 'AZUR'
                $CostType = "{0}/{1}/{2}" -f $DetailLine.'Meter Category', $DetailLine.'Consumed Service', $DetailLine.'Meter Sub-Category'
            
            }

        }

        RecordCost -ApplicationCode $ApplicationCode -CostType $CostType -Cost $DetailLine.ExtendedCost
    
    }

}

function ReportCostsOld {

    $grandTotal = 0

    foreach ($applicationCode in $BillingInformation.Keys) {

        $applicationTotal = 0

        Write-Output "Billing information for $applicationCode"

        $applicationBill = $BillingInformation[ $ApplicationCode ]

        Write-Output "`tLine item costs:"

        foreach ($costType in $applicationBill.Keys) {

            $applicationTotal += $applicationBill[$costType]

            Write-Output ("`t`t{0}`t{1:C}" -f $CostType, $applicationBill[$costType])

        }

        $grandTotal += $applicationTotal

        Write-Output ("`tTotal cost for {0}`t{1:C}" -f $applicationCode, $applicationTotal)
       
    }

    Write-Output ("Grand total across all applications {0:C}" -f $grandTotal)

}

function ReportCosts {

    $report = @()
    
    foreach ($applicationCode in $BillingInformation.Keys) {

        $applicationBill = $BillingInformation[ $ApplicationCode ]

        foreach ($costType in $applicationBill.Keys) {

            $reportLine = New-Object -TypeName PSObject -Property @{ 
                            'ApplicationCode'=$applicationCode; 
                            'CostType'=$CostType; 
                            'Cost'=$applicationBill[$costType]; }
            $report += $reportLine

        }

    }
    
    $report

}


#--------------------------------------------------------------------------------
# Main routine
#--------------------------------------------------------------------------------


# Read the data file
#--------------------------------------------------------------------------------
Write-Verbose "Reading`t$csvFileName"

# Read the data file as a single stream
$BillingData = Get-Content -Path $csvFileName -Raw

# Eliminate everything before the first field in the CSV header (AccountOwnerID) 
# and convert to CSV - this allows for arbitrary (or no) extra header information
$startLoc = $BillingData.IndexOf("AccountOwnerId")
$BillingCSV = $BillingData.Substring( $startLoc ).Split("`n") | 
              ConvertFrom-Csv |
              Select 'Account Name','Subscription Name','Meter Category','Meter Sub-Category','Consumed Service','Instance ID',ExtendedCost

<#  --- Old method - skips the first 2 lines ---
$BillingCSV = Get-Content -Path $csvFileName | 
              Select-Object -Skip 2 | 
              ConvertFrom-Csv | 
              Select 'Account Name','Subscription Name','Meter Category','Meter Sub-Category','Consumed Service','Instance ID',ExtendedCost
#>

# Build the groupings for the report
# Changed application to AADC for Azure Active Directory account - mblackman - 2016-10-20
# Changed application to CLIQ for FAPRS - mblackman - 2016-10-21
# Changed application to FAST for FA Title AppDev - mblackman - 2016-10-25
# Changed application to FALC for Home Buyers Protection - mblackman - 2016-10-26
# Added Subscription 7 for SOAX for Middleware Sandbox - mblackman - 2016-11-22
# Added Account Republic Title 1 - mblackman - 2016-11-22
# Added Account First Canadian 1 - mblackman - 2016-12-5
#--------------------------------------------------------------------------------

$reportFilterList = @()

$reportFilter = @{'Application'='FCTA';'Account'='First Canadian Title - Stephanie Hamilton';'Subscription'='*';'UseNamingStandard'=$false }
$reportFilterList += New-Object -TypeName PSObject -Property $reportFilter

$reportFilter = @{'Application'='RTAZ';'Account'='Republic Title - Aaron Miller';'Subscription'='*';'UseNamingStandard'=$false }
$reportFilterList += New-Object -TypeName PSObject -Property $reportFilter

$reportFilter = @{'Application'='AADC';'Account'='Azure Active Directory - Frank Schmahlenberger';'Subscription'='*';'UseNamingStandard'=$false }
$reportFilterList += New-Object -TypeName PSObject -Property $reportFilter

$reportFilter = @{'Application'='CLIQ';'Account'='Dan Iorg - FAPRS';'Subscription'='*';'UseNamingStandard'=$false; }
$reportFilterList += New-Object -TypeName PSObject -Property $reportFilter

$reportFilter = @{'Application'='CORP';'Account'='Enterprise Messaging and Directory Services';'Subscription'='*';'UseNamingStandard'=$false }
$reportFilterList += New-Object -TypeName PSObject -Property $reportFilter

$reportFilter = @{'Application'='FALC';'Account'='Home Buyers Protection - Brian Brown';'Subscription'='*';'UseNamingStandard'=$false }
$reportFilterList += New-Object -TypeName PSObject -Property $reportFilter

$reportFilter = @{'Application'='FINT';'Account'='FASTNextGen_Account';'Subscription'='*';'UseNamingStandard'=$false;'CostType'='NextGen' }
$reportFilterList += New-Object -TypeName PSObject -Property $reportFilter

$reportFilter = @{'Application'='EOCR';'Account'='Server Operations 1';'Subscription'='SO-1-AzureSub-2';'UseNamingStandard'=$false;'CostType'='Chris Rubio' }
$reportFilterList += New-Object -TypeName PSObject -Property $reportFilter

$reportFilter = @{'Application'='FAST';'Account'='Server Operations 1';'Subscription'='SO-1-AzureSub-5';'UseNamingStandard'=$false;'CostType'='FAST Sandbox' }
$reportFilterList += New-Object -TypeName PSObject -Property $reportFilter

$reportFilter = @{'Application'='EOCR';'Account'='Server Operations 1';'Subscription'='SO-1-AzureSub-6';'UseNamingStandard'=$false;'CostType'='Trilogy PoC' }
$reportFilterList += New-Object -TypeName PSObject -Property $reportFilter

$reportFilter = @{'Application'='SOAX';'Account'='Server Operations 1';'Subscription'='SO-1-AzureSub-7';'UseNamingStandard'=$false;'CostType'='Middleware Sandbox' }
$reportFilterList += New-Object -TypeName PSObject -Property $reportFilter

$reportFilter = @{'Application'='EOCR';'Account'='Raza Khan - Data Tree/Trace';'Subscription'='*';'UseNamingStandard'=$false;'CostType'='Raza Khan' }
$reportFilterList += New-Object -TypeName PSObject -Property $reportFilter

$reportFilter = @{'Application'='EOCR';'Account'='Test Account - Matt Allison';'Subscription'=@('GenesisPoC');'UseNamingStandard'=$false;'CostType'='GenesisPoC' }
$reportFilterList += New-Object -TypeName PSObject -Property $reportFilter

$reportFilter = @{'Application'='AZUR';'Account'='Test Account - Matt Allison';'Subscription'=@('Enterprise','Second Subscription 2014-05','MT-1-AzureSub-1','MT-1-AzureSub-2','MT-1-AzureSub-3');'UseNamingStandard'=$false;'CostType'='Development' }
$reportFilterList += New-Object -TypeName PSObject -Property $reportFilter

$reportFilter = @{'Application'='N/A';'Account'='Server Operations 1';'Subscription'=@('SO-1-AzureSub-1','SO-1-AzureSub-3','SO-1-AzureSub-4');'UseNamingStandard'=$true}
$reportFilterList += New-Object -TypeName PSObject -Property $reportFilter


# Build the report
#--------------------------------------------------------------------------------

foreach ( $entry in $reportFilterList ) {

    # Handle the filter appropriately depending on if there are one or more subsription entries
    # Wildcards (*) are only allowed in single-valued subscriptions
    if ( $entry.Subscription -is [system.array] ) {

        Write-Verbose "Processing account/subscription(s) $($entry.Account) / $($entry.Subscription -join ",")"
        $subBill = $BillingCSV | ? { ( $_.'Account Name' -eq $entry.Account ) -and ($_.'Subscription Name' -in $entry.Subscription ) }
    
    } else {
    
        Write-Verbose "Processing account/subscription $($entry.Account) / $($entry.Subscription)"
        $subBill = $BillingCSV | ? { ( $_.'Account Name' -eq $entry.Account ) -and ($_.'Subscription Name' -like $entry.Subscription ) }
    
    }

    if ( $entry.UseNamingStandard ) { 

        Write-Verbose "Capturing detailed costs for $($subBill.count) records"
        CaptureDetailedCosts $subBill

    } else {
    
        Write-Verbose "Capturing summarized costs for $($subBill.count) records"
        if ($entry.CostType) {
            $costType = $entry.CostType
        } else { 
            $costType = 'General'
        }
        RecordCost -ApplicationCode $entry.Application -CostType $costType -Cost (CalcTotalCost $subBill)

    }

}


# Show the report
#--------------------------------------------------------------------------------

ReportCosts
