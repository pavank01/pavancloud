﻿<#
.DESCRIPTION
Set-FAAzureVMSize will change the size of an existing Azure VM.

.PARAMETER ServiceName
The cloud service where the target VM resides.

.PARAMETER VmNames
The target VMs. Multiple VMs should be separated by a comma.

.PARAMETER InstanceSize
The new size of the target VMs. Allowed values are ExtraSmall, Small, Medium, Large,
    ExtraLarge, A5, A6, A7, A8, A9,Standard_D1, Standard_D2, Standard_D3, Standard_D4,
    Standard_D11, Standard_D12, Standard_D13, Standard_D14,Standard_G3, Standard_GS3

.PARAMETER DiskSize
The size of the new disk, in GB.

.EXAMPLE
Change the size of a single VM

.\Set-FAAzureVMSize.ps1 -ServiceName SO-1-1-AZUR-CS-95 -VmName AZUVNADMAZUR951 -InstanceSize A5

Change the size of several VMs

.\Set-FAAzureVMSize.ps1 -ServiceName SO-1-1-AZUR-CS-95 -VMNames AZUVNSQLAZUR951,AZUVNSQLAZUR952 -InstanceSize Large

#>

[CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [String]$ServiceName,

        [Parameter(Mandatory=$true)]
        [String[]]$VMNames,

        [Parameter(Mandatory=$true)]
        [ValidateSet("ExtraSmall","Small","Medium","Large","ExtraLarge","A5","A6","A7","A8","A9","Standard_D1","Standard_D2","Standard_D3","Standard_D4","Standard_D11","Standard_D12","Standard_D13","Standard_D14","Standard_DS3","Standard_G3","Standard_GS3")]
        [String]$InstanceSize

    )

foreach ($Name in $VMNames) {

    Get-AzureVm -ServiceName $ServiceName -Name $Name | Set-AzureVMSize -InstanceSize $InstanceSize | Update-AzureVM

}