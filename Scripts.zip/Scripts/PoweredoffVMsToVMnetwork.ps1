﻿Import-Module VMware.VimAutomation.Core
Import-Module VMware.VimAutomation.Vds

$Vcentre= 'snappvspvmwr011'
#Mention the Vcentre server
Connect-VIServer $Vcentre
$OutputObj = @()

if($Vcentre -eq 'snappvspvmwr011'){
$RequiredCluster = Get-Content -Path 'C:\_Scripts\PoweredoffVMsToVM network\ClusterList.txt'
$vms =Get-Cluster $RequiredCluster |Get-VM | where {$_.PowerState -eq "PoweredOff"} 

}
else{

$vms = Get-VM | where {$_.PowerState -eq "PoweredOff"} 

}
$vmPoweredOff = $vms | %{$_.Name}
$events = Get-VIEvent -Start (Get-Date).AddDays(-7) -Entity $vms | where{$_.FullFormattedMessage -like "*is powered off"}
$lastweekVM = $events | %{$_.Vm.Name}
$VMspoweredoffrom7days=$vmPoweredOff | where {!($lastweekVM -contains $_)}	
Write-Host "Total VM's powered off for more than 7 days - " $VMspoweredoffrom7days.count


foreach($VM in $vmPoweredOff) {
#Gets the NIC details
    $GetNetworkApapterDetails=Get-VM $VM |Get-NetworkAdapter
    
#set the nic to 'VM Network'
    if($GetNetworkApapterDetails.NetworkName -ne 'VM Network'){
    Set-NetworkAdapter -NetworkAdapter $GetNetworkApapterDetails -NetworkName "VM Network" -Confirm:$false 

    $Vmcluster=Get-Cluster -VM $VM
    $OutputObj += New-Object PSObject -Property @{
    "Name" = $VM
    "Network Adapaters"= ($GetNetworkApapterDetails.NetworkName) -join ","
    "Cluster"=$Vmcluster.Name
    }
    }
 
 }

 
 $csvName = "C:\_Scripts\PoweredoffVMsToVM network\PoweredoffVMsToVMnetwork_" + $Vcentre +"_"+(Get-Date -f "yyyy-MM-dd_") +  "Info.csv"
 
 $OutputObj |Export-CSV $csvName -NoTypeInfo	-Append

 Disconnect-VIServer $Vcentre -Confirm:$false