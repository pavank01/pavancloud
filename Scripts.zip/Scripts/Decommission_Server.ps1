############################################################################
# First American Decommission Script
#   By Joe O'Brien 04/06/2021
#   v4.0 - 11/18/2021
#
# - Various improvements with performance and Text langauge.
# - If anyone runs into any issues please let me know.
#
############################################################################
#Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

# Below are functions for YES/NO Selections. These are important to
# specify between VMware and everything else. This is because with
# VMware the connection needs to be closed on exit.

Function promptYesNo {
    while("yes","no" -notcontains $answer)
    {
        $answer = Read-Host "Would you like to continue? (Yes/No)"
    }
        If ($answer -eq "no") {
            Write-Host "Exiting..." -ForeGroundColor Red
        exit
    }
}

Function promptYesNo_Vmware {
    while("yes","no" -notcontains $answer)
    {
        $answer = Read-Host "Would you like to continue? (Yes/No)"
    }
        If ($answer -eq "no") {
            Write-Host "Exiting..." -ForeGroundColor Red
            Disconnect-VIServer -Server * -Force -Confirm:$false
        exit
    }
}

Function ConfirmationValidation {
    $null | set-clipboard
    Write-Host "Validation" -ForegroundColor Green
    Write-Host ""
    Write-Host "Please INPUT the following details from Decommission TASK:" -ForegroundColor Yellow
    $TaskIDValidationInput = Read-Host "Task Number"
    $TaskIDValidation = $TaskIDValidationInput.Trim()
    $VMValidationInput = Read-Host "VM Name"
    $VMValidationTrim = $VMValidationInput.Trim()
    $VMValidation = $VMValidationTrim.ToUpper()
    if ($TaskID -eq $TaskIDValidation -and $VM -eq $VMValidation) {
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        Write-Host "Validation Passed!" -ForegroundColor Green
        Write-Host ""
        Write-Host "$TaskID = $TaskIDValidation" -ForegroundColor Green 
        Write-Host "$VM = $VMValidation" -ForegroundColor Green 
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        Write-Host ""
    }
    else {
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Red
        Write-Host "Validation Failed!" -ForegroundColor Red
        Write-Host ""
        Write-Host "$TaskID = $TaskIDValidation" -ForegroundColor Yellow 
        Write-Host "$VM = $VMValidation" -ForegroundColor Yellow
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Red
        Write-Host ""
        exit
    }
}

Function ConfirmationValidation_VMware {
    $null | set-clipboard
    Write-Host "Validation" -ForegroundColor Green
    Write-Host ""
    Write-Host "Please INPUT the following details from Decommission TASK:" -ForegroundColor Yellow
    $TaskIDValidationInput = Read-Host "Task Number"
    $TaskIDValidation = $TaskIDValidationInput.Trim()
    $VMValidationInput = Read-Host "VM Name"
    $VMValidationTrim = $VMValidationInput.Trim()
    $VMValidation = $VMValidationTrim.ToUpper()
    if ($TaskID -eq $TaskIDValidation -and $VM -eq $VMValidation) {
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        Write-Host "Validation Passed!" -ForegroundColor Green
        Write-Host ""
        Write-Host "$TaskID = $TaskIDValidation" -ForegroundColor Green 
        Write-Host "$VM = $VMValidation" -ForegroundColor Green 
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        Write-Host ""
    }
    else {
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Red
        Write-Host "Validation Failed!" -ForegroundColor Red
        Write-Host ""
        Write-Host "$TaskID = $TaskIDValidation" -ForegroundColor Yellow 
        Write-Host "$VM = $VMValidation" -ForegroundColor Yellow
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Red
        Write-Host ""
        Disconnect-VIServer -Server * -Force -Confirm:$false
        exit
    }
}

# Lines 88 to 725 make up the logic for all parts of this script logic. 
# It's all nested into a function here called "menuPrompt" which is called 
# at the very end line.

Function menuPrompt {
    while("Azure","AWS","Physical","VMware","OCI","Exit" -notcontains $answer)
    {
        $answer = $null
        Write-Host ""
        Write-Host "FirstAmerican Server Decommission Script:"
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        $answer = Read-Host "Choose the server hosted platform: (AWS, Azure, VMware, OCI, Physical) or Type Exit to exit"
    }
    
    If ($answer -eq "Azure") {
        $psexecLogFilePath = "$env:USERPROFILE\Desktop\last_decom_azure_psexec-output.log"
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        Write-Host "Loading: Azure Code Block..." -ForeGroundColor Green
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        Write-Host ""

        # Azure PSModules Import
        Write-Host "Importing Azure Powershell Modules..."
        Import-Module Az.Compute -ErrorAction Stop
        Import-Module Az.Accounts -ErrorAction Stop
        Import-Module Az.Resources -ErrorAction Stop
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Logging into Azure using provided credentials via Connect-AzAccount
        Write-Host "Logging into Azure. Please use the interactive window to continue..."
        Write-Host ""
        Connect-AzAccount -ErrorAction Stop
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Input for Azure VM Resource Details
        Write-Host "Please enter the following information provided in ServiceFirst: "
        $TASKIDinput = Read-Host -Prompt "Task Number"
        $TASKID = $TASKIDInput.Trim()
        $VMinput = Read-Host -Prompt "VM Name"
        $VMTrim = $VMInput.Trim()
        $VM = $VMTrim.ToUpper()
        $SubscriptionNameInput = Read-Host -Prompt "Subscription Name"
        $SubscriptionName = $SubscriptionNameInput.Trim()
        $ResourceGroupNameInput = Read-Host -Prompt "Resource Group Name"
        $ResourceGroupName = $ResourceGroupNameInput.Trim()
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Setting the correct Subscription as active via Set-AzContext
        Write-Host "Logging into the Subscription: $SubscriptionName..." -ForegroundColor Green
        Write-Host ""
        Set-AzContext -SubscriptionName $SubscriptionName  -ErrorAction Stop
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Builds Variables and displays Overview for VM.
        Write-Host "Server Decommission Overview for $VM" -ForegroundColor Green
        Write-Host ""
        $azureVMDetails = Get-AzVM -ResourceGroupName $ResourceGroupName -Name $VM  -ErrorAction Stop
        $azureVMos = $azureVmdetails.storageprofile.osDisk.osType
        $azureVMstatus = ((Get-AzVM -ResourceGroupName $ResourceGroupName -Name $VM -Status).Statuses[1]).code
        Write-Host "SF TaskID:          $TaskID"
        Write-Host "Azure VM Name:      $VM"
        Write-Host "Operating System    $azureVMos"
        Write-Host "Status:             $AzureVMStatus"
        Write-Host "Resource Group:     $ResourceGroupName"
        Write-Host "Subscription:       $SubscriptionName"
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        #Write-Host "ACTION:     TEXT" -ForeGroundColor Green

        #Prompt to continue on or exit.
        promptYesNo
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Linux GuestOS information and exit
        if ($azureVMos -like "*linux*") {
            Write-Host "NOTE:   CET only performs decomission tasks on Windows Servers." -ForeGroundColor Red
            Write-Host "ACTION: For Linux/Unix please reassign $taskid to Unix Services." -ForeGroundColor Yellow
            Write-Host "        For ESX Host OS please reassign $taskid to Hypervisor Team." -ForeGroundColor Yellow
            exit
        }

        #Continues with processing starting with Function, contains vCenter disconnect function if exited.
        ConfirmationValidation
        Write-Host "Done..." -ForegroundColor Green
        Write-host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Begin processing qualified Windows Server VMs.
        Write-Host "Checking VM OS and Powerstate..." -ForegroundColor Green
        Write-Host ""
        if ($azureVMos -like "*window*") {
            #If VM is powered on logic - this is for the gather information / shutdown TASK.
            if ($AzureVMStatus -like "*running") {
                Write-Host "Azure VM Name:      $VM"
                Write-Host "Status:             $AzureVMStatus" -ForeGroundColor Yellow
                Write-Host "SF Task:            Server Retirement - Gather info and power off." -ForeGroundColor Yellow
                Write-Host ""
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

                #Yes or No prompt function
                Write-Host "Next Step:   PEXECSVC Info Gathering on $VM." -ForeGroundColor Green
                promptYesNo
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

                #Runs PSEXECSVC
                Write-Host "Gathering PSEXECSVC info on $VM... Please wait..." -ForegroundColor Green
                C:\SysinternalsSuite\psexec -accepteula \\$VM -e cmd /c "ipconfig /all & net localgroup administrators & wmic bios get serialnumber" > $psexecLogFilePath
                Get-Content $psexecLogFilePath
                Get-Content $psexecLogFilePath | Set-Clipboard

                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "ACTION:   Please paste the contents from Clipboard into $Taskid." -ForeGroundColor Green
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
                Write-Host "Next Step:  STOPPING $VM running in Azure" -ForeGroundColor Yellow
                Write-Host "IMPORTANT:  This will make the VM unresponsive as it will be shutdown. Proceed with Caution" -ForeGroundColor Yellow
                Write-Host ""
                
                #Yes or No prompt function
                promptYesNo
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

                #Issuing Azure STOP command on VM
                Write-Host "Stopping VM $VM..." -ForegroundColor Green
                Stop-AzVM -ResourceGroupName $ResourceGroupName -Name $VM -Confirm:$true
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

                #Generates a timestamp for SF Task Retirement MSG, clears the clipboard and adds message to clipboard.
                $timestamp = Get-Date -Format "dddd, MM/dd/yyyy HH:mm K"
                $vmstoppedtext = "$VM was POWERED DOWN on $timestamp UTC."
                $null | set-clipboard
                $vmstoppedtext > $psexecLogFilePath
                Get-Content $psexecLogFilePath | Set-Clipboard

                #Output text
                Write-Host ""
                Write-Host "$vmstoppedtext" -ForeGroundColor Green 
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
                Write-host "IMPORTANT: Please update $TaskID by pasting the clipboard contents."
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""

                #Exits script
                exit 
            }
            #If VM is deallocated in Azure do this logic
            if ($AzureVMStatus -like "*deallocated" -or $AzureVMStatus -like "*stopped") {
                Write-Host "Azure VM Name:      $VM" -ForeGroundColor Green
                Write-Host "Status:             $AzureVMStatus" -ForeGroundColor Green
                Write-Host "SF Task:            Server Retirement - Delete VM file." -ForegroundColor yellow
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
                 
                #Start VM Delete logic with Prompt for Y/N
                Write-Host "IMPORTANT:  Selecting YES below begins the VM Delete Process!" -ForeGroundColor yellow
                Write-host ""
                promptYesNo
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
                
                #Issues deletion cmdlet using Remove-FAAzureRMVM
                Write-Host "Starting Delete on $VM" -ForeGroundColor Green
                Remove-FAAzureRMVM -ResourceGroupName $ResourceGroupName -VMName $VM -Confirm:$false -Verbose
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

                #Generates a timestamp for SF Task Retirement MSG, clears the clipboard and adds message to clipboard.
                $timestamp = Get-Date -Format "dddd, MM/dd/yyyy HH:mm K"
                $vmdeletetext = "$VM was DELETED on $timestamp UTC."
                $null | set-clipboard
                $vmdeletetext > $psexecLogFilePath
                Get-Content $psexecLogFilePath | Set-Clipboard
                Write-Host "$vmdeletetext" -ForeGroundColor Green 
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
                Write-host "IMPORTANT: Please update $TaskID by pasting the clipboard contents."
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""

                exit
            }
        }   
        $answer = $null
        menuPrompt
    
    }
    If ($answer -eq "AWS") {
        $psexecLogFilePath = "$env:USERPROFILE\Desktop\last_decom_aws_psexec-output.log"
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        Write-Host "Loading: AWS Code Block..." -ForeGroundColor Green
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        Write-Host ""

        #AWS PSModules Import: AWSPowershell
        Write-Host "Importing AWS Powershell Module..."
        Import-Module AWSPowershell -ErrorAction Stop
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Input for AWS EC2 Resource Details
        Write-Host "Please enter the following information provided in ServiceFirst"
        $TASKIDinput = Read-Host -Prompt "Task Number"
        $TASKID = $TASKIDInput.Trim()
        $VMinput = Read-Host -Prompt "EC2(VM) Name"
        $VMTrim = $VMInput.Trim()
        $VM = $VMTrim.ToUpper()
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Yellow
        Write-Host "Important:  Please provide the Region of the EC2 Instance below, common Regions at FA include: " -ForegroundColor Yellow
        Write-Host "            -- US-WEST-1, US-WEST-2, US-EAST-1, US-EAST-2 --" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "            Please verify the region via Interactive Mode (portal), or EC2 Reports if you are unsure." -ForegroundColor Yellow
        Write-Host "            Pressing enter with no entry will default to US-WEST-2." -ForegroundColor Yellow
        Write-Host ""
        $VMregioninput = Read-Host -Prompt "EC2 Region (Default: US-WEST-2)"
        $VMregionTrim = $VMregioninput.Trim()
        $awsEC2Region = $VMregionTrim.ToUpper()
        if ($awsEC2Region -eq "") {
            $awsEC2Region = "US-WEST-2"
        }
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Yellow
        $awsAccountIDInput = Read-Host -Prompt "AWS Account ID"
        $awsAccountID = $awsAccountIDInput.Trim()
        $awsAccountProfileInput = Read-Host -Prompt "Profile Name (xacc-p-0, xacc-n-0 or xacc-s-0)"
        $awsAccountProfile = $awsAccountProfileInput.Trim()
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Logs into AWS account using the aws-azure-login cmdlet then assumes the correct role for the account ID inputted from above.
        Write-Host "Logging into AWS Account..." -ForegroundColor Green
        Write-Host ""
        Write-Host "Please make sure that you've activated the AWS-XACC-P-0, AWS-XACC-N-0, or AWS-XACC-S-0 Privileged Access Groups in the Azure Portal." -ForegroundColor yellow
        Write-Host "Once completed, select Yes below to continue." -ForegroundColor yellow
        Write-Host ""
        promptYesNo
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        $awsAzureLoginProfile = $awsAccountProfile
        aws-azure-login --profile $awsAzureLoginProfile

        $role_arn = "arn:aws:iam::" + $awsAccountID + ":role/FirstAm_super-pds"
        $roleSessionName = "DecomScript"

        $assume_role = aws sts assume-role --role-arn $role_arn --role-session-name $roleSessionName --profile $awsAzureLoginProfile --no-verify-ssl
        $assume_role_vars = $assume_role  | ConvertFrom-Json 

        ForEach ($x in $assume_role_vars){
            $env:AWS_Access_Key_ID = $x.Credentials.AccessKeyId
            $env:AWS_SECRET_Access_Key = $x.Credentials.SecretAccessKey
            $env:AWS_SESSION_TOKEN = $x.Credentials.SessionToken
        }
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        Write-Host ""
        Write-Host "Were you logged in without Errors? Select Yes to continue, No to Exit." -ForegroundColor yellow
        Write-Host ""
        promptYesNo
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Builds Variables and displays Overview for EC2/VM.
        Write-Host "Server Decommission Overview:" -ForegroundColor Green
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        $awserverslist = (Get-Ec2Instance -Region $awsEC2Region).Instances | select @{Name="Servername";Expression={$_.tags | where key -eq "Name" | select Value -expand Value}}, InstanceId
        $awserverslistcapture = $awserverslist | where Servername -eq "$vm"
        $awsserverinstanceid = $awserverslistcapture.InstanceId
        $ec2infops = Get-Ec2Instance -Region $awsEC2Region -InstanceId $awsserverinstanceid
        $ec2OSName = $ec2infops.instances.platform
        $ec2state = $ec2infops.instances.state.name
        #$ec2Info = aws ec2 --region $awsEC2Region describe-instances --instance-ids $awsserverinstanceid --no-verify-ssl
        #$ec2InfoFormatted = $ec2Info | ConvertFrom-JSon
        #$ec2state = $ec2InfoFormatted.Reservations.Instances.State.Name
        #$ec2OSname = $ec2InfoFormatted.Reservations.Instances.Platform

        if ($ec2OSname -like "*window*") {
            $ec2OSname = "Windows"
        }
        else {
          $ec2OSName = "Other"  
        }

        Write-Host ""
        Write-Host "SF TaskID:          $TaskID"
        Write-Host "AWS Account ID:     $awsAccountID"
        Write-Host "VM Name:            $VM"
        Write-Host "VM Region:          $awsEC2Region"
        Write-Host "Instance ID:        $awsserverinstanceid"
        Write-Host "Operating System:   $ec2OSname"
        Write-Host "Status:             $ec2state "
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        #Write-Host "ACTION:     TEXT" -ForeGroundColor Green

        #Prompt to continue on or exit.
        promptYesNo
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Linux EC2/GuestOS = Other information and exit
        if ($ec2OSname -like "Other") {
            Write-Host "NOTE:   CET only performs decomission tasks on Windows Servers." -ForeGroundColor Red
            Write-Host "ACTION: For Linux/Unix please reassign $taskid to Unix Services." -ForeGroundColor Yellow
            Write-Host "        For ESX Host OS please reassign $taskid to Hypervisor Team." -ForeGroundColor Yellow
            exit
        }

        #Continues with processing starting with Function.
        ConfirmationValidation
        Write-Host "Done..." -ForegroundColor Green
        Write-host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Begin processing qualified Windows Server EC2/VMs.
        Write-Host "Checking VM Eligibility and Next Steps..." -ForegroundColor Green
        Write-Host ""
        if ($ec2OSname -like "*window*") {
            if ($ec2state -like "*running") {
                Write-Host "VM Name:            $VM"
                Write-Host "Status:             $ec2state" -ForeGroundColor Yellow
                Write-Host "SF Task:            Server Retirement - Gather info and power off." -ForeGroundColor Yellow
                Write-Host ""
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

                #Yes or No prompt function
                Write-Host "Next Step:   PEXECSVC Info Gathering on $VM." -ForeGroundColor Green
                promptYesNo
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

                #Runs PSEXECSVC
                Write-Host "Gathering PSEXECSVC info on $VM... Please wait..." -ForegroundColor Green
                C:\SysinternalsSuite\psexec -accepteula \\$VM -e cmd /c "ipconfig /all & net localgroup administrators & wmic bios get serialnumber" > $psexecLogFilePath
                Get-Content $psexecLogFilePath
                Get-Content $psexecLogFilePath | Set-Clipboard

                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "ACTION:   Please paste the contents from Clipboard into $Taskid." -ForeGroundColor Green
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
                Write-Host "Next Step:  STOPPING $VM running in AWS" -ForeGroundColor Yellow
                Write-Host "IMPORTANT:  This will make the VM unresponsive as it will be shutdown. Proceed with Caution" -ForeGroundColor Yellow
                Write-Host ""
                
                #Yes or No prompt function
                promptYesNo
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

                #Issuing AWS Stop command to the AWS EC2 Instance.
                Write-Host "Stopping EC2/VM Instance $VM..." -ForegroundColor Green
                Stop-EC2Instance -Region $awsEC2Region -InstanceId $awsserverinstanceid
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

                #Generates a timestamp for SF Task Retirement MSG, clears the clipboard and adds message to clipboard.
                $timestamp = Get-Date -Format "dddd, MM/dd/yyyy HH:mm K"
                $vmstoppedtext = "$VM EC2 was STOPPED on $timestamp UTC."
                $null | set-clipboard
                $vmstoppedtext > $psexecLogFilePath
                Get-Content $psexecLogFilePath | Set-Clipboard

                #Output text
                Write-Host "$vmstoppedtext" -ForeGroundColor Green 
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
                Write-host "IMPORTANT: Please update $TaskID by pasting the clipboard contents."
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""

                exit 
            }
            #If EC2/VM is Stopped in AWS do this logic
            if ($ec2state -like "*stopped" -or $ec2state -like "*stopped") {
                Write-Host "VM Name:            $VM" -ForeGroundColor Green
                Write-Host "Status:             $ec2state" -ForeGroundColor Green
                Write-Host "SF Task:            Server Retirement - Delete VM file." -ForegroundColor yellow
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
                 
                #Start VM Delete logic with Prompt for Y/N
                Write-Host "IMPORTANT:  Selecting YES below begins the EC2/VM Termination Process!" -ForeGroundColor yellow
                Write-host ""
                promptYesNo
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
                
                #Issues termination cmdlet using Remove-EC2Instance
                Write-Host "Starting Termination on VM/EC2 Instance $VM" -ForeGroundColor Green
                Remove-EC2Instance -Region $awsEC2Region -InstanceId $awsserverinstanceid
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

                #Generates a timestamp for SF Task Retirement MSG, clears the clipboard and adds message to clipboard.
                $timestamp = Get-Date -Format "dddd, MM/dd/yyyy HH:mm K"
                $vmdeletetext = "$VM EC2 was TERMINATED on $timestamp UTC."
                $null | set-clipboard
                $vmdeletetext > $psexecLogFilePath
                Get-Content $psexecLogFilePath | Set-Clipboard
                
                #Output Text
                Write-Host "$vmdeletetext" -ForeGroundColor Green 
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
                Write-host "IMPORTANT: Please update $TaskID by pasting the clipboard contents."
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""


                exit
            }
        $answer = $null
        menuPrompt
        }
    }
    If ($answer -eq "OCI") {
        Write-Host "OCI is currently not supported..." -ForeGroundColor Red

        $answer = $null
        menuPrompt
    }
    If ($answer -eq "VMware") {
        $psexecLogFilePath = "$env:USERPROFILE\Desktop\last_decom_vmware_psexec-output.log"
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        Write-Host "Loading: VMware Code Block" -ForeGroundColor Green
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        Write-Host ""
        
        # VMware PSModules Import
        Write-Host "Importing VMware Powershell Modules..."
        Import-Module VMware.VimAutomation.Core -ErrorAction Stop
        Import-Module VMware.VimAutomation.Vds -ErrorAction Stop
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Prompt for Server/VC Info, does trim and ToUpper on VM Name to standardize.
        Write-Host "Please enter the following information provided in ServiceFirst: "
        $TASKIDinput = Read-Host -Prompt "Task Number"
        $TASKID = $TASKIDInput.Trim()
        $VMinput = Read-Host -Prompt "VM Name"
        $VMTrim = $VMInput.Trim()
        $VM = $VMTrim.ToUpper()
        $Vcentreinput = Read-Host -Prompt "vCenter Servername"
        $Vcentre = $Vcentreinput.Trim()
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Connection to vCenter using psmodule.
        Write-Host "Connecting to vCenter Server $Vcentre..." -ForegroundColor Green
        Connect-VIServer $Vcentre  -ErrorAction Stop
        Write-Host "Done..." -ForegroundColor Green
        Write-host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Builds Variables around this VM from vCenter
        Write-Host "Building Script Variables from $VM... Please wait..." -ForegroundColor Green
        #Gets the Folder name for the move process.
        $VMResult = Get-VM $VM  -ErrorAction Stop
        $VMHost = $VMResult.VMHost
        $VMCluster = $VMHost.Parent
        $VMDataCenter = $VMHost.Parent | Get-DataCenter
        $FolderName = Get-Folder -Location $VMDataCenter | Where-Object {
            ($_.Name -Like "VMs_To_Be_Deleted*") -or ($_.Name -Like "_Decommissioned")
        }
        $OutputObj = @()
        #Gets VM Details
        $VMDetails = Get-VM $VM 
        #Gets VM Disk Details
        $VMHardDisk = Get-HardDisk -VM $VM -DiskType "rawVirtual","rawPhysical" | Select-Object Name,ScsiCanonicalName
        #Gets VM Cluster Details
        $Vmcluster = Get-Cluster -VM $VM
        #Gets VM Guest OS Name
        $VMGuestOS = $VMDetails.ExtensionData.Config.GuestFullname
        #Gets VM PowerState
        $VMPowerResult = $VMResult.Powerstate
        #Gets VMs Datastore Name
        $VMdatastoreName = (get-vm $vm | get-Datastore).name
        #Gets RDM Details
        $numberrdm = Get-VM $VM | Get-HardDisk -DiskType "RawPhysical","RawVirtual" | measure
        Write-Host "Done..." -ForegroundColor Green
        Write-host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Displays Build Variable Details
        Write-Host "Server Decommission Overview:" -ForegroundColor Green
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        Write-Host "SF TaskID:          $TaskID"
        Write-Host "VMware VM Name:     $VM"
        Write-Host "Guest OS:           $VMGuestOS"
        Write-Host "Power Status:       $VMPowerResult"
        Write-Host "vCenter Server:     $Vcentre"
        
        #If SRM Is Enabled or Disabled - based upon DataStore Naming convention, display details.
        if ($VMDatastoreName -like "SRM*") {
            $numberSRM = "TRUE"
            Write-Host "SRM Enabled:        $numberSRM" -ForegroundColor Yellow
            Write-Host "SRM Storage Group:  $VMdatastoreName" -ForegroundColor Yellow
        }
        else {
            $numberSRM = "NONE"
            Write-Host "SRM Enabled:        $numberSRM" -ForeGroundColor Green
        }
        #If RDM is found or not - based upon rdm.count, display count.
        if ($numberrdm.Count -eq "0") {
            Write-Host "RDM:               "$numberrdm.Count"" -ForegroundColor Green
        }
        else {
            Write-Host "RDM:               "$numberrdm.Count"" -ForegroundColor Yellow
            Write-Host ""
            Write-Host "Please run SearchVM.PS1 to gather RDM LUN Details..." -ForegroundColor Yellow
        }
        Write-Host ""
        Write-Host "Done..." -ForegroundColor Green
        Write-host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        Write-Host "ACTION:     Before Continuing, please update $TaskID with the SRM and RMD LUN Details..." -ForeGroundColor Green

        #Calls the VMware Y/N Prompt from Functions
        Write-Host ""
        promptYesNo_Vmware
        Write-Host "Done..." -ForegroundColor Green
        Write-host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Linux GuestOS information and exit
        if ($VMGuestOS -like "*linux*") {
            Write-Host "NOTE:   CET only performs decomission tasks on Windows Servers." -ForeGroundColor Red
            Write-Host "ACTION: For Linux/Unix please reassign $taskid to Unix Services." -ForeGroundColor Yellow
            Write-Host "        For ESX Host OS please reassign $taskid to Hypervisor Team." -ForeGroundColor Yellow
            Disconnect-VIServer -Server * -Force -Confirm:$false
            exit
        }

        #Continues with processing starting with Function, contains vCenter disconnect function if exited.
        ConfirmationValidation_VMware
        Write-Host "Done..." -ForegroundColor Green
        Write-host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Begin processing qualified Windows Server VMs.
        Write-Host "Checking VM OS and Powerstate..." -ForegroundColor Green
        Write-Host ""
        if ($VMGuestOS -like "*windows*") {
            #If VM is powered on logic - this is for the gather information / shutdown TASK.
            if ($VMPowerResult -eq "PoweredOn") {
                Write-Host "VM Name:            $VM" -ForeGroundColor Green
                Write-Host "Status:             $VMPowerResult" -ForeGroundColor Green
                Write-Host "SF Task:            Server Retirement - Gather info and power off." -ForeGroundColor Yellow
                Write-Host ""
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
                
                #Yes or No prompt function with vCenter Disconnect.
                Write-Host "Next Step:   PEXECSVC Info Gathering on $VM." -ForeGroundColor Green
                Write-Host ""
                promptYesNo_Vmware
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
                
                #Gathering of machine info via PSEXEC
                Write-Host "Gathering PSEXEC info on $VM... Please wait..." -ForegroundColor Green
                C:\SysinternalsSuite\psexec -accepteula \\$VM -e cmd /c "ipconfig /all & net localgroup administrators & wmic bios get serialnumber" > $psexecLogFilePath
                Get-Content $psexecLogFilePath
                Get-Content $psexecLogFilePath | Set-Clipboard
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "ACTION:   Please paste the contents from Clipboard into $Taskid." -ForeGroundColor Green
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
                Write-Host "Next Step:  STOPPING $VM running in $vcentre..." -ForeGroundColor Yellow
                Write-Host "IMPORTANT:  This will make the VM unresponsive as it will be shutdown. Proceed with caution." -ForeGroundColor Yellow
                Write-Host ""
                
                #Yes or No prompt function with vCenter Disconnect.
                promptYesNo_Vmware
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
                
                #Issuing Stop command to Guest VM.
                Write-Host "Stopping VM $VM on $Vcentre..." -ForegroundColor Green
                Stop-VM $VM -Confirm:$true -ErrorAction Stop
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

                #Generates a timestamp for SF Task Retirement MSG, clears the clipboard and adds message to clipboard.
                $timestamp = Get-Date -Format "dddd, MM/dd/yyyy HH:mm K"
                $powerdowntext = "$VM was POWERED DOWN on $timestamp UTC."
                $null | set-clipboard
                $powerdowntext > $psexecLogFilePath
                Get-Content $psexecLogFilePath | Set-Clipboard

                #Output Text
                Write-Host "$powerdowntext" -ForeGroundColor Green 
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""

                #Disconncts from vCenter and exits script
                Disconnect-VIServer -Server * -Force -Confirm:$false
                exit
            }
            
            #If the server is powered off logic
            if ($VMPowerResult -eq "PoweredOff") {

                #Check the VM's EVENTS in vCenter to look for powerdown message and get the powerdown time. Then convert it to usable format.
                $VmwarePowerDownEventRaw = (Get-VIEvent $VM | select-object  CreatedTime,FullformattedMessage | where-object -property FullFormattedMessage -like "*is powered off*").createdTime
                
                #What to do if a powerdown event IS found.
                if ($VmwarePowerDownEventRaw -notlike "") {
                    $vmwarepowerdownevent = $VmwarePowerDownEventRaw | select-object -first 1
                    $VMwareVMPowerDownTime = $vmwarepowerdownevent | Get-Date -Format "dddd, MM/dd/yyyy HH:mm K"
                    
                    #Nows timestamp for comparison.
                    $timestamp = Get-Date -Format "dddd, MM/dd/yyyy HH:mm K"
                    
                    #compares time to see if it's been longer than the configurable threshold
                    $TimeDiff = (New-TimeSpan -Start $VMwareVMPowerDownTime -End $timestamp).TotalHours
                }
                #What to do if a powerdown event IS NOT found.
                else {
                    $assumedhours = "2880" #2800 = 4 months
                    $TimeDiff = "$assumedhours"
                    Write-Host  "IMPORTANT: No shutdown events were found in vCenter for $vm. Defaulting to $TimeDiff hours." -ForegroundColor Red
                    Write-Host ""
                }
                                
                #configurable threshold in hours, 24 is for 1 day per policy as of 11/18/2021.
                $ShutdownHoursThreshold = "24"
            
                #Display Details before prompt to continue.
                Write-Host "VM Name:            $VM" -ForeGroundColor Green
                Write-Host "Status:             $VMPowerResult" -ForeGroundColor Yellow
                Write-Host "SF Task:            Server Retirement - Delete VM file." -ForegroundColor yellow
                
                #If it's been shorter than the timeThreshold - Fail
                If ($TimeDiff -lt $ShutdownHoursThreshold) {
                    Write-Host "Shutdown Timer:     $TimeDiff hours " -ForegroundColor Red
                    Write-Host "Overall:            FAIL" -ForegroundColor Red
                    Write-Host "REASON:             The VM has been powered off for shorter than $ShutdownHoursThreshold hours! Exiting..." -ForegroundColor Yellow
                    Disconnect-VIServer -Server * -Force -Confirm:$false
                    exit
                }
                #If it's been longer than the timeThreshold - Pass
                else {
                    Write-Host "Shutdown Timer:     $TimeDiff hours " -ForegroundColor Green
                    Write-Host "Overall:            PASS" -ForegroundColor Green
                    Write-Host "REASON:             The VM has been powered off for longer than $ShutdownHoursThreshold hours! Continuing..." -ForegroundColor Green
                    Write-Host "Done..." -ForegroundColor Green
                    Write-host ""
                    Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
                }
                
                #Start VM Delete logic with Prompt for Y/N
                Write-Host "IMPORTANT: Selecting YES below begins the VM Delete Process!" -ForeGroundColor yellow
                Write-Host ""
                promptYesNo_Vmware
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

                #Moves VM to deletion folder then issues delete.
                Write-Host "Moving $VM to Deletion folder..." -ForeGroundColor Green
                Get-Folder -ID $FolderName.ID | Move-VM -VM $VM
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
                
                #Issues deletion cmdlet
                Write-Host "Starting Delete on $VM" -ForeGroundColor Green
                Remove-VM -VM $VM -DeletePermanently -RunAsync -Confirm:$True -ErrorAction Stop
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green


                #Generates a timestamp for SF Task Retirement MSG, clears the clipboard and adds message to clipboard.
                $timestamp = Get-Date -Format "dddd, MM/dd/yyyy HH:mm K"
                $vmdeletetext = "$VM was DELETED on $timestamp UTC."
                $null | set-clipboard
                $vmdeletetext > $psexecLogFilePath
                Get-Content $psexecLogFilePath | Set-Clipboard
                Write-Host "$vmdeletetext" -ForeGroundColor Green 
                Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
                Write-Host "Done..." -ForegroundColor Green
                Write-host ""
                
                #Disconnects from vCenter
                Disconnect-VIServer -Server * -Force -Confirm:$false
            }
        }
        else {
            #What happens if trying to delete a non supported OS type...
            Write-Host "Guest OS Name: $VMGuestOS vCenter Server: $Vcentre" -ForegroundColor Yellow
            Write-Host "NOTE: Linux, Unix or Other GuestOS type detected!" -ForeGroundColor Yellow
            Write-Host "      CET only performs decomission tasks on Windows Servers." -ForeGroundColor Red
            Write-Host "--------------------------------------------------------------------------------" -ForeGroundColor Yellow
            Write-Host "ACTION: For Linux/Unix: Please reassign $taskid to Unix Services." -ForeGroundColor Yellow
            Write-Host "        For ESX Host: Please reassign $taskid to Hypervisor Team." -ForeGroundColor Yellow
            Write-Host "        For Unknown: Verify the Guest OS, obtain clarification on direction and delete manually if needed."  -ForeGroundColor Yellow
            Disconnect-VIServer -Server * -Force -Confirm:$false
            Write-Host "Exiting..." -ForeGroundColor Red
            exit   
        }
 ############DO NOT TOUCH BELOW, NOT MANAGED BY CET############
            Write-Host  "Starting: Post Script Process"  -ForeGroundColor Green
            $OutputObj += New-Object PSObject -Property  @{
            "Name" = $VM
            "WWN's"= ($VMHardDisk.ScsiCanonicalName) -join ","
            "Cluster"=$Vmcluster.Name
            "Deleted By"=$env:USERNAME
            }
            
            $LogDirectory       = Get-Date -Format yyyy-MM
            $LogPath            = "\\corp.firstam.com\Restricted\ServerOps-Admin\Scripts\Reports\Remove-VM"
            
            If ( !(Test-Path -Path $LogPath\$LogDirectory -PathType Container) ) {
                    New-Item -Path $LogPath\$LogDirectory -ItemType Directory | Out-Null
                }
            
            
            $csvName = "$LogPath\$LogDirectory\" + "VM's removed from $Vcentre"+"_"+  "Info.csv" 
            
            $OutputObj |Export-CSV $csvName -NoTypeInfo -Append
            
            $Header = @"
            <style>
            TABLE {border-width: 1px; border-style: solid; border-color: black; border-collapse: collapse;}
            TH {border-width: 1px; padding: 3px; border-style: solid; border-color: black; background-color: #6495ED;}
            TD {border-width: 1px; padding: 3px; border-style: solid; border-color: black;}
            </style>
"@
            $Output= $OutputObj | ConvertTo-Html -Head $Header
            
            $mailFrom = 'SNAVPUTLVMWR001@firstam.com'
            $mailTo = @("SOMHyperVisorSystems@firstam.com")
            $subject = "LUN details of Deleted server by script"
            $body = @"
            
            Below are the Server and LUN details :
            
            $Output
"@
        
            Send-MailMessage -BodyAsHtml $body -From $mailFrom -To $mailTo -Subject $subject -SmtpServer mail.firstam.com -Attachments $csvName
            
            $Servernotfound
            Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
            Write-Host "Completed: Post Script Process"  -ForeGroundColor Green
            Write-Host "Done..." -ForegroundColor Green
            Write-Host ""
            exit
############DO NOT TOUCH ABOVE, NOT MANAGED BY CET############            
        $answer = $null
        menuPrompt
    }
    If ($answer -eq "Physical") {
        $psexecLogFilePath = "$env:USERPROFILE\Desktop\last_decom_physical_psexec-output.log"
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        Write-Host "Loading: Physical Code Block..." -ForeGroundColor Green
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        Write-Host ""

        Write-Host "Please enter the following details: "
        $TASKIDinput = Read-Host -Prompt "Task Number"
        $TASKID = $TASKIDInput.Trim()
        $VMinput = Read-Host -Prompt "Server Name"
        $VMTrim = $VMInput.Trim()
        $VM = $VMTrim.ToUpper()
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        
        #Attempts a ping, exits if servername doesn't exist.If it exists store it as a var. Does a live ping if server is online.
        Write-Host "Pinging $VM..."
        Write-Host ""
        TRY {Test-Connection -ComputerName $VM -Count 1 -ErrorAction STOP} Catch { Write-Host "$VM is not responding to ping attempts. Server may be offline. Exiting." -ForegroundColor Red }
        $PingQuiet = Test-Connection -ComputerName $VM -Count 1 -Quiet -ErrorAction Stop
        $Ping = Test-Connection -ComputerName $VM -Count 1 -ErrorAction Stop
    
        $PingIPAddress = $Ping.IPV4Address
        $PingResponseTime = $Ping.ResponseTime
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Displays Server Decom Overview Info
        Write-Host "Server Decommission Overview:" -ForegroundColor Green
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        Write-Host ""
        Write-Host "SF TaskID:          $TaskID"
        Write-Host "SF Task:            Server Retirement - Gather information and shut down physical server." -ForeGroundColor Yellow
        Write-Host "Server Name:        $VM"
        Write-Host "IPAddress:          $pingIPAddress"
        Write-Host "Ping Response:      $pingquiet"
        Write-Host "Response Time:      $PingResponseTime ms"
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        
        #Jumps to validation since there isn't delete task needed. Just Shutdown.
        ConfirmationValidation
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Displays server name, and ping stats... basically is this server on the network?
        Write-Host "Checking Server Eligibility and Next Steps..." -ForegroundColor Green
        Write-Host ""
        Write-Host "Server Name:        $VM"
        Write-Host "Ping Response:      $pingquiet"
        Write-Host "IPAddress:          $pingIPAddress"
        Write-Host ""
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Prompt Yes or No Function
        promptYesNo
        Write-Host "Done..." -ForegroundColor Green
        Write-Host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Gathers PSEXEC Info for server
        Write-Host "Gathering PSEXEC info on $VM... Please wait..." -ForegroundColor Green
        C:\SysinternalsSuite\psexec -accepteula \\$VM -e cmd /c "ipconfig /all & net localgroup administrators & wmic bios get serialnumber" > $psexecLogFilePath
        Get-Content $psexecLogFilePath
        Get-Content $psexecLogFilePath | Set-Clipboard
        Write-Host "Done..." -ForegroundColor Green
        Write-host ""
        Write-Host "ACTION:   Please paste the contents from Clipboard into $Taskid." -ForeGroundColor Green
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
        Write-Host "Next Step:  Issue SHUTDOWN command to $VM." -ForeGroundColor Yellow
        Write-Host "IMPORTANT:  This will make the Server unresponsive as it will be shutdown. Proceed with caution." -ForeGroundColor Yellow
        Write-Host ""

        #Prompt for Yes or No
        promptYesNo
        Write-Host "Done..." -ForegroundColor Green
        Write-host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Sends remote shutdown to server's Windows Operating System.
        Write-Host "Issuing SHUTDOWN to $VM..." -ForeGroundColor Green
        shutdown /s /m \\$VM /t 0 /c "Decommission"
        Write-Host "Done..." -ForegroundColor Green
        Write-host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

        #Generates a timestamp for SF Task Retirement MSG, clears the clipboard and adds message to clipboard.
        $timestamp = Get-Date -Format "dddd, MM/dd/yyyy HH:mm K"
        $powerdowntext = "$VM SHUTDOWN COMMAND issued on $timestamp UTC."
        $null | set-clipboard
        $powerdowntext > $psexecLogFilePath
        Get-Content $psexecLogFilePath | Set-Clipboard
        
        #Output Text
        Write-Host "$powerdowntext" -ForeGroundColor Green 
        Write-Host "Done..." -ForegroundColor Green
        Write-host ""
        Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

		#Onscreen ping for engineer to verify server shuts down. Adjust number of pings with $pingattempts
        $pingattempts = "30" 
        Write-Host "Pinging $VM $pingattempts times. Press CTRL-C to end early." -ForegroundColor yellow
		Write-Host "If $VM is still responding after $pingattempts attempts, additional troubleshooting is recommended." -ForegroundColor yellow
		Write-Host ""
        ping $VM -n $pingattempts
        Write-Host "Done..." -ForegroundColor Green
        Write-host ""
        exit 

        $answer = $null
        menuPrompt
    }
    If ($answer -eq "Exit") {
        Write-Host "Exiting..." -ForeGroundColor Red
        exit
    }
}
menuPrompt