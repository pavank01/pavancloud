﻿Param(
    
    [Parameter(Mandatory=$false)]
    [string]$ConfigFile,
    
    [Parameter(Mandatory=$false)]
    [ValidateSet("View","Start","Stop","Restart","Deprovision")]
    [string]$Action = $null,

    [Parameter(Mandatory=$false)]
    [switch]$Force = $false

)

Begin {

    # Global variables
    #----------------------------------------------------------------------

    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")

    # $ErrorActionPreference = "Stop"

    # Assume success
    $EnvironmentMatch = $true

    $VMs = @()

    #region - Functions

    Function Compare-VMNames {

        # Assume success
        $Success = $true

        Write-Verbose "Comparing VM Names..."

        Compare-Object -DifferenceObject $VMs -ReferenceObject $EnvVMs -IncludeEqual -Property Name | 

            ForEach-Object {

                $Server = $_.Name
        
                Switch ($_.SideIndicator) {
                
                    "==" { Write-Verbose "`t$Server matches by name." }

                    "<=" { Write-Verbose "`t$Server does not exist in definition"; $Success = $false }

                    "=>" { Write-Verbose "`t$Server does not exist in environment"; $Success = $false }

                }

            }
            
        Return $Success     

    }

    Function Compare-VMSizes {

        # Assume success
        $Success = $true

        Write-Verbose "Comparing VM sizes..."
        
        Compare-Object -DifferenceObject $VMs -ReferenceObject $EnvVMs -IncludeEqual -Property Name, InstanceSize | 

            ForEach-Object {

                $Server = $_.Name
                $Size = $_.InstanceSize

                Switch ($_.SideIndicator) {
                
                    "==" { Write-Verbose "`t$Server matches by size" }

                    "<=" { Write-Verbose "`t$Server size of $Size does not match config file size"; $Success = $false }

                }

            }

        Return $Success

    }

    Function Get-FileName($Title) {   

         $OpenFileDialog = New-Object System.Windows.Forms.OpenFileDialog
         $OpenFileDialog.title = $Title
         $OpenFileDialog.filter = "All files (*.*)| *.*"
         $OpenFileDialog.ShowDialog() | Out-Null
         $OpenFileDialog.filename

    } #end function Get-FileName

    Function Ingest-XML($xmllist,$msg) {

        If (!$xmllist) {

            $xmllist = Get-Filename($msg)

        }

        If ($xmllist -and (Test-Path $xmllist)) {

            $xmlobjects = [XML] (Get-Content -path $xmllist)
            Return $xmlobjects

        } Else { 

            Write-Verbose "File not found"
            break

        }

    }

    Function Set-Subscription($Subscription,$StorageAcct) {

        $CurrentSubscription = Get-AzureSubscription -Current

        If ($CurrentSubscription.SubscriptionName -ne $Subscription) {
            Select-AzureSubscription -Current -SubscriptionName $Subscription
            $CurrentSubscription = Get-AzureSubscription -Current
        }

        If ($CurrentSubscription.CurrentStorageAccountName -ne $StorageAcct){
            Set-AzureSubscription -SubscriptionName $Subscription -CurrentStorageAccount $StorageAcct
        }

    }

    Function Get-Confirmation($Message) {

        $caption = "Attention!"
        $yesNoButtons = 4

        $YN = [System.Windows.Forms.MessageBox]::Show($message, $caption, $yesNoButtons, "Question")
    
        Return $YN

    }

    Function Get-ListItem($Text,$ListArray) {

        $objForm = New-Object System.Windows.Forms.Form 
        $objForm.Text = "List"
        $objForm.Size = New-Object System.Drawing.Size(300,200) 
        $objForm.StartPosition = "CenterScreen"

        $objForm.KeyPreview = $True
        $objForm.Add_KeyDown( { if ($_.KeyCode -eq "Enter") { $x=$objListBox.SelectedItem;$objForm.Close() } } )
        $objForm.Add_KeyDown( { if ($_.KeyCode -eq "Escape") { $objForm.Close() } } )

        $OKButton = New-Object System.Windows.Forms.Button
        $OKButton.Location = New-Object System.Drawing.Size(75,120)
        $OKButton.Size = New-Object System.Drawing.Size(75,23)
        $OKButton.Text = "OK"
        $OKButton.Add_Click({$objListBox.SelectedItem;$objForm.Close()})
        $objForm.Controls.Add($OKButton)

        $CancelButton = New-Object System.Windows.Forms.Button
        $CancelButton.Location = New-Object System.Drawing.Size(150,120)
        $CancelButton.Size = New-Object System.Drawing.Size(75,23)
        $CancelButton.Text = "Cancel"
        $CancelButton.Add_Click({$objForm.Close()})
        $objForm.Controls.Add($CancelButton)

        $objLabel = New-Object System.Windows.Forms.Label
        $objLabel.Location = New-Object System.Drawing.Size(10,20) 
        $objLabel.Size = New-Object System.Drawing.Size(280,20) 
        $objLabel.Text = $Text
        $objForm.Controls.Add($objLabel) 

        $objListBox = New-Object System.Windows.Forms.ListBox 
        $objListBox.Location = New-Object System.Drawing.Size(10,40) 
        $objListBox.Size = New-Object System.Drawing.Size(260,20) 
        $objListBox.Height = 80

        foreach ($l in $ListArray) {

            [void] $objListBox.Items.Add($l)

        }

        $objForm.Controls.Add($objListBox)

        $objForm.Topmost = $True

        $objForm.Add_Shown( { $objForm.Activate() } )
        [void] $objForm.ShowDialog()

        Return $objListBox.SelectedItem

    }

	Function Remove-ADComputerObject {
		Param (
			[Parameter(Mandatory=$TRUE)]$serverName,
			[Parameter(Mandatory=$TRUE)]$serverDomainName
		)
		
		#Using Native AD Powershell Module
		Try {
			If (Get-ADComputer $serverName -Server $serverDomainName) {
				Get-ADComputer $serverName -Server $serverDomainName | Remove-ADObject -Confirm:$False -Recursive
				Return "'$serverName' AD computer object removed successfully"
			}
		}
		Catch {
			Return ($Error[0].InvocationInfo.InvocationName + ": " +  $Error[0].Exception.Message)
		}
		
		#Using DSQUERY.EXE and DSRM.EXE
		#$dsQueryEXE = "c:\windows\system32\dsquery.exe"
		#$dsRmEXE = "c:\windows\system32\dsrm.exe"
		#If (!(Test-Path $dsQueryEXE) -Or !(Test-Path $dsRmEXE)) {Return "Error: dsquery.exe or dsrm.exe is not found."}
		#$removeADCMD = $dsQueryEXE + " Computer -Name " + $serverName + " -s " + $serverDomainName + " | " + $dsRmEXE + " -noprompt -subtree"
		#$exitMessage = Invoke-Expression $removeADCMD
		#Return $exitMessage
		
	}
	
	Function Remove-DNSRecord {
		Param (
			[Parameter(Mandatory=$TRUE)]$serverName,
			[Parameter(Mandatory=$TRUE)]$serverDomainName
		)
		
		$removednsVBS = "$PSScriptRoot\removedns.vbs"
		
		$DNScmdEXE1 = "c:\windows\sysnative\dnscmd.exe" 	#http://serverfault.com/questions/155363/powershell-unable-to-see-dnscmd-exe
		$DNScmdEXE2 = "c:\windows\system32\dnscmd.exe"		
		If (Test-Path ($DNScmdEXE1)) {$DNScmdEXE = $DNScmdEXE1}
		ElseIf (Test-Path ($DNScmdEXE2)) {$DNScmdEXE = $DNScmdEXE2}
		Else {$DNSCmdEXE = "noDNSCMD.EXE"}

		If (!(Test-Path $DNScmdEXE) -Or !(Test-Path $removednsVBS) ){Return "Error: dnscmd.exe or removedns.vbs is not found."}
		
		$removednsVBSToRun = "cscript.exe /nologo " + $removednsVBS + " " + $serverName + "." + $serverDomainName
		$StartProcessArgList = "-NoLogo -NonInteractive -WindowStyle Hidden -Command `"$removednsVBSToRun`""

		Start-Process Powershell.exe -ArgumentList $StartProcessArgList -Wait

		$exitMessage = Get-Content "$env:Temp\$serverName.$serverDomainName-removedns.txt"
		
		Return $exitMessage
	}
	
    Function MgmtActions {

        Switch ($Action){

            "View" {
            
                Write-Host "Listing VMs in $cloudService..."

                foreach ($VM in $VMs) {
                    
                    Write-Host "`t$($VM.Name) : $($EnvVMs[$VMIndex.Item($vm.Name)].IPAddress) : $($EnvVMs[$VMIndex.Item($vm.Name)].PowerState)"
                                    
                }
        
            }

            "Start" {

                Write-Host "Starting $cloudService..."

                foreach ($VM in $VMs) {

                    Write-Host "`tStarting $($VM.Name)"
                    Start-AzureVM -ServiceName $cloudService -Name $VM.Name

                }

            }

            "Stop" {

                Write-Host "Stopping $cloudService..."

                foreach ($VM in $VMs ) {
            
                    Write-Host "`tStopping VM $($VM.Name)..."
                    Stop-AzureVM -ServiceName $cloudService -Name $VM.Name -Force

                }

                Write-Host "Complete"
        
            }


            "Restart" {
            
                Write-Host "Restarting VMs in $cloudService..."

                foreach ($VM in $VMs) {

                    Write-Host "`tRestarting $($VM.Name)"
                    Restart-AzureVM -ServiceName $cloudService -Name $VM.Name
            
                }

            }
        
            "Deprovision" {

                # TODO Fix #1
				If ($env:UserName -Match "fahq-sa-service-now") {
					$Prompt  = "Yes"
				}
				Else {
					$Prompt = Get-Confirmation("Warning!!! This action is irreversible and will permanently delete the VMs.  Do you wish to proceed?")
				}
				
				
                If ($Prompt -eq "Yes") {

                    Write-Host "Removing $cloudService..."

                    foreach ($VM in $VMs) {

                        Write-Host "`tRemoving $($VM.Name)"
                        Remove-AzureVM -ServiceName $cloudService -Name $VM.Name -DeleteVHD
						
						Write-Host "`tRemoving $($VM.Name) AD Object"
						Remove-ADComputerObject -serverName $VM.Name -serverDomainName $domain
						
						Write-Host "`tRemoving $($VM.Name) DNS Record"
						Remove-DNSRecord -serverName $VM.Name -serverDomainName $domain

                    }

                    If ( (Get-AzureVM -ServiceName $cloudService).Count -eq 0 ) {

                        # no more VMs in the service, remove it
                        Write-Host "`tRemoving Azure Cloud Service $cloudService"
                        Remove-AzureService -ServiceName $cloudService -Force

                    } Else {

                        Write-Host "`tUnable to remove cloud service, additional computers remain!`t" -ForegroundColor White -BackgroundColor Red

                    }
            
                } Else {

                    Write-Host "Operation Cancelled"
                    exit

                }

            }

        }
    }
    
    #endregion - Functions

    # Setup the environment
    #----------------------------------------------------------------------

    $VMXML = Ingest-XML -xmllist $ConfigFile -msg "Please select the VM Config XML file"

    If (!$Action) {

        $ListArray = @("View", "Start","Stop", "Restart", "Deprovision")
        $Action = Get-ListItem -Text "What action would you like to perform on $cloudService" -ListArray $ListArray 

    }

    Set-Subscription ($VMXML.ProvisionVMs.Subscription).Name ($VMXML.ProvisionVMs.Subscription).StorageAcct

    $cloudService = ($VMXML.ProvisionVMs.Subscription.Cloud).Name

    $domain = ($VMXML.ProvisionVMs.Subscription.Cloud.Defaults.Config | Where-Object {$_.Name -eq "Domain"}).Value

    $VMSize = ($VMXML.ProvisionVMs.Subscription.Cloud.Defaults.Config | Where-Object {$_.Name -eq "InstanceSize"}).Value

    $ImageLabel = ($VMXML.ProvisionVMs.Subscription.Cloud.Defaults.Config | Where-Object {$_.Name -eq "ImageLabel"}).Value

    $CfgVMs = @($VMXML.ProvisionVMs.Subscription.Cloud.VMs.VM)

    foreach ($VM in $CfgVMs) {

        $vmObject = [pscustomobject]@{'Name'='';'InstanceSize'='';'ImageLabel'=''}
        $vmObject.Name = $VM.Name

        If ( ($VM.Config | Where-Object {$_.Name -eq "InstanceSize"}).Value ) {

            $vmObject.InstanceSize = ($VM.Config | Where-Object {$_.Name -eq "InstanceSize"}).Value

        } Else { 

            $vmObject.InstanceSize = $VMSize

        }

        If  ( ($VM.Config | Where-Object {$_.Name -eq "ImageLabel"}).Value ) {

            $vmObject.ImageLabel = ($VM.Config | Where-Object {$_.Name -eq "ImageLabel"}).Value
    
        } Else {

            $vmObject.ImageLabel = $ImageLabel
        
        }

        $VMs += $vmObject

    }

    $EnvVMs = @( Get-AzureVM -ServiceName $cloudService )

    # Build an index of VM names to their object location
    $VMIndex = @{}

    for ($i=0;$i -lt $EnvVMs.Count ;$i++) { 

        $VMIndex.Item($EnvVMs.Item($i).Name) = $i
    
    }
        
}

Process {

    $Result = Compare-VMNames 

    $EnvironmentMatch = ( $Result -and $EnvironmentMatch )
    
    If ($EnvironmentMatch -or $Force) { 
    
        $Result = Compare-VMSizes
        $EnvironmentMatch = ( $Result -and $EnvironmentMatch )

    } Else {

        Write-Error -Message "Environment contains missing or extra VMs.  Additional analysis stopped." `
                    -RecommendedAction "Run this command with the -verbose parameter for details or with -force to override the error."

    }
    
    If ($EnvironmentMatch -or $Force) { 
    
        MgmtActions 
        
    } Else {

        Write-Error -Message "Environment does not match definition.  Unable to perform management action." `
                    -RecommendedAction "Run this command with the -verbose parameter for details or with -force to override the error."

    }

}

End {

    # Return an errorlevel based onthe number of errors that have occurred
    # Zero indicates no errors
    Exit $Error.Count

}
