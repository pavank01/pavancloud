﻿<#
.DESCRIPTION
New-FAAzureService will create a new cloud service in the
current subscription.

.PARAMETER ServiceName
The name of the new cloud service.

.PARAMETER Location
The geographic location for the new storage account. The
default value is 'West US'.

.EXAMPLE
.\New-FAAzureService.ps1 -ServiceName SO-1-1-AZUR-CS-1
#>
[CmdletBinding()]
    param (
        [Parameter(Mandatory=$True)]
        [string]$ServiceName,

        [Parameter(Mandatory=$False)]
        [ValidateSet("West US")]
        [string]$Location = 'West US'

    )

# Specify the naming standard for cloud services

$ServiceExp  = '(\w{2})-(\d+)-(\d+)-(\w{4})-CS-(\d+)'

# Convert the ServiceName to upper case

$ServiceName = $ServiceName.ToUpper()
	
if ($ServiceName -match $ServiceExp) {

    Write-Verbose "Cloud service name matches our naming standard."

    Write-Verbose "Checking to see if the cloud service already exists."

    $ServiceStatus = Test-AzureName -Service $ServiceName

    if ($ServiceStatus -eq "$True") {

        Write-Warning "$ServiceName already exists."

    } Else {

        Write-Verbose "Creating cloud service $ServiceName in location $Location."

        New-AzureService -ServiceName $ServiceName -Location $Location
    }

} Else {

    Write-Warning "Cloud service name provided does NOT match our naming standard."
	
}
