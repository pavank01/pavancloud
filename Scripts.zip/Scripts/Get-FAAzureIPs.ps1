﻿[CmdletBinding()]
    param (

    $SubscriptionList = @("SO-1-AzureSub-1","SO-1-AzureSub-4"),

    $MaxIps = "494", 
    
    $HtmlFragments =@(),
    
    $IpInfoFile = "IpInfo.htm",

    $IpInfoPath = "E:\Scripts\Reports",

    $FullPath = (Join-Path $IpInfoPath $IpInfoFile),

    $PathToWebRoot = "C:\inetpub\wwwroot",

    $Date = (Get-Date).tostring("MM/dd/yyyy"),

    $pathToSecureTxt = 'E:\Scripts',
    
    $DataTiers = @{"S-10.64.0.0/23" = "App Prod";
                    "S-10.64.2.0/23" = "Data Prod";
                    "S-10.64.4.0/23" = "App Dev";
                    "S-10.64.6.0/23" = "Data Dev";
                    "S-10.64.8.0/23" = "Web Dev";
                    "S-10.64.10.0/23" = "App Dev";
                    "S-10.64.12.0/23" = "App Dev";
                    "S-10.64.14.0/23" = "Data Dev";
                    "S-10.64.32.0/23" = "Web Dev";
                    "S-10.64.34.0/23" = "App Dev";
                    "S-10.64.36.0/23" = "App Dev";
                    "S-10.64.38.0/23" = "Data Dev";
                    "S-10.64.40.0/23" = "Web Dev";
                    "S-10.64.42.0/23" = "App Dev";
                    "S-10.64.44.0/23" = "App Dev";
                    "S-10.64.46.0/23" = "Data Dev";
                    "S-10.64.48.0/23" = "Web Dev";
                    "S-10.64.50.0/23" = "App Dev";
                    "S-10.64.52.0/23" = "App Dev";
                    "S-10.64.54.0/23" = "Data Dev";
                    }

    )


$UtilityPassword = Get-Content "$pathToSecureTxt\secureBackupPassword.txt" | ConvertTo-SecureString
$UtilityCred = New-Object -TypeName System.Management.Automation.PSCredential("fahq-sa-azureutil@fahqrasoazure1firstam156.onmicrosoft.com",$UtilityPassword)

Add-AzureAccount -Credential $UtilityCred | Out-Null



foreach ($Subscription in $SubscriptionList) {

    if ((Get-AzureSubscription -Current).SubscriptionName -ne $Subscription) {

        Write-Host "Changing subscription to $Subscription..."
        Select-AzureSubscription $Subscription | Out-Null

    }

    $ht = @{}
    
    $MyServices = @()

    $MyDeployments = @()

    $MyVMInfo = @()

    $MyGroup = @{}

    $MyServices = Get-AzureService

    foreach ($Service in $MyServices) {

        Try {

            Write-Verbose "Getting deployment information for $($Service.ServiceName)."

            $MyDeployments += Get-AzureDeployment -ServiceName $Service.ServiceName -ErrorAction Stop

        } Catch {

            Write-Warning "No deployment found for $($Service.ServiceName)."

        }

    }

    foreach ($Deployment in $MyDeployments) {

        if (!($Deployment.SdkVersion))  {

            $MyVMs = @()

            Write-Host "Processing ("$Deployment.Name")"

            $MyVMs = Get-AzureVM -ServiceName $Deployment.ServiceName

                foreach ($VM in $MyVMs) {

                    $Properties = [ordered]@{VMName=$VM.InstanceName
                                            Subnet=$VM.VM.ConfigurationSets.SubnetNames
                                            VNet=$VM.VirtualNetworkName}

                    $obj = New-Object -TypeName PSObject -Property $Properties
                    
                    $MyVMInfo += $obj
                    
                }

        }

    }

    $MyGroup = $MyVMInfo | Group-Object -Property Subnet

    $HtmlFragments += $MyGroup | Select-Object -Property @{name="Subnet";expression={$_.Name}},@{name="UsedIPs";expression={$_.Count}},@{name="% Used";expression={("{0:P1}" -f ($_.Count / $MaxIPs))}},@{name="VNet";expression={$_.Group.VNet[0]}},@{name="DataTier";expression={$DataTiers.Item($_.Group.Subnet[0])}} |
    
    Sort-Object -Property VNet,Subnet |

    ConvertTo-Html -Fragment -PreContent "<h2>$Subscription</h2>" |
    
    Out-String
}

ConvertTo-Html -Title "Azure IP Usage by Subnet" -CssUri table_format.css -PreContent "<h1>Azure IP Usage by Subnet $Date</h1>" -PostContent $HtmlFragments | Out-File $FullPath

Copy-Item -Path $FullPath -Destination $PathToWebRoot -Force