﻿$subscriptionName = 'SO-1-AzureSub-1'
$serviceNames = @( "SO-1-1-EOCR-CS-1", "SO-1-1-EOCR-CS-2", 
                   "SO-1-1-EOCR-CS-3", "SO-1-1-EOCR-CS-4", "SO-1-1-EOCR-CS-5",
                   "SO-1-1-EOCR-CS-6", "SO-1-1-EOCR-CS-7", "SO-1-1-EOCR-CS-8",
                   "SO-1-1-EOCR-CS-9", "SO-1-1-EOCR-CS-10", "SO-1-1-EOCR-CS-11",
                   "SO-1-1-EOCR-CS-12", "SO-1-1-EOCR-CS-13", "SO-1-1-EOCR-CS-14" )

if ((Get-AzureSubscription -Current).SubscriptionName -ne $subscriptionName) {

    Write-Host "Changing subscription to $subscriptionName..."
    Select-AzureSubscription $subscriptionName | Out-Null

}

$serviceList = Get-AzureService | ? ServiceName -in $serviceNames

foreach ($service in $serviceList) {

    $deployment = Get-AzureDeployment -ServiceName $service.ServiceName
    
    Write-Host "Deployment $($service.ServiceName) has $($deployment.RoleInstanceList.Count) instances with the following sizes:"
        
    $instanceCounts = @{}

    foreach ($instance in $deployment.RoleInstanceList) {

        if ( $instance.InstanceSize ) {

            $instanceSize = $instance.InstanceSize

        } else {

            $instanceSize = 'Not provisioned'

        }
        
        $instanceCounts[ $instanceSize ] += 1

    }

    $instanceCounts | Format-Table -HideTableHeaders

}
