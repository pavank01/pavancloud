[CmdletBinding()]
Param(
    
    [Parameter(Mandatory=$false)]
    [ValidateSet("Create","View","Start","Stop","Restart","Deprovision")]
    [string]$Action = $env:SNC_action,

    [Parameter(Mandatory=$false)]
    [string]$ServerCollection = $env:SNC_config_file_name,
    
    [Parameter(Mandatory=$false)]
    $ConfigFileLocation = '\\corp.firstam.com\Departments\IT\Azure\Scripts\Data\ENVXML',

    [Parameter(Mandatory=$false)]
    $CredentialLocation = 'C:\Azure',

    [Parameter(Mandatory=$false)]
    $ScriptLocation = 'C:\Azure',

    [Parameter(Mandatory=$false)]
    $EncryptionKeyFile = 'C:\Azure\credential.key',

    [Parameter(Mandatory=$false)]
    [switch]$UseExistingAzureSession = $false

)

#----------------------------------------------------------------------
#
# Setup global error handling
#
#----------------------------------------------------------------------

trap {

    # Write the last error message and exit
    Write-Host $Error[0] -ForegroundColor Yellow
    Exit 9001

}

#----------------------------------------------------------------------
#
# Functions
#
#----------------------------------------------------------------------

function LoadCredential {

    Param (

        [Parameter(Mandatory=$true)]
        [string]$CredentialFile,

        [Parameter(Mandatory=$false)]
        [byte[]]$Key

    )

    if ( Test-Path -Path $CredentialFile ) {

        Return Read-PSCredentialFromFile -Path $CredentialFile -Key $Key

    } else {

        # throw an error here
        Write-Error "Credential file '$CredentialFile' is missing"
        Throw "Missing credential file $CredentialFile."

    }

}

#----------------------------------------------------------------------
#
# Main code
#
#----------------------------------------------------------------------

# assume success
$success = $true
$Error.Clear()

# Change to the $ScriptLocation folder so we can use ./ as the path for scripts
# If we find this doesn't work, we can append the script path to the script name
# and then call them like &(Join-Path -Path $ScriptLocation -ChildPath 'Library-FACredentials.ps1')
Push-Location -Path $ScriptLocation

# load credential management functions
.\Library-FACredentials.ps1

# Load encryption key
$Key = ConvertFrom-Base64String -String (Get-Content -Path $EncryptionKeyFile)

# Load stored credentials
$DomainCredentialFile = Join-Path -Path $CredentialLocation -ChildPath 'domain.credential'
$DomainCredential = LoadCredential -CredentialFile $DomainCredentialFile -Key $Key

$AzureCredentialFile = Join-Path -Path $CredentialLocation -ChildPath 'azure.credential'
$AzureCredential = LoadCredential -CredentialFile $AzureCredentialFile -Key $Key

# Build the full path for the ENVXML file
$ConfigFile = Join-Path -Path $ConfigFileLocation -ChildPath ($ServerCollection + ".XML")

# Log into Azure
if ( -not $useExistingAzureSession ) {
    Write-Output "Logging into Azure as $($AzureCredential.UserName)."
    Add-AzureAccount -Credential $AzureCredential
}

switch ($Action) {

    'Create' { 
        
        # The create action is handled by the Create-FAAzureEnvironment script
        #.\ReturnCode.ps1 -Code 0 -DomainCred $DomainCredential -ConfigFile $ConfigFile
        #$ResultCode = $LASTEXITCODE
		
		.\Create-FAAzureEnvironment.ps1 -DomainCred $DomainCredential -ConfigFile $ConfigFile
		$ResultCode = $LASTEXITCODE
    }

    Default {
        # All other actions are handled by the Manage-FAAzureEnvironment script
        #.\ReturnCode.ps1 -Code 1 -Action $Action -Configfile $ConfigFile
        #$ResultCode = $LASTEXITCODE
		
		.\Manage-FAAzureEnvironment.ps1 -Action $Action -Configfile $ConfigFile
		$ResultCode = $LASTEXITCODE
    }

}

# Return to the original directory
Pop-Location

Write-Host "The code returned was $ResultCode"
Exit $ResultCode
