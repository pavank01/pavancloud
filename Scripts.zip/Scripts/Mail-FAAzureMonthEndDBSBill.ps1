﻿$MailFrom = 'FAHQ-DL-SOMCloudTeam@firstam.com'
$MailTo = @("mblackman@firstam.com","tpham@firstam.com","lwarner@firstam.com","mmikhael@firstam.com","MAllison@firstam.com")
#$MailTo = @("mblackman@firstam.com")
$SMTPServer = "mail.firstam.com"

$Month = (Get-Date).AddMonths(-1).ToString("yyyy-MM")
$FullFilePath = "E:\Scripts\Billing\AzureBill-$Month-Full.csv"
$ParseFilePath = "E:\Scripts\Billing\AzureBill-$Month-FullParse.csv"
$Subject = "DBS Azure bill for $Month"

$FileCheck = Test-Path -Path $ParseFilePath

if ($FileCheck -eq "True") {

    $Report = Import-Csv -Path $ParseFilePath

    $Body = $Report | Where-Object { ($_.ApplicationCode -eq 'EOCR') -or ($_.ApplicationCode -eq 'MSQL') -or ($_.ApplicationCode -eq 'DTCM') } |
        Select-Object -Property ApplicationCode,CostType,@{Name='Cost';Expression={[math]::Round($_.Cost,2)}} |
        ConvertTo-HTML |
        Out-String

    Send-MailMessage -Attachments $FullFilePath -Body $Body -BodyAsHtml -From $MailFrom -To $MailTo -Subject $Subject -SmtpServer mail.firstam.com

} else {

    Send-MailMessage -From $MailFrom -To $MailFrom -Subject "DBS Azure month end bill email error!" -Body "The DBS month end Azure bill did not get created properly. Look at the scheduled task FAAzureMailMonthEndBill on AZUVPUTLAZUR001. We may need to generate a new API access key. Check out the Azure OneNote page on Billing Processes." -SmtpServer $SMTPServer

}
