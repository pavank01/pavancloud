[CmdletBinding()]
Param (
	# ComputerName: Computer name or array of computer names
	[Parameter()]
	[String[]]$ComputerName = $Null,

	# Path: File with computer name or names
	[Parameter()]
	[String]$Path = $Null
)
# ---------------------------------------------------------------------------
Function Format-FileNameWithDate {
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $False)]
		[String]$Prefix,
		[Parameter(Mandatory = $False)]
		[String]$Suffix = ".txt",
		[Parameter(Mandatory = $False)]
		[String]$DateFormat = "yyyy-MM-dd"
	)
	$TextDate = Get-Date -Format $DateFormat
	Return $Prefix + $TextDate + $Suffix
}# ---------------------------------------------------------------------------
Function Test-Null($String) {
	If ($String -eq $Null -or $String -eq "") {
		$True
	} Else {
		$False
	}
}
# ---------------------------------------------------------------------------

$HasFailed = $False

# The user did not provide a list of computers to process - Exit Script
If ([String]::IsNullOrEmpty($ComputerName) -eq $True -and [String]::IsNullOrEmpty($Path) -eq $True) {
	Write-Host "Please provide a list of computers to reboot" -ForegroundColor Yellow -BackgroundColor DarkRed
	$HasFailed = $True
}

# The user provided a list of computers to process
If ([String]::IsNullOrEmpty($Path) -eq $False -and $HasFailed -eq $False) {
	# The user provided the list of computers to process in a text file
	If ((Test-Path -Path $Path) -eq $True) {
		# File exists so import the computer list
		Write-Host "Importing computer names from $Path"
		$ComputerName = @(Get-Content -Path $Path | ForEach {$_ -Replace('^*[\.](.*)$', '').ToUpper()} | Sort-Object | Select-Object -Unique)
	} Else {
		# Specified file does not exist - Exit Script
		Write-Host "File not found: $Path" -ForegroundColor Yellow -BackgroundColor DarkRed
		$HasFailed = $True
	}
} ElseIf ($ComputerName -ne '' -and $HasFailed -eq $False)  {
	# The user provided the list of computers to process on the command line
	$ComputerName = @($ComputerName | ForEach {$_ -Replace ('^*[\.](.*)$', '').ToUpper()} | Sort-Object | Select-Object -Unique)
}

If ($HasFailed -eq $True) {
	Break
} Else {
	$DomainNames = @("fastts.firstam.net", "corp.firstam.com", "datatrace.local", "datatree.local", "intl.crop.firstam.com", "itxprod.ad")

	$ServersResponding = @()
	$ServersNotResponding = @()
	ForEach ($Server In ($Servers | Sort-Object)) {
		$IsOnline = $False
		ForEach ($DomainName In $DomainNames) {
			$TempServerName = ("{0}.{1}" -f $Server, $DomainName)
			If (Test-Connection $TempServerName -Quiet -Count 1) {
				Write-Host "$TempServerName is Online" -ForegroundColor Green
				$ServersResponding += $TempServerName
				$IsOnline = $True
				Break
			}
		}
		If ($IsOnline -eq $False) {
			Write-Host "$Server is OFFLINE" -ForegroundColor Red
			$ServersNotResponding += $Server
		}
	}
	Write-Host
	Write-Host
	Write-Host ("Reboot these {0} servers now?" -f $ServersResponding.Count) -ForegroundColor Yellow -BackgroundColor DarkRed
	$Answer = Read-Host -Prompt "(y/n)"
	If ($Answer -eq "y") {
		Write-Host
		Write-Host ("Rebooting {0} servers ..." -f $ServersResponding.Count) -ForegroundColor Yellow
		Invoke-Command -ComputerName $ServersResponding -ErrorAction SilentlyContinue -ScriptBlock {
			Restart-Computer -Force
		}
	} Else {
		Write-Host
		Write-Host "The server reboots have been canceled" -ForegroundColor Green
	}
}