Modified version listed in the OneNote, includes some cluster settings from Terraform.

PLEASE RUN THE TERRAFORM VERSION for ASE Creation, use this method as a fall back.