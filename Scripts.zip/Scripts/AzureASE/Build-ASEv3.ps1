#########################################################################
# ASE V3 Deployment Script V.1.0
# by. Joe O'Brien 12/16/2021
#
# Launch the script, give it the Subscription, RG, Vnet/Subnet Details, 
# then what you want to name the ASE. Final step deploys it using the 
# template JSON file in this powershells working directory.
#########################################################################

Function promptYesNo {
    while("yes","no" -notcontains $answer)
    {
        $answer = Read-Host "Would you like to continue? (Yes/No)"
    }
        If ($answer -eq "no") {
            Write-Host "Exiting..." -ForeGroundColor Red
        exit
    }
}

Write-Host ""
Write-Host "First American CET Azure Build-ASEv3 Script:" -ForegroundColor Green
Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
# Azure PSModules Import
Import-Module Az.Resources -ErrorAction Stop

#Input for Azure VM Resource Details
Write-Host "Please enter the following ASE Deployment Parameters: " -ForegroundColor yellow
Write-Host "Where will this ASE be built?:" -ForegroundColor yellow
$aseSubscriptionNameInput = Read-Host -Prompt "Subscription Name"
$aseSubscriptionName = $aseSubscriptionNameInput.Trim()

$aseResourceGroupNameInput = Read-Host -Prompt "Resource Group Name"
$aseResourceGroupName = $aseResourceGroupNameInput.Trim()

$aseVnetNameInput = Read-Host -Prompt "Virtual Network Name"
$aseVnetName = $aseVnetNameInput.Trim()

$aseSubnetNameInput = Read-Host -Prompt "Subnet Name"
$aseSubnetName = $aseSubnetNameInput.Trim()

$aseVnetRGNameInput = Read-Host -Prompt "vNet/Subnets Resource Group"
$aseVnetRGName = $aseVnetRGNameInput.Trim()

Write-Host ""
Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green
Write-Host "Please enter the ASE Configuration Parameters: "
Write-Host ""

Write-Host "Name must match [owner:4]-[account type N|P|S]-[sub#]-[app:4]-AE-[#]   Example: AZUR-N-2-IDAS-AE-1" -ForegroundColor Yellow
$aseNameInput = Read-Host -Prompt "ASE Name"
$aseName = $aseNameInput.Trim()

Write-Host "Done..." -ForegroundColor Green
Write-Host ""
Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

#Logging into Azure using provided credentials via Connect-AzAccount
Write-Host "Logging into Azure. Please use the interactive window to continue..."
Write-Host ""
Connect-AzAccount
Write-Host "Done..." -ForegroundColor Green
Write-Host ""
Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

#Setting the correct Subscription as active via Set-AzContext
Write-Host "Logging into the Subscription: $aseSubscriptionName..." -ForegroundColor Green
Write-Host ""
Set-AzContext -SubscriptionName $aseSubscriptionName -ErrorAction Stop
Write-Host "Done..." -ForegroundColor Green
Write-Host ""
Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

Write-Host ""
Write-Host "Building Variables..." -ForegroundColor Green
Write-Host ""
$aseVNETvar = Get-AzVirtualNetwork -ResourceGroupName $aseVnetRGName -Name $aseVnetName -ErrorAction Stop
$aseSubnetIdvar = Get-AzVirtualNetworkSubnetConfig -Name $aseSubnetName -VirtualNetwork $aseVNETvar -ErrorAction Stop
$vnetLocation = $asevnetvar.location
$rgdetails = Get-AzResourceGroup -Name $aseResourceGroupName -ErrorAction Stop
$rgLocation = $rgdetails.location
$armNotetext = "-Deployment"

###################################################################################################################
#   prodASEv3TemplateParameters Notes:
#   https://docs.microsoft.com/en-us/azure/app-service/environment/create-from-template
#
#   dedicatedHostCount -        Required. In most cases, set this to 0, which means 
#                               the ASE will be deployed as normal without dedicated 
#                               hosts deployed.
#
#                               0 = App Service Environments can be deployed to a host 
#                               group for an additional charge, 2 = Two dedicated hosts 
#                               will be deployed which will host your ASE for an additional 
#                               charge.
#
#   zoneRedundant -             Required. In most cases, set this to false, which means  
#                               the ASE will not be deployed into Availability Zones(AZ).
#                               Zonal ASEs can be deployed in some regions.
#
#                               $false = disabled zone redundancy. $true enables zone 
#                               redundancy.
#
#   InternalLoadBalancingMode - Required. In most cases, set this to 3, which means both 
#                               HTTP/HTTPS traffic on ports 80/443. If this property is 
#                               set to 0, the HTTP/HTTPS traffic remains on the public VIP.
#
#                               0 = public VIP only, 1 = only ports 80/443 are mapped to 
#                               ILB VIP, 2 = only FTP ports are mapped to ILB VIP, 3 = both 
#                               ports 80/443 and FTP ports are mapped to an ILB VIP.
#
$prodASEv3TemplateParameters = @{
    "dedicatedHostCount" = 0
    "zoneRedundant" = $false
    "InternalLoadBalancingMode" = 3
    "aseName" = $aseName
    "location" = $vnetLocation
    "subnetId" = $aseSubnetIdvar.Id
    }
###################################################################################################################
###################################################################################################################
#   prodASEv3Parameters Notes:
#   https://docs.microsoft.com/en-us/powershell/module/az.resources/new-azresourcegroupdeployment?view=azps-7.0.0
#
#   Mode -          Complete: In complete mode, Resource Manager deletes resources that 
#                   exist in the resource group but are not specified in the template.
#                   Incremental: In incremental mode, Resource Manager leaves unchanged 
#                   resources that exist in the resource group but are not specified in 
#                   the template.
#
#   TemplateFile -  Specifies the full path of a custom template file. Supported template 
#                   file type: json and bicep.
#
$prodASEv3Parameters = @{
    Mode = 'Incremental'
    TemplateFile = '.\ASEv3.json'
    ResourceGroupName = $aseResourceGroupName
    Name = "$aseName$armNotetext"
    TemplateParameterObject = $prodASEv3TemplateParameters
    }
###################################################################################################################

Write-Host "Done..." -ForegroundColor Green
Write-Host ""
Write-Host "--------------------------------------------------------------------------------" -ForegroundColor Green

Write-Host "Deployment Overview..." -ForegroundColor Green
Write-Host ""
Write-Host "ASE Subscription Name:  $aseSubscriptionName"
Write-Host "ASE ResourceGroup Name: $aseResourceGroupName"
Write-Host ""
Write-Host "ASE Name:               $aseName"
write-Host "ASE RG Location:        $rgLocation"
write-host  ""
Write-Host "ASE vNET Name:          $aseVnetName"
Write-Host "ASE vNET RG Name:       $aseVnetRGName"
Write-Host "ASE vNET Subnet Name:   $aseSubnetName"
Write-Host "ASE vNET Location:      $vnetLocation"
Write-Host ""
$prodASEv3TemplateParametersaseName = $prodASEv3TemplateParameters.aseName
$prodASEv3TemplateParameterslocation = $prodASEv3TemplateParameters.location
$prodASEv3TemplateParametersdedicatedHostCount = $prodASEv3TemplateParameters.dedicatedHostCount
$prodASEv3TemplateParameterszoneRedundant = $prodASEv3TemplateParameters.zoneRedundant
$prodASEv3TemplateParameterssubnetId = $prodASEv3TemplateParameters.subnetId
$prodASEv3TemplateParametersInternalLoadBalancingMode = $prodASEv3TemplateParameters.InternalLoadBalancingMode

$prodASEv3ParametersResourceGroupName = $prodASEv3Parameters.ResourceGroupName
$prodASEv3ParametersName = $prodASEv3Parameters.Name
$prodASEv3ParametersMode = $prodASEv3Parameters.Mode
$prodASEv3ParametersTemplateFile = $prodASEv3Parameters.TemplateFile

Write-Host "ARM Parameter aseName:                      $prodASEv3TemplateParametersaseName"
Write-Host "ARM Parameter location:                     $prodASEv3TemplateParameterslocation"
Write-Host "ARM Parameter dedicatedHostCount:           $prodASEv3TemplateParametersdedicatedHostCount"
Write-Host "ARM Parameter zoneRedundant:                $prodASEv3TemplateParameterszoneRedundant"
Write-Host "ARM Parameter subnetId:                     $prodASEv3TemplateParameterssubnetId"
Write-Host "ARM Parameter InternalLoadBalancingMode:    $prodASEv3TemplateParametersInternalLoadBalancingMode"
Write-Host ""
Write-Host "PS Parameter ResourceGroupName:             $prodASEv3ParametersResourceGroupName"
Write-Host "PS Parameter Name:                          $prodASEv3ParametersName"
Write-Host "PS Parameter Mode:                          $prodASEv3ParametersMode"
Write-Host "PS Parameter TemplateFile:                  $prodASEv3ParametersTemplateFile"

Write-Host ""
Write-Host "Continue? Selecting yes will deploy the ASE." -ForegroundColor Yellow
promptYesNo
Write-Host ""

New-AzResourceGroupDeployment @prodASEv3Parameters -Verbose 