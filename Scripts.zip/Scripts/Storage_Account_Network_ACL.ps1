#Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

#$cred = Get-Credential
#Add-AzureRMAccount -Credential $cred

#Yes or No prompt for settings change prompt confirmation.
Function promptYesNo {
    while("yes","no" -notcontains $answer)
    {
        $answer = Read-Host "Would you like to ENABLE this setting (DENY)? (Yes/No)"
    }
        If ($answer -eq "no") {
            Write-Host "Exiting..." -ForeGroundColor Red
        exit
    }
}

#clears errors
$error.Clear()

#Primary Rollup IP Address Text File - Sourced in our Repo - MAKE SURE this is in the same folder as this script.
#Also removes spaces in column headers 
$SourceFolder = "."
$SourceFile = "RollupIPs.csv"
$SourcePath = $SourceFolder + "\" + $SourceFile
$SourceHeadersDirty = Get-Content -Path $SourcePath -First 2 | ConvertFrom-Csv
$SourceHeadersCleaned = $SourceHeadersDirty.PSObject.Properties.Name.Trim(' ') -Replace '\s',''
$listofips = Import-CSV -Path $SourcePath -Header $SourceHeadersCleaned | Select-Object -Skip 1
#$listofvms | Format-Table -AutoSize

#RecordsCount
$i = 0
foreach ($ip in $listofips) {
    $i++   
}

$RollupIPCount = $i

Write-Host "INFORMATION: $RollupIPCount RollUp IP Addresses in Array..." -ForegroundColor yellow
Write-Host ""

Write-Host "Loading: Azure Code Block..." -ForeGroundColor Green

#Enable-AzureRMAlias -Scope CurrentUser
Connect-AzAccount

Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
Write-Host "Please enter the following details: "

$SAinput = Read-Host -Prompt "Azure Storage Account Name"
$SA = $SAinput.Trim()
$SubscriptionNameInput = Read-Host -Prompt "Azure Subscription Name"
$SubscriptionName = $SubscriptionNameInput.Trim()
$ResourceGroupNameInput = Read-Host -Prompt "Azure Resource Group Name"
$ResourceGroupName = $ResourceGroupNameInput.Trim()

#Logging
$datepre = Get-Date -Format "MMddyyyy"
$datesuf = Get-Date -Format "HHmm"
$loggingpath = "\\corp.firstam.com\restricted\ServerOps-Admin\Scripts\Logs\StorageAccounts\"
$filename = "$SA-$datepre-$datesuf-$env:USERNAME.txt"
Write-Host ""
Start-Transcript -Path $Loggingpath$filename -NoClobber
#Logging

Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
Write-Host "Logging into Subscription..." -ForegroundColor Green
Set-AzContext -SubscriptionName $SubscriptionName 
Write-Host ""
Write-Host "Storage Account Details:" -ForegroundColor Green
Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
$sadetails = Get-AzStorageAccount -ResourceGroupName $ResourceGroupName -AccountName $SA | Select-Object *

Write-Host ""
Write-Host "Name:                "$sadetails.StorageAccountName
Write-Host "Subscription:        "$SubscriptionName
Write-Host "Resource Group:      "$sadetails.ResourceGroupName
Write-Host "Resource ID:         "$sadetails.Id
Write-Host "Location:            "$sadetails.Location
Write-Host "SKU:                 "$sadetails.SkuName
Write-Host "Kind:                "$sadetails.Kind
Write-Host "AccessTier:          "$sadetails.AccessTier
Write-Host "Created TIme:        "$sadetails.CreationTime
Write-Host ""
Write-Host "Network ACLs:" -ForegroundColor Green
Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
$SANetworkSettings = Get-AzStorageAccountNetworkRuleSet -ResourceGroupName $ResourceGroupName -AccountName $SA | Select-Object *
Write-Host "Current ACL Setting on $SA"
Write-Host ""

if ($SANetworkSettings.DefaultAction -like "*Deny*") {
    Write-Host "AllowAccess:        Deny (Selected Networks)" -ForegroundColor green
    #If we want Selected Network logic here
}
if ($SANetworkSettings.DefaultAction -like "*Allow*") {
    Write-Host "AllowAccess:        Allow (All Networks)" -ForegroundColor yellow
    #If we want Allow All logic here
}
Write-Host ""
Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
Write-Host "Preprocessing: Gathering Rules on $SA"
$PreProcessingACL = Get-AzStorageAccountNetworkRuleSet -ResourceGroupName $ResourceGroupName -AccountName $SA
Write-Host ""
Write-Host "Status: Done" -ForegroundColor Green

Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
Write-Host "Applying $RollUpIpCount Rollup IP Addresses"
Write-Host ""

Write-Host "Starting Addition----------------------------------------------------------------------" -ForegroundColor yellow 
Write-Host ""

$i = 1
foreach ($ip in $listofips) {

    $rollupIpAddress = $ip.RollupIPAddress
    $rollupIpLocation = $ip.Location
    $rollupIpResourceGroupName = $ip.ResourceGroupName
    $rollupIpPaloAltoVMName = $ip.PaloAltoVMName
    $rollupIpSubscriptionName = $ip.SubscriptionName

    if ($rollupIpAddress -eq '') {$RollupIPAddress = $RollupIPAddress -replace "","UNK"}
    if ($rollupIpLocation -eq '') {$rollupIpLocation = $rollupIpLocation -replace "","UNK"}
    if ($rollupIPResourceGroupName -eq '') {$rollupIPResourceGroupName = $rollupIpResourceGroupName -replace "","UNK"}
    if ($rollupIpPaloAltoVMName -eq '') {$rollupIpPaloAltoVMName = $rollupIpPaloAltoVMName -replace "","UNK"}
    if ($rollupIpSubscriptionName -eq '') {$rollupIpSubscriptionName = $rollupIpSubscriptionName -replace "","UNK"}

    Write-Host "Adding Rollup IP Address: $rollupIpAddress ($i of $RollUpIpCount)" -ForegroundColor Green
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    Write-Host "Rollup IP Info"
    Write-Host "IP:                 $rollupIpAddress"
    Write-Host "Location:           $rollupIpLocation"
    Write-Host "ResourceGroup:      $rollupIPResourceGroupName"
    Write-Host "Palo Alto VM Name:  $rollupIpPaloAltoVMName"
    Write-Host "Subscription Name:  $rollupIpSubscriptionName"
    Write-Host ""
    Add-AzStorageAccountNetworkRule -ResourceGroupName $ResourceGroupName -Name $SA -IPAddressOrRange $rollupIpAddress | Out-Null
    Write-Host "Status: Added." -ForegroundColor Green
    Write-Host ""
    $i++    
}

Write-Host ""
Write-Host "$RollUpIpCount Rollup IP Addresses processed." -ForegroundColor Green

Write-Host ""
Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
Write-Host "Postprocessing: Gathering Rules on $SA"
$PostProcessingACL = Get-AzStorageAccountNetworkRuleSet -ResourceGroupName $ResourceGroupName -AccountName $SA
Write-Host ""
Write-Host "Status: Done" -ForegroundColor Green

Write-Host ""
Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
Write-Host "Rules Before Change:  $SA" 
$PreProcessingACL.IpRules
Write-Host ""
Write-Host "Total: "$PreProcessingACL.IpRules.Count

Write-Host ""
Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
Write-Host "Rules Ater Change:  $SA"
$PostProcessingACL.IpRules
Write-Host ""
Write-Host "Total: "$PostProcessingACL.IpRules.Count

Write-Host ""
Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
Write-Host "Change Summary:  $SA"
Write-Host ""
Write-Host 
Write-Host "Number of Rules BEFORE Change: "$PreProcessingACL.IpRules.Count
Write-Host "Number of Rules AFTER Change: "$PostProcessingACL.IpRules.Count
Write-Host ""
Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
Write-Host "Error/Info Log:"
$error
#Enables the Deny Option if selected
Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
Write-Host "Final Steps:" 
if ($SANetworkSettings.DefaultAction -like "*Deny*") {
    Write-Host "DefaultAction:        Deny (Selected Networks)" -ForegroundColor green
    Write-Host ""
    Write-Host "Actions: None, Deny is currently set, ACL/Firewall is active." -ForegroundColor green
    Write-Host ""
    Write-Host "Script Complete: Storage Account Firewall: Default Action is already set to DENY." -ForegroundColor Green
    Write-Host
}
if ($SANetworkSettings.DefaultAction -like "*Allow*") {
    Write-Host "DefaultAction:        Allow (All Networks)" -ForegroundColor yellow
    Write-Host ""
    Write-Host "Actions: Set DefaultAction rule to DENY." -ForegroundColor yellow
    Write-Host ""
    Write-Host "IMPORTANT: Changing this setting to DENY will activate the Storage Account firewall and block ALL traffic not allowed." -ForegroundColor Red
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    promptYesNo
    Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
    Update-AzStorageAccountNetworkRuleSet -ResourceGroupName $ResourceGroupName -Name $SA -DefaultAction Deny
    Write-Host "Script Complete: Storage Account Firewall: DefaultAction now set to DENY." -ForegroundColor Green
    Write-Host
}
Stop-Transcript