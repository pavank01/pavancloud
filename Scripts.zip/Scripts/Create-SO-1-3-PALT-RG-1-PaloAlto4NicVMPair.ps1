﻿$resourceGroupName = 'SO-1-3-PALT-RG-1'

$fw1DeploymentParms = @{
    'location' = 'westus'
    'availabilitySetName' = 'PALT-FWL-AS-1'
    'vmName' = 'AZUVPFWLPALT001'
    'vmSize' = 'Standard_D4_v2'
    'adminUsername' = 'faadmin'
    'adminPassword' = 'A@1339bd040e6b'
    'storageAccountName' = 'soa1s3paltsa1'
    'virtualNetworkName' = 'SO-1-3-IaaS-VN-1'
    'virtualNetworkResourceGroup' = 'SO-1-3-AZUR-RG-1'
    'managementSubnetName' = 'S-10.64.190.0-26'
    'trustSubnetName' = 'S-10.64.190.64-26'
    'untrustSubnetName' = 'S-10.64.190.128-26'
    'dmzSubnetName' = 'S-10.64.190.192-26'
    'trustSubnetStaticAddress' = '10.64.190.70'
    'untrustSubnetStaticAddress' = '10.64.190.135'
    'dmzSubnetStaticAddress' = '10.64.190.200'
}

New-AzureRMResourceGroupDeployment -ResourceGroupName $resourceGroupName -TemplateFile .\PaloAlto-4NIC-Pair.json -TemplateParameterObject $fw1DeploymentParms -mode Incremental

$fw2DeploymentParms = @{
    'location' = 'westus'
    'availabilitySetName' = 'PALT-FWL-AS-1'
    'vmName' = 'AZUVPFWLPALT002'
    'vmSize' = 'Standard_D4_v2'
    'adminUsername' = 'faadmin'
    'adminPassword' = 'A@1339bd040e6b'
    'storageAccountName' = 'soa1s3paltsa1'
    'virtualNetworkName' = 'SO-1-3-IaaS-VN-1'
    'virtualNetworkResourceGroup' = 'SO-1-3-AZUR-RG-1'
    'managementSubnetName' = 'S-10.64.190.0-26'
    'trustSubnetName' = 'S-10.64.190.64-26'
    'untrustSubnetName' = 'S-10.64.190.128-26'
    'dmzSubnetName' = 'S-10.64.190.192-26'
    'trustSubnetStaticAddress' = '10.64.190.71'
    'untrustSubnetStaticAddress' = '10.64.190.136'
    'dmzSubnetStaticAddress' = '10.64.190.201'
}

New-AzureRMResourceGroupDeployment -ResourceGroupName $resourceGroupName -TemplateFile .\PaloAlto-4NIC-Pair.json -TemplateParameterObject $fw2DeploymentParms -mode Incremental

