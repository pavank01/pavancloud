######################################################################
# This script will enable the diagnostic settings on a service account
#
# v1.0 - Joe O'Brien
#
# - Fixed transcript/logging filename issue.
######################################################################
#Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

#Adjustable Thresholds & Settings
$LoggingRetentionDays = "90"
$LoggingOperations = "All"
$LoggingVersion = "2.0"
$MetricsLevel = "ServiceAndApi"
$MetricsRetentionDays = "7"
$MetricsVersion = "1.0"

#clears error log
$error.Clear()

#Enable-AzureRmAlias -Scope CurrentUser
#Connect-AzureRMAccount

##Interactive Login##
Connect-AzAccount  -ErrorAction Stop

Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
Write-Host "Please enter the following details: "

$SAinput = Read-Host -Prompt "Azure Storage Account Name"
$SA = $SAinput.Trim()
$SubscriptionNameInput = Read-Host -Prompt "Azure Subscription Name"
$SubscriptionName = $SubscriptionNameInput.Trim()
$ResourceGroupNameInput = Read-Host -Prompt "Azure Resource Group Name"
$ResourceGroupName = $ResourceGroupNameInput.Trim()

#Logging
$datepre = Get-Date -Format "MMddyyyy"
$datesuf = Get-Date -Format "HHmm"
$loggingpath = "\\corp.firstam.com\restricted\ServerOps-Admin\Scripts\Logs\StorageAccounts\diagnosticsettings\"
$filename = "$SA-$datepre-$datesuf-$env:USERNAME.txt"
Write-Host ""
Start-Transcript -Path $Loggingpath$filename -NoClobber

Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
Write-Host "Logging into Subscription..." -ForegroundColor Green
Set-AzContext $SubscriptionName 
Write-Host ""
Write-Host "Storage Account Details:" -ForegroundColor Green
Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
$storageAccount = Get-AzStorageAccount -ResourceGroupName $ResourceGroupName -AccountName $SA
$ctx = $storageAccount.Context
$storageAccount

Write-Host ""
Write-Host "Enabling Diagnostic Settings on $SA :" -ForegroundColor Green
Write-Host "-----------------------------------------------------------------" -ForegroundColor Green

Write-Host "Logging Settings: Blob" -ForegroundColor Yellow
Set-AzStorageServiceLoggingProperty -ServiceType Blob -LoggingOperations $LoggingOperations -RetentionDays $LoggingRetentionDays -Context $ctx -Version $LoggingVersion -PassThru

Write-Host "Logging Settings: Queue" -ForegroundColor Yellow
Set-AzStorageServiceLoggingProperty -ServiceType Queue -LoggingOperations $LoggingOperations -RetentionDays $LoggingRetentionDays -Context $ctx -Version $LoggingVersion -PassThru

Write-Host "Logging Settings: Table" -ForegroundColor Yellow
Set-AzStorageServiceLoggingProperty -ServiceType Table -LoggingOperations $LoggingOperations -RetentionDays $LoggingRetentionDays -Context $ctx -PassThru

Write-Host "Logging Settings: File" -ForegroundColor Yellow
Write-Host "As of 5/18/2021 - File Logging is not supported for Diagnostic Settings".
Write-Host ""

Write-Host "Metric Settings: Blob, ServiceAndApi:" -ForegroundColor Yellow
Set-AzStorageServiceMetricsProperty -ServiceType Blob -MetricsType Hour -MetricsLevel $MetricsLevel  -RetentionDays $MetricsRetentionDays -Version $MetricsVersion -Context $ctx -PassThru
Set-AzStorageServiceMetricsProperty -ServiceType Blob -MetricsType Minute -MetricsLevel $MetricsLevel  -RetentionDays $MetricsRetentionDays -Version $MetricsVersion -Context $ctx -PassThru

Write-Host "Metric Settings: File, ServiceAndApi:" -ForegroundColor Yellow
Set-AzStorageServiceMetricsProperty -ServiceType File  -MetricsType Hour -MetricsLevel $MetricsLevel  -RetentionDays $MetricsRetentionDays -Version $MetricsVersion -Context $ctx -PassThru
Set-AzStorageServiceMetricsProperty -ServiceType File  -MetricsType Minute -MetricsLevel $MetricsLevel  -RetentionDays $MetricsRetentionDays -Version $MetricsVersion -Context $ctx -PassThru

Write-Host "Metric Settings: Table, ServiceAndApi:" -ForegroundColor Yellow
Set-AzStorageServiceMetricsProperty -ServiceType Table  -MetricsType Hour -MetricsLevel $MetricsLevel  -RetentionDays $MetricsRetentionDays -Version $MetricsVersion -Context $ctx -PassThru
Set-AzStorageServiceMetricsProperty -ServiceType Table  -MetricsType Minute -MetricsLevel $MetricsLevel  -RetentionDays $MetricsRetentionDays -Version $MetricsVersion -Context $ctx -PassThru

Write-Host "Metric Settings: Queue, ServiceAndApi:" -ForegroundColor Yellow
Set-AzStorageServiceMetricsProperty -ServiceType Queue  -MetricsType Hour -MetricsLevel $MetricsLevel  -RetentionDays $MetricsRetentionDays -Version $MetricsVersion -Context $ctx -PassThru
Set-AzStorageServiceMetricsProperty -ServiceType Queue  -MetricsType Minute -MetricsLevel $MetricsLevel  -RetentionDays $MetricsRetentionDays -Version $MetricsVersion -Context $ctx -PassThru

Write-Host "Status for $SA :" -ForegroundColor Green
Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
Write-Host "Completed" -ForegroundColor Green

Write-Host "Error/Info Log for $SA :" -ForegroundColor Green
Write-Host "-----------------------------------------------------------------" -ForegroundColor Green
$error
Stop-Transcript