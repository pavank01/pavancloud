$VersionDetails = @()
# Collect Current OS Install
$VersionDetails += Get-WmiObject -Class Win32_OperatingSystem | Select-Object @{L="ComputerName";E={$_.CSName}}, @{L="OperatingSystem";E={($_.Caption -Replace('Microsoft',' ') -Replace('Server',' ') -Replace('[^\x20-\x7E]+', ' ') -Replace('\s+', ' ')).Trim()}}, Version, @{L="InstallDate";E={Get-Date -Date ([Management.ManagementDateTimeConverter]::ToDateTime($_.InstallDate)) -Format "MM/dd/yyyy"}}
$ComputerName = $VersionDetails.ComputerName
# Collect any OS Upgrades
$OSUpgrades = Get-ChildItem "HKLM:\System\Setup\Source OS*" -ErrorAction SilentlyContinue
If ($OSUpgrades -ne $Null) {
	ForEach ($OSUpgrade In $OSUpgrades) {
		# Cleanup OS Name
		$OS = (($OSUpgrade | Get-ItemProperty -Name ProductName).ProductName -Replace('Microsoft',' ') -Replace('Server',' ') -Replace('[^\x20-\x7E]+', ' ') -Replace('\s+', ' ')).Trim()
		# Get the OS Version Number (Major.Minor.Build)
		If (($OSUpgrade | Get-ItemProperty -Name CurrentMajorVersionNumber -ErrorAction SilentlyContinue).CurrentMajorVersionNumber -ne $Null) {
			$Version = "{0}.{1}.{2}" -f ($OSUpgrade | Get-ItemProperty -Name CurrentMajorVersionNumber).CurrentMajorVersionNumber, ($OSUpgrade | Get-ItemProperty -Name CurrentMinorVersionNumber).CurrentMinorVersionNumber, ($OSUpgrade | Get-ItemProperty -Name CurrentBuild).CurrentBuild
		} Else {
			$Version = "{0}.{1}" -f ($OSUpgrade | Get-ItemProperty -Name CurrentVersion).CurrentVersion, ($OSUpgrade | Get-ItemProperty -Name CurrentBuild).CurrentBuild
		}
		# Convert the Registry Date to a Readable Date
		$InstallDate = [TimeZone]::CurrentTimeZone.ToLocalTime(([DateTime]'1/1/1970').AddSeconds(($OSUpgrade | Get-ItemProperty -Name InstallDate).InstallDate))
		$VersionDetails += "" | Select-Object @{L="ComputerName";E={$ComputerName}}, @{L="OperatingSystem";E={$OS}}, @{L="Version";E={$Version}}, @{L="InstallDate";E={Get-Date -Date $InstallDate -Format "MM/dd/yyyy"}}
		$OS = $Null
		$Version = $Null
		$InstallDate = $Null
	}
}
# Sort with Latest Install First
$VersionDetails | Sort-Object InstallDate -Descending


<#

These servers have been upgraded

ComputerName    OperatingSystem          Version    InstallDate
------------    ---------------          -------    -----------
SNAVPWEBDFTP002 Windows 2012 R2 Standard 6.3.9600   12/02/2017
SNAVPWEBDFTP002 Windows 2012 Standard    6.2.9200   05/02/2014

ComputerName    OperatingSystem          Version    InstallDate
------------    ---------------          -------    -----------
SNAVPWEBDFTP003 Windows 2012 R2 Standard 6.3.9600   12/10/2017
SNAVPWEBDFTP003 Windows 2012 Standard    6.2.9200   05/02/2014


These servers have not bee upgraded

ComputerName    OperatingSystem          Version    InstallDate
------------    ---------------          -------    -----------
SNAVNWEBMFAM008 Windows 2008 R2 Standard 6.1.7601   02/18/2014

ComputerName    OperatingSystem          Version    InstallDate
------------    ---------------          -------    -----------
SNAVNWEBEWBD009 Windows 2012 R2 Standard 6.3.9600   05/22/2015

ComputerName    OperatingSystem          Version    InstallDate
------------    ---------------          -------    -----------
SNAVPMGTOTRS002 Windows 2012 R2 Standard 6.3.9600   06/17/2016

ComputerName    OperatingSystem          Version    InstallDate
------------    ---------------          -------    -----------
DFWVDAPPNETI001 Windows 2016 Standard    10.0.14393 12/06/2017

ComputerName    OperatingSystem          Version    InstallDate
------------    ---------------          -------    -----------
RAMSBURY-L1     Windows 10 Enterprise    10.0.15063 10/19/2017
RAMSBURY-L1     Windows 10 Enterprise    10.0.14393 02/07/2017

#>
