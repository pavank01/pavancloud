$ErrorActionPreference= 'silentlycontinue'
$Software_Distribution = 'C:\Windows\SoftwareDistribution\Download'
$Windows_Temp = 'C:\Windows\Temp'
$Recyclebin= 'C:\$Recycle.Bin'
$Altris='C:\Program Files\Altiris\Altiris Agent\Agents\SoftwareManagement\Software Delivery'
$Olderthan= -10
Get-ChildItem -Path $Altris|where {$_.LastWriteTime -lt (Get-Date).AddDays($Olderthan)}|remove-item -force -Recurse
Get-ChildItem -Path $Software_Distribution | Remove-Item -Force -Recurse
Get-ChildItem -Path $Windows_Temp | Remove-Item -Force -Recurse
Remove-Item -Path $Recyclebin -Force -Recurse
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\apurakkal')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\apurakkal-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\CKarapakula')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\CKarapakula-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\jaykumar')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\jaykumar-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\KPai')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\KPai-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\NVelandi-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\kshree-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\MDeepak-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\MDeepak')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\mkhulakpam-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\NVelandi')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\NiNagaraj')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\NiNagaraj-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\paditya-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\Psivaramapillai')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\Psivaramapillai-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\RVemani-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\RVemani')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\SRajah-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\SRajah')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\RySuresh-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\RySuresh')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\WKondaiah-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\WKondaiah')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\ssingh-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\ssingh')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\ajoy-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\RKolkar-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\RKolkar')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\palla')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\palla-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\jerowilson')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\jerowilson-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\arout')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\arout-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\vananand-a')} | Remove-WMIObject
Get-WMIObject -Class Win32_UserProfile | where {($_.LocalPath -eq 'c:\users\vananand')} | Remove-WMIObject

Remove-Item -Path 'C:\$Recycle.Bin' -Force -Recurse
$disk = Get-WmiObject Win32_LogicalDisk -Filter "DeviceID='C:'" | Select-Object Size,FreeSpace
$xy= $disk.Size/1GB
$yz= $disk.FreeSpace/1GB
Write-Host "All the Temporaray OS Related Files have been Deleted" -ForegroundColor Green
Write-Host "Currently the C drive has $yz GB of free space available out of $xy GB" -ForegroundColor Yellow







