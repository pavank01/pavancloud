﻿<#
.SYNOPSIS
Get Performance Monitor information regarding a server or group of servers.

.DESCRIPTION
A PowerShell script to collect key performance counters from a server or group of 
servers to quickly locate or rule out any server related issues in a P1, P2, etc.
Output is to both the PowerShell window and to Grid View so you can sort by column.
Place the list of servers you want to check in Get-QuickServerStatusServerList.txt.

.PARAMETER MaxSamples
The number of Performance Monitor samples to take.
When not specified, the default is 15 samples.

.PARAMETER SampleInterval
The number of seconds between samples.
When not specified, the default is 1 second.

.NOTES
Author: Chris Throop

.EXAMPLE
.\Get-QuickServerStatus.ps1

.EXAMPLE
.\Get-QuickServerStatus.ps1 | FT

.EXAMPLE
.\Get-QuickServerStatus.ps1 -MaxSamples 5 -SampleInterval 2 | FT

#>

[CmdletBinding()]
Param(

    [Parameter(Mandatory=$false)]
    [string]$MaxSamples = 15,

    [Parameter(Mandatory=$false)]
    [string]$SampleInterval = 1,

    [Parameter(Mandatory=$false)]
    [string]$DomainName = "corp.firstam.com"
)

$Servers = @(Get-Content '.\Get-QuickServerStatusServerList.txt') | ForEach-Object {If ($DomainName -ne $Null -and $DomainName -ne "") {("{0}.{1}" -f $_, $DomainName)} Else {$_}}
$StopWatch = [system.diagnostics.stopwatch]::StartNew()

Write-Host ""
Write-Host "    CPU = CPU Utilization in Percentage Format"
Write-Host "    RAM = RAM Utilization in Percentage Format"
Write-Host "   Disk = Disk Latency in milliseconds (PhysicalDisk(_Total)\Avg. Disk sec/Transfer)"
Write-Host "Network = Network Utilization in Percentage Format"
Write-Host " Uptime = System Uptime"
Write-Host "     MS = PerfMon Max Samples"
Write-Host "     SI = PerfMon Sample Interval (in Seconds)"
Write-Host ""
Write-Host "Collecting PerfMon Information ..."

$Results = Invoke-Command -ComputerName $Servers -ScriptBlock {
       $ParamList = @{
              SampleInterval = $Using:SampleInterval
              MaxSamples = $Using:MaxSamples
       }
       $RunSpaceCPU = [runspacefactory]::CreateRunspace()
       $RunSpaceRAM = [runspacefactory]::CreateRunspace()
       $RunSpaceDisk = [runspacefactory]::CreateRunspace()
       $RunSpaceNetwork = [runspacefactory]::CreateRunspace()
       $RunSpaceUptime = [runspacefactory]::CreateRunspace()

       $RSGetCPU = [System.Management.Automation.PowerShell]::Create()
       $RSGetRAM = [System.Management.Automation.PowerShell]::Create()
       $RSGetDISK = [System.Management.Automation.PowerShell]::Create()
       $RSGetNetwork = [System.Management.Automation.PowerShell]::Create()
       $RSGetUptime = [System.Management.Automation.PowerShell]::Create()

       $RSGetCPU.RunSpace = $RunSpaceCPU
       $RSGetRAM.RunSpace = $RunSpaceRAM
       $RSGetDISK.RunSpace = $RunSpaceDisk
       $RSGetNetwork.RunSpace = $RunSpaceNetwork
       $RSGetUptime.RunSpace = $RunSpaceUptime

       $RunSpaceCPU.Open()
       $RunSpaceRAM.Open()
       $RunSpaceDisk.Open()
       $RunSpaceNetwork.Open()
       $RunSpaceUptime.Open()

       [void]$RSGetCPU.AddScript({
              Param ($SampleInterval, $MaxSamples)
              [math]::ceiling((get-counter "\Processor Information(_Total)\% Processor Time" -SampleInterval $SampleInterval -MaxSamples $MaxSamples | select -ExpandProperty countersamples | select -ExpandProperty cookedvalue | Measure-Object -Average).average)
       }).AddParameters($ParamList)

       [void]$RSGetRAM.AddScript({
              ([math]::ceiling((get-counter "\Memory\% Committed Bytes In Use" -SampleInterval 1 -MaxSamples 1 | select -ExpandProperty countersamples | select -ExpandProperty cookedvalue | Measure-Object -Average).average))
       }).AddParameters($ParamList)

       [void]$RSGetDISK.AddScript({
              Param ($SampleInterval, $MaxSamples)
              (((get-counter "\PhysicalDisk(_Total)\Avg. Disk sec/Transfer" -SampleInterval $SampleInterval -MaxSamples $MaxSamples | select -ExpandProperty countersamples | select -ExpandProperty cookedvalue | Measure-Object -Average).average)*1000).ToString("n1")
       }).AddParameters($ParamList)

       [void]$RSGetNetwork.AddScript({
              Param ($SampleInterval, $MaxSamples)
              $NETi = (get-counter "\Network Interface(*)\Bytes Total/sec" -SampleInterval $SampleInterval -MaxSamples $MaxSamples | select -ExpandProperty countersamples | select -ExpandProperty cookedvalue | Measure-Object -Average).average
              $NETb = (get-counter "\Network Interface(*)\Current Bandwidth" -SampleInterval $SampleInterval -MaxSamples $MaxSamples | select -ExpandProperty countersamples | select -ExpandProperty cookedvalue | Measure-Object -Average).average
              ($NETi*8/$NETb*100).ToString("0.000")
       }).AddParameters($ParamList)

       [void]$RSGetUptime.AddScript({
              (Get-Date).AddSeconds(-(get-counter "\System\System Up Time" -SampleInterval 1 -MaxSamples 1 | select -ExpandProperty countersamples | select -ExpandProperty cookedvalue))
       }).AddParameters($ParamList)

       $RSJobCPU = $RSGetCPU.BeginInvoke()
       $RSJobRAM = $RSGetRAM.BeginInvoke()
       $RSJobDisk = $RSGetDisk.BeginInvoke()
       $RSJobNetwork = $RSGetNetwork.BeginInvoke()
       $RSJobUptime = $RSGetUptime.BeginInvoke()

       Do {
              Start-Sleep -MilliSeconds 500
       } Until ($RSJobCPU.IsCompleted -eq $True -and $RSJobRAM.IsCompleted -eq $True -and $RSJobDisk.IsCompleted -eq $True -and $RSJobNetwork.IsCompleted -eq $True -and $RSJobUptime.IsCompleted -eq $True)

       $CPU = $RSGetCPU.EndInvoke($RSJobCPU)
       $RAM = $RSGetRAM.EndInvoke($RSJobRAM)
       $Disk = $RSGetDisk.EndInvoke($RSJobDisk)
       $Network = $RSGetNetwork.EndInvoke($RSJobNetwork)
       $Uptime = $RSGetUptime.EndInvoke($RSJobUptime)

       $RSGetCPU.Dispose()
       $RSGetRAM.Dispose()
       $RSGetDisk.Dispose()
       $RSGetNetwork.Dispose()
       $RSGetUptime.Dispose()

       $RunSpaceCPU.Close()
       $RunSpaceRAM.Close()
       $RunSpaceDisk.Close()
       $RunSpaceNetwork.Close()
       $RunSpaceUptime.Close()

       New-Object -TypeName PSObject -Property @{
              CPU = $($CPU)
              RAM = $($RAM)
              Disk = $($Disk)
              Network = $($Network)
              Uptime = $($Uptime)
              SI = $Using:SampleInterval
              MS = $Using:MaxSamples
       } | Select-Object CPU, RAM, Disk, Network, Uptime, @{L="DateTimeStamp";E={Get-Date -Format "yyyy-MM-dd hh:mm:ss"}}, MS, SI
}
$Results | Select-Object @{L="ComputerName";E={$_.PSComputerName.split(".")[0]}}, CPU, RAM, Disk, Network, Uptime, DateTimeStamp, MS, SI | Sort-Object ComputerName | FT -AutoSize
#$Results | Select-Object @{L="ComputerName";E={$_.PSComputerName.split(".")[0]}}, CPU, RAM, Disk, Network, Uptime, DateTimeStamp, MS, SI | Sort-Object ComputerName | Out-GridView
$StopWatch.Stop()
Write-Host ""
Write-Host "Elapsed Time in Seconds: " $StopWatch.Elapsed.TotalSeconds "Seconds"
Write-Host "Elapsed Time in Minutes: " $StopWatch.Elapsed.TotalMinutes "Minutes"