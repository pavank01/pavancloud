
####################
# Prerequisite check
####################
if (-NOT([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "Administrator priviliges are required. Please restart this script with elevated rights." -ForegroundColor Red
    Pause
    Throw "Administrator priviliges are required. Please restart this script with elevated rights."
}



#$request = @{}
#$request['CN'] = Read-Host "Common Name (e.g. company.com)"

$cert = Read-Host -Prompt 'Enter the Certificate Name (.cer file name)'

####################
# Install Certificate
####################


Set-Location C:\certs\2017

Get-ChildItem $cert
Import-Certificate $cert -CertStoreLocation Cert:\LocalMachine\My
  
#Import-Certificate -FilePath c:\certs\2017\VeriSign_Int.crt -CertStoreLocation Cert:\LocalMachine\CA

Clear-Host
Write-Host "Certificate has been installed"
