function Invoke-FAAzureRMNetworInterfaceIpConfigSwap {

    [CmdletBinding(SupportsShouldProcess=$true)]
    param (
        # The ResourceGroup containing all items
        [Parameter(Mandatory=$true)]
        [string]$ResourceGroupName,

        # Computer with the IP address configuration
        [Parameter(Mandatory=$true)]
        [ValidateCount(2,2)]
        [string[]]$NetworkInterfaceNames,

        # The name of the IP address configuration to swap
        [Parameter(Mandatory=$true)]
        [string]$IPConfigName

    )

    begin {

        # Array variable to hold network interfaces
        $networkInterfaces = @()

        # Integer to track which interface currently holds the desired IP configuration
        $sourceNetworkInterface = @()
        $targetNetworkInterface = @()

    }

    process {

        foreach ( $nicName in $NetworkInterfaceNames ) {

            # Get the source and target network interfaces
            Write-Verbose "Retrieving Network Interface $nicName"

            $nic = Get-AzureRmNetworkInterface -ResourceGroupName $ResourceGroupName -Name $nicName

            Write-Verbose "Obtained Network Interface $($nic.id)"

            Write-Verbose "Checking Network Interface $nicName for IP Configuration $IPConfigName"

            try {

                $ipConfig = $null
                $ipConfig = $nic | Get-AzureRmNetworkInterfaceIpConfig -Name $IPConfigName -ErrorAction Stop

                if ( $ipConfig ) {

                    Write-Verbose "Obtained IP Configuration $($ipConfig.id)"

                    # Get the ipconfiguration from the source and make an instance of it that can be used by the target
                    $IPConfigArgs = @{
                        Name = $ipConfig.Name
                        PrivateIPAddressVersion = $ipConfig.PrivateIpAddressVersion
                        PrivateIPAddress = $ipConfig.PrivateIpAddress
                        Subnet = $ipConfig.Subnet
                    }

                    $sourceNetworkInterface += $nic

                }

            } catch {

                # We expect an error if the IPConfiguration does not exist on the NIC - this is normal
                Write-Verbose "IP Configuration $IPConfigName did not exist on $nicName"

                # Assume this is the target network interface
                $targetNetworkInterface += $nic

            }

            $networkInterfaces += $nic

        }

        if ( ( $sourceNetworkInterface.Count -ne 1 ) -or ( $targetNetworkInterface.Count -ne 1 ) ) { 

            Write-Error "The number of network interfaces containing $IPConfigName was $($sourceNetworkInterface.Count) and the number of target interfaces was $($targetNetworkInterface.Count).  Was expecting 1 for each.  Unable to continue." -ErrorAction Stop

        } else {

            # remove the ipconfig from the source and add it to the target
            if ($pscmdlet.ShouldProcess("$($networkInterfaces[0].Name) and $($networkInterfaces[1].Name)", "Swapping IP addresses for $IPConfigName")) {

                try {

                    Write-Verbose "Removing IPConfig $IPConfigName from interface $($sourceNetworkInterface[0].Name)"

                    $newSourceNIC = Remove-AzureRmNetworkInterfaceIpConfig -NetworkInterface $sourceNetworkInterface[0] -Name $IPConfigName | Set-AzureRmNetworkInterface

                    Write-Verbose "Adding IPConfig $IPConfigName to interface $($targetNetworkInterface[0].Name)"

                    $newTargetNIC = Add-AzureRmNetworkInterfaceIpConfig -NetworkInterface $targetNetworkInterface[0] @IPConfigArgs | Set-AzureRmNetworkInterface

                } catch {

                    Write-Error "Failed to perform IP address swap.  Please validate the source and destination network interfaces and implement any necessary corrections for configuration $IPConfigArgs."

                } finally {


                }

            }

        }

    }

    end {

    }

}

<#

Invoke-FAAzureRMNetworInterfaceIpConfigSwap -ResourceGroupName 'MT-1-4-PAAO-RG-2' `
                                            -NetworkInterfaceName @('networkfw1-eth2','networkfw2-eth2') `
                                            -IPConfigName 'networkfw-floating' -Verbose

#>
