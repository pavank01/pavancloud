$OSInfo = Get-WmiObject -Class Win32_OperatingSystem -ErrorAction SilentlyContinue | Select-Object @{L="ComputerName";E={$_.CSName}}, @{L="Domain";E={$Null}}, @{L="OperatingSystem";E={($_.Caption -Replace('Microsoft',' ') -Replace('Server',' ') -Replace('[^\x20-\x7E]+', ' ') -Replace('\s+', ' ')).Trim()}}, @{L="OS";E={($_.Caption -Replace('Microsoft',' ') -Replace('Windows',' ') -Replace('Server',' ') -Replace('Standard',' ') -Replace('Enterprise',' ') -Replace('Datacenter',' ') -Replace('Essentials',' ') -Replace('Foundation',' ') -Replace('[^\x20-\x7E]+', ' ') -Replace('\s+', '')).Trim()}}, @{L="SP";E={$_.ServicePackMajorVersion}}, @{L="OSArchitecture";E={$_.OSArchitecture -Replace('\-bit', '')}}
$OSInfo.Domain = (Get-WmiObject -Class Win32_ComputerSystem | Select-Object @{Label="Domain"; Expression={$_.Domain.ToLower()}}).Domain

Write-Host
Write-Host $OSInfo.ComputerName -ForegroundColor White -BackgroundColor DarkGreen
Write-Host $OSInfo.Domain -ForegroundColor White -BackgroundColor DarkGreen
If ($OSInfo.SP -eq 0) {
	Write-Host ("{0} ({1}-bit)" -f $OSInfo.OperatingSystem, $OSInfo.OSArchitecture) -ForegroundColor White -BackgroundColor DarkGreen
} Else {
	Write-Host ("{0} SP{1} ({2}-bit)" -f $OSInfo.OperatingSystem, $OSInfo.SP, $OSInfo.OSArchitecture) -ForegroundColor White -BackgroundColor DarkGreen
}
Write-Host

# ----------------------------------------------------------------------------
# Windows 2008
# Looks for KB4019276 that adds TLS 1.1/1.2 support to Windows 2008 SP2
# TLS 1.1/1.2 is not possible in Windows 2008 RTM or SP1
# TLS 1.0 cannot be disabled in Windows 2008 as RDP does not support TLS 1.1/1.2
$KB4019276_2008SP2 = $False
If ($OSInfo.OS -eq "2008" -and $OSInfo.SP -ge 2) {
	Write-Host "Windows 2008 - Scanning for KB4019276 ..." -ForegroundColor Cyan
	$KB4019276_2008SP2 = If ((Get-HotFix -Id KB4019276 -ErrorAction SilentlyContinue) -ne $Null) {$True} Else {$False}
}
If ($OSInfo.OS -eq "2008" -and $OSInfo.SP -ge 2 -and $KB4019276_2008SP2 -eq $True) {
	Write-Host
	Write-Host "TLS 1.1 / TLS 1.2 Supported - KB4019276 Installed" -ForegroundColor Green
} ElseIf ($OSInfo.OS -eq "2008" -and $OSInfo.SP -ge 2 -and $KB4019276_2008SP2 -eq $False) {
	Write-Host
	Write-Host "TLS 1.1 / TLS 1.2 Not Currently Supported - KB4019276 Missing" -ForegroundColor Yellow
} ElseIf ($OSInfo.OS -eq "2008" -and $OSInfo.SP -lt 2) {
	Write-Host
	Write-Host "Cannot Support TLS 1.1 / TLS 1.2" -ForegroundColor Yellow -BackgroundColor DarkRed
}
# ----------------------------------------------------------------------------
# Windows 2008 R2
# Looks for KB3080079 that adds TLS 1.1/1.2 support to RDP in Windows 2008 SP1
# TLS 1.1/1.2 support for RDP is not possible in Windows 2008 R2 RTM
$KB3080079_2008R2SP1 = $False
If ($OSInfo.OS -eq "2008R2" -and $OSInfo.SP -ge 1) {
	Write-Host "Windows 2008 R2 - Scanning for KB3080079 ..." -ForegroundColor Cyan
	$KB3080079_2008R2SP1 = If ((Get-HotFix -Id KB3080079 -ErrorAction SilentlyContinue) -ne $Null) {$True} Else {$False}
}
If ($OSInfo.OS -eq "2008R2" -and $OSInfo.SP -ge 1 -and $KB3080079_2008R2SP1 -eq $True) {
	Write-Host
	Write-Host "TLS 1.1 / TLS 1.2 for RDP Supported - KB3080079 Installed" -ForegroundColor Green
} ElseIf ($OSInfo.OS -eq "2008R2" -and $OSInfo.SP -ge 1 -and $KB3080079_2008R2SP1 -eq $False) {
	Write-Host
	Write-Host "TLS 1.1 / TLS 1.2 for RDP Not Currently Supported - KB3080079 Missing" -ForegroundColor Yellow
} ElseIf ($OSInfo.OS -eq "2008R2" -and $OSInfo.SP -lt 1) {
	Write-Host
	Write-Host "Cannot Support TLS 1.1 / TLS 1.2 for RDP" -ForegroundColor Yellow -BackgroundColor DarkRed
	Write-Host "Without Installation of SP1 and KB3080079" -ForegroundColor Yellow -BackgroundColor DarkRed
	Write-Host "DO NOT DISABLE TLS 1.0 WITHOUT THESE" -ForegroundColor Yellow -BackgroundColor DarkRed
}
