﻿function Get-MultiserverInfo {
[CmdletBinding(SupportsPaging = $true)]
    param (
[Parameter(Mandatory=$true,
    ValueFromPipeline=$true)]
        [string]$Inputpath,
[Parameter(Mandatory=$true,
    ValueFromPipeline=$true)]		
        [string]$Outputpath
        )
#$cred = Get-Credential -Message "Enter your -A USERNAME"
$out=@()
$Servers = GC "$Inputpath" # Change location where you have the server list saved.
$ErrorActionPreference = 'Stop'
foreach($server in $Servers){
$out+= Try{Invoke-Command -ComputerName $Server -Scriptblock {
Write-Progress -Activity “Gathering Server Information”
$computerName = (Get-wmiobject win32_operatingsystem).pscomputername
$ComputerOS = (Get-WmiObject -class Win32_OperatingSystem).Caption
$computerRAM = Get-CimInstance Win32_PhysicalMemory | Measure-Object -Property capacity -Sum | Foreach {"{0:N0}" -f ([math]::round(($_.Sum / 1GB),2))}
$computerCPU = ((get-wmiobject Win32_Processor).NumberOfLogicalProcessors).count
$ComputerIP = (Get-NetIPConfiguration).ipv4address.ipaddress
$Cdrive = ((Get-WmiObject -Class Win32_logicaldisk -Filter "DeviceID = 'C:'").size/1gb).ToString('#.#') +' GB'
$Ddrive = ((Get-WmiObject -Class Win32_logicaldisk -Filter "DeviceID = 'D:'").size/1gb).ToString('#.#') +' GB'
$Edrive = ((Get-WmiObject -Class Win32_logicaldisk -Filter "DeviceID = 'E:'").size/1gb).ToString('#.#') +' GB'
$Fdrive = ((Get-WmiObject -Class Win32_logicaldisk -Filter "DeviceID = 'F:'").size/1gb).ToString('#.#') +' GB'
$Gdrive = ((Get-WmiObject -Class Win32_logicaldisk -Filter "DeviceID = 'G:'").size/1gb).ToString('#.#') +' GB'

[PScustomObject]@{ ServerName = "$computerName"
   OperatingSystem = "$ComputerOS"
   CPU = "$computerCPU" + " " + "CPU"
   Memory = "$computerRAM" + " " + "GB"
   C_Drive = "$Cdrive"
   D_Drive = "$Ddrive"
   E_Drive = "$Edrive"
   F_Drive = "$Fdrive"
   G_Drive = "$Gdrive"
   IPv4Address ="$ComputerIP"

}}} #-Authentication Kerberos -Credential $cred}
Catch {$computerName = Write-Host $($Server.Servername) "Access Denied through script" -ForegroundColor Red }}
$out | Export-Csv "$Outputpath" -NoTypeInformation
$out | FT -AutoSize
Write-Host "Please find the Serverinfo file in Path $Outputpath" -ForegroundColor Yellow -BackgroundColor Black
}
