<#
This script helps you get the VPC flow loags by entering the Instace IP
#>
$profile = "XACCProd" # Enter the AWS profile that you want to use.
$AccountId = '296007370337' # application workload account ID
aws-azure-login --profile $profile

Write-Host "Logging into xacc $profile" -ForegroundColor Green
	$env:AWS_ACCESS_KEY_ID = "$(aws configure get aws_access_key_id --profile $profile)"
	$env:AWS_SECRET_ACCESS_KEY = "$(aws configure get profile."$profile".aws_secret_access_key)"
	$env:AWS_SESSION_TOKEN = "$(aws configure get profile."$profile".aws_session_token)"
	$j = aws sts assume-role --role-arn arn:aws:iam::"$($AccountId)":role/FirstAm_infrastructure-reader --role-session-name test1 --output json --no-verify-ssl
	$env:AWS_ACCESS_KEY_ID = "$(($j | ConvertFrom-Json).Credentials.AccessKeyId)"
	$env:AWS_SECRET_ACCESS_KEY = "$(($j | ConvertFrom-Json).Credentials.SecretAccessKey)"
	$env:AWS_SESSION_TOKEN = "$(($j | ConvertFrom-Json).Credentials.SessionToken)"
	$WA = (aws iam list-account-aliases --no-verify-ssl | ConvertFrom-Json).AccountAliases
    Write-Host "Logged into AWS APP Account : $WA" -ForegroundColor Green
# enter the Instance IP
$Env:AWS_DEFAULT_REGION="us-west-2"
$InstanceNIC = (aws ec2 describe-network-interfaces --no-verify-ssl | ConvertFrom-Json).NetworkInterfaces | ?{$_.PrivateIpAddress -eq '10.77.44.50'}
$NetworkInterfaceId = "$($InstanceNIC.NetworkInterfaceId)"
$SubnetId = $InstanceNIC.SubnetId
$subnet = (aws ec2 describe-subnets --no-verify-ssl|ConvertFrom-Json).subnets | ?{$_.SubnetId -eq "$($SubnetId)"}
$subnetOwnerID = $subnet.OwnerId
Write-Host "Owner ID : $subnetOwnerID" -ForegroundColor Green
Write-Host "Post login select reader role" -ForegroundColor Red
aws-azure-login --profile $profile
	Write-Host "Logging into xacc $profile" -ForegroundColor Green
	
	$env:AWS_ACCESS_KEY_ID = "$(aws configure get aws_access_key_id --profile $profile)"
	$env:AWS_SECRET_ACCESS_KEY = "$(aws configure get profile."$profile".aws_secret_access_key)"
	$env:AWS_SESSION_TOKEN = "$(aws configure get profile."$profile".aws_session_token)"
$j = aws sts assume-role --role-arn arn:aws:iam::"$($subnetOwnerID)":role/FirstAm_infrastructure-reader --role-session-name test2 --output json
	$env:AWS_ACCESS_KEY_ID = "$(($j | ConvertFrom-Json).Credentials.AccessKeyId)"
	$env:AWS_SECRET_ACCESS_KEY = "$(($j | ConvertFrom-Json).Credentials.SecretAccessKey)"
	$env:AWS_SESSION_TOKEN = "$(($j | ConvertFrom-Json).Credentials.SessionToken)"
    $WA = (aws iam list-account-aliases --no-verify-ssl | ConvertFrom-Json).AccountAliases
    Write-Host "Logged into AWS BU Account : $WA" -ForegroundColor Green
$vpcid = "$($subnet.VpcId)"
$flowlogID = ((aws ec2 describe-flow-logs --no-verify-ssl |ConvertFrom-Json).FlowLogs | ? {$_.ResourceId -eq "$vpcid"}).FlowLogId
$LogGroupName = (aws ec2 describe-flow-logs --flow-log-ids $flowlogID --no-verify-ssl |ConvertFrom-Json).FlowLogs.LogGroupName
$logStreamName = ((aws logs describe-log-streams --log-group-name $LogGroupName --no-verify-ssl |ConvertFrom-Json).logStreams | ?{$_.logStreamName -eq "$eni"}).logStreamName
$CSV = (aws logs get-log-events --log-group-name $LogGroupName --log-stream-name $logStreamName --no-verify-ssl |ConvertFrom-Json).events
$eni = "$NetworkInterfaceId" + "-all"
$CSV | Export-Csv -Path $env:USERPROFILE\Desktop\"$eni".csv

start "$env:USERPROFILE\desktop\"$eni".csv"