<#
.Title - Get-Multipleserver-Uptime.ps1

.Version - v1
	Major Versions will start with whole numbers.
	Minor tweaks will be .number.
	Example: 
	V1 (Major releases)
	Or
	V1.1 (minor releases)

.Description - The below script will grab uptime for multiple servers.  This script will work great and will not give an RPC error.
	Example:  This script is to automate the VM build process.

.Notes - You can edit the below and edit the server names and replace them with valid servernames.

.Author - Tuan Pham - 7/20/2021

.Example- You can copy all the below and and just run it in PowerShell.  You need to ensure that you are running this from a jumpbox or with "-a" account.
	Example:
	 ./Get-Multipleserver-Uptime.ps1

#>



$servers = "AWSVPPFRFSHQP01","AWSVPPFRFSHQP05","AWSVPPFRFSHQP07"
$currentdate = Get-Date
foreach($server in $servers){
$Bootuptime = (Get-CimInstance -ClassName Win32_OperatingSystem -ComputerName $server).LastBootUpTime
   $uptime = $currentdate - $Bootuptime
   Write-Output "$server Uptime : $($uptime.Days) Days, $($uptime.Hours) Hours, $($uptime.Minutes) Minutes"
}