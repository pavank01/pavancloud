<#
.DESCRIPTION
   This script help you to login to the aws workload account. you need to copy this to your "C:\Users\username\Documents\PowerShell\Modules\AWS-Connect", by default the script logs you in to us-west-2 loaction.
   you need to append the below config to your aws configuration file.
   -----------------------------------------------------------------------------------------------------------
   [profile xaccs]
region=us-west-2
azure_tenant_id=4cc65fd6-9c76-4871-a542-eb12a5a7800c
azure_app_id_uri=https://signin.aws.amazon.com/saml/aws-xacc-s-0
azure_default_role_arn=arn:aws:iam::452625104604:role/CAVM/IAM_FirstamSuperPDSInteractiveAccessRole
azure_default_duration_hours=8
azure_default_username=shkrishnan@firstam.com

[profile XACCNonProd]
region=us-west-2
azure_tenant_id=4cc65fd6-9c76-4871-a542-eb12a5a7800c
azure_app_id_uri=https://signin.aws.amazon.com/saml/aws-xacc-n-0
azure_default_role_arn=arn:aws:iam::014345246069:role/CAVM/IAM_FirstamSuperPDSInteractiveAccessRole
azure_default_duration_hours=8
azure_default_username=shkrishnan@firstam.com

[profile XACCProd]
region=us-west-2
azure_tenant_id=4cc65fd6-9c76-4871-a542-eb12a5a7800c
azure_app_id_uri=https://signin.aws.amazon.com/saml/aws-xacc-p-0
azure_default_role_arn=arn:aws:iam::207790399741:role/CAVM/IAM_FirstamSuperPDSInteractiveAccessRole
azure_default_duration_hours=8
azure_default_username=shkrishnan@firstam.com

[profile XACCReader]
region=us-west-2
azure_tenant_id=4cc65fd6-9c76-4871-a542-eb12a5a7800c
azure_app_id_uri=https://signin.aws.amazon.com/saml/aws-xacc-p-0
azure_default_role_arn=arn:aws:iam::014345246069:role/CAVM/FirstAm_infrastructure-reader
azure_default_duration_hours=8
azure_default_username=shkrishnan@firstam.com

[profile xaccpr]
region=us-west-2
azure_tenant_id=4cc65fd6-9c76-4871-a542-eb12a5a7800c
azure_app_id_uri=https://signin.aws.amazon.com/saml/aws-xacc-p-0
azure_default_role_arn=arn:aws:iam::207790399741:role/CAVM/FirstAm_infrastructure-reader
azure_default_duration_hours=8
azure_default_username=shkrishnan@firstam.com

[profile AVMprogrammatic]
azure_tenant_id=4cc65fd6-9c76-4871-a542-eb12a5a7800c
azure_app_id_uri=https://signin.aws.amazon.com/saml/AWS-AWSI-P-0
azure_default_username=prod-sa-ceng@firstam.com
azure_default_role_arn=arn:aws:iam::207790399741:role/CAVM/AVM_programmatic
azure_default_duration_hours=8
azure_default_remember_me=false
region=us-west-2
output=json
cli_pager=

[profile NonProdAVMprogrammatic]
azure_tenant_id=4cc65fd6-9c76-4871-a542-eb12a5a7800c
azure_app_id_uri=https://signin.aws.amazon.com/saml/AWS-AWSI-N-1
azure_default_username=prod-sa-ceng@firstam.com
azure_default_role_arn=arn:aws:iam::384082364908:role/CAVM/AVM_programmatic
azure_default_duration_hours=8
azure_default_remember_me=false
region=us-west-2
output=json
----------------------------------------------------------------------------------------------
.EXAMPLE
   AWS-Connect -Profile XACCProd -AccountId 422373810717 
.EXAMPLE
   AWS-Connect -Profile XACCProd -AccountId 422373810717 -Region us-east-2
#>
function AWS-Connect
{
    [CmdletBinding()]
    Param
    (
        # Param1 help description
        [Parameter(Mandatory=$true, 
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true, 
                   ValueFromRemainingArguments=$false, 
                   Position=0
                   )]
        [ValidateNotNullOrEmpty()]
        [ValidateSet("XACCProd", "XACCNonProd", "XACCReader", "AVMProgrammatic")]
        [Alias("P")] 
        $Profile,

        # Param2 help description
        $AccountId,
	# Param2 help description
        $Region = "us-west-2"

    )

    
    Process
    {
        aws-azure-login --profile $profile

$Env:AWS_DEFAULT_REGION="$Region"

switch ( $profile )
{
    XACCNonProd { 
	Write-Host "Logging into xacc Non-Production role" -ForegroundColor Green
	$env:AWS_ACCESS_KEY_ID = "$(aws configure get aws_access_key_id --profile $profile)"
	$env:AWS_SECRET_ACCESS_KEY = "$(aws configure get profile."$profile".aws_secret_access_key)"
	$env:AWS_SESSION_TOKEN = "$(aws configure get profile."$profile".aws_session_token)"
	$j = aws sts assume-role --role-arn arn:aws:iam::"$($AccountId)":role/FirstAm_super-pds --role-session-name test1 --output json --no-verify-ssl
	$env:AWS_ACCESS_KEY_ID = "$(($j | ConvertFrom-Json).Credentials.AccessKeyId)"
	$env:AWS_SECRET_ACCESS_KEY = "$(($j | ConvertFrom-Json).Credentials.SecretAccessKey)"
	$env:AWS_SESSION_TOKEN = "$(($j | ConvertFrom-Json).Credentials.SessionToken)"
	aws iam list-account-aliases --no-verify-ssl
    	}
    XACCProd { 
	Write-Host "Logging into xacc Production role" -ForegroundColor Green
	$env:AWS_ACCESS_KEY_ID = "$(aws configure get aws_access_key_id --profile $profile)"
	$env:AWS_SECRET_ACCESS_KEY = "$(aws configure get profile."$profile".aws_secret_access_key)"
	$env:AWS_SESSION_TOKEN = "$(aws configure get profile."$profile".aws_session_token)"  
	$j = aws sts assume-role --role-arn arn:aws:iam::"$($AccountId)":role/FirstAm_super-pds --role-session-name test1 --output json --no-verify-ssl
	$env:AWS_ACCESS_KEY_ID = "$(($j | ConvertFrom-Json).Credentials.AccessKeyId)"
	$env:AWS_SECRET_ACCESS_KEY = "$(($j | ConvertFrom-Json).Credentials.SecretAccessKey)"
	$env:AWS_SESSION_TOKEN = "$(($j | ConvertFrom-Json).Credentials.SessionToken)"
	aws iam list-account-aliases --no-verify-ssl
    	}
    XACCReader { 
	Write-Host "Logging into xaccn reader role" -ForegroundColor Green
	$env:AWS_ACCESS_KEY_ID = "$(aws configure get aws_access_key_id --profile $profile)"
	$env:AWS_SECRET_ACCESS_KEY = "$(aws configure get profile."$profile".aws_secret_access_key)"
	$env:AWS_SESSION_TOKEN = "$(aws configure get profile."$profile".aws_session_token)"
	$j = aws sts assume-role --role-arn arn:aws:iam::"$($AccountId)":role/FirstAm_infrastructure-reader --role-session-name test1 --output json --no-verify-ssl
	$env:AWS_ACCESS_KEY_ID = "$(($j | ConvertFrom-Json).Credentials.AccessKeyId)"
	$env:AWS_SECRET_ACCESS_KEY = "$(($j | ConvertFrom-Json).Credentials.SecretAccessKey)"
	$env:AWS_SESSION_TOKEN = "$(($j | ConvertFrom-Json).Credentials.SessionToken)"
	aws iam list-account-aliases --no-verify-ssl
   	}
    
AVMprogrammatic { 
	Write-Host "Logging into AVM-programmatic" -ForegroundColor Green
	$env:AWS_ACCESS_KEY_ID = "$(aws configure get aws_access_key_id --profile $profile)"
	$env:AWS_SECRET_ACCESS_KEY = "$(aws configure get profile."$profile".aws_secret_access_key)"
	$env:AWS_SESSION_TOKEN = "$(aws configure get profile."$profile".aws_session_token)"
	$j = aws sts assume-role --role-arn arn:aws:iam::"$($AccountId)":role/FirstAm_infrastructure-reader --role-session-name test1 --output json --no-verify-ssl
	$env:AWS_ACCESS_KEY_ID = "$(($j | ConvertFrom-Json).Credentials.AccessKeyId)"
	$env:AWS_SECRET_ACCESS_KEY = "$(($j | ConvertFrom-Json).Credentials.SecretAccessKey)"
	$env:AWS_SESSION_TOKEN = "$(($j | ConvertFrom-Json).Credentials.SessionToken)"
	aws iam list-account-aliases --no-verify-ssl
 	}
}

    }
   
}