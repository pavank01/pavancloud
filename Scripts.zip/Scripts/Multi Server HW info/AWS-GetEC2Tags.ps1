
$profile = "XACCProd" # XACCProd XACCNonProd Enter the AWS profile that you want to use.
$AccountId = '392304447609' # application workload account ID
$Env:AWS_DEFAULT_REGION= "us-west-2"

aws-azure-login --profile $profile

Write-Host "Logging into xacc Non-Production role" -ForegroundColor Green
	$env:AWS_ACCESS_KEY_ID = "$(aws configure get aws_access_key_id --profile $profile)"
	$env:AWS_SECRET_ACCESS_KEY = "$(aws configure get profile."$profile".aws_secret_access_key)"
	$env:AWS_SESSION_TOKEN = "$(aws configure get profile."$profile".aws_session_token)"
	$j = aws sts assume-role --role-arn arn:aws:iam::"$($AccountId)":role/FirstAm_super-pds --role-session-name test1 --output json --no-verify-ssl
	$env:AWS_ACCESS_KEY_ID = "$(($j | ConvertFrom-Json).Credentials.AccessKeyId)"
	$env:AWS_SECRET_ACCESS_KEY = "$(($j | ConvertFrom-Json).Credentials.SecretAccessKey)"
	$env:AWS_SESSION_TOKEN = "$(($j | ConvertFrom-Json).Credentials.SessionToken)"
	aws iam list-account-aliases --no-verify-ssl


$test = (aws ec2 describe-instances --no-verify-ssl | ConvertFrom-Json).Reservations.Instances | select tags
$test | %{
[PScustomObject]@{ 
ServerName = ($_.tags | ?{$_.key -eq 'Name'}).Value
ApplicationName = ($_.tags | ?{$_.key -eq 'ApplicationName'}).Value
ApplicationServiceNumber = ($_.tags | ?{$_.key -eq 'ApplicationServiceNumber'}).Value
BusinessApplicationNumber = ($_.tags | ?{$_.key -eq 'BusinessApplicationNumber'}).Value
}
}