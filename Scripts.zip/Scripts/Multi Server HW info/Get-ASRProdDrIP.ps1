$Subscription = 'AZUR-P-AzureSub-1' # Enter the Subscription name
$RecoveryVaultName = 'AZUR-P-1-RITA-RS-11' # Enter the Vault name eg : essp-p-1-clas-rs-11
$ResourceGroupName = 'AZUR-P-1-RITA-RG-11' # Enter the resource group name
<#-------------------------------------------------------------------------------------------------#>
Set-AzContext -Subscription $Subscription
$Vaults = Get-AzRecoveryServicesVault -Name $RecoveryVaultName -ResourceGroupName $ResourceGroupName
Set-AzRecoveryServicesAsrVaultContext -Vault $Vaults
$Fabrics = Get-AzRecoveryServicesAsrFabric -Name asr-a2a-default-westus2
$drContainers = Get-AzRecoveryServicesAsrProtectionContainer -Fabric $Fabrics
$Obj = @()
$count = ((Get-AzRecoveryServicesAsrReplicationProtectedItem -ProtectionContainer $drContainers).FriendlyName).count
For ($i=0; $i -le $count; $i++) {
  $s = (Get-AzRecoveryServicesAsrReplicationProtectedItem -ProtectionContainer $drContainers)[$i]
  $Obj += [PScustomObject]@{ 
	ServerName 		= "$($s.FriendlyName)"
	PrimaryLoaction		= "$($s.PrimaryFabricFriendlyName)"
   	PrimaryIPAddress 	= "$($s.NicDetailsList.ipconfigs.StaticIPAddress)"
   	IpType 		= "$($s.NicDetailsList.ipconfigs.IpAddressType)"
	RecoveryLocation	= "$($s.RecoveryFabricFriendlyName)"
   	RecoveryIPAddress = "$($s.NicDetailsList.ipconfigs.RecoveryStaticIPAddress)"
   	RecoveryIPType 	= "$($s.NicDetailsList.ipconfigs.RecoveryIPAddressType)"
}
    }
$Obj | FT -AutoSize