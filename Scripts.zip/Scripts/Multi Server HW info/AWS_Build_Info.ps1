
$profile = Read-Host -Prompt "Enter your aws login profile name eg: XACCProd"
$AccountId = Read-Host -Prompt "Enter your aws app workload account ID eg: 049841759639" 
$REGION = Read-Host -Prompt "Enter the region you want to buid eg: us-west-2, us-east-2"
    aws-azure-login --profile $profile

Write-Host "Logging into $profile" -ForegroundColor Green
	$env:AWS_ACCESS_KEY_ID = "$(aws configure get aws_access_key_id --profile $profile)"
	$env:AWS_SECRET_ACCESS_KEY = "$(aws configure get profile."$profile".aws_secret_access_key)"
	$env:AWS_SESSION_TOKEN = "$(aws configure get profile."$profile".aws_session_token)"
	$j = aws sts assume-role --role-arn arn:aws:iam::"$($AccountId)":role/FirstAm_super-pds --role-session-name test1 --output json --no-verify-ssl
	$env:AWS_ACCESS_KEY_ID = "$(($j | ConvertFrom-Json).Credentials.AccessKeyId)"
	$env:AWS_SECRET_ACCESS_KEY = "$(($j | ConvertFrom-Json).Credentials.SecretAccessKey)"
	$env:AWS_SESSION_TOKEN = "$(($j | ConvertFrom-Json).Credentials.SessionToken)"
	$accountName = (aws iam list-account-aliases --no-verify-ssl | ConvertFrom-Json).AccountAliases
Write-Host "Logged into $accountName" -ForegroundColor Green

# Get Instance names
    $Env:AWS_DEFAULT_REGION="$REGION"
Write-host "----------------------"
Write-host "EC2 Instances on $REGION" -ForegroundColor Green
Write-host "----------------------"
    $WarningPreference = 'SilentlyContinue'
(aws ec2 describe-instances --no-verify-ssl | ConvertFrom-Json ).Reservations.Instances.Tags.value | ? {$_ -like "AWSV*"}
(aws ec2 describe-subnets --no-verify-ssl|ConvertFrom-Json).subnets | select VpcId,SubnetId,CidrBlock,AvailabilityZone,OwnerId | ft -AutoSize
