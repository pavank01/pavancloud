<#
AAD-AWS-Firstam_super-pds = '4505c9a1-a02e-4d6e-9d8a-d8186933fb28'
AWS-XACC-P-0/IAM_FirstamSuperPDSInteractiveAccessRole = '7203823f-5c31-4e6d-ad4b-76117957f2b5'
AWS-XACC-N-0/IAM_FirstamSuperPDSInteractiveAccessRole = '65819aa3-b5ed-4ee6-b6f0-c92167f091d0'
AWS-XACC-P-0/IAM_FirstamSuperCloudOpsAccessRole = '11d26caf-2162-4fc7-bf8b-3f25cea3c200'
AWS-XACC-N-0/IAM_FirstamSuperCloudOpsAccessRole = '79f1df25-8e37-4ee9-9071-dcca0b6c40e6'
AWS-XACC-S-0/IAM_FirstamSuperCloudOpsAccessRole = 'c2e4ff51-714b-4743-a868-0f43a23a0ba6'
#>
$Username = 'shkrishnan@firstam.com'
$password = gc "C:\Users\shkrishnan\Desktop\ASR_Report_test_files\recovery.txt" | ConvertTo-SecureString
$Cred1 = New-Object System.Management.Automation.PSCredential -ArgumentList $Username, $password
 
Connect-AzureAD -Credential $Cred1

$groupId = '7203823f-5c31-4e6d-ad4b-76117957f2b5','65819aa3-b5ed-4ee6-b6f0-c92167f091d0','11d26caf-2162-4fc7-bf8b-3f25cea3c200','79f1df25-8e37-4ee9-9071-dcca0b6c40e6','c2e4ff51-714b-4743-a868-0f43a23a0ba6','a5a2e3a2-da3a-4974-8b93-6553312e04eb'
$upn="shkrishnan@firstam.com"
$groupId.ForEach({
$resource = Get-AzureADMSPrivilegedResource -ProviderId aadGroups
$subject = Get-AzureADUser -Filter "userPrincipalName eq '$upn'"
$id = $_
$roleDefinitionCollection = Get-AzureADMSPrivilegedRoleDefinition -ProviderId "aadGroups" -ResourceId $id |?{$_.DisplayName -eq "Member"}
$reason = "test"
foreach ($roleDefinition in $roleDefinitionCollection) {
$schedule = $NULL
    $schedule = New-Object Microsoft.Open.MSGraph.Model.AzureADMSPrivilegedSchedule
    $schedule.Type = "Once"
    $schedule.Duration="PT8H"
    $schedule.StartDateTime = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ")
    Open-AzureADMSPrivilegedRoleAssignmentRequest -ProviderId "aadGroups" -Schedule $schedule -ResourceId $id -RoleDefinitionId $roleDefinition.id -SubjectId $subject.ObjectId -AssignmentState "Active" -Type "UserAdd" -Reason $reason
}

})