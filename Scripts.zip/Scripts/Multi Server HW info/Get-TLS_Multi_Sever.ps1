﻿function Get-TLS_MUltiple_Server {
[CmdletBinding(SupportsPaging = $true)]
    param (
[Parameter(Mandatory=$true,
    ValueFromPipeline=$true)]
        [string]$Inputpath,
        [string]$Outputpath
        )


$out=@()
$Servers = Import-Csv -Path "$Inputpath"
$ErrorActionPreference = 'Stop'
foreach($server in $Servers){
$out+= Try{
Invoke-Command -ComputerName $Server.Servername -ScriptBlock {
$SChannel = "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL" 
$TLS10Server = Get-ItemProperty -Path "$($SChannel)\Protocols\TLS 1.0\Server" -Name Enabled -ErrorAction SilentlyContinue
$TLS10Client = Get-ItemProperty -Path "$($SChannel)\Protocols\TLS 1.0\Client" -Name Enabled -ErrorAction SilentlyContinue
$TLS11Server = Get-ItemProperty -Path "$($SChannel)\Protocols\TLS 1.1\Server" -Name Enabled -ErrorAction SilentlyContinue
$TLS11Client = get-ItemProperty -Path "$($SChannel)\Protocols\TLS 1.1\Client" -Name Enabled -ErrorAction SilentlyContinue
$TLS12Server = get-ItemProperty -Path "$($SChannel)\Protocols\TLS 1.2\Server" -Name Enabled -ErrorAction SilentlyContinue
$TLS12Client = get-ItemProperty -Path "$($SChannel)\Protocols\TLS 1.2\Client" -Name Enabled -ErrorAction SilentlyContinue
$TLS20Server = get-ItemProperty -Path "$($SChannel)\Protocols\TLS 2.0\Server" -Name Enabled -ErrorAction SilentlyContinue
$TLS20Client = get-ItemProperty -Path "$($SChannel)\Protocols\TLS 2.0\Client" -Name Enabled -ErrorAction SilentlyContinue
$PCT10Server = get-ItemProperty -Path "$($SChannel)\Protocols\PCT 1.0\Server" -Name Enabled -ErrorAction SilentlyContinue
$PCT10Client = get-ItemProperty -Path "$($SChannel)\Protocols\PCT 1.0\Client" -Name Enabled -ErrorAction SilentlyContinue
$UHServer = get-ItemProperty -Path "$($SChannel)\Protocols\Multi-Protocol Unified Hello\Server" -Name Enabled -ErrorAction SilentlyContinue
$UHClient = get-ItemProperty -Path "$($SChannel)\Protocols\Multi-Protocol Unified Hello\Client" -Name Enabled -ErrorAction SilentlyContinue
$HASHMD5 = get-ItemProperty -Path "$($SChannel)\Hashes\MD5" -Name Enabled -ErrorAction SilentlyContinue
$HASHSHA = get-ItemProperty -Path "$($SChannel)\Hashes\SHA" -Name Enabled -ErrorAction SilentlyContinue
$HASHSHA256 = get-ItemProperty -Path "$($SChannel)\Hashes\SHA256" -Name Enabled -ErrorAction SilentlyContinue
$HASHSHA384 = get-ItemProperty -Path "$($SChannel)\Hashes\SHA384" -Name Enabled -ErrorAction SilentlyContinue
$HASHSHA512 = get-ItemProperty -Path "$($SChannel)\Hashes\SHA512" -Name Enabled -ErrorAction SilentlyContinue
$ALDiffieHellman = get-ItemProperty -Path "$($SChannel)\KeyExchangeAlgorithms\Diffie-Hellman" -Name Enabled -ErrorAction SilentlyContinue
$ALPKCS = get-ItemProperty -Path "$($SChannel)\KeyExchangeAlgorithms\PKCS" -Name Enabled -ErrorAction SilentlyContinue
$ALECDH = get-ItemProperty -Path "$($SChannel)\KeyExchangeAlgorithms\ECDH" -Name Enabled -ErrorAction SilentlyContinue
$CipherNull = get-ItemProperty -Path "$($SChannel)\Ciphers\NULL" -Name Enabled -ErrorAction SilentlyContinue
$CipherASE128 = get-ItemProperty -Path "$($SChannel)\Ciphers\AES 128/128" -Name Enabled -ErrorAction SilentlyContinue
$CipherASE256 = get-ItemProperty -Path "$($SChannel)\Ciphers\AES 256/256" -Name Enabled -ErrorAction SilentlyContinue
$CipherDES5656 = get-ItemProperty -Path "$($SChannel)\Ciphers\DES 56/56" -Name Enabled -ErrorAction SilentlyContinue
$CipherRC2128 = get-ItemProperty -Path "$($SChannel)\Ciphers\RC2 128" -Name Enabled -ErrorAction SilentlyContinue
$CipherRC240128 = get-ItemProperty -Path "$($SChannel)\Ciphers\RC2 40/128" -Name Enabled -ErrorAction SilentlyContinue
$CipherRC256128 = get-ItemProperty -Path "$($SChannel)\Ciphers\RC2 56/128" -Name Enabled -ErrorAction SilentlyContinue
$CipherRC4128128 = get-ItemProperty -Path "$($SChannel)\Ciphers\RC4 128/128" -Name Enabled -ErrorAction SilentlyContinue
$CipherRC440128 = get-ItemProperty -Path "$($SChannel)\Ciphers\RC4 40/128" -Name Enabled -ErrorAction SilentlyContinue
$CipherRC456128 = get-ItemProperty -Path "$($SChannel)\Ciphers\RC4 56/128" -Name Enabled -ErrorAction SilentlyContinue
$CipherRC464128 = get-ItemProperty -Path "$($SChannel)\Ciphers\RC4 64/128" -Name Enabled -ErrorAction SilentlyContinue
$CipherTDES168 = get-ItemProperty -Path "$($SChannel)\Ciphers\Triple DES 168" -Name Enabled -ErrorAction SilentlyContinue


$serverName = (Get-wmiobject win32_operatingsystem).pscomputername
$TLS10S = If((Test-Path "$($SChannel)\Protocols\TLS 1.0\Server") -and ($TLS10Server.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$TLS10C = If((Test-Path "$($SChannel)\Protocols\TLS 1.0\Client") -and ($TLS10Client.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$TLS11S = If((Test-Path "$($SChannel)\Protocols\TLS 1.1\Server") -and ($TLS11Server.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$TLS11C = If((Test-Path "$($SChannel)\Protocols\TLS 1.1\Client") -and ($TLS11Client.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$TLS12S = If((Test-Path "$($SChannel)\Protocols\TLS 1.2\Server") -and ($TLS12Server.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$TLS12C = If((Test-Path "$($SChannel)\Protocols\TLS 1.2\Client") -and ($TLS12Client.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$TLS20S = If((Test-Path "$($SChannel)\Protocols\TLS 2.0\Server") -and ($TLS20Server.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$TLS20C = If((Test-Path "$($SChannel)\Protocols\TLS 2.0\Client") -and ($TLS20Client.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$PCT10S = If((Test-Path "$($SChannel)\Protocols\TLS 2.0\Server") -and ($PCT10Server.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$PCT10C = If((Test-Path "$($SChannel)\Protocols\TLS 2.0\Client") -and ($PCT10Client.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$UHS = If((Test-Path "$($SChannel)\Protocols\Multi-Protocol Unified Hello\Server") -and ($PCT10Server.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$UHC = If((Test-Path "$($SChannel)\Protocols\Multi-Protocol Unified Hello\Client") -and ($PCT10Client.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$MD5 = If((Test-Path "$($SChannel)\Hashes\MD5") -and ($HASHMD5.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$SHA = If((Test-Path "$($SChannel)\Hashes\SHA") -and ($HASHSHA.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$SHA256 = If((Test-Path "$($SChannel)\Hashes\SHA256") -and ($HASHSHA256.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$SHA384 = If((Test-Path "$($SChannel)\Hashes\SHA384") -and ($HASHSHA384.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$SHA512 = If((Test-Path "$($SChannel)\Hashes\SHA512") -and ($HASHSHA512.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$ALGDHellman = If((Test-Path "$($SChannel)\KeyExchangeAlgorithms\Diffie-Hellman") -and ($ALDiffieHellman.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$ALGPKCS = If((Test-Path "$($SChannel)\KeyExchangeAlgorithms\PKCS") -and ($ALPKCS.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$ALGECDH = If((Test-Path "$($SChannel)\KeyExchangeAlgorithms\ECDH") -and ($ALECDH.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$Ciphernulls = If((Test-Path "$($SChannel)\Ciphers\NULL") -and ($CipherNull.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$CipherASE128s = If((Test-Path "$($SChannel)\Ciphers\AES 128/128") -and ($CipherASE128.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$CipherASE256s = If((Test-Path "$($SChannel)\Ciphers\AES 256/256") -and ($CipherASE256.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$CipherDES5656s = If((Test-Path "$($SChannel)\Ciphers\DES 56/56") -and ($CipherDES5656.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$CipherRC2128s = If((Test-Path "$($SChannel)\Ciphers\RC2 128") -and ($CipherRC2128.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$CipherRC240128s = If((Test-Path "$($SChannel)\Ciphers\RC2 40/128") -and ($CipherRC240128.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$CipherRC256128s = If((Test-Path "$($SChannel)\Ciphers\RC2 56/128") -and ($CipherRC256128.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$CipherRC4128128s = If((Test-Path "$($SChannel)\Ciphers\RC4 128/128") -and ($CipherRC4128128.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$CipherRC440128s = If((Test-Path "$($SChannel)\Ciphers\RC4 40/128") -and ($CipherRC440128.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$CipherRC456128s = If((Test-Path "$($SChannel)\Ciphers\RC4 56/128") -and ($CipherRC456128.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$CipherRC464128s = If((Test-Path "$($SChannel)\Ciphers\RC4 64/128") -and ($CipherRC464128.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
$CipherTDES168s = If((Test-Path "$($SChannel)\Ciphers\Triple DES 168") -and ($CipherTDES168.Enabled -ne 0)){Write-Output "Enabled"} else {Write-Output "Disabled"}
If ($OSInfo.SP -eq 0) {
	$OperatingSystem = "{0} ({1}-bit)" -f $OSInfo.OperatingSystem, $OSInfo.OSArchitecture
} Else {
	$OperatingSystem = "{0} SP{1} ({2}-bit)" -f $OSInfo.OperatingSystem, $OSInfo.SP, $OSInfo.OSArchitecture
}

If ([System.Version]$OSInfo.Version -lt [System.Version]'10.0') {
	$ExpectedCipherSuitesOrder = @(
		'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P521',
		'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P384',
		'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384_P256',
		'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P521',
		'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P384',
		'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256_P256',
		'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P521',
		'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P384',
		'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA_P256',
		'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P521',
		'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P384',
		'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA_P256',
		'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384_P521',
		'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384_P384',
		'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P521',
		'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P384',
		'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256_P256',
		'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384_P521',
		'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384_P384',
		'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P521',
		'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P384',
		'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256_P256',
		'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P521',
		'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P384',
		'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA_P256',
		'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P521',
		'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P384',
		'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA_P256',
		'TLS_RSA_WITH_AES_256_GCM_SHA384',
		'TLS_RSA_WITH_AES_128_GCM_SHA256',
		'TLS_RSA_WITH_AES_256_CBC_SHA256',
		'TLS_RSA_WITH_AES_128_CBC_SHA256',
		'TLS_RSA_WITH_AES_256_CBC_SHA',
		'TLS_RSA_WITH_AES_128_CBC_SHA'
	)
} Else {
	$ExpectedCipherSuitesOrder = @(
		'TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384',
		'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256',
		'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA384',
		'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256',
		'TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA',
		'TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA',
		'TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384',
		'TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256',
		'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA384',
		'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA256',
		'TLS_ECDHE_ECDSA_WITH_AES_256_CBC_SHA',
		'TLS_ECDHE_ECDSA_WITH_AES_128_CBC_SHA',
		'TLS_RSA_WITH_AES_256_GCM_SHA384',
		'TLS_RSA_WITH_AES_128_GCM_SHA256',
		'TLS_RSA_WITH_AES_256_CBC_SHA256',
		'TLS_RSA_WITH_AES_128_CBC_SHA256',
		'TLS_RSA_WITH_AES_256_CBC_SHA',
		'TLS_RSA_WITH_AES_128_CBC_SHA'
	)
}

$CurrentCipherSuitesOrder = @(((Get-ItemProperty 'HKLM:\SOFTWARE\Policies\Microsoft\Cryptography\Configuration\SSL\00010002').PSObject.Properties | Where-Object {$_.Name -notlike "ps*"} | Select-Object Value).Value -Split ",")

If ($CurrentCipherSuitesOrder -ne $Null) {
	$CipherSuitesEqual = @(Compare-Object $ExpectedCipherSuitesOrder $CurrentCipherSuitesOrder -SyncWindow 0).Length -eq 0
	If ($CipherSuitesEqual -ne $True) {
		$CipherOrder = "CORRECT ORDER"
	} Else {
		$CipherOrder = "INCORRECT ORDER"
	}
} Else {
	$CipherOrder = "Default"
}

[PScustomObject][Ordered]@{
'SERVER NAME' ="$serverName" 
'TLS 1.0 SERVER' = "$TLS10S"
'TLS 1.0 CLIENT' = "$TLS10C"
'TLS 1.1 SERVER' = "$TLS11S"
'TLS 1.1 CLIENT' = "$TLS11C"
'TLS 1.2 SERVER' = "$TLS12S"
'TLS 1.2 CLIENT' = "$TLS12C"
'TLS 2.0 SERVER' = "$TLS20S"
'TLS 2.0 CLIENT' = "$TLS20C"
'PCT 1.0 SERVER' = "$PCT10S"
'PCT 1.0 CLIENT' = "$PCT10C"
'Unified Hello server'  = "$UHS"
'Unified Hello Client'  = "$UHC"
'HASH MD5' = "$MD5"
'HASH SHA' = "$SHA"
'HASH SHA256' = "$SHA256"
'HASH SHA384' = "$SHA384"
'HASH SHA512' = "$SHA512"
'Algoritham DHE' = "$ALGDHellman"
'Algoritham PKCS'= "$ALGPKCS"
'Algoritham ECDH'= "$ALGECDH"
'Cipher nulls'          = "$Ciphernulls"
'Cipher ASE 128/128'    = "$CipherASE128s"
'Cipher ASE 256/256'    = "$CipherASE256s"
'Cipher DES 56/56'      = "$CipherDES5656s"
'Cipher RC2 128/128'    = "$CipherRC2128s"
'Cipher RC2 RC2 40/128' = "$CipherRC240128s"
'Cipher RC2 56/128'     = "$CipherRC256128s"
'Cipher RC4 128/128'    = "$CipherRC4128128s"
'Cipher RC4 56/128'     = "$CipherRC456128s"
'Cipher RC4 64/128'     = "$CipherRC464128s"
'Cipher Triple DES 168' = "$CipherTDES168s"
'Cipher Order' = "$CipherOrder"

} }  
} Catch {$computerName = Write-Host $($Server.Servername) "Access Denied\WINRM Error through script" -ForegroundColor Red }
 $out | Export-Csv "$Outputpath" -NoTypeInformation
$out | FL 
Write-Host "Please find the Serverinfo file in Path $Outputpath" -ForegroundColor Yellow -BackgroundColor Black
}}