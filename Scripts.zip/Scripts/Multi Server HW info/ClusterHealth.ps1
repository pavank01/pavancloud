<#Run the below script to check the status of the cluster

Example :PS C:\Users\shkrishnan-a\Desktop> .\Cluster_health.ps1 from the cluster node
Remote Example : Invoke-Command -FilePath .\Cluster_health.ps1 -ComputerName AZUVPSQLCOPO003.corp.firstam.com

#>
Clear-Host
$Cluster = Get-Cluster
$CLIP = (Get-ClusterResource | Where { $_.ResourceType -eq "IP Address" } | Get-ClusterParameter -Name "Address" | Select ClusterObject, Value | Where { $_.ClusterObject -eq "Cluster IP Address"
}).value

Get-ClusterNetworkInterface | Select Node,Address | FT -AutoSize
Get-ClusterResource | Where { $_.ResourceType -eq "IP Address" } | Get-ClusterParameter -Name "Address" | Select ClusterObject, Value | FT -AutoSize

Write-Host "****************************************************************************************" 
Write-Host ""
Write-Host ""
Write-Host "Cluster Name : $($Cluster.name) $CLIP"
Get-WMIObject Win32_Service | Where-Object {$_.name -like "*SQL*" -or  $_.name -like "ClusSvc" } | FT -AutoSize Name,Displayname,Startmode,State,Startname

Get-ClusterResource | Format-Table -AutoSize
#Get-ClusterNode | Select-Object -Property Name,ID,State | Format-Table -AutoSize
Get-ClusterNetworkInterface | Select-Object -Property Name,Network,State | Format-Table -AutoSize
Get-ClusterOwnerNode
$Wintness = (get-clusterresource | where-object {$_.ResourceType -like "File Share Witness"} | get-clusterparameter | ?{$_.Name -like "SharePath"} | 
select -Property @{N="File Witness Path";E={$_.value}}).'File Witness Path'

If($Wintness -like "\\*"){Write-Host "Files Share Witness Path: $Wintness" }
Else{ Write-Host "Files Share Witness Path: Not Configured or unable to connect" }

Write-Host " "

Try { # Get Cluster Group Prefered OwnerStatus
    [Object[]]$clusterGroups = Get-CimInstance -Namespace root/MSCluster -ClassName MSCluster_ResourceGroup  -ErrorAction Stop
    $clusterGroups | %{
        $ItemName = ($_.Name).Replace(" ","_")
        $PreferedOwners = (Invoke-CimMethod -InputObject $_ -MethodName GetPreferredOwners).NodeNames
        if ($PreferedOwners.Count -gt 0) {
            if ($PreferedOwners -contains $_.OwnerNode) {$CheckOutput = $_.Name+' role is running on node '+$_.OwnerNode+'. Preferred Owner is: '+$PreferedOwners }
            else {$status = 1; $CheckOutput = 'WARNING- '+$_.Name+' group is running on node '+$_.OwnerNode+'. Preferred Owner is: '+$PreferedOwners}
            write-output "$CheckOutput" |Out-String
        }
        else {write-output ($_.Name+' group is running on node '+$_.OwnerNode+' and Preferred Owner is not set') |Out-String}
    } #foreach clusternode
} # Try ClusterGroups
Catch {write-output "1 Cluster - WARNING - CIM method for Failover Cluster Preffered Node missing" |Out-String}