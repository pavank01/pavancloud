import-Module .\AWS-Connect.psm1
$awsprofile = @"
[profile Mytest]
region=us-west-2
azure_tenant_id=4cc65fd6-9c76-4871-a542-eb12a5a7800c
azure_app_id_uri=https://signin.aws.amazon.com/saml/aws-xacc-n-0
azure_default_role_arn=arn:aws:iam::276828104209:role/CAVM/FirstAm_super-cloud-ops
azure_default_duration_hours=8
azure_default_username=shkrishnan@firstam.com
"@

If(!(gc "$HOME\.aws\config" | ?{$_ -match 'mytest'})){
    Add-Content "$HOME\.aws\config" $awsprofile
    Write-Host "Adding Temp AWS profile"
    AWS-Connect -Profile 'Mytest' -AccountId (read-host "Enter the workload Account ID")
}else{AWS-Connect -Profile 'Mytest' -AccountId (read-host "Enter the workload Account ID")}

do
{
    try {
    [ValidatePattern('^REQ\d{7}$')]$request = Read-Host "Enter Service First Request Number (REQXXXXXXX)"
    } catch {Write-host "Incorrect entry" -ForegroundColor Red}
} until ($?)
do
{
    try {
    [ValidatePattern('^CHG\d{7}$')]$chanage = read-Host "Enter Service First Change Number (CHGXXXXXXX)" 
    } catch {Write-host "Incorrect entry" -ForegroundColor Red}
} until ($?)
$ApprovedOwner = read-Host "Enter Approved Owner Email"
$WLID = aws sts get-caller-identity --query [Account] --no-verify-ssl| convertfrom-json
$BUAccountID = aws ec2 describe-subnets --query "Subnets[0].[OwnerId]" --no-verify-ssl| convertfrom-json
$WLname = aws iam list-account-aliases --no-verify-ssl --query AccountAliases --no-verify-ssl | convertfrom-json
$WLname = $WLname.ToUpper()
new-item ".\$WLname.md" | out-null
$FileName = ".\$WLname.md"
if(!(Test-Path $FileName)) { Write-host "Creating file $FileName" -ForegroundColor Green}
Add-Content ".\$WLname.md" "*****************************************************"
Add-Content ".\$WLname.md" "Decommissioned account  : $($WLname.ToUpper()) : $WLID"
Add-Content ".\$WLname.md" "Business Unit account   : $BUAccountID"
Add-Content ".\$WLname.md" "Service Frist request   : $request"
Add-Content ".\$WLname.md" "Service Change request  : $chanage"
Add-Content ".\$WLname.md" "Approved Owner          : $ApprovedOwner"
Add-Content ".\$WLname.md" "Account Decom by        : $([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)"
Add-Content ".\$WLname.md" "*****************************************************"
$tags = (aws cloudformation describe-stacks --stack-name awsi-p-1-cavm-network-prereq-role |convertfrom-json).Stacks.Parameters |?{($_.ParameterKey -ne 'AVMAccountID' -and $_.ParameterKey -ne 'NetworkDeployerRoleNameSuffix' -and $_.ParameterKey -ne 'NetworkInspecRoleNameSuffix')} | Out-file -append ".\$WLname.md"
Add-Content ".\$WLname.md" "*****************************************************"
Add-Content ".\$WLname.md" "Deleting cloud formation Stacks"
Add-Content ".\$WLname.md" "*****************************************************"
[hashtable]$Stacks = [ordered]@{
    NetworkDeployMentRole = @("awsi-t-1-cavm-network-prereq-role");
    AVM_VPC_PL_Resources_WL = @("awsi-t-1-cavm-customresource-deletedefaultvpc", "awsi-t-1-cavm-vpc-delete-default-all-regions", "awsi-t-1-cavm-infra-account-roles-$WLAccountID" , "awsi-t-1-cavm-vpc-prereq-roles");
    AVM_IAM_PL_Resources_WL = @("awsi-t-1-cavm-iam-baseline-roles-setup", "awsi-t-1-cavm-iam-managed-policy-setup", "awsi-t-1-cavm-iam-deployment-roles", "awsi-t-1-cavm-iam-custom-roles-setup");
    AVM_Monitor_PL_Resources_WL = @("awsi-t-1-cavm-guard-duty-setup", "awsi-t-1-cavm-guard-duty-lambda", "awsi-t-1-cavm-guardduty-crossaccount-role-$WLAccountID", "awsi-t-1-cavm-config-rule-required-tags", "awsi-t-1-cavm-config-rules", "awsi-t-1-cavm-splunk-cross-account-role", "awsi-t-1-cavm-qualys-connector", "awsi-t-1-cavm-prismacloud", "awsi-t-1-cavm-redlock", "awsi-t-1-cavm-metric-filter-alarm", "awsi-t-1-cavm-s3-access-logging-bucket", "awsi-t-1-cavm-config-child-setup", "awsi-t-1-cavm-cloudtrail-child-setup", "awsi-t-1-cavm-logging-deployment-roles");
    VPC_pipeline_AVM = @("awsi-t-1-cavm-vpc-pipeline-$WLAccountID");
    Monitor_pipeline_AVM = @("awsi-t-1-cavm-monitor-pipeline-$WLAccountID");
    IAM_Pipeline_AVM = @("awsi-t-1-cavm-iam-baseline-pipeline-$WLAccountID");
    Master_pipeline_AVM = @( "awsi-t-1-cavm-custom-global-tags", "awsi-t-1-cavm-applytagslambda", "awsi-t-1-cavm-service-catalog-lambda-role", "awsi-t-1-cavm-master-basic-account-setup-$WLAccountID");
}
Write-host " "
$stacks["NetworkDeployMentRole"].foreach({aws cloudformation delete-stack --stack-name $_ 
Add-Content ".\$WLname.md" "Deleted $_"
Write-host "Deleting Stack $_" -ForegroundColor Green
})
$stacks["AVM_VPC_PL_Resources_WL"].foreach({aws cloudformation delete-stack --stack-name $_
 Add-Content ".\$WLname.md" "Deleted $_" 
Write-host "Deleting Stack $_" -ForegroundColor Green
})
$stacks["AVM_IAM_PL_Resources_WL"].foreach({aws cloudformation delete-stack --stack-name $_
 Add-Content ".\$WLname.md" "Deleted $_"
 Write-host "Deleting Stack $_" -ForegroundColor Green
 })
$stacks["AVM_Monitor_PL_Resources_WL"].foreach({aws cloudformation delete-stack --stack-name $_
 Add-Content ".\$WLname.md" "Deleted $_"
 Write-host "Deleting Stack $_" -ForegroundColor Green
})
$stacks["VPC_pipeline_AVM"].foreach({aws cloudformation delete-stack --stack-name $_
Add-Content ".\$WLname.md" "Deleted $_"
Write-host "Deleting Stack $_" -ForegroundColor Green
})
$stacks["Monitor_pipeline_AVM"].foreach({aws cloudformation delete-stack --stack-name $_
Add-Content ".\$WLname.md" "Deleted $_"
Write-host "Deleting Stack $_" -ForegroundColor Green
})
$stacks["IAM_Pipeline_AVM"].foreach({aws cloudformation delete-stack --stack-name $_
Add-Content ".\$WLname.md" "Deleted $_"
Write-host "Deleting Stack $_" -ForegroundColor Green
})
$stacks["Master_pipeline_AVM"].foreach({aws cloudformation delete-stack --stack-name $_
Add-Content ".\$WLname.md" "Deleted $_"
Write-host "Deleting Stack $_" -ForegroundColor Green
})
Write-host "$($WLname.ToUpper()) is decommissioned" -ForegroundColor Green
Add-Content ".\$WLname.md" "*********************$WLname account is decommissioned***********************"
