import-Module .\AWS-Connect.psm1
AWS-Connect -Profile 'Mytest' -AccountId "$(read-Host "Enter AccountId")"
$WLAccountID = aws sts get-caller-identity --query [Account] --no-verify-ssl| convertfrom-json
$BUAccountID = aws ec2 describe-subnets --query "Subnets[0].[OwnerId]"
$WLname = aws iam list-account-aliases --no-verify-ssl --query AccountAliases --no-verify-ssl | convertfrom-json

$FileName = ".\$WLname.md"
if(Test-Path $FileName) { Remove-Item $FileName}
[hashtable]$Stacks = [ordered]@{
    NetworkDeployMentRole = @("awsi-t-1-cavm-network-prereq-role");
    AVM_VPC_PL_Resources_WL = @("awsi-t-1-cavm-customresource-deletedefaultvpc", "awsi-t-1-cavm-vpc-delete-default-all-regions", "awsi-t-1-cavm-infra-account-roles-$WLAccountID" , "awsi-t-1-cavm-vpc-prereq-roles");
    AVM_IAM_PL_Resources_WL = @("awsi-t-1-cavm-iam-baseline-roles-setup", "awsi-t-1-cavm-iam-managed-policy-setup", "awsi-t-1-cavm-iam-deployment-roles", "awsi-t-1-cavm-iam-custom-roles-setup");
    AVM_Monitor_PL_Resources_WL = @("awsi-t-1-cavm-guard-duty-setup", "awsi-t-1-cavm-guard-duty-lambda", "awsi-t-1-cavm-guardduty-crossaccount-role-$WLAccountID", "awsi-t-1-cavm-config-rule-required-tags", "awsi-t-1-cavm-config-rules", "awsi-t-1-cavm-splunk-cross-account-role", "awsi-t-1-cavm-qualys-connector", "awsi-t-1-cavm-prismacloud", "awsi-t-1-cavm-redlock", "awsi-t-1-cavm-metric-filter-alarm", "awsi-t-1-cavm-s3-access-logging-bucket", "awsi-t-1-cavm-config-child-setup", "awsi-t-1-cavm-cloudtrail-child-setup", "awsi-t-1-cavm-logging-deployment-roles");
    VPC_pipeline_AVM = @("awsi-t-1-cavm-vpc-pipeline-$WLAccountID");
    Monitor_pipeline_AVM = @("awsi-t-1-cavm-monitor-pipeline-$WLAccountID");
    IAM_Pipeline_AVM = @("awsi-t-1-cavm-iam-baseline-pipeline-$WLAccountID");
    Master_pipeline_AVM = @("awsi-t-1-cavm-master-basic-account-setup-$WLAccountID", "awsi-t-1-cavm-applytagslambda", "awsi-t-1-cavm-custom-global-tags", "awsi-t-1-cavm-service-catalog-lambda-role");
}
$stacks["NetworkDeployMentRole"].foreach({aws cloudformation create-stack --stack-name $_ --template-body file://stack_empty.yaml })
$stacks["AVM_VPC_PL_Resources_WL"].foreach({aws cloudformation create-stack --stack-name $_ --template-body file://stack_empty.yaml })
$stacks["AVM_IAM_PL_Resources_WL"].foreach({aws cloudformation create-stack --stack-name $_ --template-body file://stack_empty.yaml })
$stacks["AVM_Monitor_PL_Resources_WL"].foreach({aws cloudformation create-stack --stack-name $_ --template-body file://stack_empty.yaml })
$stacks["VPC_pipeline_AVM"].foreach({aws cloudformation create-stack --stack-name $_ --template-body file://stack_empty.yaml })
$stacks["Monitor_pipeline_AVM"].foreach({aws cloudformation create-stack --stack-name $_ --template-body file://stack_empty.yaml })
$stacks["IAM_Pipeline_AVM"].foreach({aws cloudformation create-stack --stack-name $_ --template-body file://stack_empty.yaml })
$stacks["Master_pipeline_AVM"].foreach({aws cloudformation create-stack --stack-name $_ --template-body file://stack_empty.yaml })

