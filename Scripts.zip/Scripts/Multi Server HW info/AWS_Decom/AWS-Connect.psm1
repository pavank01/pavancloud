<#
.Synopsis
   Custom script to login to AWS
#>
function AWS-Connect
{
    [CmdletBinding()]
    Param
    (
        # Param1 help description
        [Parameter(Mandatory=$true, 
                   ValueFromPipeline=$true,
                   ValueFromPipelineByPropertyName=$true, 
                   ValueFromRemainingArguments=$false, 
                   Position=0
                   )]
        [ValidateNotNullOrEmpty()]
		[ValidateSet("Mytest","XACCProd", "XACCNonProd", "XACCProdReader", "XACCNonReader", "AVMProgrammatic", "XACCNonProd-cloudops", "XACCProd-cloudops")]
        [Alias("P")] 
        $Profile,

        # Param2 help description
        $AccountId,
	# Param2 help description
        $Region = "us-west-2"
	)
Process
    {
        aws-azure-login --profile $profile
        $Env:AWS_DEFAULT_REGION="$Region"
switch ( $profile )
{	
Mytest { 
	Write-Host "Logging into $AccountId" -ForegroundColor Green
	$env:AWS_ACCESS_KEY_ID = "$(aws configure get aws_access_key_id --profile $profile)" 
	$env:AWS_SECRET_ACCESS_KEY = "$(aws configure get profile."$profile".aws_secret_access_key)" 
	$env:AWS_SESSION_TOKEN = "$(aws configure get profile."$profile".aws_session_token)" 
	$j = aws sts assume-role --role-arn arn:aws:iam::"$($AccountId)":role/FirstAm_super-cloud-ops --role-session-name test1 --output json --no-verify-ssl
	$env:AWS_ACCESS_KEY_ID = "$(($j | ConvertFrom-Json).Credentials.AccessKeyId)" 
	$env:AWS_SECRET_ACCESS_KEY = "$(($j | ConvertFrom-Json).Credentials.SecretAccessKey)" 
	$env:AWS_SESSION_TOKEN = "$(($j | ConvertFrom-Json).Credentials.SessionToken)" 
	$a = (aws iam list-account-aliases --no-verify-ssl |convertfrom-json).AccountAliases
	Write-Host "Logged into $($a.ToUpper())" -ForegroundColor Green
    	}
XACCNonProd { 
	Write-Host "Logging into xacc Non-Production Account" -ForegroundColor Green
	$env:AWS_ACCESS_KEY_ID = "$(aws configure get aws_access_key_id --profile $profile)"
	$env:AWS_SECRET_ACCESS_KEY = "$(aws configure get profile."$profile".aws_secret_access_key)"
	$env:AWS_SESSION_TOKEN = "$(aws configure get profile."$profile".aws_session_token)"  
	$j = aws sts assume-role --role-arn arn:aws:iam::"$($AccountId)":role/FirstAm_super-pds --role-session-name test1 --output json --no-verify-ssl
	$env:AWS_ACCESS_KEY_ID = "$(($j | ConvertFrom-Json).Credentials.AccessKeyId)"
	$env:AWS_SECRET_ACCESS_KEY = "$(($j | ConvertFrom-Json).Credentials.SecretAccessKey)"
	$env:AWS_SESSION_TOKEN = "$(($j | ConvertFrom-Json).Credentials.SessionToken)"
	aws iam list-account-aliases --no-verify-ssl
    	}
XACCProd { 
	Write-Host "Logging into xacc Production Account" -ForegroundColor Green
	$env:AWS_ACCESS_KEY_ID = "$(aws configure get aws_access_key_id --profile $profile)"
	$env:AWS_SECRET_ACCESS_KEY = "$(aws configure get profile."$profile".aws_secret_access_key)"
	$env:AWS_SESSION_TOKEN = "$(aws configure get profile."$profile".aws_session_token)"  
	$j = aws sts assume-role --role-arn arn:aws:iam::"$($AccountId)":role/FirstAm_super-pds --role-session-name test1 --output json --no-verify-ssl
	$env:AWS_ACCESS_KEY_ID = "$(($j | ConvertFrom-Json).Credentials.AccessKeyId)"
	$env:AWS_SECRET_ACCESS_KEY = "$(($j | ConvertFrom-Json).Credentials.SecretAccessKey)"
	$env:AWS_SESSION_TOKEN = "$(($j | ConvertFrom-Json).Credentials.SessionToken)"
	aws iam list-account-aliases --no-verify-ssl
    	}
XACCNonReader { 
	Write-Host "Logging into xaccn reader Account" -ForegroundColor Green
	$env:AWS_ACCESS_KEY_ID = "$(aws configure get aws_access_key_id --profile $profile)"
	$env:AWS_SECRET_ACCESS_KEY = "$(aws configure get profile."$profile".aws_secret_access_key)"
	$env:AWS_SESSION_TOKEN = "$(aws configure get profile."$profile".aws_session_token)"
	$j = aws sts assume-role --role-arn arn:aws:iam::"$($AccountId)":role/FirstAm_infrastructure-reader --role-session-name test1 --output json --no-verify-ssl
	$env:AWS_ACCESS_KEY_ID = "$(($j | ConvertFrom-Json).Credentials.AccessKeyId)"
	$env:AWS_SECRET_ACCESS_KEY = "$(($j | ConvertFrom-Json).Credentials.SecretAccessKey)"
	$env:AWS_SESSION_TOKEN = "$(($j | ConvertFrom-Json).Credentials.SessionToken)"
	aws iam list-account-aliases --no-verify-ssl
   	}
XACCProdReader { 
	Write-Host "Logging into xaccn reader Account" -ForegroundColor Green
	$env:AWS_ACCESS_KEY_ID = "$(aws configure get aws_access_key_id --profile $profile)"
	$env:AWS_SECRET_ACCESS_KEY = "$(aws configure get profile."$profile".aws_secret_access_key)"
	$env:AWS_SESSION_TOKEN = "$(aws configure get profile."$profile".aws_session_token)"
	$j = aws sts assume-role --role-arn arn:aws:iam::"$($AccountId)":role/FirstAm_infrastructure-reader --role-session-name test1 --output json --no-verify-ssl
	$env:AWS_ACCESS_KEY_ID = "$(($j | ConvertFrom-Json).Credentials.AccessKeyId)"
	$env:AWS_SECRET_ACCESS_KEY = "$(($j | ConvertFrom-Json).Credentials.SecretAccessKey)"
	$env:AWS_SESSION_TOKEN = "$(($j | ConvertFrom-Json).Credentials.SessionToken)"
	aws iam list-account-aliases --no-verify-ssl
   	}	
    
AVMprogrammatic { 
	Write-Host "Logging into AVM-programmatic Account" -ForegroundColor Green
	$env:AWS_ACCESS_KEY_ID = "$(aws configure get aws_access_key_id --profile $profile)"
	$env:AWS_SECRET_ACCESS_KEY = "$(aws configure get profile."$profile".aws_secret_access_key)"
	$env:AWS_SESSION_TOKEN = "$(aws configure get profile."$profile".aws_session_token)"
	$j = aws sts assume-role --role-arn arn:aws:iam::"$($AccountId)":role/FirstAm_infrastructure-reader --role-session-name test1 --output json --no-verify-ssl
	$env:AWS_ACCESS_KEY_ID = "$(($j | ConvertFrom-Json).Credentials.AccessKeyId)"
	$env:AWS_SECRET_ACCESS_KEY = "$(($j | ConvertFrom-Json).Credentials.SecretAccessKey)"
	$env:AWS_SESSION_TOKEN = "$(($j | ConvertFrom-Json).Credentials.SessionToken)"
	aws iam list-account-aliases --no-verify-ssl
	}
XACCNonProd-cloudops { 
		Write-Host "Logging into $AccountId" -ForegroundColor Green
		$env:AWS_ACCESS_KEY_ID = "$(aws configure get aws_access_key_id --profile $profile)" 
		$env:AWS_SECRET_ACCESS_KEY = "$(aws configure get profile."$profile".aws_secret_access_key)" 
		$env:AWS_SESSION_TOKEN = "$(aws configure get profile."$profile".aws_session_token)" 
		$j = aws sts assume-role --role-arn arn:aws:iam::"$($AccountId)":role/FirstAm_super-cloud-ops --role-session-name test1 --output json --no-verify-ssl
		$env:AWS_ACCESS_KEY_ID = "$(($j | ConvertFrom-Json).Credentials.AccessKeyId)" 
		$env:AWS_SECRET_ACCESS_KEY = "$(($j | ConvertFrom-Json).Credentials.SecretAccessKey)" 
		$env:AWS_SESSION_TOKEN = "$(($j | ConvertFrom-Json).Credentials.SessionToken)" 
		aws iam list-account-aliases --no-verify-ssl
		}
XACCProd-cloudops { 
		Write-Host "Logging into xacc Non-Production role" -ForegroundColor Green
		$env:AWS_ACCESS_KEY_ID = "$(aws configure get aws_access_key_id --profile $profile)" 
		$env:AWS_SECRET_ACCESS_KEY = "$(aws configure get profile."$profile".aws_secret_access_key)" 
		$env:AWS_SESSION_TOKEN = "$(aws configure get profile."$profile".aws_session_token)" 
		$j = aws sts assume-role --role-arn arn:aws:iam::"$($AccountId)":role/FirstAm_super-cloud-ops --role-session-name test1 --output json --no-verify-ssl
		$env:AWS_ACCESS_KEY_ID = "$(($j | ConvertFrom-Json).Credentials.AccessKeyId)" 
		$env:AWS_SECRET_ACCESS_KEY = "$(($j | ConvertFrom-Json).Credentials.SecretAccessKey)" 
		$env:AWS_SESSION_TOKEN = "$(($j | ConvertFrom-Json).Credentials.SessionToken)" 
		aws iam list-account-aliases --no-verify-ssl
		}
	}
    }
}