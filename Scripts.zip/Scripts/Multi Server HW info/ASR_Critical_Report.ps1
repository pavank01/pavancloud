﻿
$Subscription = 'AZUR-P-AzureSub-1' # Enter the Subscription name
Set-AzContext -Subscription $Subscription | Out-Null

    $AllVaults = Get-AzRecoveryServicesVault
    $Obj = @()
    foreach($Vault in $AllVaults){
        Set-AzRecoveryServicesAsrVaultContext -Vault $Vault | Out-Null
            $Fabrics = Get-AzRecoveryServicesAsrFabric
            $drContainers = $Fabrics | foreach ({Get-AzRecoveryServicesAsrProtectionContainer -Fabric $_})
            $s = $drContainers | foreach({Get-AzRecoveryServicesAsrReplicationProtectedItem -ProtectionContainer $_})
    $s | foreach({
    $Obj += [PScustomObject]@{ 
	ServerName 		= "$($_.FriendlyName)"
    VaultName       =  "$((($_.RecoveryServicesProviderId).split('/'))[8])"
    ReplicationHealth    = "$($_.ReplicationHealth)"
	PrimaryLoaction		= "$($_.PrimaryFabricFriendlyName)"
   	PrimaryIPAddress 	= "$($_.NicDetailsList.ipconfigs.StaticIPAddress)"
   	IpType 		= "$($_.NicDetailsList.ipconfigs.IpAddressType)"
	RecoveryLocation	= "$($_.RecoveryFabricFriendlyName)"
   	RecoveryIPAddress = "$($_.NicDetailsList.ipconfigs.RecoveryStaticIPAddress)"
   	RecoveryIPType 	= "$($_.NicDetailsList.ipconfigs.RecoveryIPAddressType)"
   LastRpoCalculatedTime = "$($_.ProviderSpecificDetails.LastRpoCalculatedTime)"
    }
    })

    }
    
    $Obj | Export-Csv -Path C:\ASR_Sub_Report.csv | ft -autosize


