<#
.DESCRIPTION
New-FAAzureStorageContainer.ps1 will create a new storage
container in the specified storage account.

.PARAMETER StorageAccountName
The name of the target storage account.

.PARAMETER StorageContainerName
The name of the new storage container.

.PARAMETER Permission
The permission settings for the newly created storage 
container. The default setting is 'Off'.

.EXAMPLE
.\New-FAAzureStorageContainer.ps1 -StorageAccountName soa1s1azursa1 -StorageContainerName scripts
#>
[CmdletBinding()]
    param (
               
        [Parameter(Mandatory=$True)]
        [string]$StorageAccountName,

        [Parameter(Mandatory=$True)]
        [string]$StorageContainerName,

        [Parameter(Mandatory=$False)]
        [string]$Permission = 'Off'

    )

# Convert the storage container to lower case

$StorageContainerName = $StorageContainerName.ToLower()


# Gather the key and context of the storage account

$Key = Get-AzureStorageKey -StorageAccountName $StorageAccountName

$Context = New-AzureStorageContext -StorageAccountName $StorageAccountName -StorageAccountKey $Key.Primary


# Check to see if the storage container exists. If it does not, it will be created

$StorageContainerStatus = Get-AzureStorageContainer -Name $StorageContainerName -Context $Context -ErrorAction SilentlyContinue

if ($StorageContainerStatus) {

    Write-Warning "$StorageContainerName already exists."

} Else {

    Write-Verbose "Creating storage container $StorageContainerName in storage account $StorageAccountName."

    New-AzureStorageContainer -Name $StorageContainerName -Permission $Permission -Context $Context
}