﻿$Month = (Get-Date).AddMonths(-1).ToString("yyyy-MM")

$BillDownloadName = "AzureBill-$Month.csv"

$BillSummaryName = "AzureBill-$Month-Summary.csv"

$BillHTMLName = "FAAzureBill.htm"

$BillHTMLSourceDir = "E:\Scripts\Billing"

$BillHTMLSourcePath = Join-Path $BillHTMLSourceDir $BillHTMLName

$BillSummaryPath = Join-Path $BillHTMLSourceDir $BillSummaryName

$PathToWebRoot = "C:\inetpub\wwwroot"

$BillParse = .\Parse-AzureBill.ps1 -csvFileName E:\Scripts\Billing\$BillDownloadName |
    Select-Object -Property ApplicationCode,CostType,Cost |
    Sort-Object -Property ApplicationCode
 
sleep -Seconds 300

$BillParse | Export-Csv -Path $BillSummaryPath -NoTypeInformation -Force

$BillParse | ConvertTo-Html -Title "Azure Bill Summary" -CssUri table_format.css -PreContent "<h1>Azure Bill summary by Application and Resource for $Month</h1><p><pre><a href=""/billing/$BillDownloadName"" download>Download full bill</a>     <a href=""/billing/$BillSummaryName"" download>Download summary bill</a></pre></p>" | Out-File -FilePath $BillHTMLSourcePath -Force

Copy-Item -Path $BillHTMLSourcePath -Destination $PathToWebRoot -Force

Copy-Item -Path E:\Scripts\Billing\$BillDownloadName -Destination C:\inetpub\wwwroot\billing -Force

Copy-Item -Path E:\Scripts\Billing\$BillSummaryName -Destination C:\inetpub\wwwroot\billing -Force