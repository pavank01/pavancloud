﻿$Date = (Get-Date).ToString("yyyy-MM-dd")
$Month = (Get-Date).ToString("yyyy-MM")
$LastMonth = (Get-Date).AddMonths(-1).ToString("yyyy-MM")
$BillReportRoot = "E:\Scripts\Billing"
$PathToWebRoot = "C:\inetpub\wwwroot"
$BillingWebRoot = "C:\inetpub\wwwroot\billing"

$LastMonthFullName = "AzureBill-$LastMonth-Full.csv"
$LastMonthFullPath = Join-Path -Path $BillReportRoot -ChildPath $LastMonthFullName

$LastMonthParseName = "AzureBill-$LastMonth-FullParse.csv"
$LastMonthParsePath = Join-Path -Path $BillReportRoot -ChildPath $LastMonthParseName

$SMTPServer = "mail.firstam.com"
$MailFrom = 'FAHQ-DL-SOMCloudTeam@firstam.com'
$MailTo = @("apptio@firstam.com")
$MailCC = @("FAHQ-DL-SOMCloudTeam@firstam.com","mallison@firstam.com","lwarner@firstam.com")
$Subject = "Azure bill for $LastMonth"

# Download last months full bill and save as CSV
$LastMonthFullReport = E:\Scripts\Download-FAAzureBillingData.ps1 -LastMonth -FileName $LastMonthFullPath

# Parse last months full bill
$LastMonthParse = E:\Scripts\Parse-AzureBill.ps1 -csvFileName $LastMonthFullPath |
    Select-Object -Property ApplicationCode,CostType,@{Name='Cost';Expression={[math]::Round($_.Cost,2)}} |
    Sort-Object -Property ApplicationCode,CostType
    
# Save parsed bill as CSV
$LastMonthParse | Export-Csv -Path $LastMonthParsePath -NoTypeInformation -Force

# Convert to HMTL fragment and email to APPTIO
$HTMLFragment = $LastMonthParse | ConvertTo-HTML | Out-String
Send-MailMessage -Attachments $LastMonthParsePath -Body $HTMLFragment -BodyAsHtml -From $MailFrom -To $MailTo -Cc $MailCC -Subject $Subject -SmtpServer $SMTPServer

# Copy last months full bill to web directory
Copy-Item -Path $LastMonthFullPath -Destination $BillingWebRoot -Force

# Copy last months parsed bill to web directory
Copy-Item -Path $LastMonthParsePath -Destination $BillingWebRoot -Force