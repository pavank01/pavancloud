$SQLVersions = @{
	"8.0" = "SQL Server 2000";
	"9.0" = "SQL Server 2005";
	"10.0" = "SQL Server 2008";
	"10.1" = "SQL Server 2008 (SP1)";
	"10.2" = "SQL Server 2008 (SP2)";
	"10.3" = "SQL Server 2008 (SP3)";
	"10.4" = "SQL Server 2008 (SP4)";
	"10.50" = "SQL Server 2008 R2";
	"10.51" = "SQL Server 2008 R2 (SP1)";
	"10.52" = "SQL Server 2008 R2 (SP2)";
	"10.53" = "SQL Server 2008 R2 (SP3)";
	"10.54" = "SQL Server 2008 R2 (SP4)";
	"11.0" = "SQL Server 2012";
	"11.1" = "SQL Server 2012 (SP1)";
	"11.2" = "SQL Server 2012 (SP2)";
	"11.3" = "SQL Server 2012 (SP3)";
	"11.4" = "SQL Server 2012 (SP4)";
	"12.0" = "SQL Server 2014";
	"12.1" = "SQL Server 2014 (SP1)";
	"12.2" = "SQL Server 2014 (SP2)";
	"12.3" = "SQL Server 2014 (SP3)";
	"12.4" = "SQL Server 2014 (SP4)";
	"13.0" = "SQL Server 2016";
	"13.1" = "SQL Server 2016 (SP1)";
	"13.2" = "SQL Server 2016 (SP2)";
	"13.3" = "SQL Server 2016 (SP3)";
	"13.4" = "SQL Server 2016 (SP4)";
	"17.0" = "SQL Server 2017"
}

$ComputerName = (Get-WmiObject Win32_ComputerSystem -Property Name).Name
$InstalledInstances = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server").InstalledInstances
$Instances = @()
ForEach ($InstalledInstance in $InstalledInstances) {
	$TempInstance = @()
	$InstancePath = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL").$InstalledInstance
	$SQLEdition = ((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$InstancePath\Setup").Edition -Replace('Edition\: Core-based Licensing','')).Trim()
	$SQLVersionNumber = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$InstancePath\Setup").PatchLevel
	$SQLVersionArray = $SQLVersionNumber.Split("\.")
	$SQLShortVersion = ("{0}.{1}" -f [Int]$SQLVersionArray[0], [Int]$SQLVersionArray[1])
	If ($SQLVersions.Contains($SQLShortVersion) -eq $True) {
		$SQLVersionName = ("{0} {1}" -f $SQLVersions.($SQLShortVersion), $SQLEdition)
	} Else {
		$SQLVersionName = "Oops!"
	}
	$TcpPort = (Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$InstancePath\MSSQLServer\SuperSocketNetLib\Tcp\IPAll").TcpPort
	If ($TcpPort -gt 0) {
		$Port = [Int]$TcpPort
	} Else {
		$Port = [Int](Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\$InstancePath\MSSQLServer\SuperSocketNetLib\Tcp\IPAll").TcpDynamicPorts
	}
	If ($Port -eq 0) {
		$Port = "N/A"
	}
	$TempInstance += "" | Select-Object @{L="ComputerName";E={$ComputerName}}, @{L="SQLVersionName";E={$SQLVersionName}}, @{L="SQLVersionNumber";E={$SQLVersionNumber}}, @{L="InstanceName";E={$InstalledInstance}}, @{L="InstancePort";E={$Port}}
	$Instances += $TempInstance
}
$Instances | Sort-Object InstanceName

