json_file = inspec.profile.file('output.json')
attributes = JSON.parse(json_file)


# Load rules from BaseRules.json
global_rule_json_file = Dir.glob(".terraform/modules/**/BaseRules.json").first
json = File.read(global_rule_json_file)

global_rules = JSON.parse(json)
global_rules_array = global_rules['securityRules']

control "nsg" do
    title "nsg"
    impact 1.0

    nsgs = attributes['inspec_nsg']['value']

    nsgs.each do |nsg|
        # Test #1 -- Check NSG exists or not
        aznsg = azure_network_security_group(resource_group: nsg['resource_group_name'], name: nsg['name'])
        
        describe aznsg do
            it { should exist }
        end

        # Test #2 -- Compare each NSG rule with standard.
        global_rules_array.each do |tfNsgRule|
          describe aznsg do
            nsgrule = {
              :name                       => tfNsgRule['name'],
              :access                     => tfNsgRule['access'],
              :direction                  => tfNsgRule['direction'],
              :priority                   => tfNsgRule['priority'],
              :protocol                   => tfNsgRule['protocol'],
              :sourcePortRange            => ( tfNsgRule['sourcePortRange'].count          == 1 ? (tfNsgRule['sourcePortRange'].join(","))             : ('') ),
              :sourcePortRanges           => ( tfNsgRule['sourcePortRange'].count          >  1 ? (tfNsgRule['sourcePortRange'].sort)                  : ([]) ),
              :destinationPortRange       => ( tfNsgRule['destinationPortRange'].count     == 1 ? (tfNsgRule['destinationPortRange'].join(","))        : ('') ),
              :destinationPortRanges      => ( tfNsgRule['destinationPortRange'].count     >  1 ? (tfNsgRule['destinationPortRange'].sort)             : ([]) ),
              :sourceAddressPrefix        => ( tfNsgRule['sourceAddressPrefix'].count      == 1 ? (tfNsgRule['sourceAddressPrefix'].join(","))         : ('') ),
              :sourceAddressPrefixes      => ( tfNsgRule['sourceAddressPrefix'].count      >  1 ? (tfNsgRule['sourceAddressPrefix'].sort)              : ([]) ),
              :destinationAddressPrefix   => ( tfNsgRule['destinationAddressPrefix'].count == 1 ? (tfNsgRule['destinationAddressPrefix'].join(","))    : ('') ),
              :destinationAddressPrefixes => ( tfNsgRule['destinationAddressPrefix'].count >  1 ? (tfNsgRule['destinationAddressPrefix'].sort)         : ([]) )
            }

            its('security_rules_raw') { should include nsgrule }
          end
        end

        # Test #3 -- NSG is associated with a subnet.
        describe azure_subnet(resource_id: nsg['subnet_id']) do
            its('nsg') { should eq nsg['name'] }
        end
    end
end
