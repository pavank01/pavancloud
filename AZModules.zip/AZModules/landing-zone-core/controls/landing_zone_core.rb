json_file = inspec.profile.file('output.json')
attributes = JSON.parse(json_file)

control "landing-zone-core" do
    title "Landing Zone Core"
    impact 1.0

    lzs = attributes['inspec_landing_zone_core']['value']

    lzs.each do |lz|
        describe azure_resource_group(name: lz['resource_group_name']) do
            it { should exist }
        end

        describe azure_virtual_network(resource_group: lz['resource_group_name'], name: lz['virtual_network_name']) do
            it { should exist }

            lz['address_space'].each do |space|
                its('address_space') { should include space }
            end

            lz['dns_servers'].each do |dns_server|
                its('dns_servers') { should include dns_server }
            end
        end

        lz["subnets"].each do |pk,pv|
            pv.each do |sk,sv|
                describe azure_subnet(resource_group: lz['resource_group_name'], vnet: lz['virtual_network_name'], name: sv['name']) do
                    it { should exist }
                    its('address_prefix') { should eq sv['address_prefix'] }
                end
            end
        end
    end
end