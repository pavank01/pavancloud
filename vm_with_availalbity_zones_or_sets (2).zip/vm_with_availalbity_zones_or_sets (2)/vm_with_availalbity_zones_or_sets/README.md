Create Azure VM’s in availability zones or sets or neither. 

Also used to create NSG’s/ASG’s and associate to created VM’s or create new VM’s and associate to existing NSG/ASG’s.

Make configuration changes to the following files:
- 1_backend.tf 
- 2_vm.tfvars
- 3_nsg-rules.tf
